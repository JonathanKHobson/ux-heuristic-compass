# UX Heuristics Compass Skill

This folder contains the standalone UX Heuristics Compass skill package. It can be used as a lightweight prompt/reference layer when the full MCP is unavailable, and it can also help a host AI recognize when to route work to the MCP.

Included files:

- `SKILL.md`: the main operating guide.
- `references/`: compact support docs used by the skill.
- `agents/` and `examples/` when present: optional role cards and output examples.
- License, notice, brand, and third-party notice files for redistribution clarity.

This skill is part of the Compass Suite by Jonathan Kyle Hobson. Modified versions should keep attribution and should not imply they are official Compass releases unless explicitly published by Jonathan Kyle Hobson.
