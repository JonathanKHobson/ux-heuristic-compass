# UX Heuristics Compass Claude Plugin

This plugin bundles:

- the UX Heuristics Compass skill instructions
- a plugin-local UXHC MCP server
- `.mcp.json` configuration for that MCP server
- agent role guidance for host-run UX review panels

Use `ux-heuristic-compass-plugin.zip` when a Claude host asks for a
custom plugin package. Use `ux-heuristic-compass-0.1.0.mcpb` when
Claude Desktop asks for a Desktop Extension.

First smoke test after enabling the plugin:

```text
Use UX Heuristics Compass and call get_started.
```

Expected warning: Claude may warn that this plugin includes local
software or MCP access. That is expected. Install only if you trust the
source.
