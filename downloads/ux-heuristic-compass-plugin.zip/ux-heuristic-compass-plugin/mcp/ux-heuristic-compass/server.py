from __future__ import annotations

import argparse
import json
import os
import tempfile
from pathlib import Path
from typing import Any

from ux_heuristic_compass import (
    audit_ux_surface,
    calibrate_ux_sensitivity,
    calibrate_ux_severity,
    compare_ux_audits,
    draft_project_addon_profile,
    generate_ux_audit_report,
    get_agent_run,
    list_heuristics,
    prepare_ux_source,
    quick_scan_ux,
    run_agent_audit,
    run_usability_test,
    save_preferences,
    stress_test_heuristic_finding,
    update_preferences,
    ux_heuristic_overview,
    validate_ux_report_payload,
)
from ux_heuristic_compass.rubric import get_active_checklist_items
from ux_heuristic_compass.state import onboarding_contract


def get_started(topic: str | None = None, audience: str = "both", user_id: str = "local_default") -> dict[str, Any]:
    counts = list_heuristics()["counts"]
    onboarding = onboarding_contract(user_id)
    return {
        "schema_version": "uxhc.get_started.v2",
        "product": "UX Heuristic Compass",
        "first_steps": [
            "Prepare a screenshot, image bundle, or bounded URL list with prepare_ux_source.",
            "Provide checklist_ratings for the active platform and optional profiles.",
            "Run quick_scan_ux for compact triage or audit_ux_surface for the full checklist-level scorecard.",
            "Run validate_ux_report_payload before generating a report.",
            "Use stress_test_heuristic_finding to check whether a single finding is real usability friction or a false positive.",
        ],
        "runtime_contract": {
            "core_heuristics": 10,
            "optional_heuristics": 4,
            "core_items_per_platform": counts["core_items_desktop"],
            "optional_items_per_platform": counts["optional_items_desktop"],
            "dual_platform_all_items": counts["dual_platform_all_items"],
            "score_direction": "100% means every active checklist item scored 0.",
            "canonical_calibration_tool": "calibrate_ux_sensitivity",
            "compatibility_calibration_tool": "calibrate_ux_severity",
        },
        "optional_profile_map": {
            "accessibility": {"heuristic_id": "h11", "description": "Accessibility and ease of access."},
            "inclusion": {"heuristic_id": "h12", "description": "Empathetic engagement and inclusion."},
            "journey": {"heuristic_id": "h13", "description": "Customer journey and satisfaction."},
            "ux_writing": {"heuristic_id": "h14", "description": "UX writing and content design."},
        },
        "profile_aliases": {
            "content_strategy": "ux_writing",
            "content_tone": "ux_writing",
            "ux_content": "ux_writing",
            "content": "ux_writing",
            "microcopy": "ux_writing",
            "copy": "ux_writing",
            "customer_experience": "journey",
            "cx": "journey",
            "empathy": "inclusion",
        },
        "checklist_rating_contract": {
            "required_fields": ["checklist_item_id", "rating", "evidence_refs", "rationale", "confidence"],
            "rating_scale": "0=no issue, 1=minor, 2=moderate, 3=major, 4=catastrophic",
            "example": {
                "checklist_item_id": "h08_d_02",
                "heuristic_id": "h08",
                "platform": "desktop",
                "rating": 3,
                "evidence_refs": ["img-1"],
                "rationale": "The primary action is visible but visually weaker than surrounding content.",
                "confidence": "medium",
            },
        },
        "onboarding_required": onboarding["onboarding_required"],
        "onboarding_status": onboarding["onboarding_status"],
        "onboarding": onboarding,
        "agent_modes": {
            "agent_mode_1": "run_agent_audit = Researcher persona scorecard aggregation. The host embodies the researcher personas and submits scorecards; UXHC aggregates and flags disagreements.",
            "agent_mode_2": "run_usability_test = Bounded usability-test prep/synthetic walkthrough support unless real participant logs are supplied. It is not unbounded autonomous navigation.",
        },
        "behavioral_contracts": {
            "core_audit_first": "The source scope, UX Health Snapshot, checklist-level scorecard, top finding, plain-language read, and one recommendation lead before support flows.",
            "audit_outputs": ["report_readiness_contract", "plain_language_read", "before_using_this_interface", "follow_up_activity", "follow_up_activity_extended", "reasoning_flow_suggestions", "evaluator_bias_advisories", "prioritization_flow"],
            "human_loop": "quick_scan_ux can expose 3 light context questions when context or ratings are missing; audit_ux_surface uses 3 beginning, 3 middle, and 3 final HIL questions when enabled.",
            "reasoning_flows": "Advanced audits use targeted Atlas-adapted imported-static flow cards plus authored UXHC cards as audit-support intelligence; no live Atlas dependency is required.",
            "teaching_activities": "Audit outputs may include a separate follow_up_activity_extended registry of validation activities after the scorecard; draft File-o-Fun sources include facilitation notes.",
            "implementation_inspection": "Optional audit_context lane for AI coding harnesses that can inspect code, rendered previews, or external frontend audit results. It supports evidence gathering but never replaces checklist ratings.",
            "report_design_harness": "Report artifacts use the UXHC static one-page HTML design system. The MCP renderer owns HTML; hosts repair payloads through validation instead of handmaking reports.",
            "finding_review": "stress_test_heuristic_finding returns UX-native false-positive and evaluator-bias checks, not argument-analysis language.",
        },
        "mvp_boundary": {
            "default_rubric": "Nielsen Norman Group 10 usability heuristics plus opt-in optional profiles",
            "excluded_from_baseline": ["donor/conversion checklists", "full crawler", "auth automation", "unbounded autonomous browser-agent navigation"],
            "later_lane": "Curated project-specific heuristic add-ons with provenance.",
        },
        "topic": topic,
        "audience": audience,
        "user_id": user_id,
    }


def _register_mcp_tools() -> Any:
    try:
        from mcp.server.fastmcp import FastMCP
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("The `mcp` package is required to run UX Heuristic Compass as an MCP server.") from exc

    mcp = FastMCP("ux-heuristic-compass")

    @mcp.tool(name="get_started")
    def get_started_tool(topic: str | None = None, audience: str = "both", user_id: str = "local_default") -> dict[str, Any]:
        return get_started(topic=topic, audience=audience, user_id=user_id)

    @mcp.tool(name="ux_heuristic_overview")
    def ux_heuristic_overview_tool(topic: str | None = None, audience: str = "both") -> dict[str, Any]:
        return ux_heuristic_overview(topic=topic, audience=audience)

    @mcp.tool(name="list_heuristics")
    def list_heuristics_tool(include_optional: bool = True, platform: str | None = None, detail_level: str = "summary") -> dict[str, Any]:
        return list_heuristics(include_optional=include_optional, platform=platform, detail_level=detail_level)

    @mcp.tool(name="prepare_ux_source")
    def prepare_ux_source_tool(
        sources: list[str] | str | None = None,
        source_type: str = "auto",
        viewport: str = "desktop",
        task_flow: str | None = None,
        max_pages: int = 3,
        capture_urls: bool = False,
        output_dir: str | None = None,
        render_wait_ms: int | str = 1000,
    ) -> dict[str, Any]:
        return prepare_ux_source(
            sources,
            source_type=source_type,
            viewport=viewport,
            task_flow=task_flow,
            max_pages=max_pages,
            capture_urls=capture_urls,
            output_dir=output_dir,
            render_wait_ms=render_wait_ms,
        )

    @mcp.tool(name="quick_scan_ux")
    def quick_scan_ux_tool(
        prepared_source: dict[str, Any] | None = None,
        sources: list[str] | str | None = None,
        observations: list[Any] | str | None = None,
        checklist_ratings: list[dict[str, Any]] | None = None,
        profiles: list[str] | str | None = None,
        platform: str | None = None,
        goal: str | None = None,
        user_id: str = "local_default",
        hil_enabled: bool | None = None,
        audit_context: dict[str, Any] | None = None,
        optional_profile_mode: str | None = None,
        full_advanced: bool | None = None,
        hil_answers: Any = None,
        host_question_ui_status: str | None = None,
        rating_overrides: Any = None,
        resolved_gate_ids: list[str] | str | None = None,
        output_detail: str = "compact",
    ) -> dict[str, Any]:
        return quick_scan_ux(
            prepared_source,
            sources=sources,
            observations=observations,
            checklist_ratings=checklist_ratings,
            profiles=profiles,
            platform=platform,
            goal=goal,
            user_id=user_id,
            hil_enabled=hil_enabled,
            audit_context=audit_context,
            optional_profile_mode=optional_profile_mode,
            full_advanced=full_advanced,
            hil_answers=hil_answers,
            host_question_ui_status=host_question_ui_status,
            rating_overrides=rating_overrides,
            resolved_gate_ids=resolved_gate_ids,
            output_detail=output_detail,
        )

    @mcp.tool(name="audit_ux_surface")
    def audit_ux_surface_tool(
        prepared_source: dict[str, Any] | None = None,
        sources: list[str] | str | None = None,
        observations: list[Any] | str | None = None,
        checklist_ratings: list[dict[str, Any]] | None = None,
        profiles: list[str] | str | None = None,
        platform: str | None = None,
        goal: str | None = None,
        user_id: str = "local_default",
        hil_enabled: bool | None = None,
        audit_context: dict[str, Any] | None = None,
        optional_profile_mode: str | None = None,
        full_advanced: bool | None = None,
        hil_answers: Any = None,
        host_question_ui_status: str | None = None,
        rating_overrides: Any = None,
        resolved_gate_ids: list[str] | str | None = None,
        output_detail: str = "compact",
    ) -> dict[str, Any]:
        return audit_ux_surface(
            prepared_source,
            sources=sources,
            observations=observations,
            checklist_ratings=checklist_ratings,
            profiles=profiles,
            platform=platform,
            goal=goal,
            user_id=user_id,
            hil_enabled=hil_enabled,
            audit_context=audit_context,
            optional_profile_mode=optional_profile_mode,
            full_advanced=full_advanced,
            hil_answers=hil_answers,
            host_question_ui_status=host_question_ui_status,
            rating_overrides=rating_overrides,
            resolved_gate_ids=resolved_gate_ids,
            output_detail=output_detail,
        )

    @mcp.tool(name="validate_ux_report_payload")
    def validate_ux_report_payload_tool(payload: dict[str, Any]) -> dict[str, Any]:
        return validate_ux_report_payload(payload)

    @mcp.tool(name="generate_ux_audit_report")
    def generate_ux_audit_report_tool(
        payload: dict[str, Any] | None = None,
        payload_path: str | None = None,
        output_path: str | None = None,
        viewer_path: str | None = None,
        include_viewer: bool = True,
        pdf_path: str | None = None,
        include_pdf: bool = False,
        report_title: str | None = None,
        run_visual_qa: bool = False,
    ) -> dict[str, Any]:
        return generate_ux_audit_report(
            payload,
            payload_path=payload_path,
            output_path=output_path,
            viewer_path=viewer_path,
            include_viewer=include_viewer,
            pdf_path=pdf_path,
            include_pdf=include_pdf,
            report_title=report_title,
            run_visual_qa=run_visual_qa,
        )

    @mcp.tool(name="calibrate_ux_sensitivity")
    def calibrate_ux_sensitivity_tool(fixtures: list[dict[str, Any]] | None = None, tolerance: int = 0) -> dict[str, Any]:
        return calibrate_ux_sensitivity(fixtures=fixtures, tolerance=tolerance)

    @mcp.tool(name="calibrate_ux_severity")
    def calibrate_ux_severity_tool(fixtures: list[dict[str, Any]] | None = None, tolerance: int = 0) -> dict[str, Any]:
        return calibrate_ux_severity(fixtures=fixtures, tolerance=tolerance)

    @mcp.tool(name="compare_ux_audits")
    def compare_ux_audits_tool(
        baseline_audit: dict[str, Any],
        candidate_audit: dict[str, Any],
        comparison_mode: str = "saved_audit",
        baseline_label: str = "baseline",
        candidate_label: str = "candidate",
        severity_tolerance: int = 0,
    ) -> dict[str, Any]:
        return compare_ux_audits(
            baseline_audit,
            candidate_audit,
            comparison_mode=comparison_mode,
            baseline_label=baseline_label,
            candidate_label=candidate_label,
            severity_tolerance=severity_tolerance,
        )

    @mcp.tool(name="draft_project_addon_profile")
    def draft_project_addon_profile_tool(
        project_name: str | None = None,
        product_type: str | None = None,
        audience: str | None = None,
        tasks: list[str] | str | None = None,
        constraints: list[str] | str | None = None,
        competitive_references: list[str] | str | None = None,
        proposed_criteria: list[str] | str | None = None,
    ) -> dict[str, Any]:
        return draft_project_addon_profile(
            project_name=project_name,
            product_type=product_type,
            audience=audience,
            tasks=tasks,
            constraints=constraints,
            competitive_references=competitive_references,
            proposed_criteria=proposed_criteria,
        )

    @mcp.tool(name="save_preferences")
    def save_preferences_tool(
        user_id: str = "local_default",
        ux_level: str | None = None,
        hil_default: str | None = None,
        agent_default: str | None = None,
        platform_default: str | None = None,
        optional_profiles: list[str] | str | None = None,
    ) -> dict[str, Any]:
        return save_preferences(
            user_id=user_id,
            ux_level=ux_level,
            hil_default=hil_default,
            agent_default=agent_default,
            platform_default=platform_default,
            optional_profiles=optional_profiles,
        )

    @mcp.tool(name="update_preferences")
    def update_preferences_tool(
        user_id: str = "local_default",
        ux_level: str | None = None,
        hil_default: str | None = None,
        agent_default: str | None = None,
        platform_default: str | None = None,
        optional_profiles: list[str] | str | None = None,
    ) -> dict[str, Any]:
        return update_preferences(
            user_id=user_id,
            ux_level=ux_level,
            hil_default=hil_default,
            agent_default=agent_default,
            platform_default=platform_default,
            optional_profiles=optional_profiles,
        )

    @mcp.tool(name="run_agent_audit")
    def run_agent_audit_tool(
        audit_session: dict[str, Any] | None = None,
        source_manifest: dict[str, Any] | None = None,
        per_agent_scorecards: list[dict[str, Any]] | None = None,
        personas: list[Any] | None = None,
        platform: str = "desktop",
        profiles: list[str] | str | None = None,
    ) -> dict[str, Any]:
        return run_agent_audit(
            audit_session=audit_session,
            source_manifest=source_manifest,
            per_agent_scorecards=per_agent_scorecards,
            personas=personas,
            platform=platform,
            profiles=profiles,
        )

    @mcp.tool(name="get_agent_run")
    def get_agent_run_tool(agent_run_id: str) -> dict[str, Any]:
        return get_agent_run(agent_run_id)

    @mcp.tool(name="run_usability_test")
    def run_usability_test_tool(
        target_audience: str,
        task_scope: list[str] | str,
        source_or_url: list[str] | str | None = None,
        prepared_source: dict[str, Any] | None = None,
        platform: str = "desktop",
        safety_policy: dict[str, Any] | None = None,
        personas: list[dict[str, Any]] | None = None,
        output_dir: str | None = None,
    ) -> dict[str, Any]:
        return run_usability_test(
            target_audience=target_audience,
            task_scope=task_scope,
            source_or_url=source_or_url,
            prepared_source=prepared_source,
            platform=platform,
            safety_policy=safety_policy,
            personas=personas,
            output_dir=output_dir,
        )

    @mcp.tool(name="stress_test_heuristic_finding")
    def stress_test_heuristic_finding_tool(
        checklist_item_id: str,
        rating: float,
        rationale: str,
        platform: str | None = None,
        evidence_refs: list[str] | str | None = None,
    ) -> dict[str, Any]:
        return stress_test_heuristic_finding(
            checklist_item_id=checklist_item_id,
            rating=rating,
            rationale=rationale,
            platform=platform,
            evidence_refs=evidence_refs,
        )

    return mcp


def _sample_ratings(platform: str = "desktop", profiles: list[str] | None = None) -> list[dict[str, Any]]:
    ratings = []
    for item in get_active_checklist_items(platform, profiles=profiles):
        score = 0
        if item["id"].endswith("_02") and item["heuristic_id"] in {"h01", "h08"}:
            score = 3
        elif item["id"].endswith("_03") and item["heuristic_id"] in {"h04"}:
            score = 2
        ratings.append(
            {
                "checklist_item_id": item["id"],
                "rating": score,
                "evidence_refs": ["img-1"],
                "rationale": "Self-test checklist rating." if score else "No visible issue in self-test fixture.",
                "confidence": "medium",
            }
        )
    return ratings


def _self_test() -> dict[str, Any]:
    previous_state = os.environ.get("UXHC_STATE_DIR")
    with tempfile.TemporaryDirectory() as tmpdir:
        os.environ["UXHC_STATE_DIR"] = str(Path(tmpdir) / "state")
        screenshot = Path(tmpdir) / "example-home.png"
        screenshot.write_bytes(b"ux heuristic compass smoke fixture")
        prepared = prepare_ux_source([str(screenshot)], visible_text_summaries=["Home page with hidden primary action"])
        ratings = _sample_ratings("desktop", profiles=["accessibility"])
        audit = audit_ux_surface(prepared, checklist_ratings=ratings, profiles=["accessibility"], platform="desktop")
        validation = validate_ux_report_payload(audit)
        calibration = calibrate_ux_sensitivity()
        comparison = compare_ux_audits(audit, audit)
        prefs = save_preferences(
            ux_level="practitioner",
            hil_default="ai_decides",
            agent_default="ask_each_time",
            platform_default="desktop",
            optional_profiles=["accessibility"],
        )
        agent_scorecards = [
            {"agent_id": "agent_a", "checklist_ratings": ratings},
            {"agent_id": "agent_b", "checklist_ratings": [{**row, "rating": min(4, row["rating"] + (1 if row["rating"] else 0))} for row in ratings]},
            {"agent_id": "agent_c", "checklist_ratings": ratings},
        ]
        agent = run_agent_audit(audit_session=audit, source_manifest=prepared, per_agent_scorecards=agent_scorecards, platform="desktop", profiles=["accessibility"])
        retrieved = get_agent_run(agent["agent_run_id"]) if agent.get("agent_run_id") else {"status": "error"}
        usability = run_usability_test(
            target_audience="startup product managers",
            task_scope="Review the home page",
            prepared_source=prepared,
            platform="desktop",
        )
        stress = stress_test_heuristic_finding(
            checklist_item_id="h08_d_02",
            rating=3,
            rationale="Primary action is present but not visually dominant in the fixture.",
            platform="desktop",
            evidence_refs=["img-1"],
        )
        addon = draft_project_addon_profile(
            project_name="Self-test product",
            audience="first-time evaluators",
            tasks=["complete the primary task"],
        )
    if previous_state is None:
        os.environ.pop("UXHC_STATE_DIR", None)
    else:
        os.environ["UXHC_STATE_DIR"] = previous_state
    return {
        "core_tool_count": 8,
        "tool_count": 18,
        "rubric_heuristic_count": list_heuristics()["counts"]["heuristics"],
        "dual_platform_all_items": list_heuristics()["counts"]["dual_platform_all_items"],
        "prepared_status": prepared["status"],
        "audit_display_state": audit["ux_health_snapshot"]["display_state"],
        "validation_status": validation["qa_status"],
        "calibration_status": calibration["calibration_status"],
        "comparison_mode": comparison["comparison_mode"],
        "preferences_status": prefs["status"],
        "agent_status": agent["status"],
        "agent_retrieval_status": retrieved["status"],
        "usability_status": usability["status"],
        "stress_test_status": stress["status"],
        "addon_status": addon["status"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="UX Heuristic Compass MCP server.")
    parser.add_argument("--self-test", action="store_true", help="Run a direct runtime smoke test and exit.")
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(_self_test(), indent=2, sort_keys=True))
        return 0
    mcp = _register_mcp_tools()
    mcp.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
