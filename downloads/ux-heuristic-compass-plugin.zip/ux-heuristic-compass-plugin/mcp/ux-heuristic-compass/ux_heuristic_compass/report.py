from __future__ import annotations

from datetime import datetime
from html import escape
import json
import os
from pathlib import Path
import textwrap
from typing import Any

from .behavior import REPORT_REQUIRED_FIELDS


REPORT_SCHEMA_VERSION = "uxhc.report.v2"
REPORT_DESIGN_SYSTEM_VERSION = "uxhc.report_design_system.v1"

CONTENT_SLOT_LIMITS: dict[str, dict[str, Any]] = {
    "plain_language_read": {
        "max_chars": 520,
        "max_sentences": 2,
        "repair": "Shorten to one or two nontechnical sentences that name the main UX risk and why it matters.",
    },
    "before_using_this_interface": {
        "max_chars": 420,
        "required_prefix": "Before using this interface,",
        "repair": "Start with the required prefix and keep the warning to one focused sentence.",
    },
    "one_recommendation": {
        "max_chars": 380,
        "repair": "Return one concrete fix or validation action, not a roadmap paragraph.",
    },
    "top_finding.title": {
        "max_chars": 120,
        "repair": "Use a short finding title that names the user-visible problem.",
    },
}

REPORT_HARNESS_HOST_INSTRUCTION = (
    "Repair the payload and retry validate_ux_report_payload or generate_ux_audit_report. "
    "Do not create standalone HTML, PDF, or a handmade report outside the UXHC renderer."
)

DRAFT_TEXT_PATTERNS = ("lorem ipsum", "todo", "tbd", "[placeholder]", "{{", "}}")
HUMAN_PANEL_PHRASES = (
    "blended (ai + human panel)",
    "ai + human panel",
    "human panel only",
    "ai vs human",
    "human evaluator chip",
)
FORBIDDEN_HTML_PATTERNS = ("<script", "<a ", " href=", " src=", "@import", "url(")

REQUIRED_CHECKLIST_RATING_FIELDS = [
    "checklist_item_id",
    "heuristic_id",
    "platform",
    "rating",
    "evidence_refs",
    "rationale",
    "confidence",
]


def validate_ux_report_payload(payload: dict[str, Any]) -> dict[str, Any]:
    missing: list[str] = []
    warnings: list[str] = []
    blocking_issues: list[dict[str, Any]] = []

    if not isinstance(payload, dict):
        return {
            "schema_version": REPORT_SCHEMA_VERSION,
            "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
            "qa_status": "blocked",
            "validation_status": "blocked",
            "missing_report_fields": ["payload"],
            "blocking_issues": [
                _issue(
                    code="payload_not_dictionary",
                    field="payload",
                    message="Report payload must be a dictionary.",
                    repair="Submit the report_ready_payload or payload_path returned by a scored UXHC audit.",
                )
            ],
            "warnings": [],
            "repair_instructions": ["Submit a dictionary payload returned by audit_ux_surface or quick_scan_ux."],
            "content_slot_limits": CONTENT_SLOT_LIMITS,
            "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
            "what_to_resubmit": ["Submit a dictionary payload returned by audit_ux_surface."],
        }

    source = payload.get("source") or {}
    snapshot = payload.get("ux_health_snapshot") or {}
    scorecard = payload.get("scorecard") or {}
    checklist_ratings = payload.get("checklist_ratings") or scorecard.get("checklist_ratings") or []
    heuristic_scores = payload.get("heuristic_scores") or scorecard.get("heuristic_scores") or []

    if not source.get("source_id"):
        missing.append("source.source_id")
    if not source.get("status"):
        missing.append("source.status")
    elif source.get("status") == "blocked":
        missing.append("source.status")
    if not payload.get("platform"):
        missing.append("platform")
    if snapshot.get("display_state") != "scored":
        missing.append("ux_health_snapshot.display_state")
    if scorecard.get("score_status") != "scored":
        missing.append("scorecard.score_status")
    for field in ("core_quality_percentage", "core_grade", "core_descriptor", "overall_quality_percentage", "overall_grade", "overall_descriptor"):
        if scorecard.get(field) in (None, "", []):
            missing.append(f"scorecard.{field}")
    if not heuristic_scores:
        missing.append("heuristic_scores")
    if not checklist_ratings:
        missing.append("checklist_ratings")
    if snapshot.get("display_state") == "scored" or scorecard.get("score_status") == "scored":
        _validate_behavior_fields(payload, missing)

    for idx, rating in enumerate(checklist_ratings, start=1):
        for field in REQUIRED_CHECKLIST_RATING_FIELDS:
            if rating.get(field) in (None, "", []):
                if field == "evidence_refs" and rating.get("evidence_limits"):
                    continue
                missing.append(f"checklist_ratings[{idx}].{field}")
        if rating.get("rating") is not None and not (0 <= float(rating["rating"]) <= 4):
            missing.append(f"checklist_ratings[{idx}].rating")

    if any(profile in {"donor", "conversion", "donation", "fundraising"} for profile in (payload.get("profiles", {}).get("accepted") or [])):
        missing.append("profiles.accepted")
        warnings.append("Donor/conversion profiles are excluded from the baseline product.")

    content_missing, content_issues = _validate_content_slots(payload)
    missing.extend(content_missing)
    blocking_issues.extend(_blocking_issues_from_missing(missing))
    blocking_issues.extend(content_issues)

    status = "ready" if not blocking_issues else "blocked"
    repair_instructions = _repair_instructions(missing, blocking_issues)
    return {
        "schema_version": REPORT_SCHEMA_VERSION,
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": status,
        "validation_status": status,
        "missing_report_fields": missing,
        "blocking_issues": blocking_issues,
        "warnings": warnings,
        "repair_instructions": repair_instructions,
        "content_slot_limits": CONTENT_SLOT_LIMITS,
        "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION if status == "blocked" else "Payload is ready for the UXHC renderer.",
        "what_to_resubmit": repair_instructions,
    }


def _validate_behavior_fields(payload: dict[str, Any], missing: list[str]) -> None:
    for field in REPORT_REQUIRED_FIELDS:
        if field in {"heuristic_scores", "checklist_ratings", "evidence_limits"}:
            continue
        if payload.get(field) in (None, "", []):
            missing.append(field)
    plain_read = str(payload.get("plain_language_read") or "").strip()
    if plain_read and _sentence_count(plain_read) > 2:
        missing.append("plain_language_read.max_2_sentences")
    before = str(payload.get("before_using_this_interface") or "")
    if before and not before.startswith("Before using this interface,"):
        missing.append("before_using_this_interface.prefix")
    contract = payload.get("report_readiness_contract") or {}
    if not contract:
        missing.append("report_readiness_contract")
    elif contract.get("status") != "ready":
        missing.append("report_readiness_contract.status")


def _issue(*, code: str, field: str, message: str, repair: str) -> dict[str, str]:
    return {"code": code, "field": field, "message": message, "repair_instruction": repair}


def _get_path(payload: dict[str, Any], dotted_path: str) -> Any:
    value: Any = payload
    for part in dotted_path.split("."):
        if not isinstance(value, dict):
            return None
        value = value.get(part)
    return value


def _payload_has_human_panel(payload: dict[str, Any]) -> bool:
    return bool(
        payload.get("human_panel")
        or payload.get("human_evaluators")
        or payload.get("human_panel_scores")
        or payload.get("blended_scorecard")
    )


def _scan_text_fields(payload: dict[str, Any]) -> list[tuple[str, str]]:
    fields = [
        "plain_language_read",
        "before_using_this_interface",
        "one_recommendation",
        "top_finding.title",
        "top_finding.observed_issue",
        "top_finding.recommendation",
    ]
    rows: list[tuple[str, str]] = []
    for field in fields:
        value = _get_path(payload, field) if "." in field else payload.get(field)
        if isinstance(value, str) and value.strip():
            rows.append((field, value))
    for idx, finding in enumerate(payload.get("findings") or [], start=1):
        if not isinstance(finding, dict):
            continue
        for key in ["title", "observed_issue", "recommendation", "user_impact"]:
            value = finding.get(key)
            if isinstance(value, str) and value.strip():
                rows.append((f"findings[{idx}].{key}", value))
    return rows


def _validate_content_slots(payload: dict[str, Any]) -> tuple[list[str], list[dict[str, Any]]]:
    missing: list[str] = []
    issues: list[dict[str, Any]] = []
    for field, limit in CONTENT_SLOT_LIMITS.items():
        value = _get_path(payload, field) if "." in field else payload.get(field)
        if not isinstance(value, str) or not value.strip():
            continue
        max_chars = int(limit.get("max_chars") or 0)
        if max_chars and len(value.strip()) > max_chars:
            missing.append(f"{field}.max_{max_chars}_chars")
            issues.append(
                _issue(
                    code="content_slot_too_long",
                    field=field,
                    message=f"{field} is {len(value.strip())} characters; limit is {max_chars}.",
                    repair=str(limit.get("repair") or "Shorten this content slot."),
                )
            )
    for field, value in _scan_text_fields(payload):
        lower = value.lower()
        if any(pattern in lower for pattern in DRAFT_TEXT_PATTERNS):
            missing.append(f"{field}.placeholder_text")
            issues.append(
                _issue(
                    code="placeholder_text",
                    field=field,
                    message="Report content contains placeholder text.",
                    repair="Replace placeholder text with evidence-bound report copy or omit the optional section.",
                )
            )
        if not _payload_has_human_panel(payload) and any(phrase in lower for phrase in HUMAN_PANEL_PHRASES):
            missing.append(f"{field}.human_panel_language")
            issues.append(
                _issue(
                    code="human_panel_language_without_data",
                    field=field,
                    message="Human-panel or blended-score language appeared without explicit human-panel payload data.",
                    repair="Use AI-only audit language unless the payload explicitly includes human-panel data.",
                )
            )
    return missing, issues


def _blocking_issues_from_missing(missing: list[str]) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for field in missing:
        if ".max_" in field or field.endswith(".placeholder_text") or field.endswith(".human_panel_language"):
            continue
        if field.endswith(".prefix"):
            repair = "Start before_using_this_interface exactly with 'Before using this interface,'."
            code = "invalid_prefix"
        elif field.endswith(".status"):
            repair = "Use the scored audit report_ready_payload after report_readiness_contract.status is ready."
            code = "invalid_status"
        elif field.startswith("checklist_ratings"):
            repair = "Use the checklist_ratings returned by UXHC scoring with checklist_item_id, rating, evidence_refs or evidence_limits, rationale, and confidence."
            code = "invalid_checklist_rating"
        else:
            repair = "Use report_ready_payload or repair the named field before generating the report."
            code = "missing_report_field"
        issues.append(_issue(code=code, field=field, message=f"Report payload is missing or invalid: {field}.", repair=repair))
    return issues


def _repair_instructions(missing: list[str], blocking_issues: list[dict[str, Any]]) -> list[str]:
    instructions = _what_to_resubmit(missing)
    for issue in blocking_issues:
        repair = str(issue.get("repair_instruction") or "").strip()
        if repair and repair not in instructions:
            instructions.append(repair)
    if blocking_issues and REPORT_HARNESS_HOST_INSTRUCTION not in instructions:
        instructions.append(REPORT_HARNESS_HOST_INSTRUCTION)
    return instructions


def _sentence_count(text: str) -> int:
    stripped = text.strip()
    if not stripped:
        return 0
    count = sum(stripped.count(mark) for mark in [".", "?", "!"])
    return max(1, count)


def _what_to_resubmit(missing: list[str]) -> list[str]:
    if not missing:
        return []
    hints: list[str] = []
    if any(item.startswith("source.") for item in missing):
        hints.append("Run prepare_ux_source with at least one usable screenshot/image or completed capture before generating a report.")
    if any(item.startswith("ux_health_snapshot") or item.startswith("scorecard") or item == "checklist_ratings" for item in missing):
        hints.append("Run audit_ux_surface or quick_scan_ux with complete checklist_ratings for every active checklist item.")
    if any(item.startswith("checklist_ratings") for item in missing):
        hints.append("Each checklist rating needs checklist_item_id, 0-4 rating, rationale, confidence, and evidence_refs or evidence_limits.")
    if "profiles.accepted" in missing:
        hints.append("Remove donor/conversion profile requests from the baseline payload.")
    behavior_fields = {"plain_language_read", "before_using_this_interface", "top_finding", "one_recommendation", "report_readiness_contract"}
    if any(item in behavior_fields or item.startswith("plain_language_read") or item.startswith("before_using_this_interface") or item.startswith("report_readiness_contract") for item in missing):
        hints.append("Resubmit the scored audit payload with report_readiness_contract, plain_language_read, before_using_this_interface, top_finding, and one_recommendation.")
    return hints


def generate_ux_audit_report(
    payload: dict[str, Any] | None = None,
    *,
    payload_path: str | None = None,
    output_path: str | None = None,
    viewer_path: str | None = None,
    include_viewer: bool = True,
    pdf_path: str | None = None,
    include_pdf: bool = False,
    report_title: str | None = None,
    run_visual_qa: bool = False,
) -> dict[str, Any]:
    visual_qa_status: dict[str, Any] = {
        "status": "not_requested",
        "reason": "Optional browser visual QA was not requested in this report call.",
        "browser_handoff_required": bool(run_visual_qa),
    }
    if payload is None and payload_path:
        try:
            payload = json.loads(Path(payload_path).expanduser().read_text(encoding="utf-8"))
        except Exception as exc:
            return {
                "schema_version": REPORT_SCHEMA_VERSION,
                "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
                "qa_status": "blocked",
                "validation_status": "blocked",
                "validation": {
                    "schema_version": REPORT_SCHEMA_VERSION,
                    "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
                    "qa_status": "blocked",
                    "validation_status": "blocked",
                    "missing_report_fields": ["payload_path"],
                    "blocking_issues": [
                        _issue(
                            code="payload_path_unreadable",
                            field="payload_path",
                            message=f"Could not read payload_path: {exc}",
                            repair="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                        )
                    ],
                    "warnings": [f"Could not read payload_path: {exc}"],
                    "repair_instructions": ["Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux."],
                    "content_slot_limits": CONTENT_SLOT_LIMITS,
                    "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
                    "what_to_resubmit": ["Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux."],
                },
                "blocking_issues": [
                    _issue(
                        code="payload_path_unreadable",
                        field="payload_path",
                        message=f"Could not read payload_path: {exc}",
                        repair="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                    )
                ],
                "repair_instructions": ["Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux."],
                "content_slot_limits": CONTENT_SLOT_LIMITS,
                "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
                "visual_qa_status": visual_qa_status,
                "markdown": "",
                "markdown_path": None,
                "viewer_path": None,
                "pdf_path": None,
            }
    payload = payload or {}
    validation = validate_ux_report_payload(payload)
    if validation["qa_status"] != "ready":
        return {
            "schema_version": REPORT_SCHEMA_VERSION,
            "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
            "qa_status": "blocked",
            "validation_status": "blocked",
            "validation": validation,
            "blocking_issues": validation.get("blocking_issues", []),
            "repair_instructions": validation.get("repair_instructions", []),
            "content_slot_limits": CONTENT_SLOT_LIMITS,
            "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
            "visual_qa_status": visual_qa_status,
            "markdown": "",
            "markdown_path": None,
            "viewer_path": None,
            "pdf_path": None,
        }

    markdown = _render_markdown(payload, report_title=report_title)
    viewer_html: str | None = None
    render_validation: dict[str, Any] = {
        "qa_status": "ready",
        "blocking_issues": [],
        "warnings": [],
    }
    if include_viewer and (viewer_path or output_path):
        viewer_html = _render_viewer_html(payload, markdown, report_title=report_title)
        render_validation = _validate_static_html(viewer_html, human_panel_allowed=_payload_has_human_panel(payload))
        if render_validation["qa_status"] != "ready":
            return {
                "schema_version": REPORT_SCHEMA_VERSION,
                "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
                "qa_status": "blocked",
                "validation_status": "blocked",
                "validation": validation,
                "render_validation": render_validation,
                "blocking_issues": render_validation.get("blocking_issues", []),
                "repair_instructions": [issue["repair_instruction"] for issue in render_validation.get("blocking_issues", [])],
                "content_slot_limits": CONTENT_SLOT_LIMITS,
                "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
                "visual_qa_status": visual_qa_status,
                "markdown": "",
                "markdown_path": None,
                "viewer_path": None,
                "pdf_path": None,
            }
    saved_path: str | None = None
    saved_viewer_path: str | None = None
    saved_pdf_path: str | None = None
    pdf_rendering: dict[str, Any] = {"requested": bool(include_pdf), "renderer": None, "fallback_used": False, "file_size_bytes": None, "page_count_estimate": None}
    if output_path:
        path = Path(output_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(markdown, encoding="utf-8")
        saved_path = str(path)
        if include_viewer and not viewer_path:
            viewer_path = str(path.with_suffix(".html"))
        if include_pdf and not pdf_path:
            pdf_path = str(path.with_suffix(".pdf"))
    if include_viewer and viewer_path:
        viewer = Path(viewer_path).expanduser()
        viewer.parent.mkdir(parents=True, exist_ok=True)
        if viewer_html is None:
            viewer_html = _render_viewer_html(payload, markdown, report_title=report_title)
            render_validation = _validate_static_html(viewer_html, human_panel_allowed=_payload_has_human_panel(payload))
        viewer.write_text(viewer_html, encoding="utf-8")
        saved_viewer_path = str(viewer)
    if include_pdf and pdf_path:
        pdf = Path(pdf_path).expanduser()
        pdf.parent.mkdir(parents=True, exist_ok=True)
        pdf_rendering = _render_pdf(markdown, pdf)
        saved_pdf_path = str(pdf)
    if run_visual_qa:
        if saved_viewer_path:
            visual_qa_status = _run_visual_qa(Path(saved_viewer_path))
        else:
            visual_qa_status = {
                "status": "skipped",
                "reason": "No HTML viewer path was generated for visual QA.",
                "browser_handoff_required": False,
            }
    qa_status = "ready_with_warnings" if pdf_rendering.get("fallback_used") else "ready"
    return {
        "schema_version": REPORT_SCHEMA_VERSION,
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": qa_status,
        "validation_status": "ready",
        "validation": validation,
        "render_validation": render_validation,
        "blocking_issues": [],
        "repair_instructions": [],
        "content_slot_limits": CONTENT_SLOT_LIMITS,
        "visual_qa_status": visual_qa_status,
        "markdown": markdown,
        "markdown_path": saved_path,
        "viewer_path": saved_viewer_path,
        "pdf_path": saved_pdf_path,
        "pdf_rendering": pdf_rendering,
    }


def _render_markdown(payload: dict[str, Any], *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Audit Report"
    snapshot = payload.get("ux_health_snapshot") or {}
    source = payload.get("source") or {}
    scorecard = payload.get("scorecard") or {}
    findings = payload.get("findings") or []
    heuristic_scores = payload.get("heuristic_scores") or []
    checklist_ratings = payload.get("checklist_ratings") or []
    evidence_limits = payload.get("evidence_limits") or []
    next_steps = payload.get("next_validation_steps") or []
    activity = payload.get("follow_up_activity") or {}
    extended_activities = payload.get("follow_up_activity_extended") or []
    reasoning_flows = payload.get("reasoning_flow_suggestions") or []
    prioritization = payload.get("prioritization_flow") or {}
    bias_advisories = payload.get("evaluator_bias_advisories") or []
    implementation_contract = payload.get("implementation_inspection_contract") or {}
    implementation_summary = payload.get("implementation_evidence_summary") or {}
    human_loop = payload.get("human_loop_host_action") or {}
    hil_compliance = payload.get("hil_compliance") or {}
    scope_lock = payload.get("audit_scope_lock") or {}

    lines = [
        f"# {title}",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d')}",
        "",
        "## Executive Summary",
        "",
        f"- Platform: {payload.get('platform', '')}",
        f"- Core grade: {scorecard.get('core_grade', '')} ({scorecard.get('core_quality_percentage', '')}%) - {scorecard.get('core_descriptor', '')}",
        f"- Expanded grade: {scorecard.get('expanded_grade') or 'N/A'} ({scorecard.get('expanded_quality_percentage') or 'N/A'}%)",
        f"- Overall label: {snapshot.get('overall_label', '')}",
        f"- Plain-language read: {payload.get('plain_language_read', '')}",
        f"- Before using this interface: {payload.get('before_using_this_interface', '')}",
        f"- Top priority: {snapshot.get('top_priority', '')}",
        f"- One recommendation: {payload.get('one_recommendation', '')}",
        f"- Source status: {source.get('status', '')}",
        "",
        "## Heuristic Grade Table",
        "",
        "| Heuristic | Items | Avg Severity | Quality | Grade |",
        "|---|---:|---:|---:|---|",
    ]
    for score in heuristic_scores:
        lines.append(
            f"| {score.get('heuristic_name', score.get('heuristic_id', ''))} | {score.get('active_item_count', '')} | {score.get('average_item_severity', '')} | {score.get('quality_percentage', '')}% | {score.get('letter_grade', '')} |"
        )

    lines.extend(_scope_section_markdown(scope_lock))

    lines.extend(["", "## Severity Summary", ""])
    counts = snapshot.get("severity_counts") or {}
    if counts:
        for level in ["4", "3", "2", "1", "0"]:
            lines.append(f"- Severity {level}: {counts.get(level, 0)}")
    else:
        lines.append("- No scored findings.")

    lines.extend(["", "## Top Findings", ""])
    if findings:
        for finding in sorted(findings, key=lambda item: (-item.get("severity", 0), item.get("heuristic_name", "")))[:10]:
            lines.extend(
                [
                    f"### {finding.get('title', 'Untitled finding')}",
                    "",
                    f"- Checklist item: {finding.get('checklist_item_id', '')}",
                    f"- Heuristic: {finding.get('heuristic_name', '')}",
                    f"- Severity: {finding.get('severity', '')} - {finding.get('severity_label', '')}",
                    f"- Evidence: {finding.get('evidence_ref', '')}",
                    f"- Confidence: {finding.get('confidence', '')}",
                    f"- Issue: {finding.get('observed_issue', '')}",
                    f"- Recommendation: {finding.get('recommendation', '')}",
                    "",
                ]
            )
    else:
        lines.append("- No checklist items scored above 0.")

    lines.extend(["", "## Checklist Issue Ledger", ""])
    lines.extend(["| Item | Rating | Confidence | Evidence | Rationale |", "|---|---:|---|---|---|"])
    for rating in checklist_ratings:
        if float(rating.get("rating", 0)) <= 0:
            continue
        evidence = ", ".join(rating.get("evidence_refs") or [])
        rationale = str(rating.get("rationale") or "").replace("|", "\\|")
        lines.append(f"| {rating.get('checklist_item_id', '')} | {rating.get('rating', '')} | {rating.get('confidence', '')} | {evidence} | {rationale} |")
    lines.extend(["", "## Complete Checklist Scores", ""])
    lines.extend(_checklist_tables_markdown(checklist_ratings, heuristic_scores))

    lines.extend(["", "## Evidence Limits", ""])
    if evidence_limits:
        for item in evidence_limits:
            if isinstance(item, dict):
                lines.append(f"- {item.get('checklist_item_id', 'source')}: {item.get('reason', '')} ({item.get('confidence_impact', '')})")
            else:
                lines.append(f"- {item}")
    else:
        lines.append("- No major evidence limits were recorded.")

    lines.extend(_evidence_appendix_markdown(payload))

    lines.extend(["", "## Follow-Up Activity", ""])
    if activity.get("try_this_next"):
        _append_activity(lines, "Try This Next", activity["try_this_next"])
        if activity.get("solo_activity"):
            _append_activity(lines, "Solo Activity", activity["solo_activity"])
        if activity.get("group_activity"):
            _append_activity(lines, "Group Activity", activity["group_activity"])
        if activity.get("fit_check"):
            lines.append(f"- Fit check: {activity['fit_check']}")
    else:
        lines.append("- No follow-up activity was generated.")

    if extended_activities:
        lines.extend(["", "## Additional Validation Activities", ""])
        for card in extended_activities:
            _append_activity(lines, card.get("title", "Activity"), card)
            if card.get("facilitation_note"):
                lines.append(f"- Facilitation note: {card['facilitation_note']}")

    lines.extend(["", "## Reasoning Flow Suggestions", ""])
    if reasoning_flows:
        for flow in reasoning_flows:
            lines.extend(
                [
                    f"### {flow.get('title', flow.get('flow_id', 'Reasoning flow'))}",
                    "",
                    f"- Heuristic: {flow.get('heuristic_id', '')}",
                    f"- Use when: {flow.get('use_when', '')}",
                    f"- Source: {flow.get('source', '')}",
                    "- Steps:",
                ]
            )
            lines.extend(f"  - {step}" for step in flow.get("steps") or [])
            if flow.get("facilitation_note"):
                lines.append(f"- Facilitation note: {flow['facilitation_note']}")
            enrichment = flow.get("knowledge_atlas_enrichment") or {}
            if enrichment:
                lines.append(f"- Atlas status: {enrichment.get('status', '')} ({enrichment.get('source_entry_id', '')})")
            lines.append("")
    else:
        lines.append("- No reasoning-flow suggestion was needed for this audit.")

    lines.extend(["", "## Evaluator Bias Advisories", ""])
    if bias_advisories:
        for advisory in bias_advisories:
            lines.append(f"- {advisory.get('name', advisory.get('bias_id', 'Bias advisory'))}: {advisory.get('relevance_note', '')} Mitigation: {advisory.get('mitigation', '')}")
    else:
        lines.append("- No evaluator bias advisory was triggered.")

    lines.extend(["", "## Implementation-Aware Inspection", ""])
    if implementation_contract:
        lines.append(f"- Status: {implementation_contract.get('status', '')}")
        lines.append(f"- Route: {implementation_contract.get('route_id', '')}")
        lines.append(f"- Harness: {implementation_contract.get('ai_coding_harness', '')}")
        lines.append(f"- Purpose: {implementation_contract.get('purpose', '')}")
        lines.append(f"- Score policy: {(implementation_contract.get('external_result_policy') or {}).get('score_policy', '')}")
        if implementation_summary:
            lines.append(f"- Evidence summary status: {implementation_summary.get('status', '')}")
            if implementation_summary.get("score_policy"):
                lines.append(f"- Evidence score policy: {implementation_summary['score_policy']}")
            heuristics = ", ".join(implementation_summary.get("likely_affected_heuristics") or [])
            lines.append(f"- Likely affected heuristics: {heuristics or 'none detected'}")
            for source_item in implementation_summary.get("sources") or []:
                dimensions = ", ".join(source_item.get("matched_dimensions") or [])
                lines.append(f"- {source_item.get('source', 'source')}: {dimensions or 'no matched dimensions'} - {source_item.get('summary', '')}")
            if implementation_summary.get("evidence_limit"):
                lines.append(f"- Evidence limit: {implementation_summary['evidence_limit']}")
        else:
            lines.append("- Evidence summary: no implementation evidence was supplied yet.")
    else:
        lines.append("- Not requested for this audit.")

    lines.extend(["", "## Prioritization Flow", ""])
    if prioritization:
        lines.extend(
            [
                f"### {prioritization.get('title', prioritization.get('flow_id', 'Prioritization flow'))}",
                "",
                f"- Use when: {prioritization.get('use_when', '')}",
                f"- Source: {prioritization.get('source_note', prioritization.get('source', ''))}",
                "- Steps:",
            ]
        )
        lines.extend(f"  - {step}" for step in prioritization.get("steps") or [])
    else:
        lines.append("- Not needed because the overall score is above B.")

    lines.extend(["", "## Human Review", ""])
    if human_loop:
        lines.append(f"- Pause required: {human_loop.get('PAUSE_REQUIRED', False)}")
        lines.append(f"- Stage: {human_loop.get('stage', 'none')}")
        if hil_compliance:
            lines.append(f"- Native question UI status: {hil_compliance.get('host_question_ui_status', 'unknown')}")
            lines.append(f"- HIL blocked until native UI: {hil_compliance.get('HIL_BLOCKED_UNTIL_NATIVE_UI', False)}")
            lines.append(f"- Resolved gates: {', '.join(hil_compliance.get('resolved_gate_ids') or []) or 'none'}")
            lines.append(f"- Unresolved gates: {', '.join(hil_compliance.get('unresolved_gate_ids') or []) or 'none'}")
        questions = human_loop.get("questions_for_user") or []
        if questions:
            lines.append("- Questions:")
            for question in questions:
                lines.append(f"  - {question.get('question_id', '')}: {question.get('question', '')}")
    else:
        lines.append("- No human-loop action was supplied.")

    lines.extend(["", "## Recommended Next Validation", ""])
    if next_steps:
        lines.extend(f"- {item}" for item in next_steps)
    else:
        lines.append("- Re-run the audit after fixes or test the highest-risk task with users.")

    lines.extend(
        [
            "",
            "## Scope Note",
            "",
            "This report is a heuristic evaluation artifact. It does not replace usability testing, analytics, accessibility compliance review, or direct user research.",
        ]
    )
    return "\n".join(lines).strip() + "\n"


def _scope_section_markdown(scope_lock: dict[str, Any]) -> list[str]:
    if not scope_lock:
        return []
    omitted = scope_lock.get("omitted_optional_profiles") or []
    scored = scope_lock.get("scored_optional_profiles") or []
    scored_labels = [f"{item.get('profile')} ({item.get('heuristic_id')})" for item in scored]
    lines = [
        "",
        "## Audit Scope and Omitted Profiles",
        "",
        f"- Scope status: {scope_lock.get('status', '')}",
        f"- Optional profile mode: {scope_lock.get('optional_profile_mode', '')}",
        f"- Full advanced requested: {scope_lock.get('full_advanced_requested', False)}",
        f"- Scored optional profiles: {', '.join(scored_labels) or 'none'}",
    ]
    if omitted:
        lines.append("- Omitted optional profiles:")
        for item in omitted:
            lines.append(f"  - {item.get('profile')} ({item.get('heuristic_id')}): {item.get('heuristic_name')}")
        lines.append(f"- Rerun guidance: {scope_lock.get('rerun_guidance', '')}")
    else:
        lines.append("- Omitted optional profiles: none")
    return lines


def _evidence_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    source = payload.get("source") or {}
    items = {str(item.get("item_id")): item for item in source.get("items") or []}
    rows: list[dict[str, Any]] = []
    for ref in source.get("evidence_refs") or []:
        item_id = str(ref.get("item_id") or ref.get("evidence_ref") or "")
        item = items.get(item_id, {})
        rows.append(
            {
                "evidence_ref": ref.get("evidence_ref") or item_id,
                "label": ref.get("label") or item.get("state_label") or item.get("url") or item.get("input_path") or "",
                "source_type": ref.get("source_type") or item.get("source_type") or "",
                "quality": ref.get("quality") or item.get("quality") or "",
                "screenshot_path": item.get("screenshot_path") or "",
                "input_path": item.get("input_path") or "",
                "url": item.get("url") or "",
                "page_title": item.get("page_title") or "",
                "capture_metadata_path": item.get("capture_metadata_path") or "",
            }
        )
    return rows


def _evidence_appendix_markdown(payload: dict[str, Any]) -> list[str]:
    rows = _evidence_rows(payload)
    lines = ["", "## Evidence Appendix", ""]
    if not rows:
        lines.append("- No evidence references were supplied.")
        return lines
    lines.extend(["| Evidence ref | Source type | Quality | Label/title | Screenshot | Metadata |", "|---|---|---|---|---|---|"])
    for row in rows:
        label = str(row.get("page_title") or row.get("label") or "").replace("|", "\\|")
        screenshot = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "").replace("|", "\\|")
        metadata = str(row.get("capture_metadata_path") or "").replace("|", "\\|")
        lines.append(f"| {row.get('evidence_ref', '')} | {row.get('source_type', '')} | {row.get('quality', '')} | {label} | {screenshot} | {metadata} |")
    return lines


def _append_activity(lines: list[str], label: str, card: dict[str, Any]) -> None:
    lines.extend(
        [
            f"### {label}: {card.get('title', '')}",
            "",
            f"- Why this fits: {card.get('why_this_fits', '')}",
            f"- Content focus: {card.get('content_focus', '')}",
            f"- Thinking focus: {card.get('thinking_focus', '')}",
            f"- Source note: {card.get('source_note', '')}",
            "- Steps:",
        ]
    )
    lines.extend(f"  - {step}" for step in card.get("steps") or [])
    lines.append("")


def _checklist_tables_markdown(checklist_ratings: list[dict[str, Any]], heuristic_scores: list[dict[str, Any]]) -> list[str]:
    if not checklist_ratings:
        return ["- No checklist ratings were supplied."]
    names = {str(score.get("heuristic_id")): str(score.get("heuristic_name") or score.get("heuristic_id")) for score in heuristic_scores}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rating in checklist_ratings:
        grouped.setdefault(str(rating.get("heuristic_id") or "unknown"), []).append(rating)
    lines: list[str] = []
    for heuristic_id, rows in sorted(grouped.items()):
        title = names.get(heuristic_id, heuristic_id)
        lines.extend(
            [
                f"<details>",
                f"<summary>{escape(title)} ({heuristic_id}) - {len(rows)} checklist items</summary>",
                "",
                "| Item | Checklist text | Score | Confidence | Evidence | Rationale |",
                "|---|---|---:|---|---|---|",
            ]
        )
        for row in rows:
            evidence = ", ".join(str(item) for item in row.get("evidence_refs") or [])
            text = str(row.get("checklist_text") or "").replace("|", "\\|")
            rationale = str(row.get("rationale") or "").replace("|", "\\|")
            lines.append(
                f"| {row.get('checklist_item_id', '')} | {text} | {row.get('rating', '')} | {row.get('confidence', '')} | {evidence} | {rationale} |"
            )
        lines.extend(["", "</details>", ""])
    return lines


def _checklist_tables_html(payload: dict[str, Any]) -> str:
    checklist_ratings = payload.get("checklist_ratings") or []
    heuristic_scores = payload.get("heuristic_scores") or []
    if not checklist_ratings:
        return "<p>No checklist ratings were supplied.</p>"
    names = {str(score.get("heuristic_id")): str(score.get("heuristic_name") or score.get("heuristic_id")) for score in heuristic_scores}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rating in checklist_ratings:
        grouped.setdefault(str(rating.get("heuristic_id") or "unknown"), []).append(rating)
    blocks: list[str] = []
    for heuristic_id, rows in sorted(grouped.items()):
        row_html = []
        for row in rows:
            evidence = ", ".join(str(item) for item in row.get("evidence_refs") or [])
            rating_value = float(row.get("rating") or 0)
            state_label = "Passed" if rating_value <= 0 else "Issue"
            if rating_value >= 3:
                state_label = "Major"
            row_html.append(
                f'<tr class="checklist-row checklist-state-{escape(state_label.lower())}">'
                f"<td>{escape(str(row.get('checklist_item_id', '')))}</td>"
                f"<td>{escape(str(row.get('checklist_text', '')))}</td>"
                f"<td><span class=\"score-pill severity-{int(round(rating_value))}\">{escape(str(row.get('rating', '')))}</span></td>"
                f"<td>{escape(state_label)}</td>"
                f"<td>{escape(str(row.get('confidence', '')))}</td>"
                f"<td>{escape(evidence)}</td>"
                f"<td>{escape(str(row.get('rationale', '')))}</td>"
                "</tr>"
            )
        blocks.append(
            f"""
            <details class="checklist-table">
              <summary>{escape(names.get(heuristic_id, heuristic_id))} ({escape(heuristic_id)}) - {len(rows)} checklist items</summary>
              <table>
                <thead><tr><th>Item</th><th>Checklist text</th><th>Score</th><th>Status</th><th>Confidence</th><th>Evidence</th><th>Rationale</th></tr></thead>
                <tbody>{''.join(row_html)}</tbody>
              </table>
            </details>
            """
        )
    legend = """
    <p class="section-intro">All checklist rows are shown. Use the Score and Status columns to scan Passed, Issue, and Major rows without JavaScript filters.</p>
    """
    return legend + "\n".join(blocks)


def _scope_section_html(scope_lock: dict[str, Any]) -> str:
    if not scope_lock:
        return ""
    omitted = scope_lock.get("omitted_optional_profiles") or []
    scored = scope_lock.get("scored_optional_profiles") or []
    scored_text = ", ".join(f"{item.get('profile')} ({item.get('heuristic_id')})" for item in scored) or "none"
    omitted_items = "".join(f"<li>{escape(str(item.get('profile')))} ({escape(str(item.get('heuristic_id')))}): {escape(str(item.get('heuristic_name')))}</li>" for item in omitted)
    omitted_html = f"<ul>{omitted_items}</ul>" if omitted_items else "<p>None</p>"
    return f"""
    <section class="scope-lock">
      <h2>Audit Scope and Omitted Profiles</h2>
      <p><strong>Status:</strong> {escape(str(scope_lock.get('status', '')))}</p>
      <p><strong>Optional profile mode:</strong> {escape(str(scope_lock.get('optional_profile_mode', '')))}</p>
      <p><strong>Scored optional profiles:</strong> {escape(scored_text)}</p>
      <p><strong>Omitted optional profiles:</strong></p>
      {omitted_html}
      <p>{escape(str(scope_lock.get('rerun_guidance', '')))}</p>
    </section>
    """


def _evidence_appendix_html(payload: dict[str, Any]) -> str:
    rows = _evidence_rows(payload)
    if not rows:
        return "<section><h2>Evidence Appendix</h2><p>No evidence references were supplied.</p></section>"
    row_html = []
    for row in rows:
        screenshot = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "")
        metadata = str(row.get("capture_metadata_path") or "")
        row_html.append(
            "<tr>"
            f"<td>{escape(str(row.get('evidence_ref', '')))}</td>"
            f"<td>{escape(str(row.get('source_type', '')))}</td>"
            f"<td>{escape(str(row.get('quality', '')))}</td>"
            f"<td>{escape(str(row.get('page_title') or row.get('label') or ''))}</td>"
            f"<td>{escape(screenshot)}</td>"
            f"<td>{escape(metadata)}</td>"
            "</tr>"
        )
    return f"""
    <section>
      <h2>Evidence Appendix</h2>
      <table>
        <thead><tr><th>Evidence ref</th><th>Source type</th><th>Quality</th><th>Label/title</th><th>Screenshot/source</th><th>Metadata</th></tr></thead>
        <tbody>{''.join(row_html)}</tbody>
      </table>
    </section>
    """


def _validate_static_html(html: str, *, human_panel_allowed: bool = False) -> dict[str, Any]:
    lower = html.lower()
    blocking_issues: list[dict[str, Any]] = []
    for pattern in FORBIDDEN_HTML_PATTERNS:
        if pattern in lower:
            blocking_issues.append(
                _issue(
                    code="forbidden_html_pattern",
                    field="html",
                    message=f"Generated HTML contains forbidden pattern: {pattern}.",
                    repair="Regenerate with the UXHC static no-JS, no-link, no-external-assets renderer.",
                )
            )
    if not human_panel_allowed and any(phrase in lower for phrase in HUMAN_PANEL_PHRASES):
        blocking_issues.append(
            _issue(
                code="human_panel_language_without_data",
                field="html",
                message="Generated HTML contains human-panel language without explicit human-panel payload data.",
                repair="Regenerate the report with AI-only audit language unless human-panel data is present.",
            )
        )
    for section in ["Plain Language Read", "Heuristic Scorecard", "Findings", "Evidence Limits", "Recommended Next Validation Steps"]:
        if section.lower() not in lower:
            blocking_issues.append(
                _issue(
                    code="missing_required_section",
                    field="html",
                    message=f"Generated HTML is missing required section: {section}.",
                    repair="Regenerate the report through the UXHC renderer so required sections appear in order.",
                )
            )
    return {
        "schema_version": "uxhc.report_html_validation.v1",
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": "blocked" if blocking_issues else "ready",
        "blocking_issues": blocking_issues,
        "warnings": [],
        "static_html_policy": {
            "one_page": True,
            "links_allowed": False,
            "external_assets_allowed": False,
            "scripts_allowed": False,
        },
    }


def _grade_color(grade: Any, percentage: Any = None) -> str:
    text = str(grade or "").upper()
    try:
        pct = float(percentage)
    except Exception:
        pct = None
    if text.startswith("A") or (pct is not None and pct >= 80):
        return "#22863a"
    if text.startswith("B+") or (pct is not None and pct >= 75):
        return "#5a7f3e"
    if text.startswith("B") or (pct is not None and pct >= 70):
        return "#7a8c3e"
    if text.startswith("C") or (pct is not None and pct >= 55):
        return "#c96a00"
    return "#cb2431"


def _severity_color(severity: Any) -> str:
    try:
        value = int(round(float(severity)))
    except Exception:
        value = 0
    if value >= 3:
        return "#cb2431" if value == 4 else "#c96a00"
    if value == 2:
        return "#b8860b"
    if value == 1:
        return "#5a7f3e"
    return "#6a737d"


def _severity_word(severity: Any) -> str:
    try:
        value = int(round(float(severity)))
    except Exception:
        value = 0
    if value >= 4:
        return "Critical"
    if value == 3:
        return "Major"
    if value == 2:
        return "Moderate"
    if value == 1:
        return "Minor"
    return "Passed"


def _top_finding_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    top = payload.get("top_finding") or {}
    if top.get("status") == "finding":
        return top
    findings = payload.get("findings") or []
    return findings[0] if findings else top


def _next_research_recommendation(payload: dict[str, Any]) -> str:
    next_steps = payload.get("next_validation_steps") or []
    if next_steps:
        return str(next_steps[0])
    activity = payload.get("follow_up_activity") or {}
    try_this = activity.get("try_this_next") or {}
    if try_this.get("title"):
        return f"Run {try_this['title']} against the top finding before treating the report as confirmed user evidence."
    top = _top_finding_from_payload(payload)
    title = top.get("title") or "the top finding"
    return f"Validate {title} with one focused task walkthrough before committing the fix plan."


def _html_paragraphs(items: list[Any]) -> str:
    if not items:
        return "<p>No entries were supplied.</p>"
    return "".join(f"<p>{escape(str(item))}</p>" for item in items)


def _header_meta(payload: dict[str, Any]) -> str:
    scorecard = payload.get("scorecard") or {}
    source = payload.get("source") or {}
    bits = [
        "AI audit",
        str(payload.get("platform") or "").capitalize(),
        f"{len(source.get('items') or [])} source item(s)",
        f"{scorecard.get('active_checklist_item_count') or len(payload.get('checklist_ratings') or [])} checklist items",
    ]
    hil = payload.get("hil_compliance") or {}
    if hil.get("native_ui_confirmed") or hil.get("host_question_ui_status") in {"native_rendered", "fallback_text_used"}:
        bits.append(f"HIL {hil.get('host_question_ui_status')}")
    return " - ".join(bit for bit in bits if bit)


def _mission_context_html(payload: dict[str, Any]) -> str:
    context = payload.get("audit_context") or {}
    text = (
        context.get("mission_context")
        or context.get("severity_context")
        or context.get("audience_context")
        or "Severity ratings reflect the supplied evidence, user goal, optional-profile scope, and any stated evidence limits. Support flows and activities should never outrank the checklist scorecard."
    )
    return f"""
    <section class="mission-box card">
      <h2>Mission Context</h2>
      <p>{escape(str(text))}</p>
    </section>
    """


def _overall_summary_html(payload: dict[str, Any]) -> str:
    scorecard = payload.get("scorecard") or {}
    grade = scorecard.get("overall_grade") or scorecard.get("core_grade") or ""
    pct = scorecard.get("overall_quality_percentage") or scorecard.get("core_quality_percentage") or ""
    descriptor = scorecard.get("overall_descriptor") or scorecard.get("core_descriptor") or ""
    before = str(payload.get("before_using_this_interface") or "")
    plain_read = str(payload.get("plain_language_read") or "No plain-language read was supplied.")
    return f"""
    <section class="overall-summary" aria-label="Overall audit summary">
      <div class="overall-grade-card">
        <div class="big-grade" style="color:{_grade_color(grade, pct)}">{escape(str(grade))}</div>
        <div class="pct">{escape(str(pct))}%</div>
        <div class="descriptor">{escape(str(descriptor))}</div>
      </div>
      <div class="plain-read">
        <div class="label">Plain Language Read</div>
        <p>{escape(plain_read)}</p>
        <div class="research-recommendation">
          <div class="label">Next Research Recommendation</div>
          <p>{escape(_next_research_recommendation(payload))}</p>
        </div>
        <p class="before">{escape(before)}</p>
      </div>
    </section>
    """


def _top_finding_alert_html(payload: dict[str, Any]) -> str:
    top = _top_finding_from_payload(payload)
    if not top or top.get("status") == "no_scored_findings":
        return """
        <section class="top-finding-alert top-finding-ok">
          <div class="label">Top Finding</div>
          <h3>No checklist items scored above 0</h3>
          <p>Use the evidence limits and validation steps before treating this as a complete usability claim.</p>
        </section>
        """
    title = top.get("title") or "Top UX finding"
    issue = top.get("observed_issue") or top.get("rationale") or top.get("summary") or payload.get("ux_health_snapshot", {}).get("top_priority") or ""
    severity = top.get("severity") or top.get("rating") or ""
    return f"""
    <section class="top-finding-alert">
      <div class="label">{escape(_severity_word(severity))} Finding - Immediate Attention</div>
      <h3>{escape(str(title))}</h3>
      <p>{escape(str(issue))}</p>
    </section>
    """


def _scorecard_html(payload: dict[str, Any]) -> str:
    scores = payload.get("heuristic_scores") or []
    count = len(scores)
    cards = []
    for score in scores:
        grade = score.get("letter_grade") or ""
        pct = score.get("quality_percentage") or ""
        cards.append(
            f"""
            <article class="score-item">
              <div class="grade" style="color:{_grade_color(grade, pct)}">{escape(str(grade))}</div>
              <div class="pct">{escape(str(pct))}% - avg severity {escape(str(score.get('average_item_severity', '')))}</div>
              <div class="name">{escape(str(score.get('heuristic_name') or score.get('heuristic_id') or 'Heuristic'))}</div>
              <div class="desc">{escape(str(score.get('descriptor') or ''))}</div>
            </article>
            """
        )
    return f"""
    <section class="card">
      <h2>Heuristic Scorecard - AI Audit, {count} Heuristics</h2>
      <div class="scorecard-grid">{''.join(cards) or '<p>No heuristic scores were supplied.</p>'}</div>
    </section>
    """


def _findings_html(payload: dict[str, Any]) -> str:
    findings = sorted(payload.get("findings") or [], key=lambda item: (-int(item.get("severity", 0)), item.get("heuristic_name", "")))[:10]
    if not findings:
        return """
        <section class="card">
          <h2>Findings - Prioritized Fix Order</h2>
          <p>No checklist items scored above 0.</p>
        </section>
        """
    blocks = []
    for idx, finding in enumerate(findings, start=1):
        severity = finding.get("severity", 0)
        blocks.append(
            f"""
            <article class="finding" style="border-left-color:{_severity_color(severity)}">
              <div class="finding-header">
                <div class="rank">{idx}</div>
                <div>
                  <div><span class="severity-badge" style="background:{_severity_color(severity)}">{escape(_severity_word(severity))}</span> <span class="heuristic-tag">{escape(str(finding.get('heuristic_name', '')))} - {escape(str(finding.get('checklist_item_id', '')))}</span></div>
                  <h3>{escape(str(finding.get('title', 'Untitled finding')))}</h3>
                </div>
              </div>
              <div class="section"><div class="section-label">Observed Issue</div><div class="section-content">{escape(str(finding.get('observed_issue', '')))}</div></div>
              <div class="section"><div class="section-label">Recommendation</div><div class="section-content">{escape(str(finding.get('recommendation', '')))}</div></div>
              <div class="mission-note">{escape(str(finding.get('user_impact') or 'This finding may increase user friction for the evaluated task.'))}</div>
              <div class="evidence-line">Evidence: {escape(str(finding.get('evidence_ref', '')))} - Confidence: {escape(str(finding.get('confidence', '')))}</div>
            </article>
            """
        )
    return f"""
    <section class="card">
      <h2>Findings - Prioritized Fix Order</h2>
      {''.join(blocks)}
    </section>
    """


def _working_well_html(payload: dict[str, Any]) -> str:
    strong = [score for score in payload.get("heuristic_scores") or [] if float(score.get("quality_percentage") or 0) >= 80][:8]
    if not strong:
        return """
        <section class="card">
          <h2>What Is Working Well</h2>
          <p>No heuristic scored at A- or above in this payload. Use this section after fixes to preserve strengths.</p>
        </section>
        """
    items = "".join(
        f"<li>{escape(str(score.get('heuristic_name') or score.get('heuristic_id')))} holds up with {escape(str(score.get('letter_grade')))} ({escape(str(score.get('quality_percentage')))}%).</li>"
        for score in strong
    )
    return f"""
    <section class="card">
      <h2>What Is Working Well</h2>
      <ul class="strengths-list">{items}</ul>
    </section>
    """


def _evidence_limits_html(payload: dict[str, Any]) -> str:
    limits = payload.get("evidence_limits") or []
    if not limits:
        body = "<p>No major evidence limits were recorded.</p>"
    else:
        rows = []
        for item in limits:
            if isinstance(item, dict):
                rows.append(f"{item.get('checklist_item_id', 'source')}: {item.get('reason', '')} ({item.get('confidence_impact', '')})")
            else:
                rows.append(str(item))
        body = _html_paragraphs(rows)
    return f"""
    <section class="card">
      <h2>Evidence Limits</h2>
      <div class="evidence-box">{body}</div>
    </section>
    """


def _validation_steps_html(payload: dict[str, Any]) -> str:
    steps = list(payload.get("next_validation_steps") or [])
    if not steps:
        steps = ["Re-run the audit after fixes or test the highest-risk task with users."]
    cards = "".join(
        f"""
        <article class="validation-option">
          <div class="option-title">Validation Step {idx}</div>
          <div class="option-copy">{escape(str(step))}</div>
        </article>
        """
        for idx, step in enumerate(steps[:6], start=1)
    )
    return f"""
    <section class="card">
      <h2>Recommended Next Validation Steps</h2>
      <div class="validation-list">{cards}</div>
    </section>
    """


def _roadmap_html(payload: dict[str, Any]) -> str:
    findings = sorted(payload.get("findings") or [], key=lambda item: (-int(item.get("severity", 0)), item.get("heuristic_name", "")))[:12]
    if not findings:
        rows = "<tr><td>Later</td><td>Re-run the audit after evidence improves.</td></tr>"
    else:
        row_items = []
        for finding in findings:
            severity = int(finding.get("severity", 0))
            bucket = "Immediate" if severity >= 4 else "Sprint 1" if severity == 3 else "Sprint 2" if severity == 2 else "Sprint 3"
            row_items.append(
                f"<tr><td><span class=\"sprint-badge\" style=\"background:{_severity_color(severity)}\">{escape(bucket)}</span></td><td>{escape(str(finding.get('recommendation') or finding.get('title') or 'Fix finding'))}</td></tr>"
            )
        rows = "".join(row_items)
    return f"""
    <section class="card">
      <h2>Prioritized Fix Roadmap</h2>
      <table class="roadmap-table">
        <thead><tr><th>When</th><th>Recommended action</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </section>
    """


def _micro_solution_role(heuristic_id: str) -> tuple[str, str]:
    if heuristic_id in {"h01", "h09", "h11"}:
        return "Engineer", "role-engineer"
    if heuristic_id in {"h08", "h12", "h14"}:
        return "Designer", "role-designer"
    return "Both", "role-both"


def _micro_solutions_html(payload: dict[str, Any]) -> str:
    findings = [finding for finding in payload.get("findings") or [] if int(finding.get("severity", 0)) >= 1][:6]
    if not findings:
        rows = "<tr><td>Both</td><td>Keep monitoring the current interface.</td><td>No issue finding</td><td>Maintains quality without inventing work.</td><td><span class=\"effort-pill\">Low</span></td></tr>"
    else:
        row_items = []
        for finding in findings:
            role, role_class = _micro_solution_role(str(finding.get("heuristic_id") or ""))
            effort = "Low-Medium" if role == "Both" else "Low"
            row_items.append(
                f"""
                <tr>
                  <td><span class="role-badge {role_class}">{escape(role)}</span></td>
                  <td>{escape(str(finding.get('recommendation') or finding.get('title') or 'Address the finding.'))}</td>
                  <td>{escape(str(finding.get('heuristic_id', '')))} / {escape(str(finding.get('checklist_item_id', '')))}</td>
                  <td>{escape(str(finding.get('user_impact') or 'Reduces friction in a visible task area.'))}</td>
                  <td><span class="effort-pill">{escape(effort)}</span></td>
                </tr>
                """
            )
        rows = "".join(row_items)
    return f"""
    <section class="card">
      <h2>High-Impact / Low-Effort Micro-Solutions</h2>
      <table class="micro-solution-table">
        <thead><tr><th>Role</th><th>Micro-solution</th><th>Linked finding</th><th>Why high impact</th><th>Estimated effort</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </section>
    """


def _render_viewer_html(payload: dict[str, Any], markdown: str, *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Audit Report"
    snapshot = payload.get("ux_health_snapshot") or {}
    scorecard = payload.get("scorecard") or {}
    scope_html = _scope_section_html(payload.get("audit_scope_lock") or {})
    checklist_html = _checklist_tables_html(payload)
    evidence_html = _evidence_appendix_html(payload)
    grade = scorecard.get("overall_grade") or scorecard.get("core_grade") or ""
    pct = scorecard.get("overall_quality_percentage") or scorecard.get("core_quality_percentage") or ""
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)}</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    :root {{ color-scheme: light; --uxhc-green: #0d6e6e; --ink: #24292e; --muted: #6a737d; --line: #e1e4e8; --soft-line: #f0f0f0; --bg: #f5f6fa; --panel: #ffffff; --warning-bg: #fff8e1; --warning-line: #f9a825; --danger: #cb2431; --major: #c96a00; --medium: #b8860b; --success: #22863a; }}
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--bg); color: var(--ink); line-height: 1.6; }}
    .header {{ background: var(--uxhc-green); color: #ffffff; padding: 40px 48px; }}
    .header h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
    .header .meta {{ font-size: 14px; opacity: 0.86; margin-top: 4px; }}
    .header .grade-badge {{ display: inline-block; background: rgba(255,255,255,0.18); border: 2px solid #ffffff; border-radius: 8px; padding: 8px 20px; font-size: 32px; font-weight: 800; margin-top: 16px; }}
    .container {{ max-width: 1100px; margin: 0 auto; padding: 32px 24px; }}
    .card, .plain-read, .overall-grade-card, .finding, .top-finding-alert, .scope-lock {{ background: var(--panel); border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); border: 1px solid var(--line); }}
    .card, .scope-lock {{ padding: 28px; margin-bottom: 24px; }}
    .card h2, .scope-lock h2 {{ font-size: 18px; font-weight: 700; margin-bottom: 16px; color: var(--uxhc-green); border-bottom: 2px solid var(--line); padding-bottom: 10px; }}
    .mission-box {{ background: var(--warning-bg); border-left: 4px solid var(--warning-line); border-radius: 0 8px 8px 0; }}
    .mission-box h2 {{ color: #6d4c00; border-bottom-color: var(--warning-line); }}
    .mission-box p {{ color: #5d4037; font-size: 14px; }}
    .overall-summary {{ display: flex; gap: 24px; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; }}
    .overall-grade-card {{ padding: 24px 32px; text-align: center; min-width: 160px; align-self: flex-start; }}
    .overall-grade-card .big-grade {{ font-size: 64px; font-weight: 900; line-height: 1; }}
    .overall-grade-card .pct {{ font-size: 20px; font-weight: 600; color: var(--muted); margin-top: 4px; }}
    .overall-grade-card .descriptor {{ font-size: 13px; color: var(--muted); margin-top: 6px; max-width: 180px; }}
    .plain-read {{ padding: 24px; flex: 1; min-width: 300px; }}
    .label {{ font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--muted); margin-bottom: 10px; }}
    .plain-read p {{ font-size: 15px; color: var(--ink); line-height: 1.7; }}
    .plain-read .before {{ font-size: 13px; color: #586069; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--line); font-style: italic; }}
    .research-recommendation {{ background: #ffffff; border-radius: 12px; padding: 20px 24px; border: 1px solid #d0d7de; border-left: 4px solid var(--uxhc-green); margin-top: 16px; }}
    .research-recommendation .label {{ color: var(--uxhc-green); }}
    .research-recommendation p {{ font-size: 14px; }}
    .top-finding-alert {{ background: linear-gradient(135deg, #fff0f0, #fff8f0); border: 2px solid var(--danger); padding: 24px; margin-bottom: 24px; }}
    .top-finding-ok {{ background: #f6f8fa; border-color: var(--line); }}
    .top-finding-alert .label {{ color: var(--danger); }}
    .top-finding-alert h3 {{ font-size: 18px; font-weight: 700; margin-bottom: 8px; }}
    .top-finding-alert p {{ font-size: 14px; color: #444; }}
    .scorecard-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }}
    .score-item {{ border: 1px solid var(--line); border-radius: 8px; padding: 16px; }}
    .score-item .grade {{ font-size: 28px; font-weight: 800; }}
    .score-item .pct {{ font-size: 13px; color: var(--muted); }}
    .score-item .name {{ font-size: 13px; font-weight: 600; margin-top: 4px; }}
    .score-item .desc {{ font-size: 11px; color: var(--muted); margin-top: 2px; }}
    .finding {{ padding: 20px; margin-bottom: 16px; border-left: 4px solid var(--medium); }}
    .finding-header {{ display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; }}
    .rank {{ background: var(--uxhc-green); color: #ffffff; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 13px; flex-shrink: 0; margin-top: 2px; }}
    .severity-badge, .sprint-badge, .role-badge {{ display: inline-block; border-radius: 12px; padding: 3px 10px; font-size: 11px; font-weight: 700; color: #ffffff; white-space: nowrap; }}
    .heuristic-tag {{ font-size: 11px; color: var(--muted); margin-left: 4px; }}
    .finding h3 {{ font-size: 15px; font-weight: 700; margin-top: 4px; }}
    .section {{ margin-top: 10px; }}
    .section-label {{ font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); margin-bottom: 4px; }}
    .section-content {{ font-size: 13px; color: #444; background: #f6f8fa; padding: 10px 12px; border-radius: 6px; }}
    .mission-note {{ font-size: 12px; color: #856404; background: #fff3cd; padding: 8px 10px; border-radius: 6px; margin-top: 8px; border-left: 3px solid var(--warning-line); }}
    .evidence-line {{ margin-top: 8px; font-size: 11px; color: var(--muted); }}
    .strengths-list {{ list-style: none; }}
    .strengths-list li {{ padding: 8px 0; border-bottom: 1px solid var(--soft-line); font-size: 14px; }}
    .evidence-box {{ background: #f6f8fa; border: 1px solid var(--line); border-radius: 6px; padding: 16px; font-size: 13px; color: #586069; }}
    .validation-list {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; }}
    .validation-option {{ border: 1px solid #d0d7de; background: #f6f8fa; border-radius: 8px; padding: 14px; }}
    .option-title {{ font-size: 13px; font-weight: 700; margin-bottom: 4px; }}
    .option-copy {{ font-size: 12px; color: #57606a; line-height: 1.55; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }}
    th {{ text-align: left; padding: 10px 12px; background: #f6f8fa; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); border-bottom: 2px solid var(--line); }}
    td {{ padding: 10px 12px; border-bottom: 1px solid var(--soft-line); font-size: 13px; vertical-align: top; }}
    details {{ margin: 12px 0; }}
    summary {{ cursor: pointer; font-weight: 700; }}
    .section-intro {{ color: var(--muted); font-size: 13px; }}
    .score-pill {{ display: inline-block; min-width: 30px; text-align: center; border-radius: 999px; padding: 2px 8px; color: #ffffff; font-size: 11px; font-weight: 800; background: var(--muted); }}
    .severity-4, .severity-3 {{ background: var(--danger); }}
    .severity-2 {{ background: var(--medium); }}
    .severity-1 {{ background: var(--success); }}
    .severity-0 {{ background: var(--muted); }}
    .role-engineer {{ background: #0969da; }}
    .role-designer {{ background: #8250df; }}
    .role-both {{ background: var(--uxhc-green); }}
    .micro-solution-table th:last-child, .micro-solution-table td:last-child {{ min-width: 118px; white-space: nowrap; }}
    .effort-pill {{ display: inline-block; border: 1px solid #d0d7de; border-radius: 999px; padding: 2px 8px; font-size: 11px; font-weight: 700; color: #57606a; background: #ffffff; white-space: nowrap; }}
    footer {{ background: var(--ink); color: #8b949e; text-align: center; padding: 24px; font-size: 12px; margin-top: 48px; }}
    @media (max-width: 700px) {{ .header {{ padding: 32px 24px; }} .container {{ padding: 24px 16px; }} .scorecard-grid {{ grid-template-columns: 1fr; }} .plain-read {{ min-width: 100%; }} table {{ display: block; overflow-x: auto; }} }}
  </style>
</head>
<body>
  <header class="header">
    <h1>{escape(title)}</h1>
    <div class="meta">{escape(_header_meta(payload))}</div>
    <div class="meta">Generated: {escape(datetime.now().strftime('%Y-%m-%d'))} - UX Heuristic Compass report harness {escape(REPORT_DESIGN_SYSTEM_VERSION)}</div>
    <div class="grade-badge">{escape(str(grade))} - {escape(str(pct))}%</div>
  </header>
  <main class="container">
    {_mission_context_html(payload)}
    {_overall_summary_html(payload)}
    {_top_finding_alert_html(payload)}
    {_scorecard_html(payload)}
    {_findings_html(payload)}
    {_working_well_html(payload)}
    {_evidence_limits_html(payload)}
    {_validation_steps_html(payload)}
    {_roadmap_html(payload)}
    {_micro_solutions_html(payload)}
    {scope_html}
    <section class="card">
      <h2>Complete Checklist Scores</h2>
      {checklist_html}
    </section>
    {evidence_html}
  </main>
  <footer>UX Heuristic Compass - static one-page report - no links, scripts, or external assets.</footer>
</body>
</html>
"""


def _run_visual_qa(viewer_path: Path) -> dict[str, Any]:
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:  # pragma: no cover - optional dependency
        return {
            "status": "unavailable",
            "reason": f"Playwright is not available in this runtime: {exc}",
            "browser_handoff_required": False,
            "checks": [],
        }

    checks: list[dict[str, Any]] = []
    browser = None
    try:  # pragma: no cover - only runs where Playwright is installed
        with sync_playwright() as p:
            browser = p.chromium.launch()
            for label, viewport in {
                "desktop": {"width": 1366, "height": 900},
                "mobile": {"width": 390, "height": 844},
            }.items():
                page = browser.new_page(viewport=viewport)
                page.goto(viewer_path.resolve().as_uri(), wait_until="load")
                body_text = page.locator("body").inner_text(timeout=3000).strip()
                overflow = page.evaluate("document.documentElement.scrollWidth > window.innerWidth + 4")
                checks.append(
                    {
                        "viewport": label,
                        "nonblank": bool(body_text),
                        "horizontal_overflow": bool(overflow),
                    }
                )
                page.close()
            browser.close()
            browser = None
    except Exception as exc:  # pragma: no cover
        try:
            if browser:
                browser.close()
        except Exception:
            pass
        return {
            "status": "failed",
            "reason": str(exc),
            "browser_handoff_required": True,
            "browser_handoff": {"automation_browser_closed": True},
            "checks": checks,
        }
    status = "passed" if checks and all(item["nonblank"] and not item["horizontal_overflow"] for item in checks) else "warnings"
    return {
        "status": status,
        "reason": "" if status == "passed" else "One or more visual QA checks reported blank content or horizontal overflow.",
        "browser_handoff_required": True,
        "browser_handoff": {"automation_browser_closed": True},
        "checks": checks,
    }


def _render_pdf(markdown: str, path: Path) -> dict[str, Any]:
    if os.environ.get("UXHC_FORCE_MINIMAL_PDF") == "1":
        return _render_minimal_pdf(markdown, path, reason="forced_by_environment")
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
    except Exception:  # pragma: no cover
        return _render_minimal_pdf(markdown, path, reason="reportlab_unavailable")

    page_width, page_height = letter
    margin = 54
    line_height = 13
    text_width = int((page_width - margin * 2) / 6.2)
    pdf = canvas.Canvas(str(path), pagesize=letter)
    y = page_height - margin
    page_count = 1

    def draw_line(line: str, *, bold: bool = False) -> None:
        nonlocal y, page_count
        if y < margin:
            pdf.showPage()
            page_count += 1
            y = page_height - margin
        pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 11 if not bold else 13)
        pdf.drawString(margin, y, line[:130])
        y -= line_height + (3 if bold else 0)

    for raw_line in markdown.splitlines():
        if not raw_line.strip():
            y -= line_height / 2
            continue
        if raw_line.startswith("# "):
            draw_line(raw_line[2:].strip(), bold=True)
            continue
        if raw_line.startswith("## "):
            y -= 4
            draw_line(raw_line[3:].strip(), bold=True)
            continue
        if raw_line.startswith("### "):
            draw_line(raw_line[4:].strip(), bold=True)
            continue
        indent = "  " if raw_line.startswith("- ") else ""
        content = raw_line[2:] if raw_line.startswith("- ") else raw_line
        prefix = "- " if raw_line.startswith("- ") else ""
        for wrapped in textwrap.wrap(content, width=text_width) or [""]:
            draw_line(f"{indent}{prefix}{wrapped}")
            prefix = "  " if prefix else ""
    pdf.save()
    return {
        "requested": True,
        "renderer": "reportlab",
        "fallback_used": False,
        "fallback_reason": "",
        "file_size_bytes": path.stat().st_size if path.exists() else None,
        "page_count_estimate": page_count,
    }


def _render_minimal_pdf(markdown: str, path: Path, *, reason: str = "fallback") -> dict[str, Any]:
    """Small dependency-free fallback for smoke environments without reportlab."""
    lines = []
    for raw in markdown.splitlines()[:60]:
        cleaned = raw.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        lines.append(cleaned[:95])
    content_lines = ["BT", "/F1 10 Tf", "54 744 Td"]
    for idx, line in enumerate(lines):
        if idx:
            content_lines.append("0 -13 Td")
        content_lines.append(f"({line}) Tj")
    content_lines.append("ET")
    stream = "\n".join(content_lines).encode("latin-1", errors="replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    output = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for idx, obj in enumerate(objects, start=1):
        offsets.append(len(output))
        output.extend(f"{idx} 0 obj\n".encode("ascii"))
        output.extend(obj)
        output.extend(b"\nendobj\n")
    xref_offset = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    output.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    output.extend(
        f"trailer << /Root 1 0 R /Size {len(objects) + 1} >>\nstartxref\n{xref_offset}\n%%EOF\n".encode("ascii")
    )
    path.write_bytes(bytes(output))
    return {
        "requested": True,
        "renderer": "minimal_pdf_fallback",
        "fallback_used": True,
        "fallback_reason": reason,
        "file_size_bytes": path.stat().st_size if path.exists() else None,
        "page_count_estimate": 1,
    }
