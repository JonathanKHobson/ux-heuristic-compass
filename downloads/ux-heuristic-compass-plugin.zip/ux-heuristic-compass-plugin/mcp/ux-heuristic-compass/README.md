# UX Heuristic Compass

UX Heuristic Compass is a local-first MCP/product for structured checklist-level heuristic UX audits of websites, application screens, screenshots, and bounded page captures.

The product goal is simple: help a reviewer identify visible usability issues, rank them by severity, and turn them into a stakeholder-ready audit report before a design or interface ships.

This repository now contains the planning package plus the full local MCP launch scope: 14 heuristic records, 204 dual-platform checklist items, checklist-level scoring, source preparation, bounded URL capture, audit payload generation, behavioral audit contracts, preferences persistence, Agent Mode 1 aggregation, bounded Agent Mode 2 evidence prep, report validation, Markdown/HTML/PDF report generation, calibration/comparison scaffolds, project-specific add-on scaffolding, tests, and a local stdio MCP server.

## MVP Boundary

UX Heuristic Compass is not a broad UX research platform in the first version. The MVP should audit:

- screenshot or image bundles
- desktop and mobile viewport captures
- bounded URL captures for 1-3 pages or a named task flow

The MVP should not include:

- full-site crawling
- authenticated flows
- autonomous browser-agent navigation
- analytics ingestion
- competitive scraping as a default path
- donor, ecommerce, nonprofit, SaaS, education, or other domain-specific checklists in the baseline rubric

Project-specific heuristic checklists are a later development lane. The north-star version can generate curated add-on checklists from the product type, audience, task, competitive references, and domain constraints, but that should be opt-in and case-by-case.

## Core Audit First Contract

UXHC's center is the heuristic audit, not the support library around it. Every completed audit should lead with the source scope, UX Health Snapshot, checklist-level scorecard, top finding, plain-language read, and one concrete recommendation before it surfaces Atlas cards, teaching activities, bias advisories, or agent frames.

Any new flow, activity, bias advisory, or agent frame must directly support at least one of these purposes:

- better checklist interpretation
- better evidence quality
- better severity or confidence calibration
- better prioritization
- better next-step validation
- better human-in-the-loop teaching

If an addition does not strengthen the bounded interface audit, it belongs in backlog, documentation, or a separate UX research product.

## Core Rubric

The baseline rubric is Nielsen Norman Group's 10 usability heuristics:

1. Visibility of system status
2. Match between system and the real world
3. User control and freedom
4. Consistency and standards
5. Error prevention
6. Recognition rather than recall
7. Flexibility and efficiency of use
8. Aesthetic and minimalist design
9. Help users recognize, diagnose, and recover from errors
10. Help and documentation

Optional general add-on profiles from the supplied HE scorecard:

- `accessibility` -> H11, accessibility and ease of access
- `inclusion` -> H12, empathetic engagement and inclusion
- `journey` -> H13, customer journey and satisfaction
- `ux_writing` -> H14, UX writing and content design

Advanced audits can now state scope explicitly with `optional_profile_mode`: `core_only`, `scoped`, `all_optionals`, or `ask`. The compatibility flag `full_advanced=true` means H1-H14 unless the host/user chooses core-only or a scoped optional subset; if optionals are omitted, the audit returns an `audit_scope_lock` and reports list the omitted profiles.

Explicitly excluded from the baseline:

- donor/conversion checklist
- project-specific nonprofit donation flow checks
- any checklist that only makes sense for one domain or business model

## Local MCP Tool Surface

The MCP server exposes 18 tools:

- `get_started`
- `ux_heuristic_overview`
- `list_heuristics`
- `prepare_ux_source`
- `quick_scan_ux`
- `audit_ux_surface`
- `validate_ux_report_payload`
- `generate_ux_audit_report`
- `calibrate_ux_sensitivity`
- `calibrate_ux_severity`
- `compare_ux_audits`
- `draft_project_addon_profile`
- `save_preferences`
- `stress_test_heuristic_finding`
- `update_preferences`
- `run_agent_audit`
- `get_agent_run`
- `run_usability_test`

The host AI owns conversation, visual interpretation, and user-facing explanation. UX Heuristic Compass owns rubric structure, bounded source manifests, scoring contracts, report readiness, browser-capture hygiene, preferences, local persistence, agent-run aggregation, and artifact generation.

`calibrate_ux_sensitivity` is canonical. `calibrate_ux_severity` remains as a compatibility alias.

`run_agent_audit` is user-facing “Researcher persona scorecard aggregation”: the host embodies the researcher personas and submits scorecards, while UXHC aggregates, flags disagreements, and persists the run. `run_usability_test` is user-facing “Bounded usability-test prep/synthetic walkthrough support” unless real participant logs are supplied; it is not unbounded autonomous navigation and should not be represented as real user evidence by default.

`list_heuristics` now defaults to compact summary output so cold agents can discover the rubric without receiving the full checklist arrays. Use `list_heuristics(detail_level="full")` when the host needs every checklist item inline.

Scored audits return behavioral contracts after the core scorecard:

- `report_readiness_contract`
- `plain_language_read`
- `before_using_this_interface`
- `follow_up_activity`
- `follow_up_activity_extended` with optional validation/teaching activities
- `human_loop_host_action` for Quick Audit context checks and Advanced Audit HIL pauses
- `implementation_inspection_contract` when an AI coding harness/code-aware inspection lane is requested
- `report_harness` metadata inside the report readiness contract, naming the static one-page HTML design-system rules
- `reasoning_flow_suggestions` with targeted Atlas-adapted imported-static flow cards plus authored UXHC cards
- `evaluator_bias_advisories` for anchoring, familiarity, halo, and evaluator-experience calibration risks
- `prioritization_flow` when an overall scored audit is B or below

Optional implementation-aware inspection is available through `audit_context`, not through a new tool. When `implementation_inspection_requested`, `codebase_available`, `implementation_evidence`, or `external_audit_results` is supplied, `quick_scan_ux` and `audit_ux_surface` can return an `implementation_inspection_contract`. This is a route for an AI coding harness such as Codex, Claude Code, Cursor, or a similar local agent to inspect source code, rendered previews, Playwright observations, or external frontend audit results and feed evidence back into the audit. UXHC maps those signals to likely affected heuristics and evidence limits; it does not run third-party audit tools, vendor external skills, or change checklist scores without submitted `checklist_ratings`.

Human-loop responses with `PAUSE_REQUIRED=true` include `host_instruction` and an `ask_user_question_call` payload. Hosts should render those through their native AskUserQuestion/question UI and wait for answers before continuing; they should not flatten required HIL questions into ordinary markdown.

HIL can resume without a separate public tool. `quick_scan_ux` and `audit_ux_surface` accept `hil_answers`, `host_question_ui_status`, `rating_overrides`, and `resolved_gate_ids`; responses include `resolved_gates`, `unresolved_gates`, `hil_compliance`, and `HIL_BLOCKED_UNTIL_NATIVE_UI` so hosts can tell whether native question UI was used, skipped, unavailable, or replaced by text fallback.

The Atlas/activity layer is audit-support intelligence, not the product center: UXHC stores UX-adapted flow cards and source IDs locally, but it does not require a live Knowledge Atlas connection at audit time. File-o-Fun-derived activities are kept separate from reasoning flows; draft-source activities include facilitation notes so hosts do not treat them as fully validated workshop scripts.

`stress_test_heuristic_finding` reviews one heuristic finding for UX fit: alternative explanations, false-positive risk, why the issue likely matters, evidence limits, evaluator bias flags for high-severity ratings, and one concrete fix.

## Planning Package

Start here:

1. `docs/planning/mission-audience-purpose-charter.md`
2. `docs/planning/master-prd.md`
3. `docs/planning/master-roadmap.md`
4. `docs/planning/backlog.md`
5. `docs/planning/source-ingestion-spec.md`
6. `docs/planning/scoring-and-report-contract.md`
7. `docs/planning/evaluation-strategy.md`

Supporting controls:

- `docs/planning/effort-impact-matrix.md`
- `docs/planning/adopt-adapt-reject-matrix.md`
- `docs/planning/file-ownership-and-parallel-work-rules.md`

## Implementation Principle

Clone the proven Critical Compass architecture pattern, not the Critical Compass purpose.

Reuse the infrastructure shape:

- local knowledge base
- deterministic payload builders
- host-facing workflow scaffolds
- report-readiness validation
- Markdown/PDF/local viewer artifacts
- conservative confidence and evidence boundaries

## Bounded URL Capture

`prepare_ux_source(..., capture_urls=True)` can capture up to 3 public URL pages into a local source manifest. It records:

- URL, viewport, page title, and visible text summary
- a screenshot path when a local Chrome capture succeeds
- capture metadata JSON
- a browser handoff status proving no temporary UXHC Chrome profile remains

Browser handoff is scoped to UXHC-owned Chrome processes only: UXHC may inspect or warn about Chrome/Playwright sessions launched by another host, but it must not ask the host to kill Claude-, Codex-, Playwright-MCP-, or other external automation sessions.

V1 URL capture remains deliberately limited: no crawling, no authenticated flows, and no autonomous browser-agent navigation.

If a caller requests more than 3 pages, the response reports both `requested_max_pages` and `effective_max_pages` plus a `max_pages_capped` warning. URL captures also accept `render_wait_ms` for bounded client-render timing and warn when the captured page appears to be a loading/client-rendered SPA state.

## Report Artifacts

`generate_ux_audit_report` writes Markdown and, by default, an adjacent static one-page HTML report. It can also write an adjacent PDF when `include_pdf=True`. It accepts either an inline scored payload or a `payload_path` returned as `report_payload_ref.path` from compact audit responses. Reports use the UXHC report design-system harness: scorecard and findings lead, evidence limits and validation steps appear before the roadmap, checklist rows are available without JavaScript, and evidence refs/paths render as plain text with no links or external assets. If validation blocks, the host must repair the payload and retry the UXHC renderer instead of handmaking HTML. Optional `run_visual_qa=True` attempts a Playwright desktop/mobile smoke when Playwright is installed and otherwise reports that QA is unavailable without blocking generation. If the minimal fallback PDF renderer is used, the report returns `qa_status: ready_with_warnings`.

## Calibration And Comparison

`calibrate_ux_sensitivity` runs deterministic severity fixtures against the current checklist scoring contract and returns a human review rubric for finding quality.

`compare_ux_audits` compares two audit payloads and classifies findings as fixed, new, unresolved, or severity-changed. In `desktop_mobile` mode, baseline-only findings are treated as desktop-only and candidate-only findings are treated as mobile-only.

## Project-Specific Add-Ons

`draft_project_addon_profile` creates an opt-in scaffold from user-supplied project context, tasks, audience, constraints, and references. It does not scrape competitors, does not modify the baseline score, and keeps all criteria in the `project_specific_addon` lane.

Replace the audit domain:

- text reasoning audit becomes interface heuristic audit
- Critical Integrity Snapshot becomes UX Health Snapshot
- bias/fallacy findings become UX heuristic findings
- check-worthy claims become evidence-needed or validation-needed UX observations

## Local Runtime

Use a stable Python environment and run the server from the project root:

```bash
python3 server.py --self-test
```

Project-scoped MCP config:

```text
.mcp.json
```

It points to your local Python runtime and this project's `server.py`:

```text
python3 /path/to/ux-heuristic-compass/server.py
```

## Validation Commands

Validation should verify runtime, report, and scope language:

```bash
cd /path/to/ux-heuristic-compass
python3 -m pytest -q
python3 server.py --self-test
find docs/planning -type f -name '*.md' | sort
rg -n "donor|conversion" README.md AGENTS.md docs/planning ux_heuristic_compass tests
rg -n "full-site crawling|autonomous browser-agent|authenticated flows" docs/planning README.md AGENTS.md
```

The donor/conversion scan should only find exclusion, rejection, or regression-test references. It must not appear as a core or optional rubric definition.

The MCP smoke should list these tools:

```text
audit_ux_surface
calibrate_ux_sensitivity
calibrate_ux_severity
compare_ux_audits
draft_project_addon_profile
generate_ux_audit_report
get_agent_run
get_started
list_heuristics
prepare_ux_source
quick_scan_ux
run_agent_audit
run_usability_test
save_preferences
stress_test_heuristic_finding
update_preferences
ux_heuristic_overview
validate_ux_report_payload
```
