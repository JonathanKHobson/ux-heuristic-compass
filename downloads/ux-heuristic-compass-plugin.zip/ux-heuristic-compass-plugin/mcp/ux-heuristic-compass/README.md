# UX Heuristics Compass

UX Heuristics Compass is a local-first UX heuristic audit MCP for reviewing websites, app screens, screenshots, prototypes, bounded page captures, and interface evidence.

Use UX Heuristics Compass when the question is: **What visible usability problems should we fix before this interface ships?**

It helps reviewers identify interface issues, calibrate severity, capture evidence limits, and turn findings into a stakeholder-ready audit report.

## What The MCP Does

UX Heuristics Compass gives a host AI a structured UX audit layer. The host AI owns visual interpretation, conversation, and final communication; UXHC owns the 14-heuristic rubric, checklist contracts, scoring structures, report payload validation, evidence graph, preferences, agent aggregation, and artifact generation.

It is not a replacement for real participant research, accessibility certification, legal compliance review, or unbounded browser automation.

## Tool Overview

Orientation and rubric:

- `get_started`: first-session onboarding, report fields, and route guidance.
- `ux_heuristic_overview`: capability lookup and audit boundaries.
- `list_heuristics`: browse the 14-heuristic system and checklist items.

Source prep and audits:

- `prepare_ux_source`: normalize screenshots, URL captures, text, code notes, or host observations into an audit source.
- `quick_scan_ux`: fast triage or guidance-only review.
- `audit_ux_surface`: full checklist-level scored audit.

Reports and calibration:

- `validate_ux_report_payload`: dry-run report readiness.
- `generate_ux_audit_report`: create Markdown/HTML/PDF report artifacts when ready.
- `calibrate_ux_sensitivity`, `calibrate_ux_severity`, and `stress_test_heuristic_finding`: tune severity and reduce evaluator bias.
- `compare_ux_audits`: compare audit outputs.

Preferences, agents, and research handoff:

- `save_preferences` and `update_preferences`: persist local audit preferences.
- `run_agent_audit` and `get_agent_run`: aggregate host-run researcher persona scorecards.
- `run_usability_test`: bounded usability-test prep or synthetic walkthrough support, not proof of real participant behavior unless real logs are supplied.

## What To Download

- Claude Desktop Extension / MCPB: easiest local MCP install for Claude Desktop.
- Claude Code or Cowork Plugin: bundled MCP plus supporting agent/skill assets.
- Skill or Skill ZIP: lightweight UX audit coach when the MCP is unavailable.
- Source ZIP: inspect, audit, or rebuild from source.

If you want to audit live pages, pair the MCP with host-side browser evidence such as screenshots, Playwright observations, Chrome DevTools output, or exported HTML.

## Dependencies And Optional Capabilities

- Python runtime and MCP host support are required for local MCP use.
- Browser automation such as Playwright or Chrome control is optional for live website evidence. Screenshots and static source bundles can also be audited.
- HTML/PDF report generation may require local rendering dependencies.
- The MCP can accept external accessibility or browser findings as evidence, but it does not certify WCAG compliance.

## Files And Folders

- `server.py` and `ux_heuristic_compass/`: MCP tools, rubric logic, scoring contracts, and report helpers.
- `packaging/`: MCPB, plugin, and skill package inputs.
- `reports/`: local generated reports and test outputs; public packages should include only reviewed examples.
- `scripts/`: readiness checks, release builders, validators, dashboard generation, and cleanup scans.
- `docs/`: planning, public docs, and implementation notes.
- `LOCAL_DEVELOPMENT.md`: local maintainer notes that may include machine-specific paths and should not be treated as public install instructions.

## Privacy And Safety Boundary

UXHC is local-first. It should not publish screenshots, private reports, browser captures, run summaries, or local state unless they have been explicitly reviewed as public-safe examples.

## Compass Suite

UX Heuristics Compass is part of the Compass Suite. Critical Compass focuses on reasoning and text trust. Prompt Compass focuses on prompt work. Research Compass, TTRPG Compass, and Job Application Compass cover adjacent specialized workflows.

Compass Suite home: https://jonathankhobson.github.io/compass-suite/

## Versioning

The package base version is `0.1.0`. Public beta tags identify release iterations. Rebuild release assets only after package cleanliness, public landing page, report renderer, and download checks pass.

## About The Author

Jonathan Kyle Hobson is a UX researcher, product strategist, and AI tool builder with 10+ years of experience across design, storytelling, and emerging technology. He holds a master's degree in User Experience from Arizona State University.

LinkedIn: https://www.linkedin.com/in/jonathankylehobson/

Kyle created UX Heuristics Compass to make heuristic UX audits more concrete, structured, and useful for people who need interface feedback before they ship.

## License And Attribution

Created by Jonathan Kyle Hobson.

- Code license: AGPL-3.0-only. See `LICENSE`.
- Documentation, prompts, skills, rubrics, checklists, examples, and public methodology text: CC BY-SA 4.0. See `LICENSE-DOCS-CC-BY-SA-4.0.md`.
- Compass names, logos, author photo, and personal brand: reserved for attribution/reference use. See `BRAND-AND-ATTRIBUTION.md`.
- Redistribution notices: see `NOTICE` and `THIRD_PARTY_NOTICES.md`.

Modified versions are not official releases unless explicitly published by Jonathan Kyle Hobson.
