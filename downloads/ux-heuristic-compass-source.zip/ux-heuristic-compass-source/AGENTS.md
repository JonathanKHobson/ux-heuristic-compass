# UX Heuristic Compass Agent Rules

## Purpose

UX Heuristic Compass helps people audit interface usability before they ship, present, or hand off a website, application screen, prototype, or design artifact.

Keep work centered on visible UX evidence, heuristic fit, severity, next fix, confidence, and report readiness.

## Scope Rules

- Start with screenshot/image audit and bounded URL capture.
- Treat URL capture as source preparation, not autonomous product research.
- Do not add broad crawling, auth automation, analytics ingestion, or competitive scraping to MVP.
- Do not include donor/conversion checklists in the default rubric.
- Do not let domain-specific checklist generation displace the core HE audit.
- If a project-specific checklist is needed later, make it an opt-in add-on profile with provenance and rationale.

## Audit Discipline

- Use Nielsen Norman Group's 10 usability heuristics as the default rubric.
- Add accessibility, inclusion, journey, or UX-writing profiles only when requested or visibly relevant.
- Keep findings evidence-bound: cite screenshot region, URL, viewport, DOM/text cue, or observed interaction.
- Use severity as a usability priority signal, not a moral judgment.
- Separate visible evidence from host-AI inference.
- If the image or page is too thin to judge, return `profile_only` or `insufficient_evidence` instead of inventing findings.

## Browser Handoff

When browser automation or URL capture is used:

1. Close automation-owned browser sessions.
2. Check for automation-only Chrome args such as `--headless`, temp `--user-data-dir`, remote debugging ports, or `ms-playwright` paths.
3. Verify either no automation Chrome remains or normal Chrome is relaunched as the real app with a visible window.
4. Treat browser cleanup as part of the task signoff.

## Report Readiness

- Generate reports only after findings include heuristic ID, severity, evidence reference, recommendation, and confidence.
- Do not ship blank sections or placeholder findings.
- Do not turn a quick scan into a full stakeholder report without report validation.
- Keep screenshots and private URLs local unless the user explicitly requests a public artifact.

## Release Hygiene

- Keep captures, local screenshots, private reports, caches, `.env*`, AppleDouble sidecars, bytecode, and browser profiles out of public bundles.
- Validate planning docs, runtime tests, package contents, and browser handoff before any release.
- Public copy should describe the tool as a heuristic UX audit assistant, not as a complete UX research platform.
