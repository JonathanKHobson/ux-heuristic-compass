#!/usr/bin/env python3
"""Export UXHC feedback Markdown or trace payloads into issue bundles."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ux_heuristic_compass.issue_export import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main())
