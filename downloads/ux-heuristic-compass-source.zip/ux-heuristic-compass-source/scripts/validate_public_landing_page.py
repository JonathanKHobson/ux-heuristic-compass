#!/usr/bin/env python3
"""Validate the UX Heuristics Compass public landing page kit."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / "dist" / "share" / "github-pages"
PUBLIC_FILES = [
    SITE / "index.html",
    SITE / "styles.css",
    SITE / "site.js",
    SITE / "landing-manifest.json",
]

FORBIDDEN_STRINGS = [
    "About & FAQ",
    "About &amp; FAQ",
    "PLACEHOLDER",
    "/Volumes/",
    "/Users/",
    "._",
    ".DS_Store",
    "artifact share",
]

REQUIRED_RELEASE_FILENAMES = [
    "ux-heuristic-compass-plugin.zip",
    "ux-heuristic-compass-0.1.0.mcpb",
    "ux-heuristic-compass.skill",
    "skill.zip",
    "ux-heuristic-compass-source.zip",
    "checksums.txt",
]


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


def read(path: Path) -> str:
    if not path.exists():
        fail(f"missing required file: {path.relative_to(ROOT)}")
    return path.read_text(encoding="utf-8")


def validate_static_text() -> None:
    combined = "\n".join(read(path) for path in PUBLIC_FILES)
    for forbidden in FORBIDDEN_STRINGS:
        if forbidden in combined:
            fail(f"forbidden public string found: {forbidden}")

    styles = read(SITE / "styles.css")
    if "compass-public-visual-system: uxhc-v1" not in styles:
        fail("shared Compass visual-system marker missing from styles.css")

    html = read(SITE / "index.html")
    labels = re.findall(r'data-tab-target="[^"]+">([^<]+)</button>', html)
    expected = ["Get Started", "About", "Install Guide", "Example", "FAQ", "Advanced"]
    if labels != expected:
        fail(f"tab order mismatch: got {labels}, expected {expected}")

    if "UX Heuristics Compass 0.1.0-beta.1" not in html:
        fail("version badge missing")

    for filename in REQUIRED_RELEASE_FILENAMES:
        expected = f"https://github.com/JonathanKHobson/ux-heuristic-compass/releases/download/v0.1.0-beta.1/{filename}"
        if expected not in html and expected not in combined:
            fail(f"verified release URL missing: {filename}")

    if "Download Opens After" in html or "Skill Download Coming Soon" in html:
        fail("pending download button copy remains after beta package verification")


def validate_manifest() -> None:
    try:
        manifest = json.loads(read(SITE / "landing-manifest.json"))
    except json.JSONDecodeError as exc:
        fail(f"landing-manifest.json is invalid JSON: {exc}")

    product = manifest.get("product", {})
    if product.get("status") != "public_beta_available":
        fail("manifest status must be public_beta_available")

    assets = manifest.get("release_assets", [])
    if len(assets) != 6:
        fail(f"expected 6 planned release assets, found {len(assets)}")

    for asset in assets:
        if asset.get("availability") != "available":
            fail(f"asset availability must be available: {asset.get('filename')}")
        if not asset.get("url"):
            fail(f"asset release URL missing: {asset.get('filename')}")
        if not asset.get("checksum"):
            fail(f"asset checksum missing: {asset.get('filename')}")


def validate_sidecars() -> None:
    for path in SITE.rglob("*"):
        if path.name == ".DS_Store" or path.name.startswith("._"):
            fail(f"sidecar file found: {path.relative_to(ROOT)}")


def main() -> int:
    validate_static_text()
    validate_manifest()
    validate_sidecars()
    print("UXHC public landing page validation passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
