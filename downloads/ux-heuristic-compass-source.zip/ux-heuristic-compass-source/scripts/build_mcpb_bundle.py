#!/usr/bin/env python3
"""Stage and optionally pack the UX Heuristics Compass MCPB bundle."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

from check_release_clean import inspect_tree


ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_DIR = ROOT / "packaging" / "mcpb" / "ux-heuristic-compass"
DEFAULT_OUTPUT_DIR = ROOT / "dist" / "mcpb"

RUNTIME_DIRS = {
    "ux_heuristic_compass": set(),
}

RUNTIME_FILES = [
    "server.py",
    "README.md",
    "LICENSE",
    "LICENSE-DOCS-CC-BY-SA-4.0.md",
    "NOTICE",
    "BRAND-AND-ATTRIBUTION.md",
    "THIRD_PARTY_NOTICES.md",
    "AGENTS.md",
]


def _skip_name(name: str) -> bool:
    return (
        name in {"__pycache__", ".pytest_cache", ".mypy_cache", ".DS_Store"}
        or name.startswith("._")
        or name.startswith(".__")
        or name.endswith((".pyc", ".pyo"))
    )


def _remove_tree(path: Path) -> None:
    def onerror(_func, _path, exc_info):  # type: ignore[no-untyped-def]
        if exc_info and issubclass(exc_info[0], FileNotFoundError):
            return
        raise exc_info[1]

    shutil.rmtree(path, onerror=onerror)


def _ignore_factory(excluded_dirs: set[str] | None = None):
    excluded_dirs = excluded_dirs or set()

    def ignore(_dir: str, names: list[str]) -> set[str]:
        ignored: set[str] = set()
        for name in names:
            if _skip_name(name) or name in excluded_dirs:
                ignored.add(name)
        return ignored

    return ignore


def _copy_file(relative_path: str, stage_dir: Path) -> None:
    source = ROOT / relative_path
    if not source.exists():
        return
    target = stage_dir / relative_path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def _copy_tree(relative_path: str, stage_dir: Path, *, excluded_dirs: set[str] | None = None) -> None:
    source = ROOT / relative_path
    if not source.exists():
        return
    target = stage_dir / relative_path
    if target.exists():
        _remove_tree(target)
    shutil.copytree(source, target, ignore=_ignore_factory(excluded_dirs))


def _copy_template_files(stage_dir: Path) -> None:
    if not TEMPLATE_DIR.exists():
        raise FileNotFoundError(f"Missing MCPB template folder: {TEMPLATE_DIR}")
    for source in TEMPLATE_DIR.iterdir():
        if _skip_name(source.name):
            continue
        target = stage_dir / source.name
        if source.is_dir():
            if target.exists():
                _remove_tree(target)
            shutil.copytree(source, target, ignore=_ignore_factory())
        else:
            shutil.copy2(source, target)


def _remove_sidecars(stage_dir: Path) -> None:
    for path in sorted(stage_dir.rglob("*"), reverse=True):
        if path.name.startswith(("._", ".__")) or path.name == ".DS_Store":
            if path.is_dir():
                _remove_tree(path)
            else:
                path.unlink(missing_ok=True)


def _assert_clean_stage(stage_dir: Path) -> None:
    errors: list[str] = []
    required = [
        "manifest.json",
        "pyproject.toml",
        "mcpb_launcher.py",
        "server.py",
        "ux_heuristic_compass/__init__.py",
        "ux_heuristic_compass/data/uxhc_flows.json",
    ]
    for relative_path in required:
        if not (stage_dir / relative_path).exists():
            errors.append(f"missing required runtime file: {relative_path}")

    forbidden_parts = {"tests", "__pycache__", ".pytest_cache", ".venv", "dist", "reports", "docs", ".playwright-cli"}
    for path in stage_dir.rglob("*"):
        relative = path.relative_to(stage_dir)
        if any(part in forbidden_parts for part in relative.parts):
            errors.append(f"forbidden path included: {relative}")
        if path.name.startswith(("._", ".__")):
            errors.append(f"AppleDouble sidecar included: {relative}")

    errors.extend(f"{finding.path}: {finding.reason}" for finding in inspect_tree(stage_dir))
    if errors:
        raise RuntimeError("\n".join(sorted(set(errors))))


def stage_bundle(output_dir: Path) -> tuple[Path, dict]:
    stage_dir = output_dir / "ux-heuristic-compass"
    if stage_dir.exists():
        _remove_tree(stage_dir)
    stage_dir.mkdir(parents=True, exist_ok=True)

    _copy_template_files(stage_dir)
    manifest = json.loads((stage_dir / "manifest.json").read_text(encoding="utf-8"))

    for runtime_dir, excluded_dirs in RUNTIME_DIRS.items():
        _copy_tree(runtime_dir, stage_dir, excluded_dirs=excluded_dirs)
    for runtime_file in RUNTIME_FILES:
        _copy_file(runtime_file, stage_dir)

    _remove_sidecars(stage_dir)
    _assert_clean_stage(stage_dir)
    return stage_dir, manifest


def pack_bundle(stage_dir: Path, output_file: Path) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    command = ["npx", "-y", "@anthropic-ai/mcpb", "pack", str(stage_dir), str(output_file)]
    subprocess.run(command, check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Stage and optionally pack the UXHC MCPB bundle.")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR), help="Directory that will receive the staged bundle.")
    parser.add_argument("--pack", action="store_true", help="Run @anthropic-ai/mcpb pack after staging.")
    parser.add_argument("--artifact", default="", help="Optional output .mcpb path when --pack is used.")
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser().resolve()
    try:
        stage_dir, manifest = stage_bundle(output_dir)
        artifact = Path(args.artifact).expanduser().resolve() if args.artifact else output_dir / f"ux-heuristic-compass-{manifest['version']}.mcpb"
        if args.pack:
            pack_bundle(stage_dir, artifact)
            print(f"packed_mcpb={artifact}")
        print(f"staged_bundle={stage_dir}")
        print(f"manifest_version={manifest.get('manifest_version')}")
        print(f"package_version={manifest.get('version')}")
        return 0
    except Exception as exc:  # pylint: disable=broad-exception-caught
        print(f"build_mcpb_bundle failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
