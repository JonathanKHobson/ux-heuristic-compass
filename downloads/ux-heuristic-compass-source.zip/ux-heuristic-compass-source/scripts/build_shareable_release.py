#!/usr/bin/env python3
"""Build UX Heuristics Compass release artifacts and share kits."""

from __future__ import annotations

import hashlib
import html
import json
import re
import shutil
import textwrap
import zipfile
from pathlib import Path

from build_mcpb_bundle import pack_bundle, stage_bundle
from check_release_clean import inspect_tree, inspect_zip


ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
MCPB_DIR = DIST / "mcpb"
PLUGIN_DIR = DIST / "plugins"
PLUGIN_SOURCE_DIR = PLUGIN_DIR / "ux-heuristic-compass-plugin"
PLUGIN_ZIP = PLUGIN_DIR / "ux-heuristic-compass-plugin.zip"
SOURCE_DIR = DIST / "source"
SOURCE_ZIP = SOURCE_DIR / "ux-heuristic-compass-source.zip"
SHARE_DIR = DIST / "share"
PAGES_DIR = SHARE_DIR / "github-pages"
DOWNLOADS_DIR = PAGES_DIR / "downloads"
MANUAL_SHARE_DIR = SHARE_DIR / "manual-share"
GITHUB_PAGES_KIT = SHARE_DIR / "ux-heuristic-compass-github-pages-kit.zip"
MANUAL_SHARE_KIT = SHARE_DIR / "ux-heuristic-compass-manual-share.zip"
SKILL_SOURCE_DIR = ROOT / "packaging" / "skills" / "ux-heuristic-compass"
MCPB_FILE = MCPB_DIR / "ux-heuristic-compass-0.1.0.mcpb"
SKILL_FILE = MCPB_DIR / "ux-heuristic-compass.skill"
SKILL_ZIP = MCPB_DIR / "skill.zip"
DIAGNOSTIC_PROMPT = ROOT / "packaging" / "mcpb" / "INSTALLER_DIAGNOSTIC_PROMPT.md"

RELEASE_TAG = "v0.1.0-beta.1"
PACKAGE_VERSION = "0.1.0"
RELEASE_LABEL = RELEASE_TAG.removeprefix("v")
RELEASE_DOWNLOAD_BASE = f"https://github.com/JonathanKHobson/ux-heuristic-compass/releases/download/{RELEASE_TAG}/"

DOWNLOAD_FILES = [
    "ux-heuristic-compass-plugin.zip",
    "ux-heuristic-compass-0.1.0.mcpb",
    "ux-heuristic-compass.skill",
    "skill.zip",
    "ux-heuristic-compass-source.zip",
]

RELEASE_FILES = [
    *DOWNLOAD_FILES,
    "ux-heuristic-compass-manual-share.zip",
]

AI_INSTALL_PROMPT = """You are a careful, technically conservative AI install assistant. Your job is to help me add or install UX Heuristics Compass - optionally including the local MCP source, plugin, MCPB/Desktop extension, and/or skill - safely, without modifying unrelated configuration or introducing unexpected dependencies. Do not delete anything; only add.

UX Heuristics Compass is a local-first UX audit assistant for reviewing websites, app screens, prototypes, screenshots, and bounded task flows against a 14-heuristic system.

Release page: https://jonathankhobson.github.io/ux-heuristic-compass/

PHASE 1 - Understand my environment
Before doing anything, ask me:
1. Which AI client are you using? (Claude Cowork, Claude Code, Claude Desktop, Codex, or other)
2. Which operating system are you on? (macOS, Windows, Linux, WSL, or other)
3. Have you installed any MCPs, plugins, or skills before? (yes / no / unsure)
4. What do you want added or installed? (local MCP source / plugin / MCPB Desktop extension / skill / all)

Do not proceed to Phase 2 until I answer all four questions.

PHASE 2 - Identify the right install path
Based on my answers, recommend the appropriate install path or paths.

Install methods and what you can automate:
- Local MCP source zip - usually the most automatable path for local clients if you can access my filesystem. Download the source zip, unpack it into a stable local folder, and add a config entry that launches the local MCP process.
- Plugin zip - add/install support depends on the client. Download and inspect the plugin zip, then determine whether the current client supports adding it automatically or whether I need to complete a UI step.
- MCPB/Desktop extension file - add/install support depends on the client. Download and inspect the MCPB file, then determine whether the current client supports adding it automatically or whether I need to complete a UI step.
- Skill or skill zip - add/install support depends on the client. Download and inspect the skill file, then determine whether the current client supports adding it automatically or whether I need to complete a UI step.

Important distinction:
- Treat the local MCP source install as the reliably automatable path when filesystem access is available.
- For plugin, MCPB/Desktop extension, and skill files, do not assume the add/install method. Check the current client, current docs, local files, and visible UI.
- If the UI or install method has changed, use current official docs or the client's visible UI rather than stale instructions.

For each path you recommend, state in one sentence what you can do automatically and what I may need to do manually. Ask me to confirm before proceeding.

PHASE 3 - Review before installing
Open the release page and identify the current version.
Download only the file or files needed for the confirmed install paths.
Before installing, check for:
- Unexpected network calls or external API dependencies
- Hidden API keys or credential requirements
- Suspicious scripts or broad file system access
- Unrelated third-party MCPs or services bundled in

If you find anything concerning, STOP. Describe the concern clearly and ask me how to proceed. Do not install until I confirm.

PHASE 4 - Install safely
For a local MCP source install:
- Prefer a stable local install folder and avoid running directly from a temporary download folder.
- Read existing config files before editing them.
- Preserve all unrelated MCP servers and settings.
- Back up any config file before changing it.
- Prefer a direct interpreter command with absolute paths instead of shell wrappers.

For plugin, MCPB/Desktop extension, or skill installs:
- Do not hand-edit installed plugin, extension, or skill cache folders.
- Download and inspect the package, then determine the current add/install method for the user's client.
- If a UI step is required, guide me through it clearly and wait for me to confirm completion.
- Do not add paid services, external APIs, provider keys, or third-party MCPs unless I explicitly ask.

PHASE 5 - Smoke test
After installing, confirm UX Heuristics Compass is available:
- If MCP tools are active: call get_started.
- If only the skill is available: ask UX Heuristics Compass to review one screenshot or short interface description.
- If install fails: tell me whether the issue is package validation, MCP launch, config syntax, missing dependency, wrong workspace root, client restart needed, or unsupported-client behavior, then suggest one concrete next step.

Constraints throughout:
- One phase at a time. Do not skip ahead.
- Ask rather than assume when uncertain.
- Preserve unrelated configuration. Do not delete anything; only add.
- Use current docs or visible client UI when the install method is unclear.
"""


def _remove_tree(path: Path) -> None:
    def onerror(_func, _path, exc_info):  # type: ignore[no-untyped-def]
        if exc_info and issubclass(exc_info[0], FileNotFoundError):
            return
        raise exc_info[1]

    shutil.rmtree(path, onerror=onerror)


def _remove_sidecars(root: Path) -> None:
    if not root.exists():
        return
    for path in sorted(root.rglob("*"), reverse=True):
        if path.name.startswith(("._", ".__")) or path.name == ".DS_Store":
            if path.is_dir():
                _remove_tree(path)
            else:
                path.unlink(missing_ok=True)


def _zip_directory(source_dir: Path, output_zip: Path, *, archive_root: str) -> None:
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    if output_zip.exists():
        output_zip.unlink()
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source_dir.rglob("*")):
            if path.is_dir():
                continue
            if path.name.startswith(("._", ".__")) or path.name == ".DS_Store":
                continue
            archive.write(path, (Path(archive_root) / path.relative_to(source_dir)).as_posix())
    _assert_zip_clean(output_zip)


def _skip_source_path(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    parts = relative.parts
    name = path.name
    forbidden_parts = {
        ".git",
        ".venv",
        ".pytest_cache",
        ".mypy_cache",
        "__pycache__",
        ".playwright-cli",
        "dist",
        "reports",
        "captures",
        "output",
        "build",
        "ux_heuristic_compass.egg-info",
    }
    if any(part in forbidden_parts for part in parts):
        return True
    if str(relative) in {"docs/planning/progress-log.md", "docs/planning/public-landing-page-phase-2-3-prep.md"}:
        return True
    if name in {".DS_Store", ".mcp.json"}:
        return True
    if name.startswith(("._", ".__", ".env")):
        return True
    if name.endswith((".pyc", ".pyo", ".sqlite", ".sqlite3", ".db", ".sqlite-wal", ".sqlite-shm", ".sqlite-journal")):
        return True
    return False


def _zip_source(output_zip: Path) -> None:
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    if output_zip.exists():
        output_zip.unlink()
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob("*")):
            if path.is_dir() or _skip_source_path(path):
                continue
            archive.write(path, (Path("ux-heuristic-compass-source") / path.relative_to(ROOT)).as_posix())
    _assert_zip_clean(output_zip)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _assert_tree_clean(path: Path) -> None:
    findings = inspect_tree(path)
    if findings:
        details = "\n".join(f"- {finding.path}: {finding.reason}" for finding in findings)
        raise RuntimeError(f"release tree is not clean: {path}\n{details}")


def _assert_zip_clean(path: Path) -> None:
    findings = inspect_zip(path)
    if findings:
        details = "\n".join(f"- {finding.path}: {finding.reason}" for finding in findings)
        raise RuntimeError(f"archive is not clean: {path}\n{details}")


def _validate_zip(path: Path) -> None:
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"zip integrity failed for {path}: {bad}")


def _build_skill_packages() -> None:
    required = [
        SKILL_SOURCE_DIR / "SKILL.md",
        SKILL_SOURCE_DIR / "references" / "heuristics-checklist.md",
        SKILL_SOURCE_DIR / "references" / "mcp-bridge.md",
        SKILL_SOURCE_DIR / "references" / "severity-calibration-guide.md",
        SKILL_SOURCE_DIR / "references" / "evidence-collection-guide.md",
        SKILL_SOURCE_DIR / "references" / "report-payload-field-guide.md",
        SKILL_SOURCE_DIR / "references" / "evaluator-bias-guard.md",
        SKILL_SOURCE_DIR / "agents" / "researcher-panel.md",
        SKILL_SOURCE_DIR / "examples" / "sample-audit-output.md",
    ]
    for path in required:
        if not path.exists():
            raise RuntimeError(f"UXHC skill missing required file: {path.relative_to(ROOT)}")

    _zip_directory(SKILL_SOURCE_DIR, SKILL_FILE, archive_root="ux-heuristic-compass")

    if SKILL_ZIP.exists():
        SKILL_ZIP.unlink()
    with zipfile.ZipFile(SKILL_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(SKILL_SOURCE_DIR.rglob("*")):
            if path.is_dir() or path.name.startswith(("._", ".__")) or path.name == ".DS_Store":
                continue
            archive.write(path, path.relative_to(SKILL_SOURCE_DIR).as_posix())

    _assert_zip_clean(SKILL_FILE)
    _assert_zip_clean(SKILL_ZIP)


def _build_mcpb() -> None:
    stage_dir, manifest = stage_bundle(MCPB_DIR)
    if manifest.get("version") != PACKAGE_VERSION:
        raise RuntimeError(f"PACKAGE_VERSION drift: script={PACKAGE_VERSION}, manifest={manifest.get('version')}")
    pack_bundle(stage_dir, MCPB_FILE)
    _validate_zip(MCPB_FILE)
    _assert_zip_clean(MCPB_FILE)


def _build_plugin_source() -> None:
    if PLUGIN_SOURCE_DIR.exists():
        _remove_tree(PLUGIN_SOURCE_DIR)
    PLUGIN_SOURCE_DIR.mkdir(parents=True, exist_ok=True)

    plugin_manifest_dir = PLUGIN_SOURCE_DIR / ".claude-plugin"
    plugin_manifest_dir.mkdir(parents=True, exist_ok=True)
    plugin_manifest = {
        "name": "ux-heuristic-compass",
        "version": PACKAGE_VERSION,
        "description": "Review interfaces with a bundled UX Heuristics Compass MCP server and skill.",
        "author": {"name": "Jonathan Kyle Hobson"},
        "license": "Proprietary",
        "keywords": ["ux", "usability", "heuristic-evaluation", "mcp"],
    }
    (plugin_manifest_dir / "plugin.json").write_text(json.dumps(plugin_manifest, indent=2) + "\n", encoding="utf-8")

    mcp_config = {
        "ux-heuristic-compass": {
            "type": "stdio",
            "command": "uv",
            "args": ["run", "--directory", "${CLAUDE_PLUGIN_ROOT}/mcp/ux-heuristic-compass", "mcpb_launcher.py"],
            "env": {"PYTHONDONTWRITEBYTECODE": "1"},
        }
    }
    (PLUGIN_SOURCE_DIR / ".mcp.json").write_text(json.dumps(mcp_config, indent=2) + "\n", encoding="utf-8")

    readme = textwrap.dedent(
        """\
        # UX Heuristics Compass Claude Plugin

        This plugin bundles:

        - the UX Heuristics Compass skill instructions
        - a plugin-local UXHC MCP server
        - `.mcp.json` configuration for that MCP server
        - agent role guidance for host-run UX review panels

        Use `ux-heuristic-compass-plugin.zip` when a Claude host asks for a
        custom plugin package. Use `ux-heuristic-compass-0.1.0.mcpb` when
        Claude Desktop asks for a Desktop Extension.

        First smoke test after enabling the plugin:

        ```text
        Use UX Heuristics Compass and call get_started.
        ```

        Expected warning: Claude may warn that this plugin includes local
        software or MCP access. That is expected. Install only if you trust the
        source.
        """
    )
    (PLUGIN_SOURCE_DIR / "README.md").write_text(readme, encoding="utf-8")

    mcp_stage_dir, _manifest = stage_bundle(PLUGIN_SOURCE_DIR / "mcp")
    if mcp_stage_dir.name != "ux-heuristic-compass":
        raise RuntimeError(f"unexpected staged MCP name: {mcp_stage_dir}")

    shutil.copytree(SKILL_SOURCE_DIR, PLUGIN_SOURCE_DIR / "skills" / "ux-heuristic-compass", ignore=shutil.ignore_patterns("._*", ".__*", ".DS_Store"))
    shutil.copytree(SKILL_SOURCE_DIR / "agents", PLUGIN_SOURCE_DIR / "agents" / "ux-heuristic-compass", ignore=shutil.ignore_patterns("._*", ".__*", ".DS_Store"))

    _remove_sidecars(PLUGIN_SOURCE_DIR)
    _assert_tree_clean(PLUGIN_SOURCE_DIR)


def _build_plugin_zip() -> None:
    _build_plugin_source()
    _zip_directory(PLUGIN_SOURCE_DIR, PLUGIN_ZIP, archive_root="ux-heuristic-compass-plugin")
    _validate_zip(PLUGIN_ZIP)
    _assert_zip_clean(PLUGIN_ZIP)
    with zipfile.ZipFile(PLUGIN_ZIP) as archive:
        top_levels = {name.split("/", 1)[0] for name in archive.namelist() if name}
    if top_levels != {"ux-heuristic-compass-plugin"}:
        raise RuntimeError(f"plugin zip must have one top-level folder, found: {sorted(top_levels)}")


def _release_notes(checksums: dict[str, str]) -> str:
    rows = "\n".join(f"- `{name}`: `{digest}`" for name, digest in checksums.items())
    return f"""# UX Heuristics Compass {RELEASE_LABEL}

UX Heuristics Compass {RELEASE_LABEL} is the first public beta package release.

## What's Included

- Claude plugin zip with MCP server, skill, and agent guidance
- Claude Desktop MCPB/Desktop Extension
- Standalone skill file and skill zip
- Clean source zip for technical review and local source installs
- Checksums for all downloadable artifacts

## Boundaries

- This is a heuristic UX audit assistant, not a replacement for participant research or accessibility certification.
- Core workflows run locally and do not require an external API service.
- Manual install QA is not implied unless separately recorded after testing in the target client.

## Checksums

{rows}
"""


def _copy_downloads(checksums: dict[str, str]) -> None:
    DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
    for target in DOWNLOADS_DIR.iterdir():
        if target.is_file():
            target.unlink()
    artifact_sources = {
        "ux-heuristic-compass-plugin.zip": PLUGIN_ZIP,
        "ux-heuristic-compass-0.1.0.mcpb": MCPB_FILE,
        "ux-heuristic-compass.skill": SKILL_FILE,
        "skill.zip": SKILL_ZIP,
        "ux-heuristic-compass-source.zip": SOURCE_ZIP,
    }
    for filename, source in artifact_sources.items():
        shutil.copy2(source, DOWNLOADS_DIR / filename)
    (DOWNLOADS_DIR / "checksums.txt").write_text(_checksums_text(checksums), encoding="utf-8")
    _remove_sidecars(DOWNLOADS_DIR)
    _assert_tree_clean(DOWNLOADS_DIR)


def _checksums_text(checksums: dict[str, str]) -> str:
    return "".join(f"{digest}  {name}\n" for name, digest in checksums.items())


def _update_pages_manifest(checksums: dict[str, str]) -> None:
    manifest_path = PAGES_DIR / "landing-manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["product"]["status"] = "public_beta_available"
    for asset in manifest.get("release_assets", []):
        filename = asset.get("filename")
        if filename == "checksums.txt":
            asset["availability"] = "available"
            asset["url"] = RELEASE_DOWNLOAD_BASE + filename
            asset["checksum"] = _sha256(DOWNLOADS_DIR / "checksums.txt")
        elif filename in checksums:
            asset["availability"] = "available"
            asset["url"] = RELEASE_DOWNLOAD_BASE + filename
            asset["checksum"] = checksums[filename]
    manifest["public_page_guardrails"] = [
        "download buttons use verified beta.1 release URLs",
        "example tab must not link private screenshots, client material, local paths, or draft reports",
        "tab order must remain Get Started, About, Install Guide, Example, FAQ, Advanced",
        "no combined About/FAQ tab",
        "manual install QA status must remain explicit and separate from package build verification",
    ]
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def _update_pages_html(checksums: dict[str, str]) -> None:
    html_path = PAGES_DIR / "index.html"
    page = html_path.read_text(encoding="utf-8")
    replacements = {
        '<p><span class="tag">Package pending</span></p>\n          <button class="button disabled" type="button" disabled>Download Opens After Beta Package Review</button>':
        f'<p><span class="tag">Public beta</span></p>\n          <a class="button" href="{RELEASE_DOWNLOAD_BASE}ux-heuristic-compass-plugin.zip" download>Download Plugin</a>',
        '<p><span class="tag">MCPB pending</span></p>\n          <button class="button secondary disabled" type="button" disabled>Download Opens After MCPB Review</button>':
        f'<p><span class="tag">Public beta</span></p>\n          <a class="button secondary" href="{RELEASE_DOWNLOAD_BASE}ux-heuristic-compass-0.1.0.mcpb" download>Download Extension</a>',
        '<p><span class="tag">Skill pending</span></p>\n          <button class="button ghost disabled" type="button" disabled>Skill Download Coming Soon</button>':
        f'<p><span class="tag">Public beta</span></p>\n          <a class="button ghost" href="{RELEASE_DOWNLOAD_BASE}ux-heuristic-compass.skill" download>Download Skill</a>',
        "Downloads are intentionally paused while local beta testing finishes. These paths are ready for the package pass, so the page can publish now without pretending the assets are finished.":
        "Downloads are live for beta.1. Choose the plugin for Claude Cowork or Claude Code, the MCPB/Desktop Extension for Claude Desktop, or the standalone skill when tool access is unavailable.",
        "Release files are intentionally not linked yet. The planned assets are plugin zip, MCPB/Desktop Extension, skill file, skill zip, source zip, checksums, and a clean GitHub Pages kit.":
        "Release files are live for beta.1. Checksums are listed below for technical verification.",
        "This prompt is staged for the package pass. Use it after beta assets are available.":
        "Use this prompt when you want a careful AI assistant to help inspect and install the package.",
        "Use the official release files only. Do not invent download URLs. If a release asset is missing, say it is not available yet.":
        "Use the official beta.1 release files only. Do not invent download URLs. If a release asset is missing, say it is not available yet.",
    }
    for before, after in replacements.items():
        if before in page:
            page = page.replace(before, after, 1)
        elif after in page:
            continue
        else:
            raise RuntimeError(f"expected landing-page text not found for replacement: {before[:80]}")

    planned_rows = """<tr><td><code>ux-heuristic-compass-plugin.zip</code></td><td>Pending package build and clean scan.</td></tr>
            <tr><td><code>ux-heuristic-compass-0.1.0.mcpb</code></td><td>Pending MCPB manifest and tool-surface verification.</td></tr>
            <tr><td><code>ux-heuristic-compass.skill</code></td><td>Pending skill guidance and prompt review.</td></tr>
            <tr><td><code>skill.zip</code></td><td>Pending skill zip package.</td></tr>
            <tr><td><code>ux-heuristic-compass-source.zip</code></td><td>Pending source package and private-file scan.</td></tr>
            <tr><td><code>checksums.txt</code></td><td>Pending SHA-256 generation after artifacts exist.</td></tr>"""
    checksum_rows = "\n".join(
        f'            <tr><td><a href="{RELEASE_DOWNLOAD_BASE}{name}" download><code>{html.escape(name)}</code></a></td><td><code>{digest}</code></td></tr>'
        for name, digest in checksums.items()
        if name != "checksums.txt"
    )
    checksum_rows += f'\n            <tr><td><a href="{RELEASE_DOWNLOAD_BASE}checksums.txt" download><code>checksums.txt</code></a></td><td>SHA-256 manifest</td></tr>'
    if planned_rows in page:
        page = page.replace(planned_rows, checksum_rows, 1)
    elif "Release Downloads and Checksums" in page:
        page, count = re.subn(
            r'(<summary>Advanced: Release Downloads and Checksums</summary>\s*<table>\s*)'
            r'.*?'
            r'(\s*</table>)',
            rf'\1{checksum_rows}\2',
            page,
            count=1,
            flags=re.DOTALL,
        )
        if count != 1:
            raise RuntimeError("release downloads checksum table not found")
    else:
        raise RuntimeError("planned download checklist rows not found")

    if "Skill Zip" not in page:
        insert_after = f'<a class="button ghost" href="{RELEASE_DOWNLOAD_BASE}ux-heuristic-compass.skill" download>Download Skill</a>'
        page = page.replace(
            insert_after,
            insert_after + f'\n          <a class="button ghost" href="{RELEASE_DOWNLOAD_BASE}skill.zip" download>Download Skill Zip</a>',
            1,
        )
    if "Download Source Zip" not in page:
        source_link = f'<p><a class="button quiet" href="{RELEASE_DOWNLOAD_BASE}ux-heuristic-compass-source.zip" download>Download Source Zip</a></p>'
        page = page.replace("</section>\n        <details>\n          <summary>Advanced: Planned Download Checklist</summary>", f"{source_link}\n        </section>\n        <details>\n          <summary>Advanced: Release Downloads and Checksums</summary>", 1)
    page = page.replace("<summary>Advanced: Planned Download Checklist</summary>", "<summary>Advanced: Release Downloads and Checksums</summary>")
    page = page.replace("<button class=\"button", "<button class=\"button")
    html_path.write_text(page, encoding="utf-8")


def _build_manual_share(checksums: dict[str, str]) -> None:
    if MANUAL_SHARE_DIR.exists():
        _remove_tree(MANUAL_SHARE_DIR)
    MANUAL_SHARE_DIR.mkdir(parents=True, exist_ok=True)
    downloads = MANUAL_SHARE_DIR / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    for file_name in DOWNLOAD_FILES:
        shutil.copy2(DOWNLOADS_DIR / file_name, downloads / file_name)
    (downloads / "checksums.txt").write_text(_checksums_text(checksums), encoding="utf-8")
    (MANUAL_SHARE_DIR / "RELEASE_NOTES.md").write_text(_release_notes(checksums), encoding="utf-8")
    (MANUAL_SHARE_DIR / "mcpb-install-diagnostics-prompt.md").write_text(DIAGNOSTIC_PROMPT.read_text(encoding="utf-8"), encoding="utf-8")
    (MANUAL_SHARE_DIR / "START_HERE.md").write_text(
        textwrap.dedent(
            f"""\
            # UX Heuristics Compass {RELEASE_LABEL}

            Start with the public landing page:
            https://jonathankhobson.github.io/ux-heuristic-compass/

            Downloads are in `downloads/`:

            - `ux-heuristic-compass-plugin.zip` for Claude plugin workflows.
            - `ux-heuristic-compass-0.1.0.mcpb` for Claude Desktop Extension workflows.
            - `ux-heuristic-compass.skill` and `skill.zip` for prompt-only skill workflows.
            - `ux-heuristic-compass-source.zip` for source review and technical installs.

            Manual install QA is separate from this package build. If you are using
            a host AI to install it, use `mcpb-install-diagnostics-prompt.md`.
            """
        ),
        encoding="utf-8",
    )
    if (PAGES_DIR / "examples").exists():
        shutil.copytree(PAGES_DIR / "examples", MANUAL_SHARE_DIR / "examples", ignore=shutil.ignore_patterns("._*", ".__*", ".DS_Store"))
    if (PAGES_DIR / "assets").exists():
        shutil.copytree(PAGES_DIR / "assets", MANUAL_SHARE_DIR / "assets", ignore=shutil.ignore_patterns("._*", ".__*", ".DS_Store"))
    _remove_sidecars(MANUAL_SHARE_DIR)
    _assert_tree_clean(MANUAL_SHARE_DIR)
    _zip_directory(MANUAL_SHARE_DIR, MANUAL_SHARE_KIT, archive_root="ux-heuristic-compass-manual-share")


def _build_github_pages_kit() -> None:
    _zip_directory(PAGES_DIR, GITHUB_PAGES_KIT, archive_root="ux-heuristic-compass-github-pages")


def main() -> int:
    try:
        _remove_sidecars(ROOT)
        for path in (MCPB_DIR, PLUGIN_DIR, SOURCE_DIR):
            if path.exists():
                _remove_tree(path)
            path.mkdir(parents=True, exist_ok=True)

        _build_mcpb()
        _build_skill_packages()
        _build_plugin_zip()
        _zip_source(SOURCE_ZIP)

        artifact_paths = {
            "ux-heuristic-compass-plugin.zip": PLUGIN_ZIP,
            "ux-heuristic-compass-0.1.0.mcpb": MCPB_FILE,
            "ux-heuristic-compass.skill": SKILL_FILE,
            "skill.zip": SKILL_ZIP,
            "ux-heuristic-compass-source.zip": SOURCE_ZIP,
        }
        checksums = {name: _sha256(path) for name, path in artifact_paths.items()}
        _copy_downloads(checksums)
        (DOWNLOADS_DIR / "checksums.txt").write_text(_checksums_text(checksums), encoding="utf-8")
        checksums["checksums.txt"] = _sha256(DOWNLOADS_DIR / "checksums.txt")
        (PAGES_DIR / "release-notes.md").write_text(_release_notes(checksums), encoding="utf-8")
        _update_pages_manifest(checksums)
        _update_pages_html(checksums)
        _remove_sidecars(PAGES_DIR)
        _build_manual_share(checksums)
        checksums.pop("checksums.txt", None)
        checksums["ux-heuristic-compass-manual-share.zip"] = _sha256(MANUAL_SHARE_KIT)
        (DOWNLOADS_DIR / "checksums.txt").write_text(_checksums_text(checksums), encoding="utf-8")
        checksums["checksums.txt"] = _sha256(DOWNLOADS_DIR / "checksums.txt")
        (PAGES_DIR / "release-notes.md").write_text(_release_notes(checksums), encoding="utf-8")
        _update_pages_manifest(checksums)
        _remove_sidecars(PAGES_DIR)
        _build_github_pages_kit()
        _remove_sidecars(DIST)

        for path in [*artifact_paths.values(), DOWNLOADS_DIR / "checksums.txt", MANUAL_SHARE_KIT, GITHUB_PAGES_KIT]:
            if path.suffix in {".zip", ".mcpb", ".skill"}:
                _validate_zip(path)
                _assert_zip_clean(path)
        _assert_tree_clean(PAGES_DIR)
        print(f"release_tag={RELEASE_TAG}")
        print(f"downloads_dir={DOWNLOADS_DIR}")
        print(f"manual_share={MANUAL_SHARE_KIT}")
        print(f"github_pages_kit={GITHUB_PAGES_KIT}")
        return 0
    except Exception as exc:  # pylint: disable=broad-exception-caught
        print(f"build_shareable_release failed: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
