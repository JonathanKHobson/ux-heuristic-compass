#!/usr/bin/env python3
"""Fail fast when a UXHC release tree or archive contains local/private state."""

from __future__ import annotations

import argparse
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path


FORBIDDEN_PARTS = {
    ".git",
    ".venv",
    ".pytest_cache",
    ".mypy_cache",
    "__pycache__",
    ".playwright-cli",
    "node_modules",
    "dist",
    "reports",
    "captures",
    "output",
    "build",
}

FORBIDDEN_NAMES = {
    ".DS_Store",
    "state.sqlite",
    "state.sqlite3",
    "state.db",
}

FORBIDDEN_SUFFIXES = {
    ".pyc",
    ".pyo",
    ".sqlite-wal",
    ".sqlite-shm",
    ".sqlite-journal",
}

FORBIDDEN_PREFIXES = {
    "._",
    ".__",
}

FORBIDDEN_CONTENT = {
    "/Users/",
    "/Volumes/",
    "PLACEHOLDER",
    "API_KEY=",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
}

TEXT_SUFFIXES = {
    ".css",
    ".html",
    ".js",
    ".json",
    ".md",
    ".py",
    ".toml",
    ".txt",
    ".yml",
    ".yaml",
}


@dataclass(frozen=True)
class Finding:
    path: str
    reason: str


def _normalized(path: str) -> str:
    return path.replace("\\", "/").strip("/")


def _parts(path: str) -> tuple[str, ...]:
    return tuple(part for part in _normalized(path).split("/") if part)


def inspect_relative_path(path: str) -> list[Finding]:
    normalized = _normalized(path)
    parts = _parts(normalized)
    name = parts[-1] if parts else normalized
    findings: list[Finding] = []

    for part in parts:
        if part in FORBIDDEN_PARTS:
            findings.append(Finding(normalized, f"forbidden path segment: {part}"))
    if name in FORBIDDEN_NAMES:
        findings.append(Finding(normalized, f"forbidden file name: {name}"))
    if name == ".mcp.json" and not (normalized == ".mcp.json" or normalized.endswith("-plugin/.mcp.json")):
        findings.append(Finding(normalized, "local MCP config included outside plugin package root"))
    if name.startswith(".env"):
        findings.append(Finding(normalized, f"forbidden env file: {name}"))
    if any(name.startswith(prefix) for prefix in FORBIDDEN_PREFIXES):
        findings.append(Finding(normalized, f"forbidden file prefix: {name}"))
    if any(name.endswith(suffix) for suffix in FORBIDDEN_SUFFIXES):
        findings.append(Finding(normalized, f"forbidden file suffix: {name}"))
    if name.endswith((".sqlite", ".sqlite3", ".db")):
        findings.append(Finding(normalized, "database file included in public release artifact"))
    return findings


def _should_scan_content(path: str) -> bool:
    return Path(path).suffix.lower() in TEXT_SUFFIXES


def _inspect_text(path: str, text: str) -> list[Finding]:
    normalized = _normalized(path)
    if normalized.endswith(("scripts/check_release_clean.py", "scripts/validate_public_landing_page.py")):
        return []
    findings: list[Finding] = []
    for token in FORBIDDEN_CONTENT:
        if token in text:
            findings.append(Finding(normalized, f"forbidden content marker: {token}"))
    return findings


def inspect_tree(root: Path) -> list[Finding]:
    findings: list[Finding] = []
    for path in sorted(root.rglob("*")):
        try:
            relative = path.relative_to(root)
        except ValueError:
            continue
        relative_text = str(relative)
        findings.extend(inspect_relative_path(relative_text))
        if path.is_file() and _should_scan_content(relative_text):
            try:
                findings.extend(_inspect_text(relative_text, path.read_text(encoding="utf-8")))
            except UnicodeDecodeError:
                findings.append(Finding(relative_text, "text-like file is not valid UTF-8"))
    return findings


def inspect_zip(archive_path: Path) -> list[Finding]:
    findings: list[Finding] = []
    with zipfile.ZipFile(archive_path) as archive:
        bad_zip = archive.testzip()
        if bad_zip:
            findings.append(Finding(bad_zip, "zip integrity check failed"))
        for name in archive.namelist():
            findings.extend(inspect_relative_path(name))
            if not name.endswith("/") and _should_scan_content(name):
                try:
                    text = archive.read(name).decode("utf-8")
                except UnicodeDecodeError:
                    findings.append(Finding(name, "text-like archive member is not valid UTF-8"))
                    continue
                findings.extend(_inspect_text(name, text))
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description="Check a UXHC release tree or archive for private/local files.")
    parser.add_argument("path", help="Tree or .zip/.mcpb/.skill archive to inspect.")
    args = parser.parse_args()

    target = Path(args.path).expanduser().resolve()
    if not target.exists():
        print(f"release-clean check failed: missing path {target}", file=sys.stderr)
        return 2

    findings = inspect_zip(target) if target.suffix in {".zip", ".mcpb", ".skill"} else inspect_tree(target)
    if findings:
        print(f"release-clean check failed for {target}", file=sys.stderr)
        for finding in findings:
            print(f"- {finding.path}: {finding.reason}", file=sys.stderr)
        return 1

    print(f"release-clean ok: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
