#!/usr/bin/env python3
"""Check UXHC public-directory metadata, docs, examples, and tool contracts."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ux_heuristic_compass.tool_contracts import PUBLIC_TOOL_NAMES, validate_tool_contracts  # noqa: E402


REQUIRED_DOCS = [
    ROOT / "docs/public/mcp-listing-profile.md",
    ROOT / "docs/public/host-compatibility.md",
    ROOT / "docs/public/security-and-boundaries.md",
    ROOT / "docs/public/example-redacted-report.md",
    ROOT / "docs/public/example-redacted-report.html",
]

REQUIRED_DOC_PHRASES = [
    "local-first",
    "bounded",
    "evidence-only",
    "no crawler",
    "auth",
    "compliance",
    "does not require playwright",
    "does not install them",
    "jsonl",
    "sqlite",
]

FORBIDDEN_EXAMPLE_MARKERS = [
    "/Users",
    "/Volumes",
    "file://",
    "href=",
    "<script",
    " src=",
    "@import",
    "url(",
    "PLACE" + "HOLDER",
]


def _failures() -> list[str]:
    failures: list[str] = []
    metadata_path = ROOT / "dist/mcp-directory-metadata.json"
    if not metadata_path.exists():
        return [f"missing {metadata_path.relative_to(ROOT)}"]
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata_tools = metadata.get("tools") or []
    if metadata.get("public_tool_count") != 18:
        failures.append("metadata public_tool_count must be 18")
    if len(metadata_tools) != len(PUBLIC_TOOL_NAMES):
        failures.append("metadata tool list length must match runtime public tool count")
    if set(metadata_tools) != set(PUBLIC_TOOL_NAMES):
        failures.append("metadata tool names must match UXHC PUBLIC_TOOL_NAMES")
    boundaries = metadata.get("boundaries") or {}
    for key in ("full_site_crawling", "auth_automation", "compliance_certification", "mandatory_third_party_services"):
        if boundaries.get(key) is not False:
            failures.append(f"metadata boundary {key} must be false")
    if (metadata.get("evidence_adapters") or {}).get("score_authority") != "evidence_only":
        failures.append("metadata evidence adapters must be score_authority=evidence_only")

    contracts = validate_tool_contracts()
    if contracts["status"] != "ready":
        failures.append(f"tool contracts blocked: {contracts['blockers']}")

    missing_docs = [path for path in REQUIRED_DOCS if not path.exists()]
    failures.extend(f"missing {path.relative_to(ROOT)}" for path in missing_docs)
    doc_text = "\n".join(path.read_text(encoding="utf-8").lower() for path in REQUIRED_DOCS if path.exists())
    for phrase in REQUIRED_DOC_PHRASES:
        if phrase not in doc_text:
            failures.append(f"public docs missing phrase: {phrase}")

    example_text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in [ROOT / "docs/public/example-redacted-report.md", ROOT / "docs/public/example-redacted-report.html"]
        if path.exists()
    )
    for marker in FORBIDDEN_EXAMPLE_MARKERS:
        if marker in example_text:
            failures.append(f"public example contains forbidden marker: {marker}")
    return failures


def main() -> int:
    failures = _failures()
    if failures:
        print("directory-readiness check failed", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        return 1
    print("directory-readiness ok: metadata, docs, examples, and tool contracts are release-ready")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
