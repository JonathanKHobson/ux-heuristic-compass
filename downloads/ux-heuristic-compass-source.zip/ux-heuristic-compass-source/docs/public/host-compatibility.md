# UXHC Host Compatibility

UX Heuristics Compass runs as a local stdio MCP. The host AI owns conversation, visual interpretation, navigation judgment, and any optional external evidence collection. UXHC owns rubric structure, bounded source manifests, scoring contracts, HIL scaffolds, trace summaries, and report generation.

## Supported Host Patterns

- Claude Desktop via MCPB/Desktop Extension.
- Claude Code or Claude Cowork via plugin/source MCP configuration.
- Codex or other local stdio MCP clients via source install.
- Skill-only use for prompt scaffolding when MCP tools are unavailable.

## Evidence Adapter Boundary

UXHC can accept host-supplied evidence from:

- Playwright MCP.
- Chrome DevTools MCP.
- axe-core / Playwright axe.
- Lighthouse.
- Figma MCP.
- Code review or component inspection.
- Manual host observations and human notes.

These adapters are optional. UXHC does not install them, launch them, or require them. Their outputs normalize into the `AuditEvidenceGraph` with `score_authority: "evidence_only"` and can support checklist interpretation, evidence traceability, and reports.

## Rendered Browser Review

When a user supplies HTML, browser-compatible UI code, a generated report, or a local preview, do not stop at static code review if layout, interaction, focus, responsive behavior, loading, or visible copy could change after rendering. Use host-owned Playwright/browser tooling when available, and call `get_started(topic="rendered_review")` for the compact UXHC guidance packet.

- Serve local HTML through HTTP/local server for browser review; avoid `file://` unless the artifact is explicitly static-file safe.
- Capture visible page state, viewport, relevant interaction states, and accessibility snapshot when the host Playwright tool supports it.
- If Playwright/browser automation is unavailable, tell the user and continue as code-only, screenshot-only, or observation-only review with explicit evidence limits.
- Playwright evidence is evidence-only: it can support checklist interpretation, but it must not directly assign UXHC 0-4 scores.

## Figma Evidence Shape

Hosts can pass Figma evidence through existing `external_evidence`, `external_adapter_results`, `adapter_results`, or `evidence_nodes` fields. Accepted adapter aliases include `figma`, `figma_mcp`, `figma_dev_mode`, `figma_node`, `figma_frame`, `figma_component`, and `prototype_frame`; all normalize to `figma_mcp`. Useful records include files, frames, nodes, components, variants, screenshots, prototype states, and design-token notes. Evidence should include stable refs such as `figma-1`, `figma-frame-1`, or `figma-node-hero`, plus labels, parent refs, text summaries, and node metadata when available.

## Handoff Expectations

- Cold hosts should follow the workflow in order: `get_started` -> `prepare_ux_source` with screenshots, rendered evidence, up to 10 explicit URL/source items, and optional `interactive_state_hints` -> choose the quick-scan mode or use `audit_ux_surface` -> if HIL pauses, keep `resume_run_id` and resume the same tool with `hil_answers` or `resolved_gate_ids` -> `validate_ux_report_payload(payload_path=report_payload_ref.path)` -> `generate_ux_audit_report(payload_path=report_payload_ref.path, response_mode="compact")`.
- Host-side tool search may surface only a subset of matching tools. UXHC has 18 public tools; verify `tool_discovery_contract.public_tool_count=18` in `get_started` or `ux_heuristic_overview`, and call `get_started(topic="tools")` for the full contracts if the host initially sees fewer.
- `list_heuristics` is the authoritative rubric discovery tool. Its summary output includes H01-H14 counts plus `support_lens_summary`; call `list_heuristics(topic="support_lenses")` when the host needs the full support-only laws/principles/WCAG/ISO/cultural/CX corpus without running an audit.
- `quick_scan_ux` without `output_detail` returns a one-question mode gate. Use `output_detail="guidance_only"` for tiny non-scored refinement help, `output_detail="status_only"` for small scored-audit orchestration, and `compact`/`full` only for diagnostics.
- Use `status_only` as the normal orchestration response for large scored audits. Request `output_detail="compact"` or `output_detail="full"` only when the host needs diagnostic audit details.
- Source batches are explicit-only. UXHC may prepare up to 10 supplied source items, but it does not crawl links, discover sitemap pages, automate auth, or click through hidden states by itself.
- Use `interactive_state_hints` to name expected tabs, accordions, toggles, modals, empty/error/loading states, or platform states. Captured hints should be backed by `state_labels` or evidence refs; uncaptured hints become evidence limits.
- Status-only audit output and reports include an active-scope badge such as `Active scope: H1-H14, 102/102 scored` so readers can see what was actually scored.
- Paused HIL responses write local beta checkpoints under the UXHC state directory. `resume_run_id` restores source, platform, profiles, checklist ratings, scorecard, HIL gates, and report payload context; the host should not resend the whole 102-item payload just to answer HIL gates.
- `host_question_ui_status` should reflect what happened: `native_rendered`, `fallback_text_used`, `unavailable`, or `skipped`. Reports distinguish `native_rendered`, `fallback_text_used`, `unavailable_resolved`, `blocked_until_native_ui`, and `skipped`.
- If `output_path` is omitted, UXHC writes Markdown and adjacent static HTML into the local UXHC state reports directory and returns the paths. Hosts should use these paths instead of asking the model to paste full report content into chat.
- Static reports include a compact Evidence Gallery when evidence exists. The gallery is a report-safe traceability layer: it groups evidence cards by finding and shows refs, state labels, screenshot/source paths, capture metadata, parent/region refs, bounds, and notes without scripts, links, or external assets.
- When culturally situated findings are evidence-backed, reports may include a support-only Cultural Context Signal and Cultural Context Integrity Advisory. Treat this as context guidance, not cultural certification, community approval, or a replacement for local/community review.
- When WCAG/accessibility findings are evidence-backed, reports may include a support-only Accessibility Readiness Signal and WCAG-Informed Accessibility Readiness section. Treat the WCAG Level Signal as an evidence-limited support cue, not WCAG, ADA, legal, procurement, or conformance certification.
- ISO UX/UI/HCI support lenses can appear in finding support lenses and the Supporting UX Laws And Principles report section. Treat them as ISO-informed support references only, not ISO compliance, conformance, certification, procurement proof, or legal assurance.
- CX/service-journey support lenses can appear in finding support lenses and the Supporting UX Laws And Principles report section. Treat them as CX support references only, not proof of ROI, NPS, retention, loyalty, satisfaction, revenue, churn, or real-customer outcomes.
- Corpus support lenses now carry normalized family wording for source quality, applicability, evidence needed, and reporting guardrails. Hosts should preserve that phrasing instead of converting support references into scores, compliance claims, universal cultural claims, business-outcome claims, or user-testing claims.
- Optional `run_visual_qa=True` is a report-generation smoke check, not a required dependency. UXHC preflights Playwright availability first; if unavailable, no browser is launched and report generation returns a warning. If visual QA runs, UXHC closes only its own temp-profile browser session and reports owned handoff metadata.
- If `quick_scan_ux` returns an unscored `quick_ux_risk_card`, treat it as a first-pass risk snapshot only. Do not show grades until complete checklist ratings are supplied.
- If `quick_scan_ux` returns a `guidance_only_card`, treat it as host-assist guidance only. It is not a grade, scorecard, report payload, compliance finding, or user-testing result.
- If `validate_ux_report_payload` or `generate_ux_audit_report` returns repair tasks, repair the payload and retry the UXHC renderer. Do not create handmade fallback HTML, PDF, or standalone reports.
- Feedback can be converted into JSON/Markdown issue bundles with `scripts/export_feedback_issues.py`; this is intentionally script/internal-helper only and does not add a public MCP tool.
- Desktop/mobile comparison reports use platform labels, compact platform report context, HIL status, active-scope summaries, evidence counts, evidence appendix rows, and checklist visibility without duplicating entire audit payloads.
- If the host captures browser evidence, it must clean up its own automation session.
- UXHC only owns browser processes it launches with a UXHC temp profile.
- Other clients' Playwright or Chrome DevTools processes are external automation and must not be killed by UXHC.
- Report generation should use `validate_ux_report_payload` and `generate_ux_audit_report`; hosts should not handmake reports when UXHC returns repair tasks.

## Claim Boundaries

- Heuristic audit findings are potential usability risks unless supported by real participant evidence.
- Synthetic walkthrough support is not real participant research and should not be described as user-tested validation.
- Automated accessibility evidence is useful, but UXHC does not certify WCAG, ADA, or full accessibility compliance.
- Figma evidence is design-time evidence unless paired with rendered/runtime evidence.
