# UX Heuristic Compass Audit Report

Generated: 2026-05-03

## Executive Summary

- Platform: desktop
- Core grade: A++ (98.53%) - Exceptional - industry benchmark
- Expanded grade: N/A (N/A%)
- Overall label: A++ - Exceptional - industry benchmark
- Plain-language read: The biggest visible usability risk is primary action hierarchy is not clear. It affects Aesthetic and Minimalist Design and should be fixed before broader polish.
- Before using this interface: Before using this interface, address Aesthetic and Minimalist Design first: Make the primary action the clearest visual starting point and reduce secondary actions around it.
- Top priority: Aesthetic and Minimalist Design: Primary action hierarchy is not clear
- One recommendation: Make the primary action the clearest visual starting point and reduce secondary actions around it.
- Source status: ready

## Heuristic Grade Table

| Heuristic | Items | Avg Severity | Quality | Grade |
|---|---:|---:|---:|---|
| Visibility of System Status | 9 | 0.0 | 100.0% | A++ |
| Match Between System and the Real World | 3 | 0.0 | 100.0% | A++ |
| User Control and Freedom | 5 | 0.4 | 90.0% | A+ |
| Consistency and Standards | 21 | 0.0 | 100.0% | A++ |
| Error Prevention | 5 | 0.0 | 100.0% | A++ |
| Recognition Rather Than Recall | 4 | 0.0 | 100.0% | A++ |
| Flexibility and Efficiency of Use | 9 | 0.0 | 100.0% | A++ |
| Aesthetic and Minimalist Design | 16 | 0.19 | 95.31% | A++ |
| Help Users Recognize, Diagnose, and Recover from Errors | 2 | 0.0 | 100.0% | A++ |
| Help and Documentation | 5 | 0.0 | 100.0% | A++ |

## Audit Scope and Omitted Profiles

- Scope status: core_scope_no_optionals
- Optional profile mode: scoped
- Full advanced requested: False
- Scored optional profiles: none
- Omitted optional profiles:
  - accessibility (h11): Accessibility and Ease of Access
  - inclusion (h12): Empathetic Engagement and Inclusion
  - journey (h13): Customer Journey and Satisfaction
  - ux_writing (h14): UX Writing and Content Design
- Rerun guidance: For a full advanced audit, rerun with optional_profile_mode='all_optionals' or profiles=['accessibility','inclusion','journey','ux_writing'].

## Severity Summary

- Severity 4: 0
- Severity 3: 1
- Severity 2: 1
- Severity 1: 0
- Severity 0: 77

## Top Findings

### Primary action hierarchy is not clear

- Checklist item: h08_d_02
- Heuristic: Aesthetic and Minimalist Design
- Severity: 3 - Major - high priority fix
- Evidence: img-1
- Confidence: medium
- Issue: The primary action is present but does not appear visually dominant enough for the main task.
- Recommendation: Make the primary action the clearest visual starting point and reduce secondary actions around it.

### Users may lack clear recovery paths

- Checklist item: h03_d_02
- Heuristic: User Control and Freedom
- Severity: 2 - Minor - low priority fix
- Evidence: img-1
- Confidence: medium
- Issue: Back/recovery behavior needs clearer persistence cues in the current flow.
- Recommendation: Add or clarify exits, back behavior, and recovery controls so users can leave wrong paths without losing context.


## Owner-Role Triage Matrix

| Owner | Linked finding | Next action | Impact | Effort | Confidence | Supporting roles |
|---|---|---|---|---|---|---|
| Designer | h08 / h08_d_02 | Make the primary action the clearest visual starting point and reduce secondary actions around it. | This checklist item indicates measurable heuristic friction for the evaluated surface. | Low-Medium | medium |  |
| Engineer | h03 / h03_d_02 | Add or clarify exits, back behavior, and recovery controls so users can leave wrong paths without losing context. | This checklist item indicates measurable heuristic friction for the evaluated surface. | Low | medium |  |

## Checklist Issue Ledger

| Item | Rating | Confidence | Evidence | Rationale |
|---|---:|---|---|---|
| h03_d_02 | 2.0 | medium | img-1 | Back/recovery behavior needs clearer persistence cues in the current flow. |
| h08_d_02 | 3.0 | medium | img-1, figma-frame-1 | The primary action is present but does not appear visually dominant enough for the main task. |

## Complete Checklist Scores

<details>
<summary>Visibility of System Status (h01) - 9 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h01_d_01 | Every interface begins with a title/header that describes page contents | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_02 | Headings and subheadings are short, straightforward and descriptive | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_03 | Value proposition is clearly stated on the home page (tagline or welcome blurb) | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_04 | The items on the home page are clearly focused on primary actions | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_05 | Each page is clearly branded so that the user knows they are on the same site | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_06 | Navigation makes it clear which page I am on | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_07 | Link names match the title of destination pages, so users will know when they have reached the intended page | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_08 | Standard elements (page titles, site navigation, page navigation, privacy policy, etc.) are easy to locate | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h01_d_09 | Logo is in a consistent location, and clicking the logo returns the user back to the home page | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Match Between System and the Real World (h02) - 3 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h02_d_01 | Navigation tabs are located at the top of the page, and look like clickable versions of real-world tabs | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h02_d_02 | Items that are not clickable do not have characteristics that suggest that they are clickable | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h02_d_03 | Items that are clickable look like they are clickable | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>User Control and Freedom (h03) - 5 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h03_d_01 | There is a search box | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h03_d_02 | There are clearly marked exits on every page allowing the user to bail out of the current task without having to depend on the browser Back button | 2.0 | medium |  | img-1 | Back/recovery behavior needs clearer persistence cues in the current flow. |
| h03_d_03 | The site does not disable the browser Back button and the Back button appears on the browser toolbar on every page | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h03_d_04 | Clicking the back button always takes the user back to the page they came from | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h03_d_05 | Undo and redo are supported | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Consistency and Standards (h04) - 21 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h04_d_01 | In your expert opinion, site content does not look like advertisements | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_02 | Clickable elements use a consistent style/color for primary, secondary, and tertiary actions | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_03 | Value proposition is clearly stated on the home page (tagline or welcome blurb) | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_04 | Navigation choices are ordered in the most logical or task-oriented manner, with less important corporate information at the bottom | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_05 | All corporate information is grouped in one distinct area, such as About Us | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_06 | The home page of the site has a memorable URL | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_07 | Terminology is consistent with general web usage | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_08 | There is a visible change when the mouse points at something clickable, excluding cursor changes | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_09 | Hypertext links that invoke actions, such as downloads or new windows, are clearly distinguished from hypertext links that load another page | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_10 | If the site spawns new windows, these will not confuse the user and can be easily closed | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_11 | Menu instructions, prompts and messages appear in the same place on each screen | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_12 | The content is up-to-date, authoritative and trustworthy | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_13 | The site contains third-party support, such as citations or testimonials, to verify the accuracy of information | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_14 | It is clear that there is a real organization behind the site, such as a physical address or office photo | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_15 | The content is fresh: the site includes recent content | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_16 | The site is free of typographic errors and spelling mistakes | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_17 | The visual design is consistent, including colors, layout, iconography, etc. | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_18 | On content pages, line lengths are neither too short (under 50 characters per line) nor too long (over 100 characters per line) when viewed in a standard browser width window | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_19 | Fonts are used consistently and are legible | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_20 | The site can be used without scrolling horizontally | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h04_d_21 | Design components, such as radio buttons and checkboxes, are used appropriately | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Error Prevention (h05) - 5 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h05_d_01 | Pages are free of scroll stoppers: headings or page elements that create the illusion that users have reached the top or bottom of a page when they have not | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h05_d_02 | The user does not need to consult user manuals or other external information to use the site | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h05_d_03 | User confirmation is required before carrying out potentially dangerous actions, such as deleting something | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h05_d_04 | The site provides feedback that helps the user learn how to use the site | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h05_d_05 | There is sufficient space between targets to prevent the user from hitting multiple or incorrect targets | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Recognition Rather Than Recall (h06) - 4 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h06_d_01 | Search suggestions or filters are provided | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h06_d_02 | Each page is clearly labeled with a descriptive and useful title that makes sense as a bookmark | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h06_d_03 | Links and link titles are descriptive and predictive, and there are no Click here links | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h06_d_04 | Buttons and links show that they have been clicked | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Flexibility and Efficiency of Use (h07) - 9 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h07_d_01 | Useful content is presented on the home page or within one click of the home page | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_02 | The terms used for navigation items and hypertext links are unambiguous and jargon-free | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_03 | If there are product pages, they contain the detail necessary to make a purchase, and users can zoom in on product images | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_04 | The words, phrases and concepts used will be familiar to the typical user | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_05 | Content feels friendly for new users | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_06 | Content feels customizable or useable for frequent or expert users | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_07 | The screen density is appropriate for the target users and their tasks | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_08 | Icons and graphics are standard and/or intuitive (concrete and familiar) | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h07_d_09 | Where tooltips are used, they provide useful additional help and do not simply duplicate text in the icon, link or field label | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Aesthetic and Minimalist Design (h08) - 16 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h08_d_01 | By just looking at the home page, the first time user will understand where to start | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_02 | Primary actions are easy to find and understand | 3.0 | medium |  | img-1, figma-frame-1 | The primary action is present but does not appear visually dominant enough for the main task. |
| h08_d_03 | Individual pages are free of clutter and irrelevant information, and attention-attracting features are used sparingly and only where relevant | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_04 | The home page is professionally designed and will create a positive first impression | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_05 | The home page looks like a home page; pages lower in the site will not be confused with it | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_06 | The site avoids advertisements, especially pop-ups | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_07 | Text is concise, with no needless instructions or welcome notes | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_08 | Pages use bulleted and numbered lists in preference to narrative text | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_09 | The most important items in a list are placed at the top | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_10 | Pages are quick to scan, with ample headings and subheadings and short paragraphs | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_11 | Information is organized hierarchically, from the general to the specific, and the organization is clear and logical | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_12 | Text links are long enough to be understood, but short enough to minimize wrapping, especially when used as a navigation list | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_13 | On all pages, the most important information, such as frequently used topics, features and functions, is presented on the first screenful of information above the fold | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_14 | The relationship between controls and their actions is obvious | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_15 | There is a clear visual starting point to every page | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h08_d_16 | The site is pleasant to look at | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Help Users Recognize, Diagnose, and Recover from Errors (h09) - 2 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h09_d_01 | The site uses a customised 404 page, which includes tips on how to find the missing page and links to Home and Search | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h09_d_02 | Error messages contain clear instructions on what to do next, including form error states | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>

<details>
<summary>Help and Documentation (h10) - 5 checklist items</summary>

| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |
|---|---|---:|---|---|---|---|
| h10_d_01 | Help is available and easy to find | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h10_d_02 | FAQs are present if appropriate | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h10_d_03 | When giving instructions, pages tell users what to do rather than what to avoid doing | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h10_d_04 | The site shows users how to do common tasks where appropriate, such as demonstrations of the site's functionality | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |
| h10_d_05 | It is easy to contact someone for assistance and a reply is received quickly | 0.0 | medium |  | img-1 | No visible issue in this public-safe example fixture. |

</details>


## Evidence Limits

- No major evidence limits were recorded.

## Evidence Appendix

| Evidence ref | Parent | Source type | Quality | Label/title | Bounds/notes | Screenshot | Metadata |
|---|---|---|---|---|---|---|---|
| img-1 |  | screenshot | ready | Example home screen |  | [local path redacted]|  |
| figma-frame-1 |  | figma_frame | ready | Landing page hero frame | x=0, y=0, width=1440, height=900 | https://www.figma.com/file/example/[sensitive label redacted]?[query redacted] |  |
| figma-token-1 | figma-frame-1 | design_token_note | ready | CTA color token note |  |  |  |

## Follow-Up Activity

### Try This Next: Navigation Recovery Walkthrough

- Why this fits: H3 issues often show up when users take a wrong path and cannot recover without friction.
- Content focus: User control, exits, back behavior, and undo/recovery paths.
- Thinking focus: Where can the user safely go next if their first choice is wrong?
- Source note: Curated from UX Heuristic Compass.
- Steps:
  - Pick the affected screen.
  - Ask one person what they notice first.
  - Compare their answer to the intended task.

### Solo Activity: Navigation Recovery Walkthrough

- Why this fits: H3 issues often show up when users take a wrong path and cannot recover without friction.
- Content focus: User control, exits, back behavior, and undo/recovery paths.
- Thinking focus: Where can the user safely go next if their first choice is wrong?
- Source note: Curated from UX Heuristic Compass.
- Steps:
  - Write the target task.
  - Walk the screen slowly from the user's point of view.
  - Mark each moment of hesitation, uncertainty, or extra memory load.

### Group Activity: Navigation Recovery Walkthrough

- Why this fits: H3 issues often show up when users take a wrong path and cannot recover without friction.
- Content focus: User control, exits, back behavior, and undo/recovery paths.
- Thinking focus: Where can the user safely go next if their first choice is wrong?
- Source note: Curated from UX Heuristic Compass.
- Steps:
  - Give each reviewer the same task.
  - Have reviewers mark friction independently.
  - Discuss only the mismatches and choose one fix to test.

- Fit check: After the activity, ask whether the result confirmed the audit finding, weakened it, or revealed a different priority.

## Reasoning Flow Suggestions

- No reasoning-flow suggestion was needed for this audit.

## Evaluator Bias Advisories

- Halo Effect: H8 is very high while functional heuristics have issues. Separate visual polish from task success. Mitigation: Audit functional heuristics before aesthetic ones and separate visual polish from task success.

## Prioritization Flow

- Not needed because the overall score is above B.

## Human Review

- Pause required: False
- Stage: none
- Native question UI status: unknown
- HIL blocked until native UI: False
- Resolved gates: none
- Unresolved gates: none

## Recommended Next Validation

- Fix severity 3-4 checklist items first, then rerun the same source state for comparison.

## Scope Note

This report is a heuristic evaluation artifact. It does not replace usability testing, analytics, accessibility compliance review, or direct user research.
