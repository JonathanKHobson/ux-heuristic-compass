# UX Heuristics Compass MCP Listing Profile

UX Heuristics Compass is a local-first MCP for bounded UX heuristic audits of visible interface evidence. It helps a host AI and reviewer turn screenshots, image bundles, public page captures, or host-supplied adapter evidence into checklist-level 0-4 ratings, grades, evidence limits, HIL scaffolds, and static reports.

## What It Does

- Prepares bounded interface evidence for review.
- Scores active checklist items across 14 UX heuristics.
- Generates UX Health Snapshots, findings, recommendations, and reports.
- Accepts evidence-only outputs from Playwright MCP, Chrome DevTools MCP, axe/Playwright axe, Lighthouse, Figma MCP, code review, host observations, and human notes.
- Saves local beta checkpoints for paused HIL audits so hosts can resume by `resume_run_id` without resubmitting all checklist ratings.
- Supports up to 10 explicit bounded source items plus host-supplied state hints for tabs, toggles, modals, loading, empty, error, and viewport states.
- Renders active-scope and desktop/mobile comparison summaries so stakeholders can see what was actually scored.
- Produces Markdown, static no-link HTML, and optional PDF reports.
- Supports public-safe report rendering for examples and sharing.

## What It Does Not Do

- It does not crawl full sites.
- It is no crawler and does not run unbounded navigation.
- It does not automate authenticated flows.
- It does not operate as an autonomous browser agent.
- It does not certify ADA, WCAG, privacy, security, legal, or compliance status.
- It does not require Playwright, Chrome DevTools, Figma, Lighthouse, axe, or any external MCP.
- It does not let adapter outputs set UXHC scores directly.

## Tool Surface

The public MCP surface is intentionally stable at 18 tools. New behavior should normally be added as fields, contracts, evidence nodes, docs, or report support inside existing tools.

## Best Fit

UXHC is best for builders, designers, product owners, educators, and local-first AI workflows that need a practical UX audit before shipping an interface. It is a heuristic audit assistant, not a replacement for participant research or accessibility certification.

## Cold-Host Quickstart

1. Start with `get_started` to read current tool contracts, optional profiles, and boundaries.
2. Use `prepare_ux_source` for a bounded screenshot, image bundle, page capture manifest, host-supplied evidence graph, or up to 10 explicit URL/source items. Add `interactive_state_hints` when tabs, accordions, toggles, modals, or alternate states matter.
3. Use `quick_scan_ux(output_detail="guidance_only")` for tiny non-scored refinement help, or `quick_scan_ux(output_detail="status_only")` / `audit_ux_surface` for scored-audit orchestration.
4. If `quick_scan_ux` is called without `output_detail`, UXHC returns a one-question mode gate for `guidance_only`, `status_only`, `compact`, or `full`.
5. Request `output_detail="compact"` or `output_detail="full"` only when diagnostic audit detail is needed.
5. If HIL pauses, use the host's native question UI when available, keep `resume_run_id`, and resume the same tool with answers or resolved gate IDs; do not flatten required questions into ordinary markdown.
6. Use `validate_ux_report_payload(payload_path=report_payload_ref.path)` and then `generate_ux_audit_report(payload_path=report_payload_ref.path, response_mode="compact")` for stakeholder artifacts. Repair returned payload issues and retry the UXHC renderer rather than handmaking HTML.

Reports can include support-only corpus advisory modules when relevant. Shipped modules include Accessibility Readiness Signal / WCAG-Informed Accessibility Readiness and Cultural Context Signal / Cultural Context Integrity Advisory. ISO UX/UI/HCI and CX/service-journey support lenses can also appear as ordinary support references in findings and the Supporting UX Laws And Principles section. These summarize evidence-backed support cues without changing the H01-H14 scorecard, certifying accessibility or cultural safety, proving ISO compliance/conformance, proving business outcomes, or replacing expert/local/community review. Corpus family phrasing is normalized for source quality, applicability, evidence needed, and claim boundaries, and overclaim regressions cover WCAG/ISO/cultural/CX/synthetic-user/score-authority drift.

Host discovery note: UXHC exposes 18 public tools. Some hosts initially surface only a subset during tool search, so `get_started` and `ux_heuristic_overview` include an authoritative `tool_discovery_contract`, and `get_started(topic="tools")` exposes the full contracts.

Rubric discovery note: `list_heuristics` exposes H01-H14 and a compact `support_lens_summary` by default. `list_heuristics(topic="support_lenses")` surfaces the support-only laws, principles, WCAG/accessibility, ISO, cultural-context, and CX corpus without requiring an audit.

## Trust Postcard

UXHC can support checklist completeness, evidence refs, local report generation, static HTML safety, HIL pause/resume contracts, evidence-only adapter boundaries, and public-safe redacted artifacts.

UXHC cannot prove real participant success, full accessibility compliance, legal compliance, authenticated-flow behavior, whole-site quality, or automatic UX truth.
