# UX Heuristic Compass MCP: Market-Aware Technical Brief For Deep Research

Snapshot date: 2026-05-04

This brief is for a competitive deep-research agent evaluating UX Heuristic Compass, or UXHC, against MCPs, Claude/Codex skills, AI UX audit products, browser-evidence tools, accessibility tools, design QA systems, and adjacent frontend review workflows.

Use this as an expert-to-expert technical handoff. It combines:

- repo-verified UXHC implementation facts from the local UXHC repository;
- a supplied market-analysis snapshot from Kyle, not live-verified in this document;
- explicit market-derived gaps and next improvement lanes.

Do not treat competitor claims in this brief as independently verified current facts. Treat them as research leads and compare them against live sources during the research task.

## 1. Core Product Thesis

UXHC is a local-first Model Context Protocol server for bounded interface heuristic audits.

Mission:

> Help a reviewer evaluate a visible interface before it ships by converting bounded evidence into a complete heuristic scorecard, plain-language UX risks, and concrete next actions.

Current positioning:

> UXHC is not a crawler, not a synthetic-user simulator, not a black-box UX score, and not a broad UX research platform. It is a local-first MCP audit contract and report engine that helps AI hosts turn bounded interface evidence into complete, evidence-limited, validated heuristic reports.

The host AI owns conversation, visual interpretation, navigation judgment, and any optional external evidence collection. UXHC owns:

- rubric structure;
- stable checklist IDs;
- source manifests;
- evidence graph normalization;
- checklist-rating validation;
- scoring and grade aggregation;
- human-in-the-loop scaffolding;
- run traces;
- report payload validation and repair tasks;
- static report artifacts.

The most important differentiation is not "AI can audit UX." Many products and skills claim that. UXHC's stronger lane is:

> evidence-bound audit contract + checklist-complete scoring + local report validation for host AIs.

## 2. Repo-Verified Current State

Repository root:

```text
<local UXHC repository>
```

Runtime command:

```bash
python3 server.py --self-test
```

Project MCP config:

```text
.mcp.json
```

Stable Python runtime used by the project MCP config:

```text
<local UXHC Python runtime>
```

Runtime state defaults to:

```text
~/.local/share/ux-heuristic-compass/state
```

The state location can be overridden with `UXHC_STATE_DIR`.

Main package shape:

```text
server.py
ux_heuristic_compass/
  addons.py
  agents.py
  audit.py
  behavior.py
  calibration.py
  comparison.py
  evidence.py
  knowledge.py
  report.py
  rubric.py
  scoring.py
  source.py
  state.py
  tracing.py
  usability.py
  data/
    evaluator_bias_registry.json
    uxhc_activities.json
    uxhc_flows.json
tests/test_runtime.py
tests/fixtures/uxhc_eval_fixture_seed_20260504.jsonl
docs/planning/
docs/public/
dist/mcp-directory-metadata.json
scripts/generate_health_dashboard.py
scripts/check_release_clean.py
reports/
```

Current verified tool count: 18 public MCP tools.

```text
get_started
ux_heuristic_overview
list_heuristics
prepare_ux_source
quick_scan_ux
audit_ux_surface
validate_ux_report_payload
generate_ux_audit_report
calibrate_ux_sensitivity
calibrate_ux_severity
compare_ux_audits
draft_project_addon_profile
save_preferences
update_preferences
run_agent_audit
get_agent_run
run_usability_test
stress_test_heuristic_finding
```

Design constraint: competitive improvements should normally be added through existing tools, contracts, schemas, report outputs, docs, examples, or optional context fields. Do not recommend new public tools unless a workflow truly cannot be handled by the current surface.

## 3. Rubric, Checklist, And Scoring Contract

Rubric module: `ux_heuristic_compass/rubric.py`

Scoring module: `ux_heuristic_compass/scoring.py`

Baseline rubric:

```text
H01 Visibility of System Status
H02 Match Between System and the Real World
H03 User Control and Freedom
H04 Consistency and Standards
H05 Error Prevention
H06 Recognition Rather Than Recall
H07 Flexibility and Efficiency of Use
H08 Aesthetic and Minimalist Design
H09 Help Users Recognize, Diagnose, and Recover from Errors
H10 Help and Documentation
```

Optional general profiles:

```text
accessibility -> H11 Accessibility and Ease of Access
inclusion -> H12 Empathetic Engagement and Inclusion
journey -> H13 Customer Journey and Satisfaction
ux_writing -> H14 UX Writing / Content and Tone
```

Current counts:

```text
14 total heuristics
10 core heuristics
4 optional heuristics
79 core checklist items per platform
23 optional checklist items per platform
204 dual-platform all-optionals checklist items
```

Checklist item IDs are stable:

```text
h{heuristic_number_zero_padded}_{platform_initial}_{item_index_zero_padded}
```

Examples:

```text
h01_d_01
h08_d_02
h11_m_03
```

Canonical rating scale:

```text
0 = No issue - heuristic passed
1 = Cosmetic - fix if time permits
2 = Minor - low priority fix
3 = Major - high priority fix
4 = Catastrophic - must fix immediately
```

Quality percentage is inverted from severity:

```text
quality_percentage = (1 - sum(ratings) / (item_count * 4)) * 100
```

Therefore:

```text
100% = every active checklist item scored 0
0% = every active checklist item scored 4
```

Scoring outputs include:

- normalized checklist ratings;
- per-heuristic quality percentages, grades, and descriptors;
- core grade;
- expanded optional grade when optional profiles are active;
- overall grade;
- top findings;
- evidence limits;
- missing/duplicate/unknown/deprecated checklist diagnostics.

Optional rating fields now include:

```text
severity_basis
finding_title
recommendation
owner_role
triage
```

`severity_basis` can carry impact, frequency, persistence, scope, confidence, and evidence strength. It does not change the canonical 0-4 score.

## 4. Source Preparation And Bounded Evidence

Source module: `ux_heuristic_compass/source.py`

Primary source tool: `prepare_ux_source`

Supported baseline inputs:

- local screenshot files;
- image bundles;
- bounded public URL capture requests;
- visible text summaries supplied by host;
- state labels and task-flow labels;
- host-supplied external evidence records;
- screenshot-region evidence records.

Bounded URL capture:

- capped at 10 explicit pages/source items;
- reports `requested_max_pages`, `effective_max_pages`, and `max_pages_capped` warning when capped;
- `capture_urls=True` may use local Chrome if available;
- `render_wait_ms` accepts bounded numeric and numeric-string input;
- likely SPA/loading states produce warnings.

Browser handoff boundary:

UXHC only owns Chrome processes launched with its own temporary `uxhc-chrome-profile`. External Playwright, Chrome DevTools, Claude, Codex, or other browser automation sessions are advisory only and must not be killed by UXHC.

Explicit non-goals:

- no full-site crawler;
- no authenticated flow automation;
- no autonomous browser-agent navigation;
- no analytics/session replay ingestion;
- no default competitor scraping.

## 5. AuditEvidenceGraph And Adapter Boundary

Evidence module: `ux_heuristic_compass/evidence.py`

Schema:

```text
uxhc.evidence_graph.v1
```

UXHC now has an internal `AuditEvidenceGraph` that normalizes evidence into typed nodes. Supported node categories include:

- screenshot;
- screenshot region, such as `img-1:r1`;
- visible text summary;
- accessibility snapshot;
- DOM snippet;
- DevTools trace;
- axe/Lighthouse result;
- Figma file/frame/node/component/variant/screenshot/prototype/design-token note;
- code component;
- host observation;
- human note.

Evidence refs are validated against graph nodes. Unknown refs warn by default and become blockers only when strict evidence validation is requested.

Adapter policy:

```text
score_authority: "evidence_only"
```

UXHC accepts host-supplied adapter output, but does not install, launch, require, or trust adapters as direct scoring authorities.

Supported adapter labels:

```text
playwright_mcp
chrome_devtools_mcp
axe_core_playwright
lighthouse
figma_mcp
host_supplied
```

Figma support is shipped as host-supplied evidence normalization. It is not a live Figma connector inside UXHC. Accepted Figma-oriented aliases include:

```text
figma
figma_mcp
figma_dev_mode
figma_node
figma_frame
figma_component
figma_variant
figma_screenshot
prototype_frame
design_token_note
```

Important distinction for researchers:

```text
design evidence != rendered evidence != interaction evidence != participant evidence
```

This distinction is a market advantage. Many tools collapse evidence types into one confidence surface. UXHC should continue separating them.

## 6. Audit Modes And HIL Contract

Audit module: `ux_heuristic_compass/audit.py`

Quick path:

```text
quick_scan_ux
```

Advanced path:

```text
audit_ux_surface
```

Quick audit is the lighter host-AI route. It can return compact scorecard-first output when checklist ratings are supplied, and light context questions when HIL is requested or context is missing.

Advanced audit is the full checklist-level route. It validates scope, ratings, evidence refs, HIL state, report readiness, support flows, and report payloads.

Optional profile controls:

```text
optional_profile_mode = core_only | scoped | all_optionals | ask
full_advanced = compatibility flag
```

If a caller asks for a full advanced audit but omits optional profiles, UXHC returns an `audit_scope_lock` with scored and omitted heuristics.

Human-loop behavior is contract-driven. When pausing, UXHC returns:

- `PAUSE_REQUIRED`;
- `required_surface: native_question_ui`;
- `host_instruction`;
- `ask_user_question_call`;
- MCP elicitation-compatible `elicitation_request`;
- `HIL_BLOCKED_UNTIL_NATIVE_UI`;
- resume contract.

HIL cadence:

```text
Quick audit: 3 pre-audit context questions when needed
Advanced beginning: exactly 3 context questions
Advanced middle: exactly 3 batched calibration questions
Advanced final: exactly 3 reflection/report-readiness questions
```

Resume happens through existing audit tools via:

```text
hil_answers
host_question_ui_status
rating_overrides
resolved_gate_ids
```

There is no separate HIL resume tool, preserving the 18-tool surface.

## 7. Behavioral Support Layer

Behavior module: `ux_heuristic_compass/behavior.py`

Knowledge loader: `ux_heuristic_compass/knowledge.py`

Registries:

```text
uxhc_flows.json
uxhc_activities.json
evaluator_bias_registry.json
```

Current knowledge layer includes dozens of support flows, teaching/validation activities, and 10 evaluator-bias records. These are support layers, not product center.

Core Audit First rule:

Completed audits must lead with source scope, UX Health Snapshot, checklist scorecard, top finding, plain-language read, and one concrete recommendation before Atlas cards, teaching activities, bias advisories, or agent frames.

Support flows and activities can help with:

- checklist interpretation;
- evidence quality;
- severity/confidence calibration;
- prioritization;
- next-step validation;
- HIL teaching.

They must not turn UXHC into a generic UX research platform.

Bias records include confirmation bias, framing effect, availability heuristic, attractiveness bias, cultural bias, data-driven rationality bias, anchoring bias, mere exposure effect, halo effect, and Dunning-Kruger effect.

## 8. Agent And Usability Modes

Agent module: `ux_heuristic_compass/agents.py`

Tool:

```text
run_agent_audit
```

User-facing language:

```text
Researcher persona scorecard aggregation
```

This is not autonomous execution. The response says `execution_mode: host_ai_executes`. The host embodies researcher personas and submits per-agent scorecards. UXHC validates, averages, flags disagreements, attaches bias context, persists the run, and can return a Six Hats frame for Agent Mode 1.

Persistence:

```text
get_agent_run(agent_run_id)
```

Usability module: `ux_heuristic_compass/usability.py`

Tool:

```text
run_usability_test
```

User-facing language:

```text
Bounded usability-test prep/synthetic walkthrough support
```

This is not real participant research unless real participant logs are supplied. It supports task scope, audience/persona setup, bounded walkthrough scaffolding, interview validity checks, transcript-analysis support, and interview planning.

This is strategically important because the market uses "synthetic users" aggressively. UXHC should not overclaim synthetic-user validity.

## 9. Reports, Repair, Redaction, And Comparison

Report module: `ux_heuristic_compass/report.py`

Tools:

```text
validate_ux_report_payload
generate_ux_audit_report
```

Reports are generated through UXHC's renderer, not handmade by the host AI. The renderer writes Markdown and static one-page HTML by default, with optional PDF when `include_pdf=True`.

Report design constraints:

- scorecard and findings lead;
- static no-link HTML;
- no external assets;
- no JavaScript-dependent checklist rows;
- evidence refs and paths render as plain text;
- evidence appendix included;
- checklist tables include item ID, text, score, confidence, evidence, and rationale;
- validation steps appear before roadmap;
- support sections appear after core audit findings.

Validation failures return `repair_tasks[]` with exact slot-specific repair instructions. Host instruction: repair the payload and retry UXHC; do not create standalone HTML manually.

Redaction:

```text
redaction_mode = none | local_paths | public_safe
```

`public_safe` redacts rendered artifacts only. It does not mutate raw audit payloads. It removes local paths, private URL details, emails, token-looking values, and caller-supplied sensitive labels.

P1/P2 report polish shipped:

- screenshot-region refs in evidence appendix;
- public-safe redaction;
- Implementation Readiness Advisory as support-only;
- owner-role triage matrix for Designer, Engineer, Product, and Research;
- comparison report payloads;
- public-safe redacted example reports in `docs/public/`.

Comparison module: `ux_heuristic_compass/comparison.py`

Tool:

```text
compare_ux_audits
```

It returns fixed, new, unresolved, and severity-changed findings, plus a `comparison_report_payload` that can be rendered by `generate_ux_audit_report`.

## 10. Observability And Distribution

Trace module: `ux_heuristic_compass/tracing.py`

Every public MCP call can persist compact JSONL `UXHCRunSummary` traces. Traces record:

- run ID;
- tool name;
- source IDs;
- evidence counts;
- checklist-rating counts;
- blockers;
- warnings;
- payload/report paths;
- HIL state;
- adapter sources.

JSONL remains the beta trace store. SQLite should be reconsidered only if real beta usage shows that JSONL trace reads are slow, cross-run filtering becomes necessary, or state inspection becomes painful.

Health dashboard:

```text
scripts/generate_health_dashboard.py
```

Public distribution metadata:

```text
dist/mcp-directory-metadata.json
```

Public docs:

```text
docs/public/mcp-listing-profile.md
docs/public/host-compatibility.md
docs/public/security-and-boundaries.md
docs/public/example-redacted-report.md
docs/public/example-redacted-report.html
```

Distribution docs state:

- local-first;
- bounded source handling;
- no crawler;
- no auth automation;
- no compliance certification;
- no mandatory Playwright/Chrome/Figma/axe/Lighthouse dependency;
- adapter outputs are evidence-only;
- public-safe report rendering is opt-in.

## 11. Supplied Market Landscape Snapshot

This section summarizes the market analysis supplied by Kyle. It is not independently live-verified in this brief.

### Direct-ish MCP And Skill Competitors

Named leads:

- `elsahafy/ux-mcp-server`;
- VertaaUX MCP;
- UX Laws MCP / UX-UI-MCP;
- UX Heuristic Evaluator Claude Code skill;
- UX Audit / UX Audit Pro Claude Code skills.

Market-analysis read:

- Some competitors are broader UX knowledge/tool bundles.
- Some are URL-scan-first or production-scanner-oriented.
- Some are Claude Code skills that are easier to adopt but less deterministic than an MCP contract.
- Some use UX laws, cognitive-load checks, implementation effort estimates, browser navigation, or frontend bug checks.

UXHC response:

- Do not become broader just to match tool counts.
- Preserve stable checklist IDs, evidence limits, HIL, validation, traces, and reports as the differentiator.
- Borrow discoverability language such as UX, WCAG, Nielsen, design system, evidence-first, accessibility, and report-ready.
- Consider UX laws as explanatory support lenses, not a replacement audit structure.

### Adjacent Evidence MCPs

Named leads:

- Playwright MCP;
- Chrome DevTools MCP;
- Figma MCP;
- axe / accessibility MCPs;
- Lighthouse MCPs.

Market-analysis read:

- These are strong evidence collectors.
- They are not UX audit methods by themselves.
- They can produce accessibility snapshots, DOM/debug evidence, console/network traces, performance signals, Figma design context, and automated a11y findings.

UXHC response:

- Keep them evidence-only.
- Accept their outputs through `AuditEvidenceGraph`.
- Do not install, run, or require them inside UXHC.
- Do not let automated scan output set heuristic scores directly.

### Product/SaaS Landscape

Named leads:

- UXAudit.Now;
- Baymard UX-Ray;
- Uxia;
- Kamili;
- Heurio;
- Zeplin AI Design Review.

Market-analysis read:

- AI UX scanners sell speed and confidence.
- Baymard-style products sell research-backed benchmarking.
- Synthetic-user tools sell fast validation but risk overclaiming.
- Collaboration tools map issues visually.
- Design handoff QA tools own tactical implementation-readiness language.

UXHC response:

- Do not outscan scanners.
- Out-trust them through evidence limits, traceability, validation, and local artifacts.
- Keep implementation readiness advisory support-only.
- Build stronger quick-start and example-report surfaces to compete on adoption.

## 12. Direct Market-Derived Gaps

These are the gaps future research should evaluate, even after P0/P1/P2 hardening.

| Market pressure | UXHC current state | Gap | Recommended direction |
|---|---|---|---|
| Competitors feel more automatic | Quick scan exists but still depends on host-supplied interpretation/ratings for scored audits | First-run path may feel less magical | Add a market-facing Quick UX Risk Card that is compact, evidence-bound, and honest about missing ratings |
| Evidence MCPs collect richer data | Evidence graph and adapter normalization shipped | UXHC does not run evidence tools internally | Keep adapters host-supplied; improve adapter examples and input shapes |
| Design/dev handoff QA is visible | Implementation Readiness Advisory shipped | UXHC may under-communicate dev handoff value | Improve advisory examples: component path, owner, evidence ref, heuristic ID, effort, validation step |
| Claude Code skills are low-friction | UXHC has MCP plus packaged skill artifacts | Host adoption may still feel heavier than a skill | Improve skill wrapper/host quickstart so Claude/Codex know when and how to call the MCP |
| Scanners market confidence | UXHC has evidence limits, traces, eval fixtures, health dashboard | Public-facing accuracy story is still thin | Publish eval summaries, fixture coverage, known limitations, and false-positive guardrails |
| Annotation tools map findings visually | Screenshot-region refs shipped | No visual evidence-region gallery/overlay yet | Future static report enhancement: optional evidence-region viewer or screenshot appendix |
| Market discovery rewards metadata | Directory metadata and public docs shipped | Release bundles may lag source changes | Add release-packaging checklist that verifies metadata/docs/examples stay current |
| Tool descriptions affect agent behavior | Tools exist and descriptions are usable | Descriptions may not yet be optimized against market smell research | Run a tool-description audit: use when, do not use when, required inputs, next step, repair path |
| Baymard-style products sell research corpus authority | UXHC is transparent heuristic evaluation | Cannot claim domain benchmark authority | Keep domain packs opt-in; never imply Baymard-like empirical corpus unless evidence exists |
| Synthetic-user tools sell fast validation | Agent Mode 2 supports prep/synthetic walkthrough | Risk of users mistaking synthetic for real participant evidence | Keep naming explicit; require real logs before labeling findings as participant evidence |
| Before/after workflows are marketable | Comparison payload support shipped | Needs flagship examples | Add before/after public example report and comparison workflow prompt |
| Collaboration products support teams | Reports and HIL exist | No multi-reviewer project workspace | Keep collaboration deferred; consider export/import or annotation later only if beta users demand it |

## 13. Already Shipped Vs Still A Gap

Use this table to prevent future researchers from recommending completed work as if it is missing.

| Capability | Current status | Notes |
|---|---|---|
| 14 heuristics with H11-H14 optionals | Shipped | 204 dual-platform all-optionals checklist items |
| Stable checklist IDs | Shipped | `h##_d_##` and `h##_m_##` |
| Checklist-level 0-4 scoring | Shipped | Canonical score remains severity rating |
| Evidence-limit contracts | Shipped | Missing/thin evidence does not become invented certainty |
| AuditEvidenceGraph | Shipped | Screenshots, regions, visible text, accessibility, DOM/devtools/code/Figma/host/human evidence |
| Screenshot-region refs | Shipped | `img-1:r1` style refs validate and render |
| Playwright/Chrome/axe/Lighthouse evidence support | Shipped as host-supplied evidence | Not internal runners |
| Figma evidence support | Shipped as host-supplied evidence | Not a live connector |
| JSONL run summaries | Shipped | SQLite deferred until real trace-query pain |
| HIL native UI and elicitation metadata | Shipped | AskUserQuestion/native UI contract plus resume inputs |
| Report repair tasks | Shipped | Slot-specific repair guidance |
| Static HTML/Markdown reports | Shipped | No-link, no-external-assets report harness |
| Public-safe report redaction | Shipped | Rendered artifacts only |
| Owner-role triage matrix | Shipped | Designer, Engineer, Product, Research |
| Implementation Readiness Advisory | Shipped | Support-only; does not alter scores |
| Comparison report payload | Shipped | Renderable through same report tool |
| Distribution metadata | Shipped | `dist/mcp-directory-metadata.json` |
| Public docs and redacted example reports | Shipped | `docs/public/` |
| Tool-description competitive audit | Gap | Future work |
| Quick UX Risk Card | Gap | Future first-run/market-facing polish |
| Visual evidence-region gallery/overlay | Gap | Future report polish |
| Public before/after comparison example | Gap | Future example gallery |
| Skill wrapper/host quickstart polish | Partial/gap | Artifacts exist, but adoption copy and host behavior can improve |
| Live Figma connector | Deferred | Optional future adapter, not baseline |
| Full crawler/auth automation | Rejected from baseline | Do not recommend as default |
| Compliance certification | Rejected | UXHC can support evidence but must not certify |

## 14. Strategic Positioning For Researchers To Test

Primary positioning:

> UX Heuristic Compass is a local-first MCP that turns bounded interface evidence into complete, validated heuristic audit reports.

Developer-facing positioning:

> Give Claude, Codex, Cursor, or another host AI a reliable UX audit contract: stable heuristic IDs, 0-4 severity scoring, evidence refs, HIL gates, report validation, local traces, and static artifacts.

UX/researcher-facing positioning:

> A structured heuristic-evaluation assistant that helps reviewers turn screenshots, page captures, Figma/design evidence, browser observations, and interface notes into calibrated UX findings and stakeholder-ready reports.

Boundary statement:

> UXHC does not replace user testing, accessibility specialists, analytics, or domain research. It helps reviewers produce more consistent pre-ship heuristic audits from bounded evidence.

Market wedge:

> AI coding tools are producing more interfaces faster than teams can review them. UXHC can become the review contract that makes those interfaces safer to ship.

Differentiation sentence to test:

> Most AI UX scanners tell you what they think. UXHC tells you what evidence supports, what is missing, and what is safe to claim.

## 15. Recommended Next Improvement Lanes

These are not implementation instructions for this brief. They are research/evaluation lanes to ask the deep researcher to validate.

### Lane A: Quick UX Risk Card

Goal: compete with "instant AI audit" products without overclaiming.

Proposed output shape:

```text
UX Health: B-
Top risk: Primary action is visually weaker than secondary content.
Why it matters: Users may hesitate or choose the wrong path.
Evidence: img-1:r2, visible text summary
Heuristic: H6 Recognition Rather Than Recall; H8 Aesthetic and Minimalist Design
Fix: Increase CTA contrast and reduce competing visual weight.
Validation: First-click check or short task test.
Evidence limits: screenshot-only; no interaction evidence.
```

Integration path: existing `quick_scan_ux` compact output and report summary, no new tool.

### Lane B: Tool Description Audit

Goal: improve host AI behavior and reduce workflow friction.

Each tool description should be reviewed for:

```text
Use when...
Do not use when...
Required inputs...
Returns...
Next host action...
Common repair path...
Evidence/privacy boundary...
```

Integration path: existing `server.py` tool metadata and public docs, no new tool.

### Lane C: Skill Wrapper / Host Quickstart

Goal: compete with simple Claude Code skills while preserving MCP rigor.

The wrapper should teach hosts:

- start with `get_started`;
- prepare evidence;
- activate optional profiles deliberately;
- use native HIL UI when paused;
- submit complete checklist ratings;
- generate report through UXHC renderer;
- never handmake fallback HTML when repair tasks are returned.

Integration path: packaging/skill artifacts and docs, no runtime API expansion.

### Lane D: Evidence-Region Report Gallery

Goal: borrow the useful part of annotation tools without building a collaboration product.

Potential shape:

- static screenshot appendix;
- region list grouped by finding;
- plain-text bounds;
- optional no-JS visual overlay if it can remain static and local;
- evidence refs stay stable.

Integration path: report renderer and evidence graph, no crawler or team workspace.

### Lane E: Public Example Gallery

Goal: make the product legible to buyers/researchers.

Minimum examples:

1. landing page quick scan;
2. SaaS/dashboard advanced audit;
3. mobile flow with accessibility profile;
4. before/after comparison report.

All examples must be public-safe redacted and generated by UXHC, not manually made.

### Lane F: Eval And Trust Page

Goal: counter black-box scanner claims.

Publish:

- fixture counts;
- what tests prove;
- what tests do not prove;
- false-positive guardrails;
- evidence limitation policy;
- HIL compliance behavior;
- adapter evidence-only policy.

Integration path: docs/public and health dashboard outputs.

## 16. Researcher Instructions

When conducting new competitive research, return findings in this exact decision format:

```text
Competitor / pattern:
Source confidence:
What they appear to do:
What UXHC already has:
What UXHC lacks:
Adopt / adapt / reject:
Recommended integration path:
Affected subsystem:
Effort:
Impact:
Risk:
Does it preserve 18-tool bounded MCP surface:
Does it preserve evidence-only adapter boundary:
Does it avoid crawler/auth/compliance overreach:
Concrete acceptance test:
```

Use these categories:

```text
direct MCP/skill competitor
evidence adapter
AI UX scanner
accessibility automation
design handoff QA
collaboration/annotation tool
analytics/session replay product
classic UX research platform
developer/frontend QA tool
```

Rank recommendations by:

1. evidence-bound trust improvement;
2. cold-host workflow improvement;
3. report/actionability improvement;
4. distribution/adoption improvement;
5. future expansion potential.

Reject recommendations that primarily push UXHC toward:

- full crawling;
- auth automation;
- compliance certification;
- direct automated score replacement;
- mandatory third-party services;
- domain-specific baseline checklists;
- synthetic-user claims presented as real participant evidence;
- broad UX research platform scope.

Prefer recommendations that strengthen:

- checklist completeness;
- evidence graph traceability;
- HIL compliance;
- report repairability;
- local-first privacy;
- static public-safe examples;
- before/after comparison;
- host AI correctness.

## 17. Best Current Research Question

The most useful competitive question is not:

> Can UXHC become another AI website auditor?

It is:

> What should UXHC borrow from AI UX audit tools, browser-evidence MCPs, design QA systems, and Claude/Codex skills while staying an evidence-bound local MCP audit contract?

If a market idea helps UXHC become more trustworthy, easier for host AIs to use, easier to distribute, or easier to verify, it is likely worth adapting.

If a market idea mainly makes UXHC broader, more automated, more crawler-like, or more confident than its evidence supports, reject it or quarantine it as a separate future product.
