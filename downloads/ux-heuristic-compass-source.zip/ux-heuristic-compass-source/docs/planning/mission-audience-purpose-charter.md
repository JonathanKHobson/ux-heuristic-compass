# UX Heuristic Compass Mission, Audience, And Purpose Charter

Status: planning
Date: 2026-05-01

## Mission Sentence

UX Heuristic Compass helps people identify obvious, actionable usability issues in an interface before it ships, so teams can fix the highest-friction problems without waiting for a full UX research cycle.

Operational mission:

> Help a reviewer evaluate a visible interface before it ships by converting bounded evidence into a complete heuristic scorecard, plain-language UX risks, and concrete next actions.

## Audience Hierarchy

1. Builders, UX generalists, product owners, educators, nonprofit teams, and solo makers who need a fast usability audit of a visible interface.
2. Host AIs such as Claude, Codex, and other MCP clients that need stable scaffolds for visual/source intake, rubric selection, severity scoring, and report generation.
3. Maintainers who need schemas, fixtures, evaluation checks, and package boundaries without mistaking infrastructure for the product center.

## Core User Job

The core job is: "Audit this interface before I ship or show it."

Users bring screenshots, a page URL, a prototype capture, or a small task flow. UX Heuristic Compass should help them see what is confusing, hidden, inconsistent, inaccessible, cognitively heavy, or hard to recover from, then rank fixes by likely impact.

## Product Pillars

- Fast heuristic evaluation for visible interface problems.
- Checklist-complete scoring: every active item receives a 0-4 rating or an explicit evidence-limit contract.
- Evidence-bound findings tied to screenshots, viewports, page states, or interaction observations.
- Severity-calibrated prioritization, not generic UX commentary.
- Human-calibrated auditing through onboarding and human-in-the-loop context, judgment, and reflection.
- Plain-language recommendations a builder can act on.
- Local-first capture and report artifacts.
- Host-AI reliability through stable contracts and readiness checks.

## Core Audit First Contract

The scorecard is the product center. UX Health Snapshot, checklist ratings, per-heuristic grades, top finding, plain-language read, and concrete recommendation must appear before supporting methods.

Atlas-adapted flows, File-o-Fun-style activities, Six Hats, interviews, and evaluator-bias advisories are support layers. They may improve interpretation, evidence quality, calibration, prioritization, next-step validation, or human teaching. They must not replace the 14-heuristic checklist audit or turn UXHC into a broad UX research platform.

Implementation-aware inspection is also a support layer. A host AI or coding harness may inspect source code, rendered previews, browser observations, or external frontend audit results, but those signals are advisory until they are converted into evidence-bound checklist ratings. This lane must not vendor third-party skill packs, run unapproved tools, or replace UXHC's scorecard with a frontend health score.

## Non-Goals

- Not a replacement for usability testing with users.
- Not a full UX research platform.
- Not a broad web crawler.
- Not an authenticated-flow automation system in MVP.
- Not a competitor-monitoring or market-intelligence scraper by default.
- Not a donor, ecommerce, education, SaaS, or nonprofit checklist product by default.

## Decision Filter For Future Work

Every roadmap item should pass this filter:

1. Does it help a person identify or prioritize visible usability issues?
2. Does it improve evidence quality, severity calibration, or recommendation usefulness?
3. Can it be explained in plain UX audit language?
4. Can it work locally or with explicit consent for external/browser actions?
5. Does it preserve the core HE audit instead of expanding into a broad UX platform?
6. Does it keep support material behind the scorecard instead of making methods the main output?

If the answer is no, the item is infrastructure, deferred, or rejected.

## Project-Specific Checklist Principle

The north-star product may create curated, project-specific heuristic add-ons case by case. Those add-ons can use competitive analysis, domain conventions, product type, audience, and task context.

That is later development. MVP baseline remains general heuristic evaluation only.

Project-specific add-ons must:

- be opt-in
- name the source of the checklist logic
- remain separate from the core 10-heuristic score
- avoid pretending domain assumptions apply universally
- be traceable in the report as an add-on profile

## Alignment Test Scenarios

- A builder uploads a desktop screenshot and asks what is obviously hard to use.
- A product owner supplies a mobile URL and asks for the top launch blockers.
- A teacher asks whether a learning page makes the next action clear.
- A host AI prepares a local screenshot manifest before auditing.
- A roadmap item proposes full-site crawling and must justify why bounded capture is insufficient.
