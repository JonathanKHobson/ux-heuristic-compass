# UX Heuristic Compass Evaluation Strategy

## Evaluation Goals

- Confirm all 14 heuristics and every checklist item load with stable IDs.
- Confirm H7 has 9 desktop and 9 mobile items with identical text.
- Confirm mobile H11-H14 authored items load with `source: "authored_mobile_v1"`.
- Confirm H14 contains no hard-coded organization, product, or interface name.
- Confirm donor/conversion criteria are absent from rubric data and default reports.
- Confirm 0-4 checklist ratings produce deterministic grades.
- Confirm evidence-limited source states do not produce invented certainty.
- Confirm onboarding persistence writes only complete preference records.
- Confirm Agent Mode 1 persists and retrieves agent runs.
- Confirm browser-assisted Agent Mode 2 leaves no automation-owned browser session behind.

## Fixture Families

| Fixture Family | Purpose |
|---|---|
| Rubric count fixture | Verifies 14 heuristics, 79 core items per platform, 23 optional items per platform, and 204 full dual-platform items. |
| H7 correction fixture | Verifies H7 desktop and mobile both have 9 identical items. |
| Optional mobile source fixture | Verifies H11-H14 mobile items are present and source-tagged as `authored_mobile_v1`. |
| H14 genericization fixture | Scans H14 description and items for hard-coded organization/product/interface names. |
| Donor exclusion fixture | Scans rubric data, fixtures, reports, and add-on scaffolds for excluded donor/conversion checklist leakage. |
| Grade calculation fixture | Tests exact quality percentages and letter grades from known item-rating arrays. |
| Screenshot source fixture | Tests checklist-level audit with evidence refs and evidence limits. |
| Mobile screenshot fixture | Tests mobile platform session scoring, touch-target-related evidence limits, and optional mobile profiles. |
| Sparse/cropped screenshot fixture | Tests `partial` or `insufficient_evidence` behavior. |
| Quick Audit fixture | Tests compact checklist-level output from `quick_scan_ux`. |
| Advanced Audit fixture | Tests HIL gate state and resume behavior from `audit_ux_surface`. |
| Partial onboarding fixture | Exits after one preference field, verifies no record is written, then verifies onboarding retriggers. |
| Agent Mode 1 fixture | Tests per-agent scorecards, averaged scorecard, disagreement flags, persistence, and `get_agent_run`. |
| Agent Mode 2 local fixture | Tests bounded Playwright task attempt on a local static page and browser handoff verification. |

## Human Review Rubric

Score each audit output 1-5:

- Evidence-bound: rating points to visible source evidence or a clear evidence limitation.
- Heuristic fit: checklist item maps to the observed issue.
- Severity fit: 0-4 rating is neither exaggerated nor minimized.
- Grade fit: percentages and letter grades match the scoring contract.
- Recommendation usefulness: fix is concrete and plausible.
- Plain-language clarity: stakeholder can understand without UX jargon.

## Regression Checks

- Checklist item IDs remain stable.
- H7 remains 9/9 with identical desktop and mobile item text.
- H11-H14 mobile items remain tagged `authored_mobile_v1`.
- H14 remains generic and adaptable to the current product, organization, or interface.
- Donor/conversion criteria do not appear in baseline rubric or default report.
- `calibrate_ux_sensitivity` remains the canonical calibration tool name.
- Optional profiles do not silently change the core H1-H10 grade.
- Project-specific add-ons remain separate from core grade.
- URL capture remains bounded.
- Incomplete source manifests do not produce full reports.
- Browser handoff verification passes after any browser automation test.

## Acceptance Threshold

Next major build is implementation-ready when:

- planning docs agree on the corrected H7 and optional mobile profile decisions
- checklist ID and evidence limit schemas are locked
- grade direction and lookup table are locked
- tool additions and changed tool contracts are specified

Next major build is release-ready when:

- rubric count, H7, optional mobile, H14 genericization, and donor exclusion tests pass
- scoring fixtures match the locked formula and grade table
- Quick Audit and Advanced Audit return checklist-level scorecards
- preferences save/update and partial-onboarding tests pass
- Agent Mode 1 persistence and retrieval tests pass if Phase 5 ships
- Agent Mode 2 browser handoff tests pass if Phase 6 ships
