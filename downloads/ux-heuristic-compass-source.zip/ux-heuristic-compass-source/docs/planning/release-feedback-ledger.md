# UXHC Release Feedback Ledger

This ledger tracks real feedback sources that create beta-hardening work. It is intentionally lightweight: issue export remains a script/internal-helper workflow, not a public MCP tool.

| Feedback ID | Source | Severity | Affected Tool/Subsystem | Status | Linked Acceptance Test |
|---|---|---|---|---|---|
| UXHC-FB-20260504-001 | Compass Suite surface test feedback | High | `validate_ux_report_payload`, `quick_scan_ux`, support lenses | Shipped 2026-05-04 | `test_report_validation_blocks_unscored_and_generates_checklist_report`; support-lens trigger regressions |
| UXHC-FB-20260504-002 | Compass Suite feedback reports | High | report-ready payloads, HIL metadata, payload-path report generation | Shipped 2026-05-04 | Phase 1 payload-backed validation/report tests |
| UXHC-FB-20260504-003 | Compass Suite output ergonomics feedback | High | `audit_ux_surface`, `quick_scan_ux`, `generate_ux_audit_report` | Shipped 2026-05-04 | Phase 2 status-only and compact-response tests |
| UXHC-FB-20260504-004 | HIL resume feedback | High | HIL checkpoints and resume through existing audit tools | Shipped 2026-05-04 | Phase 3 resume-run-id tests |
| UXHC-FB-20260504-005 | Oppia and Compass Suite HTML example review | Medium | Evidence Limits renderer and comparison language | Shipped 2026-05-04 | Evidence Limits guardrail and desktop/mobile wording tests |
| UXHC-FB-20260504-006 | Phase 5 visual QA/evidence/feedback polish | Medium | visual QA, evidence gallery, issue export | Shipped 2026-05-04 | visual-QA preflight, evidence-gallery, and issue-export tests |

## Ledger Rules

- Use real feedback sources, not speculative ideas.
- Track affected public tool or internal subsystem.
- Link each entry to at least one acceptance test or fixture.
- Keep issue export as JSON/Markdown bundles unless the 18-tool public surface decision changes.
