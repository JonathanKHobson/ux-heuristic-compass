## PRD

### Product Objective

UX Heuristic Compass is a local-first MCP tool for structured heuristic UX audits. The next major build turns the current as-built MCP into a checklist-level evaluation system with persistent preferences, upgraded audit modes, and two agent-assisted advanced-audit paths.

The tool remains modeled after the Critical Compass architecture pattern, not its domain. Critical text evaluation becomes interface heuristic evaluation; the Critical Integrity Snapshot pattern becomes a UX Health Snapshot.

### System Scale Note

The canonical rubric contains 14 heuristics:

- 10 core Nielsen Norman usability heuristics: H1-H10.
- 4 optional profiles: H11 accessibility/ease of access, H12 empathetic engagement/inclusion, H13 customer journey/satisfaction, H14 UX writing/content and tone.

Checklist scale:

- Core checklist items: 79 desktop and 79 mobile.
- Optional checklist items: 23 desktop and 23 mobile.
- Full dual-platform count with all optionals: 204 checklist items.
- Agent Mode 1 full dual-platform, all-optionals load: 612 individual ratings across 3 agents.

This scale matters for runtime design, token budgeting, report length, and progress feedback.

### Current State

Do not re-spec the shipped runtime as if it is unbuilt. The current MCP already includes:

- `get_started`
- `ux_heuristic_overview`
- `list_heuristics`
- `prepare_ux_source`
- `quick_scan_ux`
- `audit_ux_surface`
- `calibrate_ux_sensitivity`
- `validate_ux_report_payload`
- `generate_ux_audit_report`
- `compare_ux_audits`
- `draft_project_addon_profile`

Known gaps to address:

- Optional heuristics H11-H14 exist in current source data but are not loaded as full structured checklist records.
- Checklist items are not stored as first-class, rateable records.
- `quick_scan_ux` and `audit_ux_surface` do not yet enforce checklist-level scoring output.
- No preferences persistence tools exist.
- Agent Mode 1 and Agent Mode 2 do not exist.
- Agent Mode 2 requires new browser automation architecture. It is not a configuration toggle.

### Product Principles

- Checklist items are the scoring unit.
- Platform is a session dimension, not a separate heuristic taxonomy.
- H7 is not platform-specific: desktop and mobile both use the same 9 checklist items.
- Optional profiles are first-class heuristics but opt-in at audit start.
- The host AI owns conversation, visual interpretation, and user-facing explanation.
- UX Heuristic Compass owns rubric structure, manifests, scoring contracts, report readiness, preferences, persistence, and artifact generation.
- The tool must stay domain-neutral. H14 style and brand language refers to the current product, organization, or interface being evaluated.

### Heuristic Data Requirements

| ID | Heuristic | Desktop items | Mobile items | Divergent? | Source |
|---|---|---:|---:|---|---|
| H1 | Visibility of System Status | 9 | 9 | No | Spreadsheet |
| H2 | Match Between System and the Real World | 3 | 3 | No | Spreadsheet |
| H3 | User Control and Freedom | 5 | 5 | No | Spreadsheet |
| H4 | Consistency and Standards | 21 | 21 | No | Spreadsheet |
| H5 | Error Prevention | 5 | 5 | No | Spreadsheet |
| H6 | Recognition Rather Than Recall | 4 | 4 | No | Spreadsheet |
| H7 | Flexibility and Efficiency of Use | 9 | 9 | No | Spreadsheet |
| H8 | Aesthetic and Minimalist Design | 16 | 16 | No | Spreadsheet |
| H9 | Help Users Recognize, Diagnose, and Recover from Errors | 2 | 2 | No | Spreadsheet |
| H10 | Help and Documentation | 5 | 5 | No | Spreadsheet |
| H11 | Accessibility and Ease of Access | 4 | 4 | No | Desktop: spreadsheet; mobile: authored_mobile_v1 |
| H12 | Empathetic Engagement and Inclusion | 6 | 6 | No | Desktop: spreadsheet; mobile: authored_mobile_v1 |
| H13 | Customer Journey and Satisfaction | 6 | 6 | No | Desktop: spreadsheet; mobile: authored_mobile_v1 |
| H14 | UX Writing / Content and Tone | 7 | 7 | No | Desktop: spreadsheet; mobile: authored_mobile_v1 |

Acceptance criteria:

- AC-001: All 14 heuristics are loaded as structured records.
- AC-002: The donor/conversion checklist is absent from all rubric definitions, fixtures, and default reports.
- AC-003: H7 loads as 9 desktop items and 9 mobile items with identical text.
- AC-004: H11-H14 desktop items carry `source: "HE_Scorecard_Template_v2"`.
- AC-005: H11-H14 mobile items carry `source: "authored_mobile_v1"`.
- AC-006: H14 description and checklist text contain no hard-coded organization, product, or interface name.
- AC-007: Every checklist item has a deterministic ID using `h{nn}_{d|m}_{ii}` format.

### Corrected H7 Checklist Items

H7 desktop and mobile are identical:

1. Useful content is presented on the home page or within one click of the home page.
2. The terms used for navigation items and hypertext links are unambiguous and jargon-free.
3. If there are product pages, they contain the detail necessary to make a purchase, and users can zoom in on product images.
4. The words, phrases and concepts used will be familiar to the typical user.
5. Content feels friendly for new users.
6. Content feels customizable or useable for frequent or expert users.
7. The screen density is appropriate for the target users and their tasks.
8. Icons and graphics are standard and/or intuitive, concrete, and familiar.
9. Where tooltips are used, they provide useful additional help and do not simply duplicate text in the icon, link, or field label.

### Authored Mobile Optional Heuristics

The mobile H11-H14 items are canonical authored additions because the source spreadsheet only supplied optional-profile rows on desktop. They must be tracked separately with `source: "authored_mobile_v1"` so future review can revise them without confusing them with spreadsheet-derived items.

#### H11 Mobile - Accessibility and Ease of Access

Description: Evaluate whether the mobile interface meets surface-level accessibility standards appropriate for touch, small screens, and mobile-native assistive technology.

Tool description disclaimer: This is a visibility/surface accessibility screen, not a WCAG compliance audit.

Checklist:

- `h11_m_01`: P (Perceivable): Content alternatives provided; text resizable without layout breakage; color not sole conveyor of information; audio/video has captions or transcripts.
- `h11_m_02`: O (Operable): All interactive elements reachable by touch or keyboard; touch targets meet 44x44pt / 48x48dp minimum; no interaction requires precise gestures that exclude motor-impaired users; auto-playing content can be paused.
- `h11_m_03`: U (Understandable): Text readable at default zoom without horizontal scroll; forms use visible labels not placeholder-only; error recovery in plain language; app behaves predictably across screen transitions.
- `h11_m_04`: R (Robust): Compatible with VoiceOver on iOS and TalkBack on Android; interactive elements have meaningful accessibility labels; interface does not break when system font size or display zoom is increased.

#### H12 Mobile - Empathetic Engagement and Inclusion

Description: Evaluate whether the mobile interface design respects the emotional, cognitive, and situational diversity of users in mobile-specific contexts, including distracted, interrupted, and one-handed use.

Checklist:

- `h12_m_01`: Interface is designed for interrupted use; users can pause, resume, or recover place without losing context or progress.
- `h12_m_02`: No anxiety-inducing mobile patterns: no aggressive push notification prompts, no hard-to-dismiss fullscreen interstitials, no dark patterns on small screens.
- `h12_m_03`: Content and visual design are culturally appropriate for target regions, including icon choices, color meanings, and imagery.
- `h12_m_04`: App is usable in situational impairment contexts: bright sunlight, one-handed use, moving/vibrating environment, low-battery/low-data mode.
- `h12_m_05`: Interface accommodates users with varying motor control; thumb-zone-friendly layouts; sufficiently spaced interactive targets.
- `h12_m_06`: Users have meaningful control over notifications, permissions, data sharing, and personalization; these choices are easy to find and change.

#### H13 Mobile - Customer Journey and Satisfaction

Description: Evaluate whether the mobile experience delivers a coherent, trust-building, and value-reinforcing journey across the full session, from launch to completion to re-engagement.

Checklist:

- `h13_m_01`: App visual identity, tone, and brand are consistent from launch screen through core flows and notifications.
- `h13_m_02`: Core task flows are optimized for mobile: minimal steps, no unnecessary context-switching, back navigation always recovers state.
- `h13_m_03`: App offers personalized or contextually relevant content based on behavior, location if permitted, or preferences without requiring excessive setup.
- `h13_m_04`: Support is reachable within the app without leaving to a browser or switching apps.
- `h13_m_05`: App provides positive reinforcement or progress acknowledgment at appropriate moments without being patronizing.
- `h13_m_06`: Privacy and data practices are communicated at appropriate moments and permission requests explain why access is needed, not buried in settings only.

#### H14 Mobile - UX Writing / Content and Tone

Description: Evaluate whether every word in the mobile interface is usable at a glance, actionable on a small screen, and consistent with the current product's voice, accounting for truncation, tap targets, and mobile reading context.

Checklist:

- `h14_m_01`: Follows the current product's established style guide and brand voice across all screens including push notifications, empty states, and error messages.
- `h14_m_02`: Content is scannable: short headlines, front-loaded information, minimal body copy on primary screens.
- `h14_m_03`: Content avoids jargon and uses plain conversational language appropriate for a mobile-first audience.
- `h14_m_04`: UI labels are short enough to render completely at minimum viewport width without truncation; critical labels tested at smallest supported screen.
- `h14_m_05`: CTAs are verb-led, specific, and dominant tap targets; not competing with secondary actions of similar visual weight.
- `h14_m_06`: Instructional content is broken into single-thought lines or steps; no block paragraphs in primary flows.
- `h14_m_07`: Push notifications and alerts use clear non-alarming language, include context for why sent, and lead with user benefit rather than app's need.

### Grading System

Per checklist item rating scale:

| Score | Meaning |
|---:|---|
| 0 | No issue - heuristic passed |
| 1 | Cosmetic - fix if time permits |
| 2 | Minor - low priority fix |
| 3 | Major - high priority fix |
| 4 | Catastrophic - must fix immediately |

Score direction is locked: higher percentage means better quality.

Formula:

```text
quality_percentage = (1 - (sum(item_scores) / (count(items) * 4))) * 100
```

The inverse failure score may be retained internally for diagnostics, but user-facing grades use the quality percentage above.

Grade lookup:

| Percentage range | Letter grade | Descriptor |
|---|---|---|
| 95-100% | A++ | Exceptional - industry benchmark |
| 90-94% | A+ | Excellent - exceeds standard |
| 85-89% | A | Strong - meets standard |
| 80-84% | A- | Above average - minor gaps |
| 75-79% | B+ | Good - a few notable issues |
| 70-74% | B | Acceptable - some improvement needed |
| 65-69% | B- | Below average - multiple issues |
| 60-64% | C+ | Developing - significant gaps |
| 55-59% | C | Needs attention - failing in places |
| 50-54% | C- | Struggling - widespread issues |
| 40-49% | D | Poor - major usability problems |
| 30-39% | D- | Critical - severe experience failures |
| 0-29% | F | Failing - unusable or near-unusable |

Acceptance criteria:

- AC-008: Every evaluated checklist item receives one 0-4 score.
- AC-009: Every heuristic returns checklist ratings, average item severity, quality percentage, letter grade, and descriptor.
- AC-010: Overall grade is derived from active heuristic quality percentages.
- AC-011: Desktop and mobile sessions are scored independently.
- AC-012: Optional heuristic weighting follows the active product decision in the Open Questions Log.

### Quick Audit

User story: As a solo builder, I want a fast checklist-level audit of a screenshot, URL capture, or prepared source so I can see the most obvious UX issues without pausing for manual decisions.

Functional requirements:

- FR-001: Quick Audit accepts URL, screenshot/image bundle, or `prepared_source`.
- FR-002: Quick Audit asks for or infers platform from preferences, but must not silently mix desktop and mobile scoring.
- FR-003: Quick Audit evaluates all active heuristics and all active checklist items.
- FR-004: Quick Audit outputs checklist item ratings, per-heuristic grades, overall grade, evidence limits, and top findings.
- FR-005: Quick Audit does not include human-in-the-loop interruptions.

Acceptance criteria:

- AC-013: A fixture screenshot returns checklist-level ratings for all active core items.
- AC-014: A source limitation produces `evidence_limits` records rather than invented certainty.
- AC-015: Optional profiles are included only when requested or saved as defaults.

### Advanced Audit

User story: As a UX practitioner, I want a slower guided audit with review gates so I can add context, override weak assumptions, and decide when the AI should ask for more detail.

Functional requirements:

- FR-006: Advanced Audit uses the same scoring engine as Quick Audit.
- FR-007: Advanced Audit supports human-in-the-loop gates before heuristic sections, after low-scoring heuristics, and before final report.
- FR-008: Gate frequency is governed by saved preferences or explicit audit input.
- FR-009: Advanced Audit unlocks Agent Mode 1 and Agent Mode 2.

Acceptance criteria:

- AC-016: Advanced Audit can run with HIL disabled and still produce the same schema as Quick Audit.
- AC-017: Advanced Audit can pause at a configured gate and resume with added context.

### Onboarding And Preferences

User story: As a first-time user, I want the MCP to explain how audits work and save my defaults so later audits do not repeat setup questions.

Functional requirements:

- FR-010: On first use, absence of a saved preferences record triggers onboarding.
- FR-011: Onboarding explains the 10 core heuristics, 4 optional profiles, 0-4 scale, and grade system.
- FR-012: Onboarding captures UX experience level: `beginner`, `practitioner`, or `expert`.
- FR-013: Onboarding captures HIL default: `enabled`, `disabled`, or `ai_decides`.
- FR-014: Onboarding captures agent mode default: `enabled`, `disabled`, or `ask_each_time`.
- FR-015: Onboarding captures default platform: `desktop`, `mobile`, or `ask_each_time`.
- FR-016: Onboarding captures optional heuristic defaults: any of H11-H14, `none`, or `ask_each_time`.
- FR-017: Complete onboarding writes a persistent preferences record.
- FR-018: Partial onboarding writes no preference record.
- FR-019: If onboarding exits before all required preference fields are captured, the next audit attempt retriggers onboarding.

Acceptance criteria:

- AC-018: Simulate first use with no preference record and verify onboarding triggers.
- AC-019: Simulate complete onboarding and verify preferences are persisted.
- AC-020: Simulate exit after the first question, verify no preference record is written, then verify the next audit call retriggers onboarding.

### Agent Mode 1 - Multi-Persona Researcher Audit

User story: As a product lead, I want independent expert-perspective audits so disagreement becomes a useful signal instead of a hidden model artifact.

Functional requirements:

- FR-020: Agent Mode 1 runs only under Advanced Audit.
- FR-021: Default agents are: generalist UX researcher, senior accessibility specialist, and content strategist / UX writer.
- FR-022: Each agent independently scores all active checklist items.
- FR-023: Per-checklist score is the average of all agent ratings.
- FR-024: Disagreement flags are produced when agent ratings diverge by 2 or more points.
- FR-025: Each agent provides a top 3 highest-severity finding summary in its own voice.
- FR-026: Agent runs are persisted locally and retrievable through `get_agent_run`.

Acceptance criteria:

- AC-021: A 3-agent fixture produces per-agent scorecards and an averaged scorecard.
- AC-022: A 0/3/4 rating split creates a disagreement flag.
- AC-023: `get_agent_run` returns the persisted agent run by ID.

### Agent Mode 2 - Audience Persona Usability Test

User story: As a UX researcher, I want simulated audience-persona walkthroughs of a named product flow so I can gather think-aloud-style findings mapped back to heuristics.

Functional requirements:

- FR-027: Agent Mode 2 runs only under Advanced Audit.
- FR-028: The user supplies a target audience description.
- FR-029: The system creates 3 audience persona variants from the audience description.
- FR-030: Each persona attempts scoped tasks using think-aloud protocol.
- FR-031: Each persona records task attempts, outcomes, confusion, delight, and abandonment.
- FR-032: Each persona completes a post-session interview.
- FR-033: Results synthesize thematic findings and heuristic-mapped findings.
- FR-034: Playwright is the primary navigation vehicle, but fallback order remains an open architecture decision.

Acceptance criteria:

- AC-024: Agent Mode 2 refuses full-site crawling, auth automation, and unconstrained navigation.
- AC-025: A local static fixture can run a bounded task walkthrough and produce a transcript-like output.
- AC-026: Browser cleanup and handoff verification pass after every Playwright run.

### Out Of Scope

- Full site crawling.
- Authenticated flow automation.
- Autonomous browser agent navigation outside explicit Agent Mode 2 design.
- WCAG compliance certification.
- Analytics, heatmap, or session replay ingestion.
- Default competitor scraping.
- Donor/conversion checklist inclusion.
- Product- or organization-specific hard-coded style guide names.

### Feature Dependencies

- Rubric import gates all scoring, audit, and report work.
- Checklist ID stability gates comparison and saved audit retrieval.
- Scoring engine gates Quick Audit, Advanced Audit, Agent Mode 1, and reports.
- Preferences persistence gates onboarding and default audit behavior.
- Agent run persistence gates `get_agent_run`, audit comparison, and retrospective review.
- Browser automation architecture gates Agent Mode 2.

## Implementation Roadmap

| Phase | Name | Goal | Features | Effort | Impact | Impact/Effort | Dependencies And Blockers | Sequencing Rationale |
|---:|---|---|---|---|---|---:|---|---|
| 1 | Data Foundation | Load the full checklist corpus as deterministic, platform-aware rubric data. | Import H1-H14; exclude donor/conversion; corrected H7 9/9; authored mobile H11-H14; source tags; H14 genericization; stable IDs; schema version. | M | High | 1.50 | Requires final spreadsheet extraction and authored mobile optional items in code fixtures. | Everything else depends on checklist-level records. |
| 2 | Scoring Engine | Convert checklist ratings into heuristic and overall grades. | 0-4 item ratings; quality percentage formula; grade lookup; platform sessions; `evidence_limits`; grade descriptors. | M | High | 1.50 | Requires Phase 1 IDs and active heuristic list. | Scoring must be deterministic before audit tools can enforce outputs. |
| 3 | Audit Modes | Upgrade Quick Audit and Advanced Audit around checklist-level scoring. | Quick Audit schema; Advanced Audit HIL gates; source limitation handling; upgraded `quick_scan_ux` and `audit_ux_surface`; report payload alignment. | L | High | 1.00 | Requires Phase 2 scoring engine and prepared source contracts. | Users need a reliable single-agent audit before preference and agent expansion. |
| 4 | Onboarding And Preferences | Persist user defaults and first-use setup decisions. | `save_preferences`; `update_preferences`; partial onboarding no-write rule; first-use trigger; preference snapshot in sessions. | M | Medium | 1.00 | Requires storage decision and audit session schema. | Preferences improve repeated use after audit contracts are stable. |
| 5 | Agent Mode 1 | Add multi-persona researcher audit with disagreement flags. | `run_agent_audit`; `get_agent_run`; 3 default researcher personas; averaged scorecards; disagreement flags; top findings per agent. | L | High | 1.00 | Requires Phase 2 scoring, Phase 3 audit schema, and Phase 4 persistence. | This adds high-value synthesis without browser automation risk. |
| 6 | Agent Mode 2 | Add audience-persona usability testing with bounded browser automation. | `run_usability_test`; audience personas; think-aloud traces; interview outputs; Playwright architecture; browser handoff tests. | XL | High | 0.75 | Requires source prep hardening, browser cleanup protocol, and explicit navigation safety boundaries. | Highest risk and highest complexity; should follow stable non-navigation audits. |

Effort scores: S=1, M=2, L=3, XL=4. Impact scores: Low=1, Medium=2, High=3.

### Recommended Build Order

1. Implement Phase 1 and Phase 2 as the next hard gate.
2. Upgrade Quick Audit before Advanced Audit because it is the cleanest contract test.
3. Add preferences only after the audit session shape is stable.
4. Build Agent Mode 1 before Agent Mode 2 because it uses existing source interpretation and scoring infrastructure.
5. Treat Agent Mode 2 as a new capability with its own safety harness, not a hidden extension of bounded URL capture.

### Phase Gates

- Gate 1: `list_heuristics` returns 14 heuristics, 204 total dual-platform items, corrected H7/H9 counts, and no donor/conversion checklist.
- Gate 2: Fixture checklist ratings produce exact grade lookup results.
- Gate 3: Quick Audit and Advanced Audit return checklist-level contracts.
- Gate 4: First-use onboarding, complete preferences, update preferences, and partial-exit re-trigger tests pass.
- Gate 5: Agent Mode 1 persists and retrieves agent runs with disagreement flags.
- Gate 6: Agent Mode 2 passes local static fixture, bounded navigation policy, and browser handoff verification.

## Technical Architecture Notes

### Tool Schema Changes

Existing tools to preserve:

- `get_started`: add first-use onboarding entrypoint and preference-aware next steps.
- `ux_heuristic_overview`: explain 14 heuristics, optional profiles, rating scale, and grade table.
- `list_heuristics`: return all 14 heuristic records with checklist counts, platform item arrays, source tags, and schema version.
- `prepare_ux_source`: keep as source normalization; do not expand into full crawling.
- `quick_scan_ux`: upgrade output from finding summary to checklist-level Quick Audit scorecard.
- `audit_ux_surface`: upgrade output to Advanced Audit-ready checklist-level scorecard and HIL state.
- `calibrate_ux_sensitivity`: preserve this live tool name as canonical.
- `validate_ux_report_payload`: validate checklist ratings, grade fields, evidence limits, and blocked-source behavior.
- `generate_ux_audit_report`: render checklist score summaries, grade table outputs, evidence limits, and optional profile sections.
- `compare_ux_audits`: compare by stable `checklist_item_id`.
- `draft_project_addon_profile`: remain opt-in and separate from core HE health.

Compatibility alias:

- `calibrate_ux_severity`: add only as a future compatibility alias if external docs or callers require it. It is not the canonical live name.

New tools required:

| Tool | Purpose | Inputs | Output |
|---|---|---|---|
| `save_preferences` | Save complete onboarding preferences. | `user_id`, `ux_level`, `hil_default`, `agent_default`, `platform_default`, `optional_profiles` | `preference_record`, `saved=true`, `created_at` |
| `update_preferences` | Update an existing preferences record. | `user_id`, partial preference fields | Updated `preference_record`, changed fields |
| `run_agent_audit` | Run Agent Mode 1 multi-persona researcher audit. | `audit_session`, `personas?`, `active_heuristics?`, `source_manifest` | Persisted `agent_run`, `agent_run_id`, averaged scorecard, disagreement flags |
| `get_agent_run` | Retrieve persisted Agent Mode 1 output. | `agent_run_id` | Full `agent_run` or error |
| `run_usability_test` | Run Agent Mode 2 audience-persona usability test. | `target_audience`, `task_scope`, `source_or_url`, `platform`, `safety_policy` | Persona traces, interview responses, thematic findings, heuristic-mapped findings |

`get_agent_run` errors:

- `run_not_found`
- `run_expired`
- `invalid_agent_run_id`

### Checklist Item ID Format

Locked format:

```text
h{heuristic_number_zero_padded}_{platform_initial}_{item_index_zero_padded}
```

Rules:

- `platform_initial` is `d` for desktop and `m` for mobile.
- Examples: `h01_d_01`, `h01_d_09`, `h07_m_09`, `h11_d_01`.
- IDs are deterministic and stable across schema versions.
- If checklist items are reordered, IDs must remain pinned to original item order or a migration script must be provided.
- New items receive new IDs; existing IDs are not recycled.

### Heuristic Record Schema

```json
{
  "schema_version": "uxhc.rubric.v2",
  "id": "h14",
  "number": 14,
  "name": "UX Writing / Content and Tone",
  "description": "Ensure that every word is usable, simple, and adheres to the current product's established style and brand guidelines.",
  "signals": ["labels", "headings", "calls to action", "tone", "clarity"],
  "optional": true,
  "profile": "ux_writing",
  "checklist_items_desktop": [],
  "checklist_items_mobile": []
}
```

### Checklist Item Schema

```json
{
  "id": "h14_m_01",
  "heuristic_id": "h14",
  "heuristic_number": 14,
  "platform": "mobile",
  "index": 1,
  "text": "Follows the current product's established style guide and brand voice across all screens including push notifications, empty states, and error messages.",
  "source": "authored_mobile_v1",
  "active": true
}
```

Allowed `source` values:

- `HE_Scorecard_Template_v2`
- `authored_mobile_v1`
- `migration`
- `future_user_approved_addon`

### Checklist Rating Schema

```json
{
  "checklist_item_id": "h07_d_09",
  "heuristic_id": "h07",
  "platform": "desktop",
  "rating": 2,
  "rating_label": "Minor - low priority fix",
  "evidence_refs": ["img-1:primary-navigation"],
  "rationale": "Tooltip text duplicates the visible label and does not add decision support.",
  "confidence": "medium",
  "evidence_limits": []
}
```

### Evidence Limits Schema

`evidence_limits` flags checklist items that cannot be fully evaluated because of source constraints.

```json
{
  "checklist_item_id": "h01_d_04",
  "reason": "interactive state not visible in screenshot",
  "confidence_impact": "rating may understate severity",
  "evaluatable": false
}
```

Use cases:

- Screenshot-only audits missing hover, focus, or visited states.
- Partial page captures.
- Single-page submissions without navigation access.
- Cropped, blurred, or low-resolution evidence.
- Mobile screenshots that do not show notification, permission, or back-navigation states.

### Heuristic Score Schema

```json
{
  "heuristic_id": "h07",
  "platform": "desktop",
  "active_item_count": 9,
  "sum_item_scores": 8,
  "average_item_severity": 0.89,
  "quality_percentage": 77.78,
  "letter_grade": "B+",
  "descriptor": "Good - a few notable issues",
  "checklist_ratings": [],
  "evidence_limits": []
}
```

### Audit Session Schema

```json
{
  "session_id": "uxhc_sess_20260502_001",
  "schema_version": "uxhc.audit_session.v2",
  "platform": "desktop",
  "mode": "quick",
  "source_manifest_id": "src_123",
  "active_heuristics": ["h01", "h02", "h03", "h04", "h05", "h06", "h07", "h08", "h09", "h10"],
  "heuristic_scores": [],
  "overall_quality_percentage": 82.5,
  "overall_grade": "A-",
  "overall_descriptor": "Above average - minor gaps",
  "agent_mode": "none",
  "preferences_snapshot": {},
  "created_at": "2026-05-02T00:00:00Z"
}
```

### Agent Run Schema

Agent runs are persisted locally in the same storage family as preferences.

```json
{
  "agent_run_id": "uxhc_agent_run_20260502_001",
  "audit_session_id": "uxhc_sess_20260502_001",
  "schema_version": "uxhc.agent_run.v1",
  "mode": "researcher_persona_audit",
  "personas": [],
  "per_agent_scorecards": [],
  "averaged_scorecard": {},
  "disagreement_flags": [],
  "top_findings": [],
  "created_at": "2026-05-02T00:00:00Z",
  "expires_at": null
}
```

### Agent Persona Schema

```json
{
  "agent_id": "agent_a",
  "name": "Generalist UX Researcher",
  "persona": "Generalist UX researcher with 3-5 years of consumer web experience.",
  "lens": ["task clarity", "navigation", "flow friction"],
  "checklist_ratings": [],
  "top_findings": []
}
```

### Disagreement Flag Schema

```json
{
  "checklist_item_id": "h11_m_02",
  "agent_ratings": {
    "agent_a": 1,
    "agent_b": 4,
    "agent_c": 2
  },
  "spread": 3,
  "reason_to_review": "Accessibility specialist saw a severe touch-target risk that other agents rated lower."
}
```

### Preference Record Schema

```json
{
  "user_id": "local_default",
  "schema_version": "uxhc.preferences.v1",
  "ux_level": "practitioner",
  "hil_default": "ai_decides",
  "agent_default": "ask_each_time",
  "platform_default": "ask_each_time",
  "optional_profiles": ["accessibility", "ux_writing"],
  "created_at": "2026-05-02T00:00:00Z",
  "updated_at": "2026-05-02T00:00:00Z"
}
```

Partial onboarding rule:

- Do not write this record until every required field is captured.
- Store temporary onboarding state only in the active conversation/session if needed.
- If the user exits before completion, next audit attempt behaves as first use again.

### Storage Notes

- Rubric data should live in versioned package data so tests can snapshot it.
- Preferences and agent runs should live in local user data under the existing local-first runtime storage.
- Saved audit sessions may share the same storage layer once comparison and retrieval are stable.
- No global Claude/Codex configuration edits are required for this build scope.

### Agent Mode 2 Architecture Boundary

Agent Mode 2 is a new browser automation capability. It must not be implemented as:

- full site crawling
- authenticated automation
- hidden browser-agent navigation under Quick Audit
- unbounded Playwright exploration

The minimal safe architecture is:

1. User provides target audience and bounded task scope.
2. Tool creates 3 persona variants.
3. Tool opens only approved URLs or local fixtures.
4. Tool records bounded actions and observations.
5. Tool closes automation-owned browser processes.
6. Tool verifies browser handoff before returning success.

## Open Questions Log

Resolved decisions not listed here:

- Grade direction is locked: 100% means perfect quality, all checklist items scored 0.
- H7 is not platform-specific: desktop and mobile both have 9 identical items.
- H9 excludes the plain-language error-message row because workbook inspection confirmed it is the heuristic description, not a checklist item.
- Mobile H11-H14 are canonical authored variants and are no longer an open data gap.
- `calibrate_ux_sensitivity` remains the canonical live tool name.

| # | Question | Context | Stakes | Recommended default |
|---:|---|---|---|---|
| 1 | Should Agent Mode 1 personas be fixed, user-defined, or both? | The default roster is known, but some audits may need domain-specific expert lenses. | Fixed-only is simpler; user-defined personas add flexibility but can reduce comparability. | Ship fixed defaults plus optional user overrides with schema validation. |
| 2 | What is the fallback order for Agent Mode 2 navigation? | Proposed vehicles are Playwright, Claude browser agent fallback, and multimodal screenshot fallback. | Wrong fallback order can create unstable tests or overstate what the MCP can do. | Playwright first, multimodal screenshot fallback second, no Claude browser-agent fallback until separately validated. |
| 3 | What is the HIL gate trigger logic for Advanced Audit? | Gates can happen before each heuristic, after low scores, or at user-controlled cadence. | Too many gates slow audits; too few gates reduce trust and context quality. | Default to threshold-based gates for heuristic grades below B-, plus final review gate. |
| 4 | Do optional H11-H14 heuristics count equally toward overall grade? | Optional profiles can materially change the grade if averaged with H1-H10. | Equal weighting may penalize interfaces for optional scopes; separate scoring may hide important issues. | Report two values: core overall grade and expanded overall grade when optionals are active. |
| 5 | How long should persisted agent runs remain retrievable? | `get_agent_run` introduces local persistence and possible expiry. | Indefinite storage helps comparison; expiry reduces local data growth. | Keep indefinitely by default with future cleanup command; include nullable `expires_at`. |
| 6 | Should Quick Audit replace current `quick_scan_ux` behavior or live beside it? | The current tool returns a compact scan rather than full checklist-level scoring. | Replacing may surprise existing callers; adding a new tool increases surface area. | Upgrade `quick_scan_ux` to checklist-level output while preserving a compact `summary` field. |
| 7 | Should project-specific add-ons ever affect the core grade? | The north-star add-on system can produce project-specific criteria from context. | Mixing add-ons into core health makes benchmark grades unstable. | Never affect core grade; optionally show separate add-on grade. |
| 8 | Should authored mobile optional items get a formal review workflow? | They are now canonical but not spreadsheet-derived. | Future audit results can reveal weak checklist wording or missing mobile-specific criteria. | Add a future rubric-review report that groups findings by `source: authored_mobile_v1`. |
