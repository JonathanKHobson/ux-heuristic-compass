# UX Heuristic Compass Master PRD

## Executive Summary

UX Heuristic Compass is a local-first MCP tool for structured heuristic UX audits. The next major build upgrades the shipped source-prep/audit/report workflow into a checklist-level scoring system across 14 heuristics, persistent onboarding preferences, and advanced agent-assisted audit modes.

The tool stays domain-neutral. UX writing and style-guide criteria refer to the current product, organization, or interface being evaluated; no organization-specific name belongs in the canonical rubric.

The full implementation-ready PRD, roadmap, architecture notes, and open questions live in `next-major-build-plan.md`. This master PRD summarizes the active product contract.

## Current Runtime Baseline

The MCP already includes:

- `get_started`
- `ux_heuristic_overview`
- `list_heuristics`
- `prepare_ux_source`
- `quick_scan_ux`
- `audit_ux_surface`
- `calibrate_ux_sensitivity`
- `validate_ux_report_payload`
- `generate_ux_audit_report`
- `compare_ux_audits`
- `draft_project_addon_profile`

The next build should preserve these tools while upgrading their data and output contracts.

## Goals

- Import all 14 heuristics as structured records.
- Store every checklist item as a discrete, rateable record.
- Score every active checklist item on the 0-4 Nielsen severity scale.
- Convert item scores into per-heuristic and overall quality grades.
- Preserve desktop and mobile as separate audit sessions.
- Add onboarding and preferences persistence.
- Add multi-persona researcher audits with disagreement flags.
- Architect audience-persona usability tests as a new browser-assisted capability.
- Keep the core audit first: source scope, UX Health Snapshot, checklist scorecard, top finding, plain-language read, and concrete recommendation precede any support flows or activities.

## Non-Goals

- No donor/conversion checklist in the rubric, fixtures, or default reports.
- No full-site crawling.
- No authenticated flow automation.
- No unconstrained autonomous browser-agent navigation.
- No WCAG compliance certification.
- No analytics, heatmap, or session replay ingestion.
- No default competitor scraping.
- No hard-coded product, organization, or interface names in H14.

## Rubric Scope

| ID | Heuristic | Desktop items | Mobile items | Source |
|---|---|---:|---:|---|
| H1 | Visibility of System Status | 9 | 9 | Spreadsheet |
| H2 | Match Between System and the Real World | 3 | 3 | Spreadsheet |
| H3 | User Control and Freedom | 5 | 5 | Spreadsheet |
| H4 | Consistency and Standards | 21 | 21 | Spreadsheet |
| H5 | Error Prevention | 5 | 5 | Spreadsheet |
| H6 | Recognition Rather Than Recall | 4 | 4 | Spreadsheet |
| H7 | Flexibility and Efficiency of Use | 9 | 9 | Spreadsheet |
| H8 | Aesthetic and Minimalist Design | 16 | 16 | Spreadsheet |
| H9 | Help Users Recognize, Diagnose, and Recover from Errors | 2 | 2 | Spreadsheet |
| H10 | Help and Documentation | 5 | 5 | Spreadsheet |
| H11 | Accessibility and Ease of Access | 4 | 4 | Desktop spreadsheet; mobile authored_mobile_v1 |
| H12 | Empathetic Engagement and Inclusion | 6 | 6 | Desktop spreadsheet; mobile authored_mobile_v1 |
| H13 | Customer Journey and Satisfaction | 6 | 6 | Desktop spreadsheet; mobile authored_mobile_v1 |
| H14 | UX Writing / Content and Tone | 7 | 7 | Desktop spreadsheet; mobile authored_mobile_v1 |

Scale:

- Core items: 79 desktop and 79 mobile.
- Optional items: 23 desktop and 23 mobile.
- Full dual-platform, all-optionals total: 204 checklist items.
- Full Agent Mode 1 dual-platform all-optionals load: 612 individual ratings across 3 agents.

## H7 Correction

H7 is not platform-specific. Desktop and mobile each have 9 identical checklist items. Any plan, schema, fixture, or implementation that treats H7 as having fewer desktop items is obsolete.

## Checklist ID Contract

Checklist IDs use:

```text
h{heuristic_number_zero_padded}_{platform_initial}_{item_index_zero_padded}
```

Examples:

- `h01_d_01`
- `h07_m_09`
- `h11_d_01`

IDs are stable across schema versions. Reordering checklist items requires pinned IDs or a migration script.

## Scoring Contract

Every checklist item receives one 0-4 rating:

| Score | Meaning |
|---:|---|
| 0 | No issue - heuristic passed |
| 1 | Cosmetic - fix if time permits |
| 2 | Minor - low priority fix |
| 3 | Major - high priority fix |
| 4 | Catastrophic - must fix immediately |

Score direction is locked: higher percentage means better quality.

```text
quality_percentage = (1 - (sum(item_scores) / (count(items) * 4))) * 100
```

Grade lookup remains the locked table in `scoring-and-report-contract.md`.

## Audit Modes

### Quick Audit

Quick Audit accepts a URL, screenshot/image bundle, or `prepared_source`, evaluates all active heuristics and checklist items, and returns:

- checklist item ratings
- per-heuristic grades
- overall grade
- evidence limits
- top findings

Quick Audit is the compact path: the host AI may produce checklist ratings quickly, but UXHC still requires ratings or an evidence-limit contract before it scores. Quick Audit is nonblocking when context and ratings are supplied; otherwise it exposes a light 3-question context contract so the host does not pretend UXHC can judge visuals alone.

### Advanced Audit

Advanced Audit uses the same scoring engine and adds configurable human-in-the-loop gates:

- 3 beginning context questions before checklist ratings are produced
- 3 middle user-opinion/calibration questions around low-scoring heuristics
- 3 final reflection/report-readiness questions before report generation

Advanced Audit unlocks Agent Mode 1 and Agent Mode 2.

Atlas-adapted flows, teaching activities, Six Hats, interview planning, transcript analysis, and evaluator-bias advisories are audit-support intelligence. They can improve interpretation, evidence quality, calibration, prioritization, next-step validation, or HIL teaching, but they cannot change the rubric, replace checklist-level scoring, or become the main audit output.

## Onboarding And Preferences

First-time use is detected by absence of a saved preferences record.

Preferences include:

- UX experience level
- human-in-the-loop default
- agent mode default
- default platform
- optional heuristic defaults

Partial onboarding behavior:

- If onboarding exits before all required fields are captured, write no preference record.
- On the next audit attempt, re-trigger onboarding.

## New Tools

| Tool | Purpose |
|---|---|
| `save_preferences` | Save complete onboarding preferences. |
| `update_preferences` | Update an existing preferences record. |
| `run_agent_audit` | Run Agent Mode 1 multi-persona researcher audit. |
| `get_agent_run` | Retrieve a persisted Agent Mode 1 result by ID. |
| `run_usability_test` | Run Agent Mode 2 audience-persona usability test. |

`calibrate_ux_sensitivity` remains the canonical live calibration tool name. `calibrate_ux_severity` may be added later only as a compatibility alias.

## Agent Mode 1

Agent Mode 1 runs three researcher personas:

- generalist UX researcher
- senior accessibility specialist
- content strategist / UX writer

Each independently scores all active checklist items. The system returns per-agent scorecards, an averaged scorecard, disagreement flags for rating spreads of 2 or more, and each agent's top 3 highest-severity findings. Runs are persisted locally and retrievable through `get_agent_run`.

## Agent Mode 2

Agent Mode 2 is a new browser-assisted audience-persona usability test capability. It asks for a target audience, creates three persona variants, runs bounded think-aloud task attempts, captures interview responses, synthesizes themes, maps findings back to heuristics, and verifies browser handoff before success.

Agent Mode 2 must refuse full-site crawling, authenticated flows, and unconstrained navigation.

## Acceptance Criteria

- All 14 heuristics are loaded as structured records.
- H7 has 9 desktop and 9 mobile items.
- H11-H14 mobile items are loaded with `source: "authored_mobile_v1"`.
- H14 has no hard-coded organization/product/interface name.
- Donor/conversion checklist is absent.
- Checklist item IDs follow `h{nn}_{d|m}_{ii}`.
- Scoring fixtures match the locked grade table.
- Quick Audit and Advanced Audit return checklist-level score contracts.
- Partial onboarding writes no preference record and retriggers later.
- Agent runs persist and can be retrieved by ID.
- Browser-assisted usability tests verify browser handoff.
