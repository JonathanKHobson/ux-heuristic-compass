# UXHC Corpus Expansion Roadmap

## Summary

This roadmap covers the P2 support-lens corpus expansion after the research packets were supplied on 2026-05-07. The goal is not to make UXHC bigger for its own sake. The goal is to make the existing H01-H14 audit contract better at explaining why evidence-backed findings matter.

The expansion stays support-only:

- No new public MCP tools.
- No changes to H01-H14 scoring.
- No changes to the canonical 0-4 checklist ratings.
- No new canonical grade source; corpus indexes are support-only advisory summaries.
- No compliance, certification, user-testing, crawler, or synthetic-user claims.
- No raw import of long Markdown packets into runtime responses.

## Source Inventory

| Slice | Packet | Files Reviewed | Runtime Use |
|---|---|---:|---|
| `UXHC-CORPUS-001` | `NonWestern_UX_UI_CX_Extension_Packet.zip` | 6 Markdown files | Cross-cultural, Indigenous, decolonial, multilingual, faith-aware, and mediated-access lenses. |
| `UXHC-CORPUS-002` | `WCAG_Accessibility_Corpus.zip` | 2 Markdown files | WCAG 2.2 support references, A/AA clusters, component patterns, and manual-test evidence guidance. |
| `UXHC-CORPUS-003` | `ISO_UX_UI_HCI_Corpus.zip` | 1 Markdown file | ISO UX/HCI standards support references for usability, HCD process, interaction, accessibility, quality-in-use, privacy, AI UX, and workload. |
| `UXHC-CORPUS-004` | `CX_Deep_Dive_NoRepeats_Packet.zip` | 8 Markdown files | CX operating lenses for promise debt, effort, recovery, omnichannel continuity, complaints, VoC, journey ownership, and service operations. |

Current runtime state:

- `uxhc_support_lenses.json` contained 58 compact support lenses after `UXHC-CORPUS-001`.
- `UXHC-CORPUS-001` shipped 20 curated `cross_cultural_*` lenses plus the Cultural Context Signal / Cultural Context Integrity Advisory report module on 2026-05-07.
- `UXHC-CORPUS-002` shipped 20 curated `wcag_*` lenses plus the Accessibility Readiness Signal / WCAG-Informed Accessibility Readiness report module on 2026-05-07, bringing the runtime corpus to 78 compact support lenses.
- `UXHC-CORPUS-003` shipped 25 curated `iso_*` lenses as ordinary support references on 2026-05-07, bringing the runtime corpus to 103 compact support lenses.
- `UXHC-CORPUS-004` shipped 24 curated `cx_*` lenses as ordinary support references on 2026-05-07, bringing the runtime corpus to 127 compact support lenses.
- The source skill package under `packaging/skills/ux-heuristic-compass/` now includes `references/corpus-support-lenses.md`; each future corpus slice must update the skill package alongside runtime/docs changes.
- Lens output is capped by selector/report logic.
- Lens selection uses heuristic IDs, checklist IDs, checklist text patterns, and token-aware trigger matching.
- `score_policy="support_only"` is already validated.

## Report Module Strategy

The corpus expansion has two output-design lanes:

1. `UXHC-CORPUS-001` and `UXHC-CORPUS-002` add default support-only report modules.
2. `UXHC-CORPUS-003` and `UXHC-CORPUS-004` enrich existing finding/report language only.

These modules are included by default in advanced audit reports when relevant evidence or findings exist. A later slice may add user gates or report options to suppress them, but the first implementation should make them visible by default so the value is not hidden.

### Generic Advisory Module Shape

Both special modules should use the same report-safe structure:

- `module_id`
- `module_type="support_advisory"`
- `score_policy="support_only"`
- `display_default=true`
- `top_signal`
- `index_score`
- `index_label`
- `evidence_basis`
- `caveat`
- `rows`

The index score summarizes evidence-backed risk posture for the advisory module only. It must never alter the H01-H14 grade, checklist ratings, severity counts, finding order, or report readiness.

### Top Summary Placement

When present, advisory modules should surface one compact signal near the UX Health Snapshot / score summary:

- `Cultural Context Signal: ...`
- `Accessibility Readiness Signal: ...`

The top signal should be one sentence. It should name the most important evidence-backed concern or say that evidence is limited.

### Deeper Report Placement

The full advisory modules should render deeper in the report, after the core scorecard/findings/evidence-limit summary and before roadmap/triage/support-only planning sections. HTML may use static `<details>` accordions for longer detail, with no scripts, links, or external assets.

## Slice Order

### 1. `UXHC-CORPUS-001`: Non-Western And Cross-Cultural

Primary source files:

- `NonWestern_UX_UI_CX_New_Principles_Index.markdown.md`
- `Indigenous_Decolonial_UX_CX_Frameworks.markdown.md`
- `NonSecular_Faith_Spiritual_UX_CX_Patterns.markdown.md`
- `NonWestern_UI_CX_Conventions_Patterns.markdown.md`
- `NonWestern_UX_UI_CX_Audit_Toolkit.markdown.md`

Curated runtime batches:

- Cultural safety and authority.
- Indigenous data and AI governance.
- Community consent and protocol.
- Script direction, localization, literacy, and language access.
- Global South infrastructure, shared-device, low-bandwidth, and mediated-access realities.
- Faith-aware and observance-sensitive UX/CX.
- Relational, decolonial, pluriversal, and place-based design lenses.

Default guardrail:

> Treat this as culturally situated support, not a universal rule; validate with affected communities or local expertise.

Special output module:

- Top callout: `Cultural Context Signal`.
- Deeper section: `Cultural Context Integrity Advisory`.
- Index name: `Context Integrity Index`.
- Suggested labels:
  - 85-100: `Strong Context Fit`
  - 70-84: `Mostly Context-Aware`
  - 50-69: `Needs Context Review`
  - 25-49: `High Context Risk`
  - 0-24: `Insufficient Context Safety`
- Required caveat: this is evidence-limited support guidance, not a moral judgment, cultural certification, or substitute for community review.
- Status: shipped 2026-05-07.

### 2. `UXHC-CORPUS-002`: WCAG And Accessibility

Primary source files:

- `WCAG_Accessibility_Checklists_Standards_Guidelines.markdown.md`
- `wcag_accessibility_corpus/README.markdown.md`

Curated runtime batches:

- POUR summary lenses.
- WCAG 2.2 A/AA clusters for production accessibility.
- Component-pattern lenses for forms, navigation, controls, modals, tables, auth, and mobile/touch.
- Manual-test and evidence-template lenses for keyboard, focus, screen-reader, and state coverage.
- AAA material as enhancement guidance only, not default production scoring.

Default guardrail:

> Accessibility support guidance only; not WCAG, ADA, legal, procurement, or conformance certification.

Special output module:

- Top callout: `Accessibility Readiness Signal`.
- Deeper section: `WCAG-Informed Accessibility Readiness`.
- Signal name: `WCAG Level Signal`.
- Suggested labels:
  - `AAA`
  - `AA`
  - `A`
  - `Evidence-Limited Accessibility Review Needed`
- Required caveat: this can summarize the highest WCAG level implicated by support cues, but it is not a score and must not claim WCAG A, AA, or AAA conformance without full technical and manual accessibility testing.
- Status: shipped 2026-05-07.

### 3. `UXHC-CORPUS-003`: ISO UX/UI/HCI

Primary source file:

- `ISO_UX_UI_HCI_Corpus.markdown.md`

Curated runtime batches:

- ISO usability in context.
- Human-centered design process and organizational support.
- ISO 9241-110 interaction principles, keeping the existing `standard_iso_9241_110` lens for compatibility.
- Information presentation, forms, visual UI, accessibility ergonomics, quality-in-use, AI UX, privacy/trust, and mental workload.
- CIF/SQuaRE-style evidence and reporting quality where useful.

Default guardrail:

> ISO-informed support reference only; not formal ISO standards compliance, conformance, certification, procurement proof, or legal assurance.

Output behavior:

- No special ISO score or advisory index in the first pass.
- ISO lenses should appear as ordinary support lenses, report references, validation nudges, and finding explanations when relevant.
- Status: shipped 2026-05-07.

### 4. `UXHC-CORPUS-004`: CX

Primary source files:

- `CX_New_Entries_Index_NoRepeats.markdown.md`
- `CX_Frameworks_Theories_Deep_Dive.markdown.md`
- `CX_Metrics_VoC_ROI_Catalog.markdown.md`
- `CX_Service_Operations_Recovery_Complaints.markdown.md`
- `CX_Channel_Journey_Orchestration_Patterns.markdown.md`
- `CX_Governance_Culture_Transformation.markdown.md`
- `CX_NoDuplicate_Crosswalk_And_Source_Trail.markdown.md`

Curated runtime batches:

- Promise debt and expectation-performance gaps.
- Customer effort, time to value, and self-service friction.
- Service recovery, complaints, escalation, and perceived justice.
- Omnichannel continuity, channel memory, universal case ID, timeline, status transparency, and bot-to-human handoff.
- VoC and metric caveats.
- Journey ownership and CX governance.

Default guardrail:

> CX support guidance only; no ROI, NPS, retention, loyalty, satisfaction, or real-customer outcome claim unless evidence is supplied.

Output behavior:

- No special CX score or advisory index in the first pass.
- CX lenses should enrich H13-centered findings, journey language, owner triage, validation steps, and report support phrasing when relevant.
- Status: shipped 2026-05-07.

### 5. `UXHC-CORPUS-005`: Corpus Quality And Report Phrasing

Status: shipped 2026-05-07.

This slice normalizes source-quality and phrasing conventions across the four corpus families.

Shipped decisions:

- Compact policy keys: `core`, `cross_cultural`, `wcag`, `iso`, and `cx`.
- Report display families: UX/UI Support Lens, Cultural Context Support, WCAG Accessibility Support, ISO UX/UI/HCI Support, and CX Service-Journey Support.
- Each family policy supplies source quality, applicability, evidence-needed, and report-guardrail wording.
- Optional lens-card/suggestion enrichment remains additive and does not add required `uxhc.support_lens.v1` fields.
- Report phrasing stays inside **Supporting UX Laws And Principles** and deduplicates repetitive family guardrails.

### 6. `UXHC-CORPUS-006`: Overclaim Regression Suite

Status: shipped 2026-05-07.

This slice adds tests that protect the expanded corpus from becoming score authority.

Tests prove:

- Lenses never change ratings, grades, severity counts, or finding order.
- WCAG/ISO references never become compliance claims.
- Cross-cultural references never become universal culture claims.
- CX references never become business-outcome proof.
- Support lenses can enrich guidance-only mode without producing a scorecard.
- Synthetic-user or participant-research language is blocked unless evidence is supplied.

## Import Strategy

Each slice should ship in one compact curated batch:

- Target 15-30 runtime lenses per slice.
- Prefer clusters over one lens per source-card.
- Use stable ID prefixes: `cross_cultural_*`, `wcag_*`, `iso_*`, `cx_*`.
- Map every lens to H01-H14 and, where reliable, checklist item IDs.
- Use checklist text patterns when mapping is broad or checklist IDs are too narrow.
- Include trigger keywords that are specific enough to avoid noisy selection.
- Keep `audit_use`, `caveat`, `misuse_warning`, and `report_phrase` concise.

The runtime corpus should remain report-ready. The Markdown packets are research inputs, not runtime docs.

## Definition Of Done Per Slice

- Registry validation passes with no blockers.
- New lenses are `score_policy="support_only"`.
- New lenses map only to valid H01-H14 IDs and valid checklist IDs when supplied.
- Routing tests prove representative cues select the intended lens family.
- Scoring regression proves scorecards are unchanged.
- Output regression proves report/support sections stay capped and static.
- Special module regression proves `UXHC-CORPUS-001` and `UXHC-CORPUS-002` render top signals and deeper support-only advisory sections without changing canonical scores.
- Source skill package update is complete: `SKILL.md` routes to any new deep reference, `references/corpus-support-lenses.md` describes shipped slice behavior, and affected skill references mention support-only boundaries.
- Docs/backlog/progress log mark the slice shipped with verification notes.
