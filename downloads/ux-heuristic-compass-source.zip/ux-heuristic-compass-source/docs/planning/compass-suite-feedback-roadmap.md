# Compass Suite Feedback Roadmap

## Summary

This roadmap turns the Compass Suite advanced-audit feedback into the next beta hardening lane. The goal is not to expand UXHC into a crawler, scanner, or compliance product. The goal is to make real advanced audits reliable: no payload surgery, no context overflow, resumable HIL, bounded multi-state evidence capture, and report artifacts that work for desktop/mobile comparisons.

Feedback sources:

- Desktop Compass Suite feedback report shared by the user
- `reports/compass-suite-2026-05-04/uxhc-mcp-feedback-report.md`

Primary constraint: preserve the 18 public MCP tools. Route changes through existing tools and local state.

Current status:

- Phase 1 (`UXHC-BETA-001` through `UXHC-BETA-004`) shipped 2026-05-04.
- Phase 2 (`UXHC-BETA-005` through `UXHC-BETA-008`) shipped 2026-05-04.
- Phase 3 (`UXHC-BETA-101` through `UXHC-BETA-103`) shipped 2026-05-04.
- Phase 4 example-corpus and Evidence Limits guardrail slice (`UXHC-BETA-109`) shipped 2026-05-04.
- Remaining Phase 4 workflow support (`UXHC-BETA-104` through `UXHC-BETA-108`) shipped 2026-05-07.
- Phase 5 (`UXHC-BETA-201` through `UXHC-BETA-204`, `UXHC-BETA-301`, and `UXHC-BETA-302`) shipped 2026-05-04 as the visual QA, evidence-gallery, and feedback-export polish lane.
- `UXHC-BETA-111` ultra-quick guidance-only mode for component refinement shipped 2026-05-07.
- Next planned lane: support-lens corpus expansion after research packets are supplied.

## Priority Backlog

| Priority | IDs | Theme | Why It Comes First |
|---|---|---|---|
| P0 | `UXHC-BETA-110` | Host Playwright rendered-review guidance | This fixes a live cold-host failure mode: HTML/code was treated as code-only review instead of renderable UI that may need Playwright visual review over local HTTP. |
| P0 | `UXHC-BETA-111` | Ultra-quick guidance-only mode | Shipped: a small component refinement request can consult UXHC without becoming a scored audit, large chat response, report payload, or artifact workflow. |
| P0 | `UXHC-BETA-001` through `UXHC-BETA-004` | Report and state reliability | These fix the manual jq payload-repair loop that blocked clean report generation. |
| P0 | `UXHC-BETA-005` through `UXHC-BETA-008` | Output ergonomics | These make full optional-profile audits operable without context overflow or inline 800KB payloads. |
| P1 | `UXHC-BETA-101` through `UXHC-BETA-103` | HIL resume and checkpoints | Shipped: paused audits now resume from local checkpoint state without resubmitting 102 checklist ratings. |
| P1 | `UXHC-BETA-109` | Example corpus and Evidence Limits guardrail | Shipped: approved examples are inventoried and runaway Evidence Limits render compactly instead of flooding reports. |
| P1 | `UXHC-BETA-104` through `UXHC-BETA-108` | Multi-URL, multi-state, multi-platform workflows | Shipped: these address the real Compass Suite shape with up to 10 explicit sources, host-supplied state hints, active-scope badges, and desktop/mobile comparison context. |
| P2 | `UXHC-BETA-201` through `UXHC-BETA-204` | Visual QA and evidence polish | Shipped: report visual QA now preflights dependency availability and evidence-gallery rendering improves traceability. |
| P3 | `UXHC-BETA-301` and `UXHC-BETA-302` | Feedback and issue export | Shipped: feedback can be exported to JSON/Markdown issue bundles without a new public tool. |

## Phase Roadmap

### Phase 0.6: Tighten Host Playwright Guidance

Status: shipped 2026-05-07.

Ship:

- `UXHC-BETA-110`: make tool contracts, skill guidance, and host docs say that HTML/code/renderable UI can require rendered Playwright review, not only static code review.
- Add local-server guidance: serve local HTML through HTTP for browser review and avoid `file://` unless the artifact is explicitly static-file safe.

Gate:

- A cold host reading UXHC guidance chooses rendered Playwright review for reviewable HTML before giving UX conclusions from code alone.
- No new public tools are added; Playwright remains host-owned evidence collection unless UXHC is running optional report visual QA.

Shipped notes:

- `get_started` and `ux_heuristic_overview` now include a short rendered-review hint by default and expose deeper Playwright/local-server guidance with `topic="rendered_review"` plus aliases.
- Tool contracts and source skill docs now tell hosts to serve local HTML through HTTP/local server, avoid `file://` for browser review, and treat unavailable Playwright as an evidence-limited review path.

### Phase 0.7: Add Ultra-Quick Guidance-Only Mode

Status: shipped 2026-05-07.

Ship:

- `UXHC-BETA-111`: add a tiny guidance-only path for small component or screen-fragment refinement.
- Prefer an additive `quick_scan_ux` mode such as `guidance_only` or `ultra_quick`; do not add a new public tool unless the existing surface cannot support the workflow cleanly.
- Let hosts pass a small visual/code/context input plus an intent such as `direct_fix`, `fix_prompt`, `micro_plan`, or `name_the_problem`.
- Return only compact heuristic/support-lens cues, likely issue language, suggested refinements, and one validation nudge for the host to use in its requested output.

Gate:

- A cold host can use UXHC to improve a small component fix or prompt without showing the user a full audit.
- The response does not include an `overall_grade`, full scorecard, report payload, HIL-heavy flow, artifact generation, compliance claim, or user-testing claim.
- The 18 public tool surface remains unchanged unless a later explicit decision says otherwise.

Shipped notes:

- `quick_scan_ux` without `output_detail` returns a one-question `quick_scan_mode_gate` with `guidance_only`, `status_only`, `compact`, and `full` choices.
- `quick_scan_ux(output_detail="guidance_only")` and alias `output_detail="ultra_quick"` return a tiny `guidance_only_card`.
- `guidance_intent` supports `direct_fix`, `fix_prompt`, `micro_plan`, and `name_the_problem`.

### Phase 1: Stop Payload Surgery

Status: shipped 2026-05-04.

Ship:

- `UXHC-BETA-001`: correct run summary counts for payload-backed validation and report generation.
- `UXHC-BETA-002`: guarantee non-null required report fields in `report_ready_payload`.
- `UXHC-BETA-003`: make `report_readiness_contract.status="ready"` definitive.
- `UXHC-BETA-004`: strip report-blocking HIL control fields from report payloads.

Gate:

- A scored all-optionals payload validates and generates Markdown/HTML without manual jq repair.
- `report_readiness_contract.status="ready"` means `generate_ux_audit_report` is expected to succeed.

### Phase 2: Stop Context Overflow

Status: shipped 2026-05-04.

Ship:

- `UXHC-BETA-005`: `output_detail="status_only"` for audit tools.
- `UXHC-BETA-006`: `response_mode="compact"` for report generation.
- `UXHC-BETA-007`: default local report artifact paths.
- `UXHC-BETA-008`: `payload_path` support for report validation.

Gate:

- A full H1-H14 audit can be driven from status-only audit output plus payload paths.
- Report generation can return paths and validation metadata without returning full Markdown.

### Phase 3: Make HIL Resume Real

Status: shipped 2026-05-04.

Ship:

- `UXHC-BETA-101`: resumable audit checkpoints.
- `UXHC-BETA-102`: HIL resume by `resume_run_id`.
- `UXHC-BETA-103`: clearer HIL outcome status in audit and report summaries.

Gate:

- A paused 102-item audit resumes from checkpoint without resubmitting all ratings.
- Reports distinguish native HIL from fallback/unavailable resolution.

### Phase 4: Support Real Public-Site Audits

Status: shipped 2026-05-07.

Shipped:

- `UXHC-BETA-109`: Phase 4 example-output inventory and Evidence Limits guardrail.

Ship:

- `UXHC-BETA-104`: larger explicit bounded source batches up to 10.
- `UXHC-BETA-105`: bounded tab/state capture warnings and host-hinted capture support.
- `UXHC-BETA-106`: active-scope summary badge.
- `UXHC-BETA-107`: compact consolidated desktop/mobile report context.
- `UXHC-BETA-108`: stronger desktop/mobile comparison rendering.

Gate:

- A five-page, all-tabs, desktop/mobile audit can be represented as one coherent workflow through explicit sources and state hints.
- Bounded source guardrails remain intact: no crawler, no auth automation, no unbounded navigation.

Shipped notes:

- `prepare_ux_source` now accepts up to 10 explicit URL/source items and `interactive_state_hints`.
- Status-only audit outputs and reports include `active_scope_badge` / `active_scope_summary`.
- `compare_ux_audits` now returns compact `platform_report_context` for desktop/mobile scope, HIL, source/evidence counts, evidence limits, and checklist visibility.
- Comparison reports render platform scope/evidence and evidence appendix rows without links, scripts, external assets, or full audit-payload duplication.

### Phase 5: Polish Evidence And Distribution

Status: shipped 2026-05-04.

Shipped:

- `UXHC-BETA-201`: Playwright visual-QA preflight.
- `UXHC-BETA-202`: visual-QA browser handoff telemetry.
- `UXHC-BETA-203`: static visual evidence gallery support.
- `UXHC-BETA-204`: local/private traceability improvements under redaction rules.
- `UXHC-BETA-301`: JSON/Markdown issue export.
- `UXHC-BETA-302`: release feedback ledger.

Gate:

- Visual QA dependency state is visible before report generation.
- Evidence galleries remain static, local, and public-safe.
- Feedback can be turned into structured issue bundles without adding a public MCP tool.

## Test Strategy

- Add a 102-item all-optionals fixture based on the Compass Suite audit shape.
- Add a URL-only prepared-source fixture to prevent `source.status: null` and display-state regressions.
- Add a HIL-paused scored audit fixture that resumes from checkpoint.
- Add payload-path validation tests and compact report-response byte-budget tests.
- Add desktop/mobile comparison fixtures that assert platform wording and checklist visibility.
- Add tab/state evidence-limit tests for tabbed source pages.
- Run full regression after every phase: `python3 -m pytest -q`, `python3 server.py --self-test`, directory readiness check, and tool count `18`.

## Boundaries

- No new public tools in this roadmap.
- No full-site crawling, auth automation, or unbounded browser navigation.
- No compliance certification claims.
- JSONL stays the beta run-summary store; resumable checkpoints may use saved payload snapshots in the existing local state directory.
- `submit_feedback` remains deferred; use JSON/Markdown issue export first.
