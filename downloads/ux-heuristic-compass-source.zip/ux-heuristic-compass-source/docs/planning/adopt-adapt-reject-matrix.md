# UX Heuristic Compass Adopt, Adapt, Reject Matrix

## Sources

| Source | Adopt | Adapt | Reject / Defer |
|---|---|---|---|
| Critical Compass | Report readiness, local artifact viewer, scaffold-first host workflow, deterministic payload builders, conservative confidence. | Replace text-audit domain with UX source manifests, heuristic findings, severity, and UX Health Snapshot. | Bias/fallacy/CIS scoring as-is. |
| NN/g 10 usability heuristics | Baseline heuristic names and core intent. | Turn principles into machine-readable rubric cards and finding prompts. | Treating heuristic review as proof from user testing. |
| Supplied HE scorecard | Severity model, desktop/mobile separation, general optional profiles. | Extract general checklist ideas into rubric examples and optional profiles. | Donor/conversion checklist in baseline. |
| AI UX audit tools on market | Fast screenshot/URL intake, concise reports, prioritized fixes. | Use as product-positioning evidence and feature inspiration. | Cloning black-box scoring or broad website crawling before MVP. |
| Browser automation | Capture page screenshots and visible page metadata. | Restrict to bounded URL capture with cleanup/handoff. | Autonomous agent navigation in MVP. |
| Accessibility tooling | Later evidence artifact for specific checks. | Keep as optional, explicit integration. | Claiming full accessibility compliance from heuristic review alone. |

## Product Boundary

Borrow infrastructure patterns aggressively. Borrow domain checklists cautiously.

The default product remains general heuristic evaluation. Domain-specific criteria only enter through later opt-in add-on profiles.

## Project-Specific Checklist Lane

Later versions may create curated checklist profiles from:

- product type
- primary user task
- audience needs
- device context
- accessibility constraints
- competitor/reference examples
- brand or domain conventions

Those profiles must be labeled as add-ons and reported separately from the core 10-heuristic health.
