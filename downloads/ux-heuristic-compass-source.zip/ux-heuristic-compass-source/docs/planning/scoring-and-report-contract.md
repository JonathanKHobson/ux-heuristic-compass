# UX Heuristic Compass Scoring And Report Contract

## Scoring Philosophy

UX Heuristic Compass scores checklist-level heuristic evidence, not people, teams, or total product worth.

The score answers: "How severe are the visible or documented usability issues for each checklist item, given the available evidence?"

It does not answer:

- whether users actually failed in a usability test
- whether accessibility compliance is met
- whether the business should prioritize an issue over strategy work
- whether the product is objectively good or bad overall

## Rating Scale

Every active checklist item receives exactly one 0-4 rating.

| Score | Meaning |
|---:|---|
| 0 | No issue - heuristic passed |
| 1 | Cosmetic - fix if time permits |
| 2 | Minor - low priority fix |
| 3 | Major - high priority fix |
| 4 | Catastrophic - must fix immediately |

## Score Direction

Score direction is locked: higher percentage means better UX quality.

Formula:

```text
quality_percentage = (1 - (sum(item_scores) / (count(items) * 4))) * 100
```

Examples:

- All items scored 0: 100% quality.
- All items scored 4: 0% quality.
- Mixed ratings averaging 2 severity: 50% quality.

## Grade Lookup Table

| Percentage range | Letter grade | Descriptor |
|---|---|---|
| 95-100% | A++ | Exceptional - industry benchmark |
| 90-94% | A+ | Excellent - exceeds standard |
| 85-89% | A | Strong - meets standard |
| 80-84% | A- | Above average - minor gaps |
| 75-79% | B+ | Good - a few notable issues |
| 70-74% | B | Acceptable - some improvement needed |
| 65-69% | B- | Below average - multiple issues |
| 60-64% | C+ | Developing - significant gaps |
| 55-59% | C | Needs attention - failing in places |
| 50-54% | C- | Struggling - widespread issues |
| 40-49% | D | Poor - major usability problems |
| 30-39% | D- | Critical - severe experience failures |
| 0-29% | F | Failing - unusable or near-unusable |

## Checklist Item IDs

Checklist item IDs are deterministic and stable:

```text
h{heuristic_number_zero_padded}_{platform_initial}_{item_index_zero_padded}
```

Examples:

- `h01_d_01`: H1 desktop item 1.
- `h01_d_09`: H1 desktop item 9.
- `h07_m_09`: H7 mobile item 9.
- `h11_d_01`: H11 desktop item 1.

Rules:

- `d` means desktop.
- `m` means mobile.
- IDs must not change when display text is edited.
- If items are reordered, IDs stay pinned to original item order or a migration script must be provided.

## H7 Correction

H7 is not platform-specific. Desktop and mobile both have 9 identical checklist items. Any scoring, comparison, or report logic that assumes H7 desktop has fewer items is invalid.

## Optional Profile Source Rules

H11-H14 are first-class optional heuristics.

Source tags:

- Desktop H11-H14: `HE_Scorecard_Template_v2`
- Mobile H11-H14: `authored_mobile_v1`

H14 text must remain generic. It may refer to the current product, organization, brand voice, style guide, or interface being evaluated, but it must not hard-code a specific organization or product name.

## Checklist Rating Schema

Required fields:

| Field | Type | Description |
|---|---|---|
| `checklist_item_id` | string | Stable ID such as `h07_m_09`. |
| `heuristic_id` | string | Heuristic ID such as `h07`. |
| `platform` | enum | `desktop` or `mobile`. |
| `rating` | integer | 0-4 severity rating. |
| `rating_label` | string | Human-readable scale meaning. |
| `evidence_refs` | array | Source manifest evidence handles. |
| `rationale` | string | Why this rating was assigned. |
| `confidence` | enum | `high`, `medium`, or `low`. |
| `evidence_limits` | array | Any constraints that limit evaluation confidence. |

## Evidence Limits Schema

`evidence_limits` flags checklist items that cannot be fully evaluated due to source constraints.

```json
{
  "checklist_item_id": "h01_d_04",
  "reason": "interactive state not visible in screenshot",
  "confidence_impact": "rating may understate severity",
  "evaluatable": false
}
```

Use cases:

- screenshot-only audits missing hover, focus, or visited states
- partial page captures
- single-page submissions without navigation access
- cropped, blurred, or low-resolution evidence
- mobile screenshots that do not show notification, permission, or back-navigation states

## Heuristic Score Schema

Required fields:

| Field | Type | Description |
|---|---|---|
| `heuristic_id` | string | Heuristic ID. |
| `platform` | enum | `desktop` or `mobile`. |
| `active_item_count` | integer | Count of scored checklist items. |
| `sum_item_scores` | number | Sum of 0-4 item ratings. |
| `average_item_severity` | number | `sum_item_scores / active_item_count`. |
| `quality_percentage` | number | Inverted quality score where 100 means all items passed. |
| `letter_grade` | string | Grade from locked lookup table. |
| `descriptor` | string | Descriptor from locked lookup table. |
| `checklist_ratings` | array | Full checklist rating objects. |
| `evidence_limits` | array | Aggregated evidence limitations. |

## Overall Score Rules

- Desktop and mobile sessions are scored independently.
- Overall core grade is the average of active H1-H10 quality percentages.
- When optional H11-H14 profiles are active, the report must show optional profile scores.
- Until the weighting open question is resolved, reports should show core overall grade and expanded overall grade separately.
- Project-specific add-ons never modify the core grade.

## UX Health Snapshot

Derived summary fields:

| Field | Type | Description |
|---|---|---|
| `display_state` | enum | `scored`, `profile_only`, `insufficient_evidence`. |
| `platform` | enum | `desktop` or `mobile`. |
| `core_quality_percentage` | number | Average quality percentage for H1-H10. |
| `core_grade` | string | Letter grade for H1-H10. |
| `expanded_quality_percentage` | number/null | Overall with optionals when active. |
| `expanded_grade` | string/null | Letter grade with optionals when active. |
| `top_priority` | string | One sentence on the most important fix area. |
| `severity_counts` | object | Count of checklist ratings by severity. |
| `heuristic_health` | array | Per-heuristic summary. |
| `overall_label` | string | Plain-language label. |
| `comparability_warning` | string | Notes when screenshots/pages cannot fairly be compared. |

## Report Readiness

`validate_ux_report_payload` blocks report generation if:

- source manifest is missing
- platform is missing
- active heuristic list is missing
- checklist rating lacks a stable `checklist_item_id`
- checklist rating lacks a 0-4 `rating`
- checklist rating lacks rationale
- checklist rating lacks evidence reference or evidence-limit explanation
- confidence is missing
- grade fields do not match the locked formula and lookup table
- report asks for an add-on profile but no add-on ratings or explicit non-evaluability records are present

## Default Report Sections

1. Executive summary
2. Source and scope
3. UX Health Snapshot
4. Overall grade and per-heuristic grade table
5. Top issues to fix
6. Checklist-level issue ledger
7. Heuristic-by-heuristic findings
8. Evidence limits and confidence
9. Optional profile sections when active
10. Recommended next validation

## Project-Specific Add-On Rule

Project-specific checklists must never be merged silently into the core score.

They render under a separate section:

`Project-Specific Heuristic Add-On`

Each criterion must include:

- why it applies to this project
- source or rationale
- whether it came from competitive analysis, user task context, domain convention, or user-provided requirement
- whether it affects recommendations but not baseline HE health
