# UXHC Corpus Expansion PRD

## Product Intent

The support-lens corpus gives hosts better interpretive language for evidence-backed UX findings. It helps a host explain why a risk matters, choose a validation step, and name related UX/UI/CX/accessibility/standards principles without turning those principles into a second scorecard.

This is a precision layer, not a breadth contest. The right outcome is a compact set of high-signal lenses that make reports and guidance-only output smarter while keeping UXHC light.

## Users And Use Cases

Primary users:

- Host AIs using UXHC in Claude, Codex, Cursor, ChatGPT, or similar environments.
- Builders who need quick, evidence-bound UX guidance.
- Researchers/designers who want stakeholder-ready language without overclaiming.

Use cases:

- Attach relevant support lenses to scored findings.
- Improve `quick_scan_ux(output_detail="guidance_only")` cues.
- Enrich the report section "Supporting UX Laws And Principles."
- Improve validation nudges for accessibility, culture, standards, and CX evidence gaps.
- Add default report advisory modules for cultural/context integrity and accessibility readiness when relevant.

Non-goals:

- No new public tools.
- No new canonical scoring dimension; advisory indexes are support-only summaries only.
- No replacement for H01-H14.
- No WCAG/ISO/legal/compliance certification.
- No claim that cross-cultural lenses represent all cultures.
- No claim that CX lenses prove real customer outcomes.

## Runtime Contract

Use the existing `uxhc.support_lens.v1` record shape:

- `lens_id`
- `name`
- `lens_type`
- `family`
- `source_family`
- `source_refs`
- `source_status`
- `mapped_heuristic_ids`
- optional `mapped_checklist_item_ids`
- `checklist_text_patterns`
- `trigger_keywords`
- `audit_use`
- `caveat`
- `misuse_warning`
- `report_phrase`
- `score_policy="support_only"`

Do not add required schema fields in the first corpus pass. `UXHC-CORPUS-005` shipped compact internal family policies after the four source-family slices stabilized. Selected support-lens cards and summaries may include additive source-quality, applicability, evidence-needed, display-family, and reporting-guardrail fields; hosts may ignore them, and they never become score authority.

## Report Advisory Contract

`UXHC-CORPUS-001` and `UXHC-CORPUS-002` add report advisory modules. These are not new score engines. They summarize support-lens evidence in a compact report shape.

Generic advisory object:

- `module_id`
- `module_type="support_advisory"`
- `score_policy="support_only"`
- `display_default=true`
- `top_signal`
- `index_score`
- `index_label`
- `evidence_basis`
- `caveat`
- `rows`

Rules:

- Include advisory modules by default in advanced audit reports when relevant evidence-backed findings or evidence limits exist.
- Place one sentence near the UX Health Snapshot as a top signal.
- Place the fuller section deeper in the report before roadmap/triage/support-only planning sections.
- Allow future opt-out/report options later; do not gate these by default in the first implementation.
- Never let advisory index scores change H01-H14 grades, checklist ratings, severity counts, finding order, readiness, or report validation.

## Lens Selection Requirements

Each lens must be useful in at least one of these paths:

- Finding-level support lens selection.
- Audit-level support lens summary.
- Guidance-only cue selection.
- Report phrasing for supporting principles.
- Evidence-limit or validation-step phrasing.

Each lens must avoid:

- Generic trigger words that fire on unrelated findings.
- Report phrases that imply authority beyond available evidence.
- Dark-pattern or persuasion guidance without misuse warnings.
- Broad cultural claims without anti-essentialism caveats.
- Accessibility or standards phrasing that sounds like certification.

## Slice PRDs

### `UXHC-CORPUS-001`: Non-Western And Cross-Cultural

Status: shipped 2026-05-07.

Problem:

The current support-lens layer has inclusion and design-justice coverage, but it is too thin for culturally situated UX, Indigenous data governance, multilingual UX, mediated access, and faith-aware contexts.

Acceptance criteria:

- Add curated lenses for cultural safety, community authority, Indigenous data governance, script/localization, mediated access, faith-aware patterns, and decolonial/pluriversal design.
- Every culturally situated lens includes an anti-essentialism caveat.
- Lenses map mainly to H02, H04, H10, H12, H13, and H14, with H01/H03/H05/H11 where evidence supports it.
- Reports use "may need validation with..." language rather than universal claims.
- Advanced reports include a default `Cultural Context Signal` near the summary and a deeper `Cultural Context Integrity Advisory` when relevant.
- The advisory uses a `Context Integrity Index` with support-only labels: `Strong Context Fit`, `Mostly Context-Aware`, `Needs Context Review`, `High Context Risk`, or `Insufficient Context Safety`.
- The advisory caveat says the index is evidence-limited support guidance, not cultural certification, moral judgment, or substitute for community review.

Open integration space for user ideas:

- Which cultural frameworks deserve first-class runtime records versus report-only phrasing.
- Whether any cross-cultural lens should influence HIL question suggestions.
- How strongly to surface community-authority language in guidance-only mode.
- Whether later versions should ask the user if they want to include the module, or keep it visible by default with an opt-out flag.

### `UXHC-CORPUS-002`: WCAG And Accessibility

Status: shipped 2026-05-07.

Problem:

The current corpus has basic WCAG/POUR coverage but not enough practical WCAG 2.2 detail for finding explanations, component-level guidance, or manual-test validation nudges.

Acceptance criteria:

- Add curated WCAG 2.2 A/AA cluster lenses and component-pattern lenses.
- Include manual-test/evidence-template lenses for keyboard, focus, screen reader, and state coverage.
- Map WCAG lenses primarily to H11, with targeted mappings to H01, H03, H04, H05, H06, H09, H10, and H14.
- Every WCAG lens says it is support guidance, not conformance certification.
- Advanced reports include a default `Accessibility Readiness Signal` near the summary and a deeper `WCAG-Informed Accessibility Readiness` section when relevant.
- The advisory uses a `WCAG Level Signal` such as `A`, `AA`, `AAA`, or `Evidence Limited`. This is not a score and not a conformance result.
- The advisory explicitly says UXHC cannot claim WCAG A/AA/AAA conformance without full technical and manual accessibility testing.

Open integration space for user ideas:

- Whether to include Level AAA as optional enhancement language only.
- Whether to add evidence-limit prompts when WCAG-related evidence is missing.
- How much WCAG specificity should appear in reports before it becomes too heavy.
- Whether later versions should offer a separate independent accessibility audit workflow, while keeping the advanced-audit readiness signal enabled by default.

### `UXHC-CORPUS-003`: ISO UX/UI/HCI

Status: shipped 2026-05-07.

Problem:

The current corpus has only a light ISO reference. UXHC needs stronger ISO-informed support for usability-in-context, HCD process, interaction principles, information presentation, accessibility ergonomics, quality-in-use, privacy/trust, AI UX, and workload.

Acceptance criteria:

- Added curated `iso_*` lenses that map to H01-H14 without implying formal ISO compliance.
- Preserved standards/version language where useful, especially for ISO 9241, ISO/IEC 250xx, ISO 31700, and AI/privacy/workload references.
- Used ISO lenses to strengthen validation-step and evidence-quality language.
- Did not add a special ISO score or report module; ISO appears as ordinary support-lens enrichment when relevant.
- Required phrasing treats ISO as support guidance only, not formal ISO standards compliance, conformance, certification, procurement proof, or legal assurance.

Open integration space for user ideas:

- Whether ISO should appear mostly in reports or also in guidance-only mode.
- Which standards should be treated as high-signal runtime lenses versus deferred source notes.
- Whether ISO process lenses should influence owner-role triage language.

### `UXHC-CORPUS-004`: CX

Status: shipped 2026-05-07.

Problem:

H13 covers customer journey and satisfaction, but the support-lens layer needs more operational CX language for long-running service experience, recovery, omnichannel continuity, complaint handling, VoC, and journey ownership.

Acceptance criteria:

- Added curated CX lenses for promise debt, effort, service recovery, ownership gaps, channel memory, complaint handling, VoC, customer success, journey governance, and respectful retention.
- Mapped CX lenses primarily to H13, with targeted mappings to H01, H03, H04, H05, H09, H10, H12, and H14.
- Reports never imply ROI, NPS, loyalty, retention, satisfaction, revenue, churn, or real-customer outcome proof without supplied evidence.
- Did not add a special CX score or report module; CX appears as H13-centered support-lens enrichment when relevant.

Open integration space for user ideas:

- Whether CX lenses should appear only when H13 is active or also as support cues in core-only audits.
- Whether CX governance lenses should feed owner-role triage wording.
- How much business/operations language belongs in stakeholder reports for non-CX audiences.

## Testing Requirements

Per slice:

- Registry validation passes.
- Representative finding text selects expected new lenses.
- Noise tests prove generic words do not trigger unrelated lenses.
- Scoring is unchanged before and after support-lens attachment.
- Report rendering stays static, capped, linkless, scriptless, and support-only.
- `UXHC-CORPUS-001` and `UXHC-CORPUS-002` advisory modules render by default when relevant and can summarize posture without changing canonical scores.

Cross-slice:

- WCAG and ISO tests reject compliance/certification claims.
- Cross-cultural tests reject universalizing language.
- CX tests reject business-outcome proof language.
- Synthetic-user and participant-research tests reject user-testing claims unless supplied evidence supports them.
- Score-authority tests reject any claim that support lenses changed grades, ratings, severity, priority, or checklist scoring.
- Guidance-only tests confirm corpus cues can appear without grade, scorecard, report payload, HIL audit gates, or artifacts.
- Advisory-index tests confirm labels never claim cultural certification, WCAG conformance, formal ISO compliance, or real customer outcome proof.

## Rollout

Ship one slice at a time:

1. Mark the slice active in backlog and progress log.
2. Add curated lenses and focused tests.
3. Run full regression.
4. Mark the slice shipped with verification notes.
5. Update the source skill package under `packaging/skills/ux-heuristic-compass/`, including `references/corpus-support-lenses.md` and any affected bridge/report/reference docs.
6. Add or update tests proving the source skill mentions the shipped slice and keeps it support-only.
7. Pause for user review and additional integration ideas before the next slice.
