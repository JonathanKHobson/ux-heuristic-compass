# UX Heuristic Compass Source Ingestion Spec

## Purpose

`prepare_ux_source` converts user-provided screenshots, image bundles, or bounded URL captures into a source manifest that audit tools can consume safely.

The source-prep step should answer:

- What are we looking at?
- Where did it come from?
- What viewport or image context matters?
- What evidence is visible?
- What is too thin, missing, blurred, hidden, or out of scope?

## Supported MVP Inputs

| Input Type | MVP Status | Notes |
|---|---|---|
| Local screenshot file | P0 | Fastest source path. |
| Local image bundle | P0 | Supports desktop/mobile or multi-screen review. |
| Public URL capture | P1 within MVP scope | Bounded to up to 10 explicit URLs or named pages. |
| Local HTML/static page | P1 | Useful for examples and fixtures. |
| Figma/prototype evidence | P2 host-supplied | Hosts may pass Figma files, frames, nodes, components, variants, screenshots, prototype states, and design-token notes as evidence-only records. UXHC does not call Figma or require a Figma MCP internally. |
| Authenticated site | Deferred | Requires explicit consent and separate browser/session protocol. |
| Full-site crawl | Deferred | Not MVP. |

## `PreparedUXSource`

Required fields:

| Field | Type | Description |
|---|---|---|
| `source_id` | string | Stable hash or generated ID for the prepared source. |
| `source_type` | enum | `screenshot`, `image_bundle`, `url_capture`, `local_html`, `unknown`. |
| `created_at` | string | ISO timestamp. |
| `items` | array | One item per image/page/viewport. |
| `warnings` | array | Any source-quality or scope warnings. |
| `evidence_refs` | array | Stable evidence handles for findings. |
| `capture_policy` | object | Boundaries used for capture, including URL count and external access. |

## `PreparedUXSourceItem`

| Field | Type | Description |
|---|---|---|
| `item_id` | string | Stable item identifier. |
| `input_path` | string | Local source path when applicable. |
| `url` | string/null | Captured URL when applicable. |
| `viewport` | object/null | Width, height, device class, scale. |
| `screenshot_path` | string | Local prepared screenshot path. |
| `visible_text_summary` | string | Short host- or OCR-derived visible text summary when available. |
| `page_title` | string/null | URL title when available. |
| `state_label` | string/null | User-provided or inferred state name, such as home, checkout, error state. |
| `quality` | enum | `ready`, `partial`, `blocked`. |
| `warnings` | array | Item-specific warnings. |

## Evidence References

Findings should cite evidence using stable refs:

- `img-1`
- `img-1:region-header`
- `url-1:viewport-mobile`
- `dom-1:title`
- `ocr-1:visible-text`

Precise bounding boxes are P1/P2. MVP can use named regions such as header, primary CTA, navigation, form area, footer, modal, or error state.

## URL Capture Rules

MVP bounded capture:

- maximum 10 explicit URLs/source items per prepared source
- no login or private account flows
- no broad crawl from links
- no automatic tab, accordion, or toggle discovery
- no hidden form submission
- no destructive actions
- no download automation
- no persistent browser session ownership after completion

Capture output:

- screenshot path
- URL
- page title
- viewport

Interactive state hints:

- hosts may supply `interactive_state_hints` for known tabs, accordions, toggles, modals, empty/error/loading states, or platform states
- hints are matched against supplied `state_labels` and evidence refs
- unmatched hints become evidence-limit warnings instead of hidden automated navigation
- visible text summary
- high-level DOM landmarks when available
- warnings and blocked state when capture fails

## Source Quality States

| State | Meaning | Audit Behavior |
|---|---|---|
| `ready` | Source is clear enough for heuristic review. | Audit normally. |
| `partial` | Source is usable but incomplete, blurry, cropped, or context-thin. | Audit visible issues only and mark confidence. |
| `blocked` | Source cannot support a fair audit. | Return diagnostics and do not generate findings. |

## Browser Cleanup Requirement

Any URL capture implementation must close automation-owned browser sessions and verify handoff before reporting success.
