# UX Heuristic Compass Effort And Impact Matrix

## Scoring

- Impact: 1 low, 5 high.
- Effort: 1 low, 5 high.
- Priority bias: ship high-impact, low/medium-effort items first.

| Initiative | Impact | Effort | Recommendation | Notes |
|---|---:|---:|---|---|
| Core 10-heuristic rubric | 5 | 2 | Ship first | Product foundation. |
| Screenshot source manifest | 5 | 2 | Ship first | Fastest reliable input path. |
| Finding severity schema | 5 | 2 | Ship first | Keeps output actionable. |
| Quick scan UX payload | 4 | 2 | Ship first | Low activation entry point. |
| Full audit issue ledger | 5 | 3 | Ship first | Core product value. |
| Report validation | 5 | 3 | Ship first | Prevents placeholder reports. |
| Markdown report | 4 | 2 | Ship first | Useful artifact before PDF polish. |
| PDF/local viewer | 4 | 3 | P1 | Reuse Critical Compass pattern after payload stabilizes. |
| Bounded URL capture | 5 | 4 | P1 | In MVP promise, but implement after screenshot path. |
| Browser handoff validator | 5 | 3 | P1 | Required for URL capture signoff. |
| Desktop/mobile comparison | 4 | 3 | P1 | Strong value after capture exists. |
| Optional accessibility profile | 4 | 3 | P2 | Useful but must avoid overclaiming automated accessibility coverage. |
| Optional UX writing profile | 4 | 2 | P2 | Natural add-on from existing scorecard. |
| Optional inclusion/empathy profile | 3 | 3 | P2 | Needs careful language and evidence discipline. |
| Project-specific checklist generator | 4 | 4 | P2/P3 | North-star add-on, not MVP baseline. |
| Competitive-analysis-informed checklist | 4 | 5 | P3 | Valuable but can sprawl quickly. |
| Full-site crawler | 3 | 5 | Defer | High complexity and scope risk. |
| Authenticated task automation | 3 | 5 | Defer | Requires separate safety model. |
| Public SaaS dashboard | 2 | 5 | Reject for now | Not needed to prove local audit value. |

## First Build Order

1. Rubric and schemas.
2. Screenshot source prep.
3. Quick scan and full audit payloads.
4. Report validation and Markdown report.
5. Bounded URL capture with browser handoff.
6. PDF/viewer and comparison.
7. Optional add-on profiles.
8. Curated project-specific checklist generation.
