# UX Heuristic Compass Master Roadmap

## Current Beta Hardening Overlay

The original build phases below are mostly shipped. The current active roadmap is `compass-suite-feedback-roadmap.md`, which prioritizes real-session reliability from the Compass Suite audit. Phase 1 report payload truth, Phase 2 context-overflow controls, Phase 3 HIL resume/checkpoints, the Phase 4 example-corpus/Evidence Limits guardrail slice, and Phase 5 visual-QA/evidence/feedback polish shipped on 2026-05-04. `UXHC-BETA-110` host Playwright rendered-review guidance, `UXHC-BETA-104` through `UXHC-BETA-108` bounded multi-source/multi-state/desktop-mobile workflow support, `UXHC-BETA-111` ultra-quick guidance-only mode, `UXHC-CORPUS-001` non-Western/cross-cultural support lenses, `UXHC-CORPUS-002` WCAG/accessibility support lenses, `UXHC-CORPUS-003` ISO UX/UI/HCI support lenses, `UXHC-CORPUS-004` CX support lenses, and `UXHC-CORPUS-005` / `UXHC-CORPUS-006` corpus quality and overclaim hardening shipped on 2026-05-07. The remaining roadmap is future product polish unless a new beta feedback lane is opened.

## Current Priority Overlay

1. Future polish only: public example gallery, shareable report package, saved complete sessions, manual real-interface beta, live prototype connectors, and broader implementation-aware inspection.

## Roadmap Logic

The next major build should ship in dependency order:

1. checklist data foundation
2. deterministic scoring
3. checklist-level audit modes
4. preferences persistence
5. multi-persona researcher audits
6. bounded audience-persona usability tests

Do not build project-specific checklist generation, competitive-analysis automation, or broad browser navigation until the checklist-level core is correct.

## Roadmap Matrix

| Phase | Name | Goal | Features | Effort | Impact | Impact/Effort | Dependencies And Blockers |
|---:|---|---|---|---|---|---:|---|
| 1 | Data Foundation | Load the full checklist corpus as deterministic, platform-aware rubric data. | H1-H14 import; donor/conversion exclusion; corrected H7 9/9; authored mobile H11-H14; source tags; H14 genericization; stable IDs; schema version. | M | High | 1.50 | Source extraction and rubric fixture snapshots. |
| 2 | Scoring Engine | Convert checklist ratings into heuristic and overall grades. | 0-4 item ratings; inverted quality percentage; grade lookup; platform sessions; evidence limits. | M | High | 1.50 | Phase 1 item IDs and active heuristic records. |
| 3 | Audit Modes | Upgrade Quick Audit and Advanced Audit around checklist-level scoring. | Checklist-level `quick_scan_ux`; Advanced Audit HIL gates; upgraded `audit_ux_surface`; source limitation handling. | L | High | 1.00 | Phase 2 scoring contract. |
| 4 | Onboarding And Preferences | Persist first-use setup and audit defaults. | `save_preferences`; `update_preferences`; partial onboarding no-write rule; preference snapshots. | M | Medium | 1.00 | Audit session schema and local storage decision. |
| 5 | Agent Mode 1 | Add multi-persona researcher audit with disagreement flags. | `run_agent_audit`; `get_agent_run`; 3 default personas; averaged scorecards; disagreement flags. | L | High | 1.00 | Phase 2 scoring, Phase 3 schemas, Phase 4 persistence. |
| 6 | Agent Mode 2 | Add audience-persona usability tests with bounded browser automation. | `run_usability_test`; target audience intake; persona variants; think-aloud traces; interview outputs; Playwright safety and browser handoff. | XL | High | 0.75 | Explicit browser automation architecture and cleanup tests. |

Effort scores: S=1, M=2, L=3, XL=4. Impact scores: Low=1, Medium=2, High=3.

## Phase 1: Data Foundation

Goal: make rubric data correct before anything scores against it.

Build:

- Import H1-H14 as structured records.
- Store every checklist item as a discrete, rateable record.
- Store desktop and mobile item arrays for every heuristic.
- Lock H7 at 9 desktop and 9 mobile items with identical text.
- Mark desktop optional H11-H14 items with `source: "HE_Scorecard_Template_v2"`.
- Mark mobile optional H11-H14 items with `source: "authored_mobile_v1"`.
- Genericize H14 so it refers to the current product, organization, or interface being evaluated.
- Add `schema_version` to heuristic records.
- Lock checklist item IDs to `h{nn}_{d|m}_{ii}`.

Gate:

- `list_heuristics` returns 14 heuristics.
- H1-H10 total 79 items per platform.
- H11-H14 total 23 optional items per platform.
- Full dual-platform, all-optionals count is 204.
- Donor/conversion checklist is absent.
- No hard-coded organization/product/interface name appears in H14.

## Phase 2: Scoring Engine

Goal: make checklist ratings deterministic, gradeable, and reportable.

Build:

- Per-item 0-4 ratings.
- Inverted quality percentage formula.
- Locked grade lookup table.
- Per-heuristic scores and descriptors.
- Overall core grade.
- Expanded grade when optional profiles are active.
- `evidence_limits` schema and aggregation.

Gate:

- Fixture score calculations match expected percentages and grades.
- 100% means all checklist items scored 0.
- 0% means all checklist items scored 4.
- Evidence-limited items do not require invented certainty.

## Phase 3: Audit Modes

Goal: make Quick Audit and Advanced Audit enforce the checklist-level contract.

Build:

- Upgrade `quick_scan_ux` to return checklist-level ratings plus compact summary.
- Upgrade `audit_ux_surface` for Advanced Audit and HIL-ready state.
- Add platform selection and active optional profile selection.
- Add structured source limitation handling.
- Preserve report-readiness validation.

Gate:

- Quick Audit fixture returns checklist ratings for all active core items.
- Advanced Audit can run with HIL disabled and match the same output schema.
- Advanced Audit can pause and resume at a configured gate.

## Phase 4: Onboarding And Preferences

Goal: make repeated audits faster and preference-aware.

Build:

- Add `save_preferences`.
- Add `update_preferences`.
- Trigger onboarding when no preferences record exists.
- Capture UX level, HIL default, agent default, platform default, and optional profile defaults.
- Do not write a preference record on partial onboarding exit.
- Re-trigger onboarding on next audit attempt if preferences are still missing.

Gate:

- First-use onboarding test passes.
- Complete preferences save test passes.
- Partial-exit no-write and retrigger test passes.

## Phase 5: Agent Mode 1

Goal: produce useful multi-perspective audits without browser automation risk.

Build:

- Add `run_agent_audit`.
- Add `get_agent_run`.
- Persist agent runs locally.
- Use 3 default researcher personas.
- Compute averaged scorecard.
- Flag disagreement when agent ratings diverge by 2 or more.
- Include each agent's top 3 highest-severity findings.

Gate:

- Agent fixture returns 3 per-agent scorecards.
- Averaged ratings produce valid grades.
- Disagreement fixture flags the expected checklist item.
- `get_agent_run` retrieves persisted output.

## Phase 6: Agent Mode 2

Goal: add bounded audience-persona usability tests after browser safety is explicit.

Build:

- Add `run_usability_test`.
- Ask for target audience and task scope.
- Generate 3 audience persona variants.
- Run bounded think-aloud task attempts.
- Produce interview responses and thematic synthesis.
- Map findings back to heuristics.
- Use Playwright as the primary vehicle unless the open architecture question changes.
- Verify browser handoff every run.

Gate:

- Local static fixture test passes.
- Browser handoff test passes.
- Full crawling, authenticated flows, and unconstrained navigation are refused.

## Explicitly Deferred

- full-site crawling
- authenticated workflows
- unconstrained autonomous browser-agent navigation
- WCAG compliance certification
- analytics/session replay/heatmap ingestion
- public SaaS dashboard
- Figma plugin
- default competitor scraping
- hard-coded product- or organization-specific style guidance
