# UX Heuristic Compass Planning Package

This folder is the project-control layer for UX Heuristic Compass. It defines what to build, what not to build yet, and how future implementation should be verified.

## Start Here

1. `next-major-build-plan.md`
2. `scoring-and-report-contract.md`
3. `source-ingestion-spec.md`
4. `master-prd.md`
5. `master-roadmap.md`
6. `backlog.md`
7. `compass-suite-feedback-roadmap.md`
8. `corpus-expansion-roadmap.md`
9. `corpus-expansion-prd.md`
10. `evaluation-strategy.md`
11. `mission-audience-purpose-charter.md`

## Supporting Controls

- `effort-impact-matrix.md`
- `adopt-adapt-reject-matrix.md`
- `file-ownership-and-parallel-work-rules.md`
- `progress-log.md`

## Current Active Lane

Support-lens corpus expansion implementation.

The Compass Suite beta-hardening lane has shipped through `UXHC-BETA-111`. `UXHC-CORPUS-001` through `UXHC-CORPUS-006` have shipped, including corpus quality, report phrasing, and overclaim hardening. Future planning should now separate product polish from any new feedback-driven beta lane.

The corpus expansion docs are the active source of truth for:

1. corpus source inventory
2. slice order and acceptance criteria
3. support-only lens import rules
4. overclaim guardrails
5. per-slice user integration decisions

## Boundary Reminder

The MVP baseline is general heuristic evaluation. Project-specific and competitive-analysis-informed checklist generation is a later opt-in add-on lane.

The donor/conversion checklist from the supplied workbook is excluded from the baseline.

No heuristic description or UX writing checklist item may hard-code an organization, interface, or product name. H14 language must refer to the current product, organization, or interface being evaluated.
