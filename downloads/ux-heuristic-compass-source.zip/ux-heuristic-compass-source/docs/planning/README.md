# UX Heuristic Compass Planning Package

This folder is the project-control layer for UX Heuristic Compass. It defines what to build, what not to build yet, and how future implementation should be verified.

## Start Here

1. `next-major-build-plan.md`
2. `scoring-and-report-contract.md`
3. `source-ingestion-spec.md`
4. `master-prd.md`
5. `master-roadmap.md`
6. `backlog.md`
7. `evaluation-strategy.md`
8. `mission-audience-purpose-charter.md`

## Supporting Controls

- `effort-impact-matrix.md`
- `adopt-adapt-reject-matrix.md`
- `file-ownership-and-parallel-work-rules.md`
- `progress-log.md`

## Current Active Lane

Next major build planning package.

The next implementation lane is now defined in `next-major-build-plan.md`.
That document is the active source of truth for:

1. importing all 14 heuristics as checklist-level records
2. locking corrected H7 at 9 desktop and 9 mobile items
3. preserving authored mobile H11-H14 optional profile items
4. implementing checklist-level scoring, grading, and evidence limits
5. adding onboarding/preferences persistence
6. designing Agent Mode 1 and Agent Mode 2

## Boundary Reminder

The MVP baseline is general heuristic evaluation. Project-specific and competitive-analysis-informed checklist generation is a later opt-in add-on lane.

The donor/conversion checklist from the supplied workbook is excluded from the baseline.

No heuristic description or UX writing checklist item may hard-code an organization, interface, or product name. H14 language must refer to the current product, organization, or interface being evaluated.
