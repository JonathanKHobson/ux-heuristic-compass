# UX Heuristic Compass Backlog

## Priority Rules

- `P0`: current live host-behavior reliability issue.
- `P1`: remaining real-audit workflow support.
- `P2`: corpus expansion after source packets are supplied.
- `P3`: corpus quality, phrasing, and overclaim guardrails.
- `P4`: future public-product polish.

## Current Priority Order

| Priority | IDs | Theme | Status |
|---|---|---|---|
| P0 | `UXHC-BETA-111` | Ultra-quick guidance-only mode for small component refinement | Shipped 2026-05-07 |
| P1 | `UXHC-CORPUS-005` and `UXHC-CORPUS-006` | Corpus source-quality metadata, report phrasing, and overclaim tests | Shipped 2026-05-07 |
| P3 | `UHC-304` through `UHC-309` | Public examples, shareable package, saved sessions, manual beta, future connectors | Deferred |

## P0 Evidence-Centered Beta Hardening

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-P0-001 | Add durable `UXHCRunSummary` traces | Public MCP calls can persist JSONL run summaries with run id, tool, evidence counts, rating counts, blockers, warnings, payload/report paths, HIL state, and adapter sources. | Shipped 2026-05-04 |
| UXHC-P0-002 | Add `AuditEvidenceGraph` | Source prep and audits carry typed evidence nodes for screenshots, regions, visible text, accessibility snapshots, DOM/devtools/code/Figma/host evidence, and checklist refs validate against the graph. | Shipped 2026-05-04 |
| UXHC-P0-003 | Accept external adapter evidence | Playwright, Chrome DevTools, axe, Lighthouse, Figma, and host-supplied results normalize as evidence-only nodes and never directly set scores. | Shipped 2026-05-04 |
| UXHC-P0-004 | Add `severity_basis` | Checklist ratings may include impact, frequency, persistence, scope, confidence, and evidence strength without changing the canonical 0-4 score. | Shipped 2026-05-04 |
| UXHC-P0-005 | Add elicitation-compatible HIL metadata | HIL pauses include native AskUserQuestion payloads plus MCP elicitation-compatible schema and HIL compliance trace fields. | Shipped 2026-05-04 |
| UXHC-P0-006 | Add slot-specific report repair tasks | Report validation and generation failures return `repair_tasks[]` naming exact slots, issue, limit, evidence refs, and rewrite prompt. | Shipped 2026-05-04 |
| UXHC-P0-007 | Add health dashboard | `scripts/generate_health_dashboard.py` writes a local health report from self-test, eval fixture seed, and recent run traces. | Shipped 2026-05-04 |

## P0 Market-Aware Host Reliability

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-MP0-001 | Add market-facing Quick UX Risk Card | `quick_scan_ux` returns `quick_ux_risk_card`; missing checklist ratings produce `unscored_risk_snapshot` and never masquerade as a grade, complete scorecard, user test, or compliance result. | Shipped 2026-05-04 |
| UXHC-MP0-002 | Add 18-tool usage contracts | Every public tool has purpose, use-when, do-not-use-when, returns, next-host-action, and repair-path metadata; FastMCP descriptions and `get_started` expose the contracts. | Shipped 2026-05-04 |
| UXHC-MP0-003 | Add market overclaim fixtures | Fixtures cover automated a11y, Figma design evidence, Playwright snapshots, DevTools traces, synthetic walkthroughs, heuristic-review boundaries, and public-safe leak checks. | Shipped 2026-05-04 |
| UXHC-MP0-004 | Add directory readiness verifier | `scripts/check_directory_readiness.py` checks metadata/tool parity, public docs, redacted examples, tool contracts, and boundary statements. | Shipped 2026-05-04 |
| UXHC-MP0-005 | Normalize finding signature and triage fields | Audit findings include `finding_signature` and triage fields for prioritization without altering canonical 0-4 checklist scoring. | Shipped 2026-05-04 |
| UXHC-MP0-006 | Add support-only UX/UI lens layer | UX/UI laws, principles, standards, conventions, and non-Nielsen heuristic lenses map to findings as explanatory support, render in reports, and never alter 0-4 checklist scoring. | Shipped 2026-05-04 |

## P0 Host Behavior Tightening

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-BETA-110 | Add Playwright rendered-review guidance | Tool contracts, skill docs, and host docs tell Claude/Codex-style hosts that HTML/code/renderable UI may require rendered Playwright review instead of code-only review; guidance says to serve local HTML through HTTP and avoid `file://` for browser review unless the artifact is explicitly static-file safe. | Shipped 2026-05-07 |
| UXHC-BETA-111 | Add ultra-quick guidance-only mode | Existing UXHC tools support a tiny component-refinement lane where the host can reference the heuristic/support-lens corpus without producing a scored audit, report payload, scorecard, HIL-heavy flow, or long chat output. `quick_scan_ux` without `output_detail` returns a one-question mode gate; `output_detail="guidance_only"` / `"ultra_quick"` returns the quiet guidance lane. | Shipped 2026-05-07 |

### `UXHC-BETA-111` Product Shape

Use case:

- A designer or builder has a small component, screen fragment, HTML snippet, screenshot, or prompt target that feels off.
- They do not want a full audit, a Quick UX Risk Card, a report, or a long chat explanation.
- They want the host AI to consult UXHC briefly so it can make better direct edits, write a better fix prompt, or produce a small refinement guide.

Implementation defaults:

- Preserve the 18 public MCP tools unless a later decision proves a new public tool is truly necessary.
- Prefer extending `quick_scan_ux` with an ultra-quick/guidance-only mode over adding a tool.
- Make omitted, empty, `auto`, or `ask` `output_detail` return a quick-scan mode gate so hosts see `guidance_only`, `status_only`, `compact`, and `full`.
- Return a compact machine-friendly guidance object for the host to use, not a stakeholder-facing audit artifact.
- Allow host intent values such as `direct_fix`, `fix_prompt`, `micro_plan`, or `name_the_problem`.
- Include only the highest-signal heuristic/support-lens cues, likely issue language, suggested refinement directions, and a validation nudge.

Guardrails:

- No `overall_grade`, scorecard, checklist-complete claim, report payload, artifact generation, or compliance/user-testing language.
- No default HIL unless missing context makes the guidance unsafe or meaningless.
- No finding severity unless the host supplies enough explicit evidence and asks for scoring.
- Support lenses remain explanatory and `score_policy="support_only"`.

## P1 Report And Workflow Polish

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-P1-001 | Formalize screenshot-region refs | `img-1:r1` style refs carry parent, label, optional bounds, and notes; reports render them in the evidence appendix. | Shipped 2026-05-04 |
| UXHC-P1-002 | Add public-safe redaction | `generate_ux_audit_report(redaction_mode="public_safe")` redacts local paths, private URL details, emails, tokens, and supplied sensitive labels in rendered artifacts only. | Shipped 2026-05-04 |
| UXHC-P1-003 | Add implementation readiness advisory | Implementation/code evidence appears only as support-only advisory language and never changes checklist scores. | Shipped 2026-05-04 |
| UXHC-P1-004 | Add owner-role triage matrix | Reports classify next actions for Designer, Engineer, Product, and Research, while preserving host-supplied triage overrides. | Shipped 2026-05-04 |
| UXHC-P1-005 | Add comparison report payload | `compare_ux_audits` returns `comparison_report_payload` usable by the existing report renderer. | Shipped 2026-05-04 |

## P2 Distribution And Future Adapters

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-P2-001 | First-class host-supplied Figma evidence | Figma adapter aliases and Figma file/frame/node/component/variant/screenshot/prototype/design-token evidence normalize into the `AuditEvidenceGraph` with `score_authority: "evidence_only"`. | Shipped 2026-05-04 |
| UXHC-P2-002 | Add public distribution metadata | `dist/mcp-directory-metadata.json` lists the 18-tool surface, supported hosts, install methods, boundaries, data handling, safety notes, and evidence-only adapter policy. | Shipped 2026-05-04 |
| UXHC-P2-003 | Add public compatibility and boundary docs | `docs/public/` explains host compatibility, security boundaries, no crawler/auth/compliance posture, JSONL trace policy, and adapter evidence boundaries. | Shipped 2026-05-04 |
| UXHC-P2-004 | Add redacted example report | Public-safe Markdown and HTML examples render through the UXHC report tool and scan clean for local paths, private labels, links, scripts, and external assets. | Shipped 2026-05-04 |
| UXHC-P2-005 | Keep JSONL trace storage for beta | Docs define SQLite reconsideration only after real beta trace reads or cross-run filtering become painful. | Shipped 2026-05-04 |

## P0 Compass Suite Feedback: Report And State Reliability

Source feedback:

- Desktop Compass Suite feedback report shared by the user
- `reports/compass-suite-2026-05-04/uxhc-mcp-feedback-report.md`

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-BETA-001 | Fix run summary counts from payload-backed calls | `validate_ux_report_payload` and `generate_ux_audit_report(payload_path=...)` report correct checklist rating count, source IDs, HIL state, payload paths, and report paths. | Shipped 2026-05-04 |
| UXHC-BETA-002 | Guarantee report payload required fields | `report_ready_payload.source.status` is never null; complete scored audits produce report-valid display state; thin evidence is represented through evidence limits or an explicitly supported scored-with-limits state. | Shipped 2026-05-04 |
| UXHC-BETA-003 | Make report readiness definitive | `report_readiness_contract.status="ready"` covers every field that can block report generation and validates without manual payload repair. | Shipped 2026-05-04 |
| UXHC-BETA-004 | Strip control-only HIL fields from report payloads | Report-generation payloads do not carry blocking control fields such as `PAUSE_REQUIRED`, `HIL_BLOCKED_UNTIL_NATIVE_UI`, unresolved gates, or native-question action payloads; report-safe HIL outcome metadata remains. | Shipped 2026-05-04 |

## P0 Compass Suite Feedback: Output Ergonomics

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-BETA-005 | Add status-only audit output | `audit_ux_surface(output_detail="status_only")` and `quick_scan_ux(output_detail="status_only")` return pause state, HIL counts, grade, percentage, payload path, source status, and next host action within a small byte budget. | Shipped 2026-05-04 |
| UXHC-BETA-006 | Add compact report response mode | `generate_ux_audit_report(response_mode="compact")` omits full Markdown/HTML from the tool response when artifacts are written, while returning status, paths, validation, render metadata, and repair tasks. | Shipped 2026-05-04 |
| UXHC-BETA-007 | Add default report artifact paths | When `output_path` is omitted, report generation writes Markdown and HTML to the local UXHC reports directory and returns those paths. | Shipped 2026-05-04 |
| UXHC-BETA-008 | Add payload-path validation | `validate_ux_report_payload(payload_path=...)` validates a saved payload file and matches object-based validation results. | Shipped 2026-05-04 |

## P1 Compass Suite Feedback: HIL Resume And Audit Checkpoints

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-BETA-101 | Persist resumable audit checkpoints | Paused audits save checklist ratings, source summary, scorecard, HIL state, unresolved gates, and report payload ref in the local state directory. | Shipped 2026-05-04 |
| UXHC-BETA-102 | Resume HIL without resubmitting ratings | Existing audit tools accept `resume_run_id`; resume calls with answers/gate IDs restore prior scored state and do not reopen the collect-ratings gate. | Shipped 2026-05-04 |
| UXHC-BETA-103 | Improve HIL status reporting | Audit and report summaries distinguish `native_rendered`, `fallback_text_used`, `unavailable_resolved`, and `skipped` without overstating native HIL. | Shipped 2026-05-04 |

## P1 Compass Suite Feedback: Multi-URL, Multi-State, Multi-Platform Workflows

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-BETA-104 | Support larger explicit source batches safely | `prepare_ux_source` can handle up to 10 explicit sources while preserving no-crawler, no-auth, no-unbounded-navigation policy. | Shipped 2026-05-07 |
| UXHC-BETA-105 | Add bounded tab/state capture support | Hosts can pass `interactive_state_hints`; UXHC records captured vs uncaptured state hints and turns uncaptured tabs/accordions/toggles/modals/states into evidence-limit warnings without clicking through the UI. | Shipped 2026-05-07 |
| UXHC-BETA-106 | Add active-scope summary badge | Reports and status-only output expose a compact scope badge such as `Active scope: H1-H14, 102/102 scored`. | Shipped 2026-05-07 |
| UXHC-BETA-107 | Add consolidated desktop/mobile advanced report payload | `compare_ux_audits` includes compact platform report context for desktop/mobile score, HIL, scope, source/evidence counts, evidence limits, and checklist visibility without duplicating full audit payloads. | Shipped 2026-05-07 |
| UXHC-BETA-108 | Strengthen comparison reports | Desktop/mobile comparison reports use direct platform language and include HIL, active scope, evidence appendix rows, evidence limits, and checklist visibility when available. | Shipped 2026-05-07 |
| UXHC-BETA-109 | Add Phase 4 example corpus and Evidence Limits guardrail | Provided Compass Suite and Oppia report outputs are inventoried as fixtures; long Evidence Limits sections render a short summary plus inline accordion detail, and repeated missing evidence-ref diagnostics are grouped. | Shipped 2026-05-04 |

## P2 Compass Suite Feedback: Visual QA, Evidence Gallery, Runtime Polish

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-BETA-201 | Add Playwright visual-QA preflight | `server.py --self-test` reports visual-QA availability for the active runtime; report generation warns before `run_visual_qa=True` if Playwright is unavailable. | Shipped 2026-05-04 |
| UXHC-BETA-202 | Improve visual-QA browser handoff telemetry | Visual QA returns owned process/profile metadata in addition to `automation_browser_closed`. | Shipped 2026-05-04 |
| UXHC-BETA-203 | Add compact visual evidence gallery support | Reports include grouped evidence cards for multi-state audits while preserving public-safe redaction and no external assets; thumbnails remain deferred. | Shipped 2026-05-04 |
| UXHC-BETA-204 | Improve local traceability under redaction | Public-safe reports stay redacted, while local/private reports keep screenshot and state traceability easy to inspect. | Shipped 2026-05-04 |

## P3 Compass Suite Feedback: Feedback And Issue Export

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-BETA-301 | Add structured issue export without a public tool | Feedback reports or run summaries can be converted into JSON/Markdown issue bundles without changing the 18-tool surface. | Shipped 2026-05-04 |
| UXHC-BETA-302 | Add release feedback ledger | Feedback source, severity, affected tool, status, and linked acceptance tests are tracked in planning docs. | Shipped 2026-05-04 |

## P2 Corpus Expansion Lanes

These lanes expand the support-lens corpus only; H01-H14 remain the scoring body. Source packets were supplied on 2026-05-07 and are inventoried in `corpus-expansion-roadmap.md`.

Skill-package rule: every shipped corpus slice must update `packaging/skills/ux-heuristic-compass/` alongside runtime changes. `SKILL.md` should stay light, while `references/corpus-support-lenses.md` carries deeper slice-specific guidance, mappings, caveats, and forbidden-claim language.

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-CORPUS-001 | Add non-Western and cross-cultural UX support lenses | Non-Western, cross-cultural, Indigenous, decolonial, multilingual, low-resource, and culturally situated UX/HCI lenses map to H01-H14 with anti-essentialism caveats and `score_policy="support_only"`; advanced reports include a default `Cultural Context Signal` plus deeper `Cultural Context Integrity Advisory` without changing canonical scores. | Shipped 2026-05-07 |
| UXHC-CORPUS-002 | Add WCAG/accessibility support-lens expansion | WCAG/accessibility guidance maps to H01-H14; advanced reports include a default `Accessibility Readiness Signal` plus deeper `WCAG-Informed Accessibility Readiness` with a WCAG Level Signal (`A`, `AA`, `AAA`, or `Evidence Limited`) that is not a score and never WCAG/ADA/legal/procurement/conformance certification. | Shipped 2026-05-07 |
| UXHC-CORPUS-003 | Add ISO standards support-lens expansion | ISO usability, human-centered design, interaction, accessibility, quality-in-use, AI, privacy/security, workload, operations, and related UX standards map to H01-H14 and relevant checklist patterns; report phrasing treats ISO as support guidance, not formal standards compliance, conformance, certification, procurement proof, or legal assurance. | Shipped 2026-05-07 |
| UXHC-CORPUS-004 | Add CX support-lens expansion | CX operating lenses for promise debt, customer effort, recovery, complaints, omnichannel continuity, VoC, customer success, journey ownership, and service governance map to H01-H14, especially H13, without claiming ROI, NPS, retention, satisfaction, or real-customer outcome proof. | Shipped 2026-05-07 |

## P3 Corpus Quality And Report Integration

| ID | Title | Acceptance Criteria | Status |
|---|---|---|---|
| UXHC-CORPUS-005 | Add corpus source-quality metadata and phrasing rules | Support lenses are normalized through family policies for source quality, applicability, evidence needed, and report guardrails across core, cross-cultural, WCAG, ISO, and CX lenses without adding required schema fields. | Shipped 2026-05-07 |
| UXHC-CORPUS-006 | Add corpus overclaim regression tests | Tests prove WCAG/ISO/cross-cultural/CX references and advisory indexes do not become compliance claims, universal cultural claims, synthetic-user claims, business-outcome claims, or score modifiers. | Shipped 2026-05-07 |

## P0 Data Foundation And Scoring

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-001 | Import all 14 heuristics | `list_heuristics` returns H1-H14 with names, descriptions, optional flags, signals, and platform item arrays. |
| UHC-002 | Import checklist items as records | Every checklist item is stored as a discrete rateable record with stable ID, platform, index, source, and text. |
| UHC-003 | Lock H7 corrected count | H7 has 9 desktop and 9 mobile items, identical across platforms. |
| UHC-004 | Import authored mobile optionals | H11-H14 mobile items load with `source: "authored_mobile_v1"`. |
| UHC-005 | Preserve spreadsheet desktop optionals | H11-H14 desktop items load with `source: "HE_Scorecard_Template_v2"`. |
| UHC-006 | Genericize H14 | H14 description and checklist text refer to the current product, organization, brand voice, or interface being evaluated, with no hard-coded name. |
| UHC-007 | Exclude donor/conversion checklist | Donor/conversion criteria do not appear in rubric data, fixtures, default reports, or generated checklist outputs. |
| UHC-008 | Lock checklist item ID format | IDs follow `h{nn}_{d|m}_{ii}` and stay stable across schema versions. |
| UHC-009 | Add checklist-level scoring engine | Per-item 0-4 ratings produce per-heuristic quality percentages, grades, and descriptors. |
| UHC-010 | Add evidence limits schema | Source-constrained items return structured `evidence_limits` instead of invented certainty. |
| UHC-011 | Update scoring tests | Fixtures prove 100% means all item ratings are 0 and 0% means all item ratings are 4. |

## P1 Audit Modes And Preferences

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-101 | Upgrade `quick_scan_ux` | Quick Audit returns checklist-level ratings, per-heuristic grades, overall grade, evidence limits, and compact top-findings summary. |
| UHC-102 | Upgrade `audit_ux_surface` | Advanced Audit uses the same scoring engine and supports HIL-ready pause/resume state. |
| UHC-103 | Add platform session selection | Audits require or infer `desktop` vs `mobile`, and never silently mix platform scoring. |
| UHC-104 | Add optional profile selection | H11-H14 are included only when requested or saved as defaults. |
| UHC-105 | Add report payload validation | Reports block missing checklist IDs, ratings, grade fields, evidence refs, confidence, or evidence-limit explanations. |
| UHC-106 | Add `save_preferences` | Complete onboarding writes a persistent preference record. |
| UHC-107 | Add `update_preferences` | Existing preference fields can be updated without overwriting unspecified values. |
| UHC-108 | Add partial onboarding behavior | Exiting onboarding before all required fields writes no record and retriggers on next audit attempt. |
| UHC-109 | Preserve calibration tool name | `calibrate_ux_sensitivity` remains canonical; `calibrate_ux_severity` is only a future compatibility alias. |
| UHC-110 | Add Core Audit First guardrails | Docs and tests state that UX Health Snapshot, scorecard, top finding, plain-language read, and recommendation lead before Atlas/activity support layers. |
| UHC-111 | Reset HIL cadence | Quick Audit exposes light context questions when needed; Advanced Audit exposes 3 beginning, 3 middle, and 3 final questions. |

## P2 Agent Modes

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-201 | Add `run_agent_audit` | Agent Mode 1 runs 3 researcher personas and returns per-agent scorecards plus averaged scorecard. |
| UHC-202 | Persist agent runs | Agent Mode 1 outputs are saved locally with `agent_run_id`. |
| UHC-203 | Add `get_agent_run` | `get_agent_run(agent_run_id)` returns the full persisted agent run or a typed not-found/expired error. |
| UHC-204 | Add disagreement flags | Any checklist item with agent rating spread of 2 or more is prominently flagged. |
| UHC-205 | Add Agent Mode 1 tests | Fixture proves per-agent ratings, averaged grades, top findings, persistence, and retrieval. |
| UHC-206 | Architect `run_usability_test` | Agent Mode 2 design includes target audience intake, task scope, persona variants, Playwright boundaries, and browser handoff. |
| UHC-207 | Add bounded usability fixture | Local static fixture proves bounded think-aloud output without full crawling or auth automation. |

## P3 Future Expansion

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-301 | Project-specific add-on scoring | Add-on criteria remain opt-in and never modify core grade. |
| UHC-302 | Authored mobile optional review loop | Reports can group issues by `source: "authored_mobile_v1"` to support future rubric refinement. |
| UHC-303 | Live Figma/prototype connector | Future live connector remains optional; shipped P2 support accepts host-supplied Figma evidence without adding a runtime dependency. |
| UHC-304 | Public example gallery | Redacted example audits demonstrate before/after usefulness; first public-safe example shipped in `docs/public/`. |
| UHC-305 | Shareable report package | Public-safe export strips local paths and private source details; P2 docs and examples define the initial release-clean standard. |
| UHC-306 | Save complete audit sessions | Add `save_audit_result` / `get_audit_result` or equivalent only after the core audit/HIL contract is stable. |
| UHC-307 | Manual real-interface audit | Run a full live audit against a representative interface when manual testing is available. |
| UHC-308 | Future Atlas/activity expansion gate | New support cards ship only when they displace a concrete UX audit need and pass the Core Audit First decision filter. |
| UHC-309 | Optional implementation-aware inspection lane | Host AI or coding harness can attach source-code, rendered-preview, browser-observation, or external frontend-audit evidence as advisory support without changing checklist scores unless complete `checklist_ratings` are supplied. |

## Rejected From Baseline

| Item | Reason |
|---|---|
| Donor/conversion checklist | Use-case-specific and excluded from the general HE product. |
| Full crawler | Reliability, safety, and cleanup risk too high before bounded source/audit/report core is stable. |
| Auth automation | Requires separate consent, safety, and browser-state design. |
| Default competitor scraping | Turns UX audit into market intelligence before core audit ships. |
| Hard-coded organization style guidance | The tool must adapt H14 to the current product, organization, or interface being evaluated. |
