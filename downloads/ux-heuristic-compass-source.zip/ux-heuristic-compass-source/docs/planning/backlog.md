# UX Heuristic Compass Backlog

## Priority Rules

- `P0`: required for next checklist-level build gate.
- `P1`: required for preferences and advanced audit reliability.
- `P2`: agent-assisted audit expansion.
- `P3`: future north-star or public-product polish.

## P0 Data Foundation And Scoring

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-001 | Import all 14 heuristics | `list_heuristics` returns H1-H14 with names, descriptions, optional flags, signals, and platform item arrays. |
| UHC-002 | Import checklist items as records | Every checklist item is stored as a discrete rateable record with stable ID, platform, index, source, and text. |
| UHC-003 | Lock H7 corrected count | H7 has 9 desktop and 9 mobile items, identical across platforms. |
| UHC-004 | Import authored mobile optionals | H11-H14 mobile items load with `source: "authored_mobile_v1"`. |
| UHC-005 | Preserve spreadsheet desktop optionals | H11-H14 desktop items load with `source: "HE_Scorecard_Template_v2"`. |
| UHC-006 | Genericize H14 | H14 description and checklist text refer to the current product, organization, brand voice, or interface being evaluated, with no hard-coded name. |
| UHC-007 | Exclude donor/conversion checklist | Donor/conversion criteria do not appear in rubric data, fixtures, default reports, or generated checklist outputs. |
| UHC-008 | Lock checklist item ID format | IDs follow `h{nn}_{d|m}_{ii}` and stay stable across schema versions. |
| UHC-009 | Add checklist-level scoring engine | Per-item 0-4 ratings produce per-heuristic quality percentages, grades, and descriptors. |
| UHC-010 | Add evidence limits schema | Source-constrained items return structured `evidence_limits` instead of invented certainty. |
| UHC-011 | Update scoring tests | Fixtures prove 100% means all item ratings are 0 and 0% means all item ratings are 4. |

## P1 Audit Modes And Preferences

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-101 | Upgrade `quick_scan_ux` | Quick Audit returns checklist-level ratings, per-heuristic grades, overall grade, evidence limits, and compact top-findings summary. |
| UHC-102 | Upgrade `audit_ux_surface` | Advanced Audit uses the same scoring engine and supports HIL-ready pause/resume state. |
| UHC-103 | Add platform session selection | Audits require or infer `desktop` vs `mobile`, and never silently mix platform scoring. |
| UHC-104 | Add optional profile selection | H11-H14 are included only when requested or saved as defaults. |
| UHC-105 | Add report payload validation | Reports block missing checklist IDs, ratings, grade fields, evidence refs, confidence, or evidence-limit explanations. |
| UHC-106 | Add `save_preferences` | Complete onboarding writes a persistent preference record. |
| UHC-107 | Add `update_preferences` | Existing preference fields can be updated without overwriting unspecified values. |
| UHC-108 | Add partial onboarding behavior | Exiting onboarding before all required fields writes no record and retriggers on next audit attempt. |
| UHC-109 | Preserve calibration tool name | `calibrate_ux_sensitivity` remains canonical; `calibrate_ux_severity` is only a future compatibility alias. |
| UHC-110 | Add Core Audit First guardrails | Docs and tests state that UX Health Snapshot, scorecard, top finding, plain-language read, and recommendation lead before Atlas/activity support layers. |
| UHC-111 | Reset HIL cadence | Quick Audit exposes light context questions when needed; Advanced Audit exposes 3 beginning, 3 middle, and 3 final questions. |

## P2 Agent Modes

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-201 | Add `run_agent_audit` | Agent Mode 1 runs 3 researcher personas and returns per-agent scorecards plus averaged scorecard. |
| UHC-202 | Persist agent runs | Agent Mode 1 outputs are saved locally with `agent_run_id`. |
| UHC-203 | Add `get_agent_run` | `get_agent_run(agent_run_id)` returns the full persisted agent run or a typed not-found/expired error. |
| UHC-204 | Add disagreement flags | Any checklist item with agent rating spread of 2 or more is prominently flagged. |
| UHC-205 | Add Agent Mode 1 tests | Fixture proves per-agent ratings, averaged grades, top findings, persistence, and retrieval. |
| UHC-206 | Architect `run_usability_test` | Agent Mode 2 design includes target audience intake, task scope, persona variants, Playwright boundaries, and browser handoff. |
| UHC-207 | Add bounded usability fixture | Local static fixture proves bounded think-aloud output without full crawling or auth automation. |

## P3 Future Expansion

| ID | Title | Acceptance Criteria |
|---|---|---|
| UHC-301 | Project-specific add-on scoring | Add-on criteria remain opt-in and never modify core grade. |
| UHC-302 | Authored mobile optional review loop | Reports can group issues by `source: "authored_mobile_v1"` to support future rubric refinement. |
| UHC-303 | Figma/prototype source adapter | Figma/prototype handling is source prep, not a core runtime dependency. |
| UHC-304 | Public example gallery | Redacted example audits demonstrate before/after usefulness. |
| UHC-305 | Shareable report package | Public-safe export strips local paths and private source details. |
| UHC-306 | Save complete audit sessions | Add `save_audit_result` / `get_audit_result` or equivalent only after the core audit/HIL contract is stable. |
| UHC-307 | Manual real-interface audit | Run a full live audit against a representative interface when manual testing is available. |
| UHC-308 | Future Atlas/activity expansion gate | New support cards ship only when they displace a concrete UX audit need and pass the Core Audit First decision filter. |
| UHC-309 | Optional implementation-aware inspection lane | Host AI or coding harness can attach source-code, rendered-preview, browser-observation, or external frontend-audit evidence as advisory support without changing checklist scores unless complete `checklist_ratings` are supplied. |

## Rejected From Baseline

| Item | Reason |
|---|---|
| Donor/conversion checklist | Use-case-specific and excluded from the general HE product. |
| Full crawler | Reliability, safety, and cleanup risk too high before bounded source/audit/report core is stable. |
| Auth automation | Requires separate consent, safety, and browser-state design. |
| Default competitor scraping | Turns UX audit into market intelligence before core audit ships. |
| Hard-coded organization style guidance | The tool must adapt H14 to the current product, organization, or interface being evaluated. |
