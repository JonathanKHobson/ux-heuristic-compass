# File Ownership And Parallel Work Rules

## Purpose

Future implementation should avoid overlapping edits. Split work by subsystem and keep write scopes clear.

## Suggested Workstreams

| Workstream | Owns | Avoids |
|---|---|---|
| Product docs | `docs/planning`, `README.md`, `AGENTS.md` | Runtime code unless documenting exact interface. |
| Rubric/KB | heuristic data files, rubric schemas, examples | Report renderer templates. |
| Source prep | screenshot/image/URL manifest code and fixtures | Audit scoring logic. |
| Audit engine | finding builders, severity derivation, health snapshot | Browser automation code. |
| Report artifacts | validation, Markdown/PDF/viewer | Rubric content changes. |
| Browser capture | URL capture, viewport setup, cleanup checks | Heuristic scoring. |
| Tests/evals | fixtures, validators, smoke tests | Large feature rewrites. |

## Parallel Edit Rules

- Do not edit another workstream's files without coordination.
- Keep generated artifacts out of commits unless they are intended fixtures.
- Prefer small vertical slices: source fixture -> audit payload -> report validation.
- Do not broaden URL capture while report readiness is unstable.
- Do not build project-specific checklist generation until baseline HE audit has passing fixtures.

## Implementation Sequence

1. Build schemas and rubric.
2. Build screenshot source prep.
3. Build audit payloads.
4. Build validation and Markdown report.
5. Add bounded URL capture and browser cleanup.
6. Add PDF/viewer.
7. Add optional general profiles.
8. Add project-specific checklist generator.

## Verification Before Merge

Each workstream must provide:

- command run
- fixture or test name
- pass/fail result
- known limitations
- whether browser handoff was required and verified
