from __future__ import annotations

from typing import Any


TOOL_CONTRACT_SCHEMA_VERSION = "uxhc.tool_contracts.v1"
TOOL_DISCOVERY_SCHEMA_VERSION = "uxhc.tool_discovery.v1"

TOOL_DISCOVERY_TOPIC_ALIASES = {
    "tools",
    "tool_inventory",
    "tool_discovery",
    "tool_discovery_contract",
    "tool_list",
}

PUBLIC_TOOL_NAMES = [
    "get_started",
    "ux_heuristic_overview",
    "list_heuristics",
    "prepare_ux_source",
    "quick_scan_ux",
    "audit_ux_surface",
    "validate_ux_report_payload",
    "generate_ux_audit_report",
    "calibrate_ux_sensitivity",
    "calibrate_ux_severity",
    "compare_ux_audits",
    "draft_project_addon_profile",
    "save_preferences",
    "stress_test_heuristic_finding",
    "update_preferences",
    "run_agent_audit",
    "get_agent_run",
    "run_usability_test",
]


TOOL_USAGE_CONTRACTS: dict[str, dict[str, str]] = {
    "get_started": {
        "purpose": "Orient a cold host to UXHC capabilities, boundaries, optional profiles, HIL, the authoritative 18-tool surface, and the preferred audit workflow.",
        "use_when": "Use first in a new UXHC session, onboarding flow, or when the host is unsure which UXHC tool comes next.",
        "do_not_use_when": "Do not use as a scored audit, browser crawler, or substitute for source preparation and checklist ratings.",
        "returns": "Startup guidance, authoritative 18-tool discovery contract, profile mapping, checklist rating contract, behavioral contracts, rendered-review hint, and product boundaries.",
        "next_host_action": "Prepare bounded evidence with prepare_ux_source or collect user preferences with save_preferences.",
        "repair_path": "If the workflow or tool inventory is unclear, rerun get_started and verify public_tool_count=18; for HTML/UI code, call get_started(topic='rendered_review') before final UX claims.",
    },
    "ux_heuristic_overview": {
        "purpose": "Explain the UXHC heuristic rubric, optional profile model, and compact authoritative 18-tool inventory without running an audit.",
        "use_when": "Use when a host or user needs rubric context, heuristic definitions, scoring meaning, or quick orientation to the full UXHC tool surface.",
        "do_not_use_when": "Do not use for checklist item inventories; use list_heuristics for active item contracts.",
        "returns": "Human-readable rubric overview, heuristic framing, profile context, and compact all-18 tool discovery contract.",
        "next_host_action": "Use get_started for full contracts, list_heuristics for item IDs, or prepare_ux_source to start an evidence-bound audit.",
        "repair_path": "If checklist IDs are needed, call list_heuristics(detail_level='full'); if the host sees fewer than 18 tools, call get_started(topic='tools').",
    },
    "list_heuristics": {
        "purpose": "Return the active H01-H14 heuristic/profile inventory, checklist item contract, and support-only lens corpus summary.",
        "use_when": "Use before submitting checklist_ratings, when a host needs H01-H14 profile/item mapping, or when the host needs to discover support-only UX/UI laws, corpus lenses, and evidence guidance without running an audit.",
        "do_not_use_when": "Do not use support lenses as UX judgments or scores; H01-H14 checklist ratings remain the canonical scoring body.",
        "returns": "Compact or full heuristic definitions, profile-to-heuristic mapping, item counts, checklist rows, support_lens_summary, and topic/detail-gated support_lens_catalog.",
        "next_host_action": "Submit checklist_ratings with returned item IDs to quick_scan_ux or audit_ux_surface; use support lenses only to explain evidence-backed findings and validation needs.",
        "repair_path": "If checklist output is too compact, retry with detail_level='full'; if support lens discovery is needed, retry with topic='support_lenses' or detail_level='support_lenses'.",
    },
    "prepare_ux_source": {
        "purpose": "Normalize bounded screenshots, image bundles, URL manifests, and host-supplied evidence into a UXHC source manifest.",
        "use_when": "Use before quick_scan_ux or audit_ux_surface when the host has interface evidence to evaluate, including up to 10 explicit URL/source items, state hints, or rendered Playwright/browser observations for HTML or UI code.",
        "do_not_use_when": "Do not use for full-site crawling, auth automation, destructive browser actions, or compliance scanning.",
        "returns": "Prepared source manifest, evidence refs, interactive_state_summary, AuditEvidenceGraph, capture warnings, and adapter evidence summary.",
        "next_host_action": "Have the host interpret the evidence and submit checklist_ratings to quick_scan_ux or audit_ux_surface.",
        "repair_path": "If source status is partial/blocked, provide screenshots, rendered evidence, captured state labels, or a smaller bounded source set; serve local HTML through HTTP/local server instead of file:// when browser review is needed.",
    },
    "quick_scan_ux": {
        "purpose": "Produce either ultra-quick non-scoring guidance, a small scored-audit status response, or explicit quick-scan diagnostics from bounded evidence.",
        "use_when": "Use for cold-host triage, tiny component refinement, direct-fix prompts, screenshot/observation-only risk cards, rendered-review observations, compact checklist-guided scoring, or resuming a paused quick HIL checkpoint by resume_run_id.",
        "do_not_use_when": "Do not present guidance_only or an unscored quick risk card as a complete scorecard, user test, crawler result, report artifact, or compliance finding.",
        "returns": "Omitted output_detail returns a quick_scan_mode_gate; output_detail='guidance_only' returns a tiny non-scoring guidance card; output_detail='status_only' returns small workflow fields; compact/full expose diagnostic quick-scan details.",
        "next_host_action": "Choose output_detail explicitly: guidance_only for direct edits/fix prompts/micro-plans, status_only for scored-audit orchestration, compact/full for diagnostics; if HIL pauses, resume with resume_run_id plus answers.",
        "repair_path": "If a mode gate appears, rerun with the selected output_detail; if status says unscored/blocked, add checklist_ratings or evidence limits; if HTML/UI code was supplied without rendering, gather browser evidence or state the rendered-review limit.",
    },
    "audit_ux_surface": {
        "purpose": "Run the full checklist-level UXHC audit contract for bounded interface evidence, with support-only UX/UI laws, principles, WCAG/accessibility lenses, ISO UX/UI/HCI lenses, CX/service-journey lenses, and cultural-context lenses attached to findings when relevant.",
        "use_when": "Use when the host can provide checklist_ratings for every active item and needs grades, findings, HIL, report payloads, rendered-review evidence integration, or resume from resume_run_id.",
        "do_not_use_when": "Do not use as an autonomous browser crawler, synthetic user claim, or automated accessibility/compliance certification.",
        "returns": "By default returns a status-only orchestration contract with grade, HIL counts, source status, report readiness, payload refs, and resume_run_id/checkpoint refs when paused; output_detail='compact' or 'full' returns larger audit details, including support-only ISO/WCAG/CX/cultural-context lenses and WCAG/accessibility or cultural-context corpus advisory modules when relevant.",
        "next_host_action": "Resolve HIL gates by calling audit_ux_surface(resume_run_id=..., hil_answers=... or resolved_gate_ids=..., host_question_ui_status=...), then validate and render report_payload_ref.path.",
        "repair_path": "If blocked or needs ratings, request output_detail='compact' or 'full' for diagnostics; if resume fails, use the latest audit_checkpoint_ref.resume_run_id or rerun the audit to create a fresh checkpoint.",
    },
    "validate_ux_report_payload": {
        "purpose": "Validate a scored audit or comparison payload before UXHC report generation.",
        "use_when": "Use before generate_ux_audit_report or after changing report-ready content slots; prefer payload_path from report_payload_ref for large audits.",
        "do_not_use_when": "Do not use to generate standalone handmade HTML/PDF or bypass renderer repair tasks.",
        "returns": "QA status, blocking issues, repair tasks, content slot limits, report harness metadata, and run summary counts for inline payloads or payload_path inputs.",
        "next_host_action": "If ready, call generate_ux_audit_report(payload_path=..., response_mode='compact'); if blocked, repair the payload and retry validation.",
        "repair_path": "Apply returned repair_tasks exactly; do not create a fallback report outside UXHC.",
    },
    "generate_ux_audit_report": {
        "purpose": "Render a validated audit or comparison payload through the UXHC static report harness, including support-only UX laws/principles, ISO, CX, and WCAG/accessibility cues, and corpus advisory modules when present.",
        "use_when": "Use when a scored audit/report_ready_payload or comparison_report_payload is ready to become Markdown/HTML/PDF; prefer payload_path plus response_mode='compact' for MCP hosts.",
        "do_not_use_when": "Do not use to crawl, inspect pages, invent scores, or handmake reports after validation failure.",
        "returns": "Default local Markdown/HTML paths, optional PDF path, QA status, validation/render metadata, redaction metadata, and repair tasks on failure; compact mode omits full Markdown content.",
        "next_host_action": "Open or share the generated artifact; if blocked, repair the payload and retry this tool.",
        "repair_path": "Use repair_tasks and content_slot_limits; never generate standalone fallback HTML manually.",
    },
    "calibrate_ux_sensitivity": {
        "purpose": "Check severity calibration against UXHC fixtures and tolerance settings.",
        "use_when": "Use during regression checks or when changing scoring/severity behavior.",
        "do_not_use_when": "Do not use as a live audit or source-evidence interpreter.",
        "returns": "Calibration status, fixture results, tolerance, and pass/fail diagnostics.",
        "next_host_action": "Fix any failed scoring calibration before shipping runtime changes.",
        "repair_path": "Inspect failed fixtures, repair scoring logic or fixture expectations, then rerun calibration.",
    },
    "calibrate_ux_severity": {
        "purpose": "Compatibility alias for severity calibration; delegates to the canonical sensitivity calibration path.",
        "use_when": "Use when older hosts still call the severity calibration name.",
        "do_not_use_when": "Do not add new workflows around this alias; prefer calibrate_ux_sensitivity.",
        "returns": "Canonical calibration result with alias metadata.",
        "next_host_action": "Use calibrate_ux_sensitivity in new docs and tests.",
        "repair_path": "If results diverge from the canonical tool, repair the alias delegation.",
    },
    "compare_ux_audits": {
        "purpose": "Compare two UXHC audit payloads for fixed, new, unresolved, and severity-changed findings.",
        "use_when": "Use after before/after audits, desktop/mobile comparisons, or fix validation passes.",
        "do_not_use_when": "Do not compare unscored quick risk cards as if they were complete audits.",
        "returns": "Comparison summary, finding deltas, top remaining risk, compact platform_report_context, evidence limits, and comparison_report_payload.",
        "next_host_action": "Pass comparison_report_payload to generate_ux_audit_report for a static comparison artifact.",
        "repair_path": "If matching is weak, add checklist_item_id/finding_signature fields and rerun the comparison.",
    },
    "draft_project_addon_profile": {
        "purpose": "Draft an opt-in project-specific add-on profile without changing UXHC baseline scoring.",
        "use_when": "Use when a product needs clearly separated local criteria beyond H01-H14.",
        "do_not_use_when": "Do not use to smuggle donor, conversion, legal, compliance, or domain baselines into core UXHC scoring.",
        "returns": "Add-on scaffold, blocked terms when unsafe, and baseline-health impact policy.",
        "next_host_action": "Review the add-on as separate project context before any future opt-in use.",
        "repair_path": "Remove blocked terms or reframe as non-scored project context and retry.",
    },
    "save_preferences": {
        "purpose": "Save UXHC onboarding preferences for platform, optional profiles, HIL, agent behavior, and UX level.",
        "use_when": "Use during onboarding or when a user explicitly sets persistent UXHC behavior defaults.",
        "do_not_use_when": "Do not silently infer durable preferences from a single audit turn.",
        "returns": "Saved or incomplete preference status plus missing fields.",
        "next_host_action": "Use saved preferences in subsequent prepare/audit calls or ask for missing onboarding answers.",
        "repair_path": "If incomplete, supply required preference fields and retry.",
    },
    "stress_test_heuristic_finding": {
        "purpose": "Stress-test one UX finding for false positives, evaluator bias, alternative explanations, and a concrete fix.",
        "use_when": "Use for a high-severity or uncertain checklist finding before reporting it strongly.",
        "do_not_use_when": "Do not use as an argument-analysis tool or replacement for the full audit scorecard.",
        "returns": "UX-native false-positive checks, bias flags, alternative explanations, and one concrete fix.",
        "next_host_action": "Adjust confidence, evidence limits, or recommendation before report generation.",
        "repair_path": "If evidence_refs are missing, add traceable evidence or downgrade confidence.",
    },
    "update_preferences": {
        "purpose": "Update existing UXHC user preferences without resubmitting the whole onboarding record.",
        "use_when": "Use when the user changes platform/profile/HIL/agent defaults.",
        "do_not_use_when": "Do not use to write inferred preferences without explicit user intent.",
        "returns": "Updated preference record and changed fields.",
        "next_host_action": "Continue the audit using updated defaults.",
        "repair_path": "If no record exists, call save_preferences first.",
    },
    "run_agent_audit": {
        "purpose": "Aggregate host-executed researcher persona scorecards and flag disagreement patterns.",
        "use_when": "Use for Agent Mode 1 when multiple host personas have completed checklist ratings.",
        "do_not_use_when": "Do not treat it as autonomous agents, real participant evidence, or a substitute for checklist ratings.",
        "returns": "Agent run contract or aggregated scorecard, disagreement flags, bias context, and persistence ID.",
        "next_host_action": "If contract-ready, host personas produce scorecards; then call audit_ux_surface or rerun with per_agent_scorecards.",
        "repair_path": "If personas are invalid, pass dictionaries with agent_id, label, lens, and optional weighting.",
    },
    "get_agent_run": {
        "purpose": "Retrieve a previously persisted UXHC agent audit aggregation by ID.",
        "use_when": "Use after run_agent_audit returns an agent_run_id.",
        "do_not_use_when": "Do not use for report generation or source lookup.",
        "returns": "Stored agent run or a structured not-found/invalid-id error.",
        "next_host_action": "Use the retrieved scorecard or disagreement flags in audit synthesis/reporting.",
        "repair_path": "If not found, rerun run_agent_audit or check the agent_run_id.",
    },
    "run_usability_test": {
        "purpose": "Prepare bounded usability-test/synthetic walkthrough support and transcript synthesis scaffolds.",
        "use_when": "Use for Agent Mode 2 prep, bounded walkthrough support, interview validity checks, or real participant log synthesis.",
        "do_not_use_when": "Do not label synthetic walkthroughs as real user testing or run unbounded crawling/auth flows.",
        "returns": "Bounded test contract, synthetic/persona walkthrough support, evidence level, interview checks, and synthesis flows.",
        "next_host_action": "Supply real participant logs for user-test claims or use output as prep/synthetic support with evidence limits.",
        "repair_path": "If scope is blocked, narrow task_scope to bounded visible interface tasks and retry.",
    },
}


REQUIRED_CONTRACT_FIELDS = ("purpose", "use_when", "do_not_use_when", "returns", "next_host_action", "repair_path")

TOOL_DISCOVERY_GROUPS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Orientation/setup", ("get_started", "ux_heuristic_overview", "list_heuristics")),
    ("Evidence/source prep", ("prepare_ux_source",)),
    ("Quick/full audit", ("quick_scan_ux", "audit_ux_surface")),
    ("Report validation/rendering", ("validate_ux_report_payload", "generate_ux_audit_report")),
    ("Calibration/comparison", ("calibrate_ux_sensitivity", "calibrate_ux_severity", "compare_ux_audits")),
    ("Preferences", ("save_preferences", "update_preferences")),
    ("Agent/usability modes", ("run_agent_audit", "get_agent_run", "run_usability_test")),
    ("Finding stress/add-on support", ("stress_test_heuristic_finding", "draft_project_addon_profile")),
)


def _normalize_topic(topic: str | None) -> str:
    return (topic or "").strip().lower().replace("-", "_").replace(" ", "_")


def is_tool_discovery_topic(topic: str | None) -> bool:
    return _normalize_topic(topic) in TOOL_DISCOVERY_TOPIC_ALIASES


def tool_description(tool_name: str) -> str:
    contract = TOOL_USAGE_CONTRACTS[tool_name]
    return " ".join(f"{field.replace('_', ' ')}: {contract[field]}" for field in REQUIRED_CONTRACT_FIELDS)


def public_tool_contracts() -> dict[str, dict[str, str]]:
    return {name: dict(TOOL_USAGE_CONTRACTS[name]) for name in PUBLIC_TOOL_NAMES}


def compact_tool_inventory() -> list[dict[str, Any]]:
    grouped: list[dict[str, Any]] = []
    for group_name, tool_names in TOOL_DISCOVERY_GROUPS:
        grouped.append(
            {
                "group": group_name,
                "tools": [
                    {
                        "name": tool_name,
                        "purpose": TOOL_USAGE_CONTRACTS[tool_name]["purpose"],
                    }
                    for tool_name in tool_names
                ],
            }
        )
    return grouped


def tool_discovery_contract(*, include_full_contracts: bool = False) -> dict[str, Any]:
    discovered_names = [tool["name"] for group in compact_tool_inventory() for tool in group["tools"]]
    result: dict[str, Any] = {
        "schema_version": TOOL_DISCOVERY_SCHEMA_VERSION,
        "public_tool_count": len(PUBLIC_TOOL_NAMES),
        "authoritative_tool_names": list(PUBLIC_TOOL_NAMES),
        "inventory_tool_count": len(discovered_names),
        "inventory_complete": len(discovered_names) == len(PUBLIC_TOOL_NAMES) and set(discovered_names) == set(PUBLIC_TOOL_NAMES),
        "tool_search_warning": "Some hosts surface only the first few matching tools during local tool search. UXHC has 18 public tools; use this inventory as authoritative and request a larger search limit where the host supports it.",
        "topic_aliases": sorted(TOOL_DISCOVERY_TOPIC_ALIASES),
        "compact_inventory": compact_tool_inventory(),
        "host_instruction": "If a host reports fewer than 18 UXHC tools, call get_started or ux_heuristic_overview and verify public_tool_count=18 before concluding tools are missing.",
    }
    if include_full_contracts:
        result["full_tool_contracts"] = public_tool_contracts()
    return result


def validate_tool_contracts() -> dict[str, Any]:
    blockers: list[dict[str, str]] = []
    for name in PUBLIC_TOOL_NAMES:
        contract = TOOL_USAGE_CONTRACTS.get(name)
        if not contract:
            blockers.append({"tool": name, "field": "contract", "issue": "missing"})
            continue
        for field in REQUIRED_CONTRACT_FIELDS:
            value = str(contract.get(field) or "").strip()
            if len(value) < 20:
                blockers.append({"tool": name, "field": field, "issue": "too_short_or_missing"})
        description = tool_description(name).lower()
        if description.strip() in {name, name.replace("_", " ")} or "use when" not in description or "do not use when" not in description:
            blockers.append({"tool": name, "field": "description", "issue": "generic_or_missing_required_phrases"})
    return {
        "schema_version": TOOL_CONTRACT_SCHEMA_VERSION,
        "status": "ready" if not blockers else "blocked",
        "tool_count": len(PUBLIC_TOOL_NAMES),
        "required_fields": list(REQUIRED_CONTRACT_FIELDS),
        "blockers": blockers,
    }
