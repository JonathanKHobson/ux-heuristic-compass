from __future__ import annotations

import hashlib
import re
from typing import Any

from .rubric import CORE_HEURISTICS, REJECTED_BASELINE_PROFILES


def _as_list(value: list[str] | str | None) -> list[str]:
    if value is None or value == "":
        return []
    if isinstance(value, str):
        return [part.strip() for part in value.replace("\n", ",").split(",") if part.strip()]
    return [str(item).strip() for item in value if str(item).strip()]


def _slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug[:48] or "criterion"


def _stable_id(prefix: str, value: str) -> str:
    return f"{prefix}_{hashlib.sha256(value.encode('utf-8')).hexdigest()[:10]}"


def _rejected_terms(values: list[str]) -> list[str]:
    found: list[str] = []
    for value in values:
        normalized = value.lower().replace("-", "_")
        for term in sorted(REJECTED_BASELINE_PROFILES):
            if term in normalized or term.replace("_", " ") in value.lower():
                found.append(term)
    return sorted(set(found))


def _core_links() -> list[dict[str, str]]:
    return [
        {"heuristic_id": CORE_HEURISTICS[1]["id"], "heuristic_name": CORE_HEURISTICS[1]["name"]},
        {"heuristic_id": CORE_HEURISTICS[5]["id"], "heuristic_name": CORE_HEURISTICS[5]["name"]},
        {"heuristic_id": CORE_HEURISTICS[7]["id"], "heuristic_name": CORE_HEURISTICS[7]["name"]},
    ]


def draft_project_addon_profile(
    *,
    project_name: str | None = None,
    product_type: str | None = None,
    audience: str | None = None,
    tasks: list[str] | str | None = None,
    constraints: list[str] | str | None = None,
    competitive_references: list[str] | str | None = None,
    proposed_criteria: list[str] | str | None = None,
) -> dict[str, Any]:
    """Draft an opt-in project-specific heuristic add-on scaffold.

    This does not scrape competitors or alter the baseline 10-heuristic health score.
    """

    task_list = _as_list(tasks)
    constraint_list = _as_list(constraints)
    reference_list = _as_list(competitive_references)
    proposed_list = _as_list(proposed_criteria)
    context_values = [project_name or "", product_type or "", audience or ""] + task_list + constraint_list + reference_list + proposed_list
    blocked_terms = _rejected_terms(context_values)
    if blocked_terms:
        return {
            "schema_version": "v1",
            "tool": "draft_project_addon_profile",
            "status": "blocked",
            "blocked_terms": blocked_terms,
            "message": "This V1 scaffold blocks donor/conversion-style add-ons to keep the excluded checklist out of the product baseline.",
            "baseline_health_impact": "none",
            "scoring_policy": {
                "separate_from_core_he_health": True,
                "can_modify_baseline_score": False,
            },
        }

    missing = []
    if not project_name:
        missing.append("project_name")
    if not audience:
        missing.append("audience")
    if not task_list and not proposed_list:
        missing.append("tasks or proposed_criteria")

    criteria: list[dict[str, Any]] = []
    for task in task_list[:4]:
        criteria.append(
            _criterion(
                label=f"Task success for {task}",
                why=f"This criterion checks whether the interface supports the named task for the intended user without adding a domain-specific baseline score.",
                evidence=f"Screenshot, URL capture, or host observation showing the user path for: {task}.",
                source="project_task",
            )
        )
    if audience:
        criteria.append(
            _criterion(
                label=f"Audience fit for {audience}",
                why="This criterion checks whether labels, hierarchy, and task framing match the stated audience.",
                evidence="Host-observed language, navigation, and decision points tied to the stated audience.",
                source="audience_context",
            )
        )
    for constraint in constraint_list[:2]:
        criteria.append(
            _criterion(
                label=f"Constraint clarity: {constraint}",
                why="This criterion checks whether an important project constraint is visible, understandable, or safely handled.",
                evidence=f"Visible UI state or explanation related to constraint: {constraint}.",
                source="domain_constraint",
            )
        )
    for item in proposed_list[:3]:
        criteria.append(
            _criterion(
                label=item,
                why="This user-proposed criterion is kept in the project-specific lane until reviewed.",
                evidence="Reviewer-supplied evidence or source capture tied to this criterion.",
                source="user_proposed",
                review_required=True,
            )
        )
    for reference in reference_list[:2]:
        criteria.append(
            _criterion(
                label=f"Reference-informed expectation from {reference}",
                why="This criterion records a user-supplied competitive/reference expectation without scraping or treating it as a default product requirement.",
                evidence=f"Reviewer-supplied notes from reference: {reference}.",
                source="user_supplied_reference",
                review_required=True,
            )
        )

    status = "ready" if not missing and criteria else "needs_more_context"
    return {
        "schema_version": "v1",
        "tool": "draft_project_addon_profile",
        "status": status,
        "missing_context": missing,
        "project_context": {
            "project_name": project_name or "",
            "product_type": product_type or "",
            "audience": audience or "",
            "tasks": task_list,
            "constraints": constraint_list,
            "competitive_references": reference_list,
        },
        "addon_profile": {
            "profile_id": _stable_id("projaddon", "|".join(context_values)),
            "name": f"{project_name or 'Project'} heuristic add-on",
            "profile_type": "project_specific",
            "criteria": criteria[:8],
        },
        "baseline_health_impact": "none",
        "scoring_policy": {
            "separate_from_core_he_health": True,
            "can_modify_baseline_score": False,
            "report_section": "Project-specific add-on findings",
        },
        "provenance": {
            "source_mode": "user_supplied_context_only",
            "competitive_analysis": "not_performed",
            "references": reference_list,
        },
        "warnings": [
            "This scaffold is opt-in and must not modify the baseline Nielsen 10-heuristic UX Health score.",
            "Competitive references are accepted only as user-supplied context; V1 does not scrape competitors.",
        ],
    }


def _criterion(
    *,
    label: str,
    why: str,
    evidence: str,
    source: str,
    review_required: bool = False,
) -> dict[str, Any]:
    return {
        "criterion_id": _stable_id("crit", label),
        "label": label,
        "why_relevant": why,
        "evidence_needed": evidence,
        "score_lane": "project_specific_addon",
        "linked_core_heuristics": _core_links(),
        "provenance": {
            "source": source,
            "review_required": review_required,
        },
    }
