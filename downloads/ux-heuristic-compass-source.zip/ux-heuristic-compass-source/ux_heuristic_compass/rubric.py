from __future__ import annotations

from copy import deepcopy
from typing import Any

from .knowledge import support_lens_catalog
from .rendered_review import rendered_review_guidance, rendered_review_hint
from .tool_contracts import is_tool_discovery_topic, tool_discovery_contract


RUBRIC_SCHEMA_VERSION = "uxhc.rubric.v3"
SPREADSHEET_SOURCE = "HE_Scorecard_Template_v2"
AUTHORED_MOBILE_SOURCE = "authored_mobile_v1"


REJECTED_BASELINE_PROFILES = {
    "donor",
    "donation",
    "conversion",
    "fundraising",
    "nonprofit_donor",
}


GRADE_TABLE: list[dict[str, Any]] = [
    {"min": 95, "max": 100, "letter_grade": "A++", "descriptor": "Exceptional - industry benchmark"},
    {"min": 90, "max": 94, "letter_grade": "A+", "descriptor": "Excellent - exceeds standard"},
    {"min": 85, "max": 89, "letter_grade": "A", "descriptor": "Strong - meets standard"},
    {"min": 80, "max": 84, "letter_grade": "A-", "descriptor": "Above average - minor gaps"},
    {"min": 75, "max": 79, "letter_grade": "B+", "descriptor": "Good - a few notable issues"},
    {"min": 70, "max": 74, "letter_grade": "B", "descriptor": "Acceptable - some improvement needed"},
    {"min": 65, "max": 69, "letter_grade": "B-", "descriptor": "Below average - multiple issues"},
    {"min": 60, "max": 64, "letter_grade": "C+", "descriptor": "Developing - significant gaps"},
    {"min": 55, "max": 59, "letter_grade": "C", "descriptor": "Needs attention - failing in places"},
    {"min": 50, "max": 54, "letter_grade": "C-", "descriptor": "Struggling - widespread issues"},
    {"min": 40, "max": 49, "letter_grade": "D", "descriptor": "Poor - major usability problems"},
    {"min": 30, "max": 39, "letter_grade": "D-", "descriptor": "Critical - severe experience failures"},
    {"min": 0, "max": 29, "letter_grade": "F", "descriptor": "Failing - unusable or near-unusable"},
]


OPTIONAL_PROFILE_TO_HEURISTIC = {
    "accessibility": "h11",
    "inclusion": "h12",
    "journey": "h13",
    "ux_writing": "h14",
}


HEURISTIC_ALIASES = {
    "h01_visibility_status": "h01",
    "h02_match_real_world": "h02",
    "h03_user_control_freedom": "h03",
    "h04_consistency_standards": "h04",
    "h05_error_prevention": "h05",
    "h06_recognition_recall": "h06",
    "h07_flexibility_efficiency": "h07",
    "h08_aesthetic_minimalist": "h08",
    "h09_error_recovery": "h09",
    "h10_help_documentation": "h10",
}


H9_DEPRECATED_DESCRIPTION = "Error messages should be expressed in plain language"

LEGACY_H9_CHECKLIST_TEXT_ALIASES = {
    ("h09_d_02", "the site uses a customised 404 page"): "h09_d_01",
    ("h09_m_02", "the site uses a customised 404 page"): "h09_m_01",
    ("h09_d_03", "error messages contain clear instructions"): "h09_d_02",
    ("h09_m_03", "error messages contain clear instructions"): "h09_m_02",
}

LEGACY_CHECKLIST_ITEM_ALIASES = {
    "h09_d_03": "h09_d_02",
    "h09_m_03": "h09_m_02",
}


CORE_ITEMS: dict[int, list[str]] = {
    1: [
        "Every interface begins with a title/header that describes page contents",
        "Headings and subheadings are short, straightforward and descriptive",
        "Value proposition is clearly stated on the home page (tagline or welcome blurb)",
        "The items on the home page are clearly focused on primary actions",
        "Each page is clearly branded so that the user knows they are on the same site",
        "Navigation makes it clear which page I am on",
        "Link names match the title of destination pages, so users will know when they have reached the intended page",
        "Standard elements (page titles, site navigation, page navigation, privacy policy, etc.) are easy to locate",
        "Logo is in a consistent location, and clicking the logo returns the user back to the home page",
    ],
    2: [
        "Navigation tabs are located at the top of the page, and look like clickable versions of real-world tabs",
        "Items that are not clickable do not have characteristics that suggest that they are clickable",
        "Items that are clickable look like they are clickable",
    ],
    3: [
        "There is a search box",
        "There are clearly marked exits on every page allowing the user to bail out of the current task without having to depend on the browser Back button",
        "The site does not disable the browser Back button and the Back button appears on the browser toolbar on every page",
        "Clicking the back button always takes the user back to the page they came from",
        "Undo and redo are supported",
    ],
    4: [
        "In your expert opinion, site content does not look like advertisements",
        "Clickable elements use a consistent style/color for primary, secondary, and tertiary actions",
        "Value proposition is clearly stated on the home page (tagline or welcome blurb)",
        "Navigation choices are ordered in the most logical or task-oriented manner, with less important corporate information at the bottom",
        "All corporate information is grouped in one distinct area, such as About Us",
        "The home page of the site has a memorable URL",
        "Terminology is consistent with general web usage",
        "There is a visible change when the mouse points at something clickable, excluding cursor changes",
        "Hypertext links that invoke actions, such as downloads or new windows, are clearly distinguished from hypertext links that load another page",
        "If the site spawns new windows, these will not confuse the user and can be easily closed",
        "Menu instructions, prompts and messages appear in the same place on each screen",
        "The content is up-to-date, authoritative and trustworthy",
        "The site contains third-party support, such as citations or testimonials, to verify the accuracy of information",
        "It is clear that there is a real organization behind the site, such as a physical address or office photo",
        "The content is fresh: the site includes recent content",
        "The site is free of typographic errors and spelling mistakes",
        "The visual design is consistent, including colors, layout, iconography, etc.",
        "On content pages, line lengths are neither too short (under 50 characters per line) nor too long (over 100 characters per line) when viewed in a standard browser width window",
        "Fonts are used consistently and are legible",
        "The site can be used without scrolling horizontally",
        "Design components, such as radio buttons and checkboxes, are used appropriately",
    ],
    5: [
        "Pages are free of scroll stoppers: headings or page elements that create the illusion that users have reached the top or bottom of a page when they have not",
        "The user does not need to consult user manuals or other external information to use the site",
        "User confirmation is required before carrying out potentially dangerous actions, such as deleting something",
        "The site provides feedback that helps the user learn how to use the site",
        "There is sufficient space between targets to prevent the user from hitting multiple or incorrect targets",
    ],
    6: [
        "Search suggestions or filters are provided",
        "Each page is clearly labeled with a descriptive and useful title that makes sense as a bookmark",
        "Links and link titles are descriptive and predictive, and there are no Click here links",
        "Buttons and links show that they have been clicked",
    ],
    7: [
        "Useful content is presented on the home page or within one click of the home page",
        "The terms used for navigation items and hypertext links are unambiguous and jargon-free",
        "If there are product pages, they contain the detail necessary to make a purchase, and users can zoom in on product images",
        "The words, phrases and concepts used will be familiar to the typical user",
        "Content feels friendly for new users",
        "Content feels customizable or useable for frequent or expert users",
        "The screen density is appropriate for the target users and their tasks",
        "Icons and graphics are standard and/or intuitive (concrete and familiar)",
        "Where tooltips are used, they provide useful additional help and do not simply duplicate text in the icon, link or field label",
    ],
    8: [
        "By just looking at the home page, the first time user will understand where to start",
        "Primary actions are easy to find and understand",
        "Individual pages are free of clutter and irrelevant information, and attention-attracting features are used sparingly and only where relevant",
        "The home page is professionally designed and will create a positive first impression",
        "The home page looks like a home page; pages lower in the site will not be confused with it",
        "The site avoids advertisements, especially pop-ups",
        "Text is concise, with no needless instructions or welcome notes",
        "Pages use bulleted and numbered lists in preference to narrative text",
        "The most important items in a list are placed at the top",
        "Pages are quick to scan, with ample headings and subheadings and short paragraphs",
        "Information is organized hierarchically, from the general to the specific, and the organization is clear and logical",
        "Text links are long enough to be understood, but short enough to minimize wrapping, especially when used as a navigation list",
        "On all pages, the most important information, such as frequently used topics, features and functions, is presented on the first screenful of information above the fold",
        "The relationship between controls and their actions is obvious",
        "There is a clear visual starting point to every page",
        "The site is pleasant to look at",
    ],
    9: [
        "The site uses a customised 404 page, which includes tips on how to find the missing page and links to Home and Search",
        "Error messages contain clear instructions on what to do next, including form error states",
    ],
    10: [
        "Help is available and easy to find",
        "FAQs are present if appropriate",
        "When giving instructions, pages tell users what to do rather than what to avoid doing",
        "The site shows users how to do common tasks where appropriate, such as demonstrations of the site's functionality",
        "It is easy to contact someone for assistance and a reply is received quickly",
    ],
}


OPTIONAL_DESKTOP_ITEMS: dict[int, list[str]] = {
    11: [
        "P - Content alternatives are provided, content is adaptable, and content is easy to hear and see",
        "O - All functionality is available and flexible, enough time is provided, content is safe, and content is easy to find",
        "U - Content text is readable and understandable, content appears and operates in predictable ways, and users are helped to avoid and correct mistakes",
        "R - Compatibility is maximized for current and future user agents",
    ],
    12: [
        "The interface acknowledges and responds to user emotions, either through design, content, or interactive elements",
        "The design ensures users feel safe and secure, minimizing anxiety-inducing elements",
        "The content and design elements respect and reflect a wide range of cultural norms and values",
        "Information is presented in a way that shows understanding and consideration for the user's emotional state",
        "Design and content are accessible to users with various physical and cognitive abilities, promoting inclusivity",
        "Features and functionalities empower users, giving them control and choice in their interactions",
    ],
    13: [
        "The interface reflects the brand's values and aesthetics consistently across all elements",
        "Navigation and workflows are intuitive, creating a seamless experience from start to finish",
        "The system offers personalized options or content based on user data and preferences",
        "Easy access to support and a straightforward method for users to provide feedback",
        "Features or elements make the user feel valued and rewarded for their engagement",
        "Clear communication about data usage, privacy policies, and other aspects that build user trust",
    ],
    14: [
        "Follows the current product's established style guide and brand voice",
        "Content is clear",
        "Content avoids jargon and uses simple, everyday language",
        "All UI labels use simple and concise words",
        "Calls to action are specific, use active language, and are clearly organized by importance",
        "No paragraphs more than three lines",
        "The content above the fold, including headings, subheadings, and copy, makes each page's purpose clear and obvious",
    ],
}


OPTIONAL_MOBILE_ITEMS: dict[int, list[str]] = {
    11: [
        "P (Perceivable): Content alternatives provided; text resizable without layout breakage; color not sole conveyor of information; audio/video has captions or transcripts",
        "O (Operable): All interactive elements reachable by touch or keyboard; touch targets meet 44x44pt / 48x48dp minimum; no interaction requires precise gestures that exclude motor-impaired users; auto-playing content can be paused",
        "U (Understandable): Text readable at default zoom without horizontal scroll; forms use visible labels not placeholder-only; error recovery in plain language; app behaves predictably across screen transitions",
        "R (Robust): Compatible with VoiceOver on iOS and TalkBack on Android; interactive elements have meaningful accessibility labels; interface does not break when system font size or display zoom is increased",
    ],
    12: [
        "Interface is designed for interrupted use; users can pause, resume, or recover place without losing context or progress",
        "No anxiety-inducing mobile patterns: no aggressive push notification prompts, no hard-to-dismiss fullscreen interstitials, no dark patterns on small screens",
        "Content and visual design are culturally appropriate for target regions, including icon choices, color meanings, and imagery",
        "App is usable in situational impairment contexts: bright sunlight, one-handed use, moving/vibrating environment, low-battery/low-data mode",
        "Interface accommodates users with varying motor control; thumb-zone-friendly layouts; sufficiently spaced interactive targets",
        "Users have meaningful control over notifications, permissions, data sharing, and personalization; these choices are easy to find and change",
    ],
    13: [
        "App visual identity, tone, and brand are consistent from launch screen through core flows and notifications",
        "Core task flows are optimized for mobile: minimal steps, no unnecessary context-switching, back navigation always recovers state",
        "App offers personalized or contextually relevant content based on behavior, location if permitted, or preferences without requiring excessive setup",
        "Support is reachable within the app without leaving to a browser or switching apps",
        "App provides positive reinforcement or progress acknowledgment at appropriate moments without being patronizing",
        "Privacy and data practices are communicated at appropriate moments and permission requests explain why access is needed, not buried in settings only",
    ],
    14: [
        "Follows the current product's established style guide and brand voice across all screens including push notifications, empty states, and error messages",
        "Content is scannable: short headlines, front-loaded information, minimal body copy on primary screens",
        "Content avoids jargon and uses plain conversational language appropriate for a mobile-first audience",
        "UI labels are short enough to render completely at minimum viewport width without truncation; critical labels tested at smallest supported screen",
        "CTAs are verb-led, specific, and dominant tap targets; not competing with secondary actions of similar visual weight",
        "Instructional content is broken into single-thought lines or steps; no block paragraphs in primary flows",
        "Push notifications and alerts use clear non-alarming language, include context for why sent, and lead with user benefit rather than app's need",
    ],
}


HEURISTIC_META: list[dict[str, Any]] = [
    {
        "number": 1,
        "name": "Visibility of System Status",
        "short_name": "System status",
        "description": "Keep users informed about what is going on through feedback within a reasonable amount of time.",
        "signals": ["loading", "progress", "status", "feedback", "confirmation", "saving", "submitted"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 2,
        "name": "Match Between System and the Real World",
        "short_name": "Real-world match",
        "description": "Speak the users' language and follow real-world conventions, making information appear in a natural and logical order.",
        "signals": ["jargon", "label", "unclear wording", "terminology", "mental model", "order"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 3,
        "name": "User Control and Freedom",
        "short_name": "Control and freedom",
        "description": "Provide emergency exits, undo paths, and recovery from unwanted actions.",
        "signals": ["back", "undo", "cancel", "exit", "escape", "modal", "locked"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 4,
        "name": "Consistency and Standards",
        "short_name": "Consistency",
        "description": "Users should not have to wonder whether different words, situations, or actions mean the same thing.",
        "signals": ["inconsistent", "standard", "pattern", "style", "button", "link", "navigation"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 5,
        "name": "Error Prevention",
        "short_name": "Error prevention",
        "description": "Prevent problems before they occur through careful design, constraints, confirmation, defaults, and clarity.",
        "signals": ["mistake", "danger", "delete", "validation", "required", "input", "prevent"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 6,
        "name": "Recognition Rather Than Recall",
        "short_name": "Recognition",
        "description": "Make options, instructions, and context visible instead of forcing users to remember information from one part of the dialogue to another.",
        "signals": ["hidden", "remember", "recall", "context", "breadcrumb", "instruction", "hint"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 7,
        "name": "Flexibility and Efficiency of Use",
        "short_name": "Efficiency",
        "description": "Support efficient paths for frequent users while keeping novice paths understandable.",
        "signals": ["shortcut", "filter", "search", "repeat", "customize", "advanced", "efficient"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 8,
        "name": "Aesthetic and Minimalist Design",
        "short_name": "Minimalist design",
        "description": "Reduce clutter and emphasize the information and actions users need now.",
        "signals": ["clutter", "busy", "visual hierarchy", "above the fold", "density", "start", "primary action"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 9,
        "name": "Help Users Recognize, Diagnose, and Recover from Errors",
        "short_name": "Error recovery",
        "description": "Make errors plain, specific, recoverable, and tied to the next action.",
        "signals": ["error", "message", "recover", "invalid", "404", "try again", "field"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 10,
        "name": "Help and Documentation",
        "short_name": "Help",
        "description": "Provide findable help for tasks that cannot be completed through the interface alone.",
        "signals": ["help", "faq", "support", "documentation", "contact", "guide", "learn"],
        "optional": False,
        "profile": "core",
    },
    {
        "number": 11,
        "name": "Accessibility and Ease of Access",
        "short_name": "Accessibility",
        "description": "Evaluate visible accessibility and ease-of-access concerns. This is a surface screen, not a WCAG compliance audit.",
        "signals": ["accessibility", "contrast", "screen reader", "keyboard", "touch target", "label"],
        "optional": True,
        "profile": "accessibility",
    },
    {
        "number": 12,
        "name": "Empathetic Engagement and Inclusion",
        "short_name": "Inclusion",
        "description": "Evaluate the alignment of the interface with the full spectrum of human emotions, psychology, and behaviors.",
        "signals": ["emotion", "safe", "secure", "inclusive", "anxiety", "culture", "control"],
        "optional": True,
        "profile": "inclusion",
    },
    {
        "number": 13,
        "name": "Customer Journey and Satisfaction",
        "short_name": "Journey",
        "description": "Ensure that the interface contributes to a positive, cohesive, and value-driven experience for the customer.",
        "signals": ["journey", "support", "feedback", "privacy", "trust", "personalized", "brand"],
        "optional": True,
        "profile": "journey",
    },
    {
        "number": 14,
        "name": "UX Writing / Content and Tone",
        "short_name": "UX writing",
        "description": "Ensure that every word is usable, simple, and adheres to the current product's established style and brand guidelines.",
        "signals": ["labels", "headings", "calls to action", "tone", "clarity", "jargon", "copy"],
        "optional": True,
        "profile": "ux_writing",
    },
]


def _heuristic_id(number: int) -> str:
    return f"h{number:02d}"


def _checklist_id(number: int, platform: str, index: int) -> str:
    return f"h{number:02d}_{platform[0]}_{index:02d}"


def _make_items(number: int, platform: str, texts: list[str], source: str) -> list[dict[str, Any]]:
    return [
        {
            "id": _checklist_id(number, platform, idx),
            "heuristic_id": _heuristic_id(number),
            "heuristic_number": number,
            "platform": platform,
            "index": idx,
            "text": text,
            "source": source,
            "active": True,
        }
        for idx, text in enumerate(texts, start=1)
    ]


def _build_heuristics() -> list[dict[str, Any]]:
    heuristics: list[dict[str, Any]] = []
    for meta in HEURISTIC_META:
        number = int(meta["number"])
        if number <= 10:
            desktop_texts = CORE_ITEMS[number]
            mobile_texts = CORE_ITEMS[number]
            desktop_source = SPREADSHEET_SOURCE
            mobile_source = SPREADSHEET_SOURCE
        else:
            desktop_texts = OPTIONAL_DESKTOP_ITEMS[number]
            mobile_texts = OPTIONAL_MOBILE_ITEMS[number]
            desktop_source = SPREADSHEET_SOURCE
            mobile_source = AUTHORED_MOBILE_SOURCE
        record = {
            "schema_version": RUBRIC_SCHEMA_VERSION,
            "id": _heuristic_id(number),
            "number": number,
            "name": meta["name"],
            "short_name": meta["short_name"],
            "description": meta["description"],
            "signals": list(meta["signals"]),
            "optional": bool(meta["optional"]),
            "profile": meta["profile"],
            "checklist_items_desktop": _make_items(number, "desktop", desktop_texts, desktop_source),
            "checklist_items_mobile": _make_items(number, "mobile", mobile_texts, mobile_source),
        }
        heuristics.append(record)
    return heuristics


HEURISTICS: list[dict[str, Any]] = _build_heuristics()
CORE_HEURISTICS: list[dict[str, Any]] = [item for item in HEURISTICS if not item["optional"]]
OPTIONAL_HEURISTICS: list[dict[str, Any]] = [item for item in HEURISTICS if item["optional"]]


OPTIONAL_PROFILES: dict[str, dict[str, Any]] = {
    heuristic["profile"]: {
        "id": heuristic["profile"],
        "heuristic_id": heuristic["id"],
        "name": heuristic["name"],
        "description": heuristic["description"],
    }
    for heuristic in OPTIONAL_HEURISTICS
}


def canonical_heuristic_id(heuristic_id: str | None) -> str | None:
    if not heuristic_id:
        return None
    key = str(heuristic_id).strip().lower()
    if key in HEURISTIC_ALIASES:
        return HEURISTIC_ALIASES[key]
    if key.startswith("h") and len(key) >= 3:
        short = key[:3]
        if short in {heuristic["id"] for heuristic in HEURISTICS}:
            return short
    return None


def _normalize_match_text(value: str | None) -> str:
    return " ".join(str(value or "").lower().split())


def canonical_checklist_item_id(checklist_item_id: str, checklist_text: str | None = None) -> str:
    key = str(checklist_item_id).strip().lower()
    text = _normalize_match_text(checklist_text)
    for (legacy_id, text_fragment), canonical_id in LEGACY_H9_CHECKLIST_TEXT_ALIASES.items():
        if key == legacy_id and text_fragment in text:
            return canonical_id
    return LEGACY_CHECKLIST_ITEM_ALIASES.get(key, key)


def deprecated_checklist_item_reason(checklist_item_id: str, checklist_text: str | None = None) -> str | None:
    key = str(checklist_item_id).strip().lower()
    text = _normalize_match_text(checklist_text)
    if key in {"h09_d_01", "h09_m_01"} and _normalize_match_text(H9_DEPRECATED_DESCRIPTION) in text:
        return "H9 plain-language error-message text is the heuristic description, not a checklist item."
    return None


def checklist_item_by_id(checklist_item_id: str) -> dict[str, Any] | None:
    key = canonical_checklist_item_id(checklist_item_id)
    for heuristic in HEURISTICS:
        for platform_key in ("checklist_items_desktop", "checklist_items_mobile"):
            for item in heuristic[platform_key]:
                if item["id"] == key:
                    return deepcopy(item)
    return None


def heuristic_by_id(heuristic_id: str) -> dict[str, Any] | None:
    canonical = canonical_heuristic_id(heuristic_id)
    if canonical is None:
        return None
    for heuristic in HEURISTICS:
        if heuristic["id"] == canonical:
            return deepcopy(heuristic)
    return None


def _active_heuristic_ids(include_optional: bool, profiles: list[str] | str | None = None) -> list[str]:
    ids = [heuristic["id"] for heuristic in CORE_HEURISTICS]
    accepted, _rejected = normalize_profiles(profiles)
    if include_optional:
        optional_ids = [heuristic["id"] for heuristic in OPTIONAL_HEURISTICS]
    else:
        optional_ids = [OPTIONAL_PROFILE_TO_HEURISTIC[profile] for profile in accepted if profile in OPTIONAL_PROFILE_TO_HEURISTIC]
    for heuristic_id in optional_ids:
        if heuristic_id not in ids:
            ids.append(heuristic_id)
    return ids


def get_active_checklist_items(platform: str = "desktop", profiles: list[str] | str | None = None) -> list[dict[str, Any]]:
    platform_key = normalize_platform(platform)
    item_key = "checklist_items_mobile" if platform_key == "mobile" else "checklist_items_desktop"
    active_ids = _active_heuristic_ids(include_optional=False, profiles=profiles)
    items: list[dict[str, Any]] = []
    for heuristic in HEURISTICS:
        if heuristic["id"] in active_ids:
            items.extend(deepcopy(heuristic[item_key]))
    return items


def normalize_platform(platform: str | None) -> str:
    label = (platform or "desktop").lower()
    if label in {"mobile", "phone", "ios", "android"}:
        return "mobile"
    return "desktop"


def infer_platform_from_source(prepared_source: dict[str, Any] | None, explicit: str | None = None) -> str:
    if explicit:
        return normalize_platform(explicit)
    if not prepared_source:
        return "desktop"
    for item in prepared_source.get("items") or []:
        viewport = item.get("viewport") or {}
        device = str(viewport.get("device_class") or "").lower()
        if device == "mobile":
            return "mobile"
    return "desktop"


def normalize_profiles(profiles: list[str] | str | None = None) -> tuple[list[str], list[str]]:
    if profiles is None or profiles == "":
        return [], []
    if isinstance(profiles, str):
        raw = [part.strip() for part in profiles.replace(",", " ").split() if part.strip()]
    else:
        raw = [str(part).strip() for part in profiles if str(part).strip()]

    accepted: list[str] = []
    rejected: list[str] = []
    profile_aliases = {
        "access": "accessibility",
        "ease_of_access": "accessibility",
        "a11y": "accessibility",
        "empathy": "inclusion",
        "inclusive": "inclusion",
        "customer_journey": "journey",
        "satisfaction": "journey",
        "writing": "ux_writing",
        "content": "ux_writing",
        "content_tone": "ux_writing",
        "content_strategy": "ux_writing",
        "content_strategy_profile": "ux_writing",
        "microcopy": "ux_writing",
        "copy": "ux_writing",
        "copywriting": "ux_writing",
        "ux_content": "ux_writing",
        "uxwriting": "ux_writing",
        "customer_experience": "journey",
        "cx": "journey",
        "h11": "accessibility",
        "h12": "inclusion",
        "h13": "journey",
        "h14": "ux_writing",
    }
    for profile in raw:
        key = profile.lower().replace("-", "_")
        key = profile_aliases.get(key, key)
        if key in REJECTED_BASELINE_PROFILES:
            rejected.append(profile)
        elif key in OPTIONAL_PROFILES:
            if key not in accepted:
                accepted.append(key)
        else:
            rejected.append(profile)
    return accepted, rejected


def infer_heuristic(text: str) -> dict[str, Any]:
    haystack = text.lower()
    best: dict[str, Any] | None = None
    best_hits = -1
    for heuristic in CORE_HEURISTICS:
        hits = sum(1 for signal in heuristic["signals"] if signal in haystack)
        if hits > best_hits:
            best = heuristic
            best_hits = hits
    if best is None or best_hits <= 0:
        return deepcopy(CORE_HEURISTICS[7])
    return deepcopy(best)


def _compact_heuristic(heuristic: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": heuristic["id"],
        "number": heuristic["number"],
        "name": heuristic["name"],
        "description": heuristic["description"],
        "optional": heuristic["optional"],
        "profile": heuristic.get("profile"),
        "desktop_item_count": len(heuristic["checklist_items_desktop"]),
        "mobile_item_count": len(heuristic["checklist_items_mobile"]),
        "include_items_hint": "Call list_heuristics(detail_level='full') to retrieve checklist item arrays.",
    }


def _optional_profile_map() -> dict[str, dict[str, Any]]:
    return {
        profile: {
            **deepcopy(metadata),
            "activation": f'Add "{profile}" to profiles to include {metadata["heuristic_id"]}.',
        }
        for profile, metadata in OPTIONAL_PROFILES.items()
    }


def _support_lens_topic(topic: str | None) -> bool:
    key = (topic or "").strip().lower().replace("-", "_").replace(" ", "_")
    return key in {"support_lenses", "support_lens", "lenses", "lens_catalog", "supporting_laws", "ux_laws", "ui_laws", "corpus"}


def list_heuristics(include_optional: bool = True, platform: str | None = None, detail_level: str = "summary", topic: str | None = None) -> dict[str, Any]:
    selected = HEURISTICS if include_optional else CORE_HEURISTICS
    normalized_detail = str(detail_level or "summary").lower()
    lens_detail_requested = _support_lens_topic(topic) or normalized_detail in {"support_lenses", "support_lens", "lenses", "lens_catalog", "corpus"}
    full_detail = normalized_detail in {"full", "items", "checklist"}
    payload: dict[str, Any] = {
        "schema_version": RUBRIC_SCHEMA_VERSION,
        "detail_level": "support_lenses" if lens_detail_requested else "full" if full_detail else "summary",
        "heuristics": deepcopy(selected) if full_detail else [_compact_heuristic(item) for item in selected],
        "core_heuristics": deepcopy(CORE_HEURISTICS) if full_detail else [_compact_heuristic(item) for item in CORE_HEURISTICS],
        "optional_heuristics": deepcopy(OPTIONAL_HEURISTICS) if include_optional and full_detail else [_compact_heuristic(item) for item in OPTIONAL_HEURISTICS] if include_optional else [],
        "optional_profiles": _optional_profile_map() if include_optional else {},
        "inactive_optional_profile_prompt": "Optional profiles available: accessibility (H11), inclusion (H12), journey (H13), ux_writing (H14). Add a profile name to profiles to include it in scoring.",
        "rejected_baseline_profiles": sorted(REJECTED_BASELINE_PROFILES),
        "grade_table": deepcopy(GRADE_TABLE),
        "checklist_id_format": "h{heuristic_number_zero_padded}_{platform_initial}_{item_index_zero_padded}",
        "score_direction": "higher_percentage_is_better",
        "source_note": "Core rubric follows Nielsen Norman Group's 10 usability heuristics. Optional profiles are first-class opt-in heuristics. Donor/conversion criteria are excluded from baseline rubric definitions.",
        "counts": _counts(selected),
        "support_lens_summary": support_lens_catalog(detail_level="summary"),
    }
    if lens_detail_requested:
        payload["support_lens_catalog"] = support_lens_catalog(detail_level="full")
        payload["support_lens_instruction"] = "Support lenses are explanatory only. Use them to interpret evidence-backed findings and validation needs; do not use them to create or alter checklist ratings, grades, severity, compliance claims, cultural certification, ISO conformance, CX outcome proof, or user-testing claims."
    if platform:
        payload["platform"] = normalize_platform(platform)
        active_items = get_active_checklist_items(platform, profiles=list(OPTIONAL_PROFILES) if include_optional else [])
        payload["active_checklist_items"] = deepcopy(active_items) if full_detail else [
            {
                "id": item["id"],
                "heuristic_id": item["heuristic_id"],
                "platform": item["platform"],
                "text": item["text"],
            }
            for item in active_items
        ]
    return payload


def _counts(heuristics: list[dict[str, Any]]) -> dict[str, Any]:
    core = [item for item in heuristics if not item["optional"]]
    optional = [item for item in heuristics if item["optional"]]
    return {
        "heuristics": len(heuristics),
        "core_heuristics": len(core),
        "optional_heuristics": len(optional),
        "core_items_desktop": sum(len(item["checklist_items_desktop"]) for item in core),
        "core_items_mobile": sum(len(item["checklist_items_mobile"]) for item in core),
        "optional_items_desktop": sum(len(item["checklist_items_desktop"]) for item in optional),
        "optional_items_mobile": sum(len(item["checklist_items_mobile"]) for item in optional),
        "dual_platform_all_items": sum(len(item["checklist_items_desktop"]) + len(item["checklist_items_mobile"]) for item in heuristics),
    }


def ux_heuristic_overview(topic: str | None = None, audience: str = "both") -> dict[str, Any]:
    guidance = rendered_review_guidance(topic)
    tool_guidance = is_tool_discovery_topic(topic)
    accepted_profiles, rejected_profiles = ([], []) if guidance or tool_guidance else normalize_profiles(topic)
    counts = _counts(HEURISTICS)
    result = {
        "schema_version": "uxhc.overview.v2",
        "product": "UX Heuristic Compass",
        "purpose": "Structured checklist-level heuristic UX audits for screenshots, image bundles, bounded URL captures, and host-observed interface evidence.",
        "tool_discovery_contract": tool_discovery_contract(),
        "runtime_policy": {
            "host_ai_owns": ["conversation", "visual interpretation", "user-facing explanation"],
            "uxhc_owns": ["rubric structure", "source manifests", "scoring contracts", "report readiness", "artifact generation", "local preferences", "agent-run aggregation"],
            "core_audit_first": "Source scope, UX Health Snapshot, checklist-level scorecard, top finding, plain-language read, and one recommendation precede support flows and activities.",
        },
        "mvp_boundary": {
            "supports": ["screenshots", "image_bundles", "bounded_url_capture_requests", "checklist_level_scorecards"],
            "does_not_support": [
                "full_site_crawling",
                "authenticated_flow_automation",
                "unbounded_autonomous_browser_agent_navigation",
                "default_competitor_scraping",
                "wcag_compliance_certification",
            ],
        },
        "recommended_workflow": [
            "get_started",
            "prepare_ux_source",
            "quick_scan_ux with an explicit mode: guidance_only for tiny refinement help, status_only for scored-audit orchestration, compact/full for diagnostics",
            "audit_ux_surface with checklist_ratings for the full audit contract",
            "run_agent_audit when the host AI has produced per-persona scorecards",
            "run_usability_test for bounded Agent Mode 2 evidence prep, not autonomous navigation",
            "stress_test_heuristic_finding for a UX-native false-positive check on one finding",
            "validate_ux_report_payload",
            "generate_ux_audit_report",
        ],
        "core_heuristic_count": counts["core_heuristics"],
        "optional_heuristic_count": counts["optional_heuristics"],
        "core_items_per_platform": counts["core_items_desktop"],
        "optional_items_per_platform": counts["optional_items_desktop"],
        "dual_platform_all_items": counts["dual_platform_all_items"],
        "score_direction": "100% means all active checklist items scored 0; 0% means all active checklist items scored 4.",
        "optional_profiles": deepcopy(OPTIONAL_PROFILES),
        "accepted_requested_profiles": accepted_profiles,
        "rejected_requested_profiles": rejected_profiles,
        "first_use": {
            "preferences_tool": "save_preferences",
            "partial_onboarding_policy": "Incomplete onboarding writes no preference record and should be retried on the next audit attempt.",
        },
        "behavioral_contracts": {
            "report_readiness_contract": "Returned by quick_scan_ux and audit_ux_surface; defines required completed-audit fields.",
            "plain_language_read": "Required for scored audits; 1-2 nontechnical sentences.",
            "before_using_this_interface": "Required for scored audits; starts exactly with 'Before using this interface,'.",
            "human_loop_host_action": "Quick Audit can return 3 light context questions; Advanced Audit returns 3 beginning, 3 middle, or 3 final questions when PAUSE_REQUIRED is true.",
            "follow_up_activity": "Returned by scored audits; maps low-scoring heuristics to one immediate UX validation activity.",
            "follow_up_activity_extended": "Optional scored-audit field with additional authored UXHC and Atlas-adapted validation activities; draft File-o-Fun sources include facilitation notes.",
            "reasoning_flow_suggestions": "Advanced audits return up to 3 targeted Atlas-adapted or authored UXHC static flow cards as audit-support intelligence with imported_static source metadata.",
            "support_lens_suggestions": "Findings may be annotated with support-only UX/UI laws, principles, standards, conventions, non-Nielsen heuristic lenses, curated cultural-context lenses, WCAG/accessibility lenses, ISO UX/UI/HCI lenses, and CX/service-journey lenses. These explain why a finding matters but never change checklist scores or grades.",
            "corpus_advisories": "Relevant corpus lenses can produce support-only report modules such as Accessibility Readiness Signal / WCAG-Informed Accessibility Readiness or Cultural Context Signal / Cultural Context Integrity Advisory. ISO and CX lenses remain ordinary support references with no ISO/CX score or advisory module. These modules and lenses do not change H01-H14 grades, certify WCAG/accessibility compliance, certify cultural safety, prove ISO conformance, prove business outcomes, or replace expert/community review.",
            "evaluator_bias_advisories": "Optional scored-audit calibration notes for anchoring, mere exposure, halo, and evaluator experience risks.",
            "prioritization_flow": "Returned when overall scored audit quality is B or below; uses RICE triage adapted for UX findings.",
            "implementation_inspection_contract": "Optional support lane when audit_context requests implementation-aware inspection by a host AI or coding harness; implementation evidence remains advisory until checklist_ratings are supplied.",
            "quick_scan_mode_gate": "quick_scan_ux without output_detail returns a tiny chooser for guidance_only, status_only, compact, or full so modes are not hidden.",
            "guidance_only": "quick_scan_ux(output_detail='guidance_only') is ultra-quick support-only guidance; it creates no grade, scorecard, report payload, checkpoint, artifact, compliance claim, or user-testing claim.",
            "rendered_review": "When evidence is browser-compatible HTML, UI code, or a local preview, prefer rendered browser evidence before final UX claims; call get_started(topic=\"rendered_review\") for Playwright/local-server guidance.",
        },
        "quick_scan_modes": {
            "mode_gate": "Omitted, empty, auto, or ask output_detail returns a quick_scan_mode_choice gate.",
            "guidance_only": "Quiet host-assist lane for direct fixes, fix prompts, micro-plans, or naming what feels wrong.",
            "status_only": "Small scored-audit orchestration response.",
            "compact": "Compact diagnostic response.",
            "full": "Full diagnostic response.",
        },
        "rendered_review_hint": rendered_review_hint(),
        "agent_modes": {
            "agent_mode_1": {
                "tool": "run_agent_audit",
                "execution_mode": "host_ai_executes",
                "autonomous_execution": False,
            },
            "agent_mode_2": {
                "tool": "run_usability_test",
                "execution_mode": "bounded_evidence_prep",
                "autonomous_execution": False,
            },
        },
        "audience": audience,
    }
    if guidance:
        result["rendered_review_guidance"] = guidance
    if tool_guidance:
        result["tool_discovery_guidance"] = {
            "topic": "tool_discovery",
            "message": "UXHC has 18 public tools. Use get_started(topic='tools') when full usage contracts are needed.",
            "full_contracts_tool": "get_started",
        }
    return result
