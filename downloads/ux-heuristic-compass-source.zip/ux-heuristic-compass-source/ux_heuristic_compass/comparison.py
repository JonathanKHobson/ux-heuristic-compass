from __future__ import annotations

import hashlib
import re
from datetime import datetime, timezone
from typing import Any


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _normalize_text(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()
    return re.sub(r"\s+", " ", normalized)


def _finding_signature(finding: dict[str, Any]) -> str:
    checklist_item_id = finding.get("checklist_item_id")
    if checklist_item_id:
        return str(checklist_item_id)
    heuristic_id = str(finding.get("heuristic_id") or "unknown")
    issue = _normalize_text(str(finding.get("observed_issue") or finding.get("title") or finding.get("finding_id") or ""))
    return f"{heuristic_id}:{issue[:140]}"


def _rating_signature(rating: dict[str, Any]) -> str:
    return str(rating.get("checklist_item_id") or rating.get("id") or "")


def _comparison_id(before: list[dict[str, Any]], after: list[dict[str, Any]], mode: str) -> str:
    seed = "|".join([mode] + sorted(_finding_signature(item) for item in before + after))
    return "uxcmp_" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:12]


def _compact_record(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "checklist_item_id": record.get("checklist_item_id", ""),
        "finding_id": record.get("finding_id", ""),
        "heuristic_id": record.get("heuristic_id", ""),
        "heuristic_name": record.get("heuristic_name", ""),
        "title": record.get("title") or record.get("checklist_text", ""),
        "severity": record.get("severity", record.get("rating", 0)),
        "severity_label": record.get("severity_label", record.get("rating_label", "")),
        "evidence_ref": record.get("evidence_ref", ", ".join(record.get("evidence_refs") or [])),
        "recommendation": record.get("recommendation", ""),
        "rationale": record.get("rationale", ""),
    }


def _records_for_comparison(audit: dict[str, Any]) -> tuple[list[dict[str, Any]], str]:
    checklist_ratings = [
        rating
        for rating in audit.get("checklist_ratings") or audit.get("scorecard", {}).get("checklist_ratings") or []
        if float(rating.get("rating", 0)) > 0
    ]
    if checklist_ratings:
        normalized = []
        for rating in checklist_ratings:
            row = dict(rating)
            row["severity"] = row.get("rating", 0)
            row["severity_label"] = row.get("rating_label", "")
            row.setdefault("title", row.get("checklist_text", row.get("checklist_item_id", "")))
            normalized.append(row)
        return normalized, "checklist_item_id"
    return list(audit.get("findings") or audit.get("top_findings") or []), "legacy_finding_signature"


def compare_ux_audits(
    baseline_audit: dict[str, Any],
    candidate_audit: dict[str, Any],
    *,
    comparison_mode: str = "saved_audit",
    baseline_label: str = "baseline",
    candidate_label: str = "candidate",
    severity_tolerance: int = 0,
) -> dict[str, Any]:
    before, matching_strategy_before = _records_for_comparison(baseline_audit)
    after, matching_strategy_after = _records_for_comparison(candidate_audit)
    matching_strategy = "checklist_item_id" if matching_strategy_before == matching_strategy_after == "checklist_item_id" else "legacy_finding_signature"
    tolerance = max(0, min(2, int(severity_tolerance)))
    mode = comparison_mode if comparison_mode in {"saved_audit", "desktop_mobile"} else "saved_audit"
    signature = _rating_signature if matching_strategy == "checklist_item_id" else _finding_signature
    before_map = {signature(item): item for item in before}
    after_map = {signature(item): item for item in after}
    before_keys = {key for key in before_map if key}
    after_keys = {key for key in after_map if key}
    shared_keys = before_keys & after_keys

    fixed = [_compact_record(before_map[key]) for key in sorted(before_keys - after_keys)]
    new = [_compact_record(after_map[key]) for key in sorted(after_keys - before_keys)]
    unresolved: list[dict[str, Any]] = []
    severity_changed: list[dict[str, Any]] = []
    for key in sorted(shared_keys):
        before_record = before_map[key]
        after_record = after_map[key]
        before_severity = float(before_record.get("severity", before_record.get("rating", 0)))
        after_severity = float(after_record.get("severity", after_record.get("rating", 0)))
        delta = round(after_severity - before_severity, 2)
        record = {
            "baseline": _compact_record(before_record),
            "candidate": _compact_record(after_record),
            "severity_delta": delta,
        }
        if abs(delta) > tolerance:
            severity_changed.append(record)
        else:
            unresolved.append(record)

    highest_remaining = sorted(new + [_compact_record(after_map[key]) for key in shared_keys], key=lambda item: -float(item.get("severity", 0)))
    mode_payload: dict[str, Any] = {}
    if mode == "desktop_mobile":
        mode_payload = {
            "desktop_label": baseline_label,
            "mobile_label": candidate_label,
            "desktop_only_count": len(fixed),
            "mobile_only_count": len(new),
            "shared_count": len(shared_keys),
            "interpretation": "Desktop/mobile comparison classifies matched checklist items as shared, baseline-only issues as desktop-only, and candidate-only issues as mobile-only.",
        }

    return {
        "schema_version": "uxhc.comparison.v2",
        "tool": "compare_ux_audits",
        "comparison_id": _comparison_id(before, after, mode),
        "comparison_mode": mode,
        "matching_strategy": matching_strategy,
        "created_at": _utc_now(),
        "baseline_label": baseline_label,
        "candidate_label": candidate_label,
        "severity_tolerance": tolerance,
        "baseline_audit_metadata": baseline_audit.get("audit_metadata") or {},
        "candidate_audit_metadata": candidate_audit.get("audit_metadata") or {},
        "summary": {
            "fixed_count": len(fixed),
            "new_count": len(new),
            "unresolved_count": len(unresolved),
            "severity_changed_count": len(severity_changed),
            "highest_remaining_severity": highest_remaining[0]["severity"] if highest_remaining else 0,
        },
        "fixed_findings": fixed,
        "new_findings": new,
        "unresolved_findings": unresolved,
        "severity_changed_findings": severity_changed,
        "mode_details": mode_payload,
        "next_action": _next_action(new, unresolved, severity_changed),
    }


def _next_action(
    new: list[dict[str, Any]],
    unresolved: list[dict[str, Any]],
    severity_changed: list[dict[str, Any]],
) -> str:
    high_new = [item for item in new if float(item.get("severity", 0)) >= 3]
    high_changed = [item for item in severity_changed if float(item["candidate"].get("severity", 0)) >= 3]
    if high_new or high_changed:
        return "Review new or worsened severity 3-4 checklist items before treating the candidate audit as improved."
    if unresolved:
        return "Confirm unresolved checklist issues are acceptable or schedule them into the next fix pass."
    return "No unresolved or new issues were detected by the saved-audit comparison."
