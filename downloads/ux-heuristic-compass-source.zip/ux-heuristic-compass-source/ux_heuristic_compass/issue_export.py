from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from .state import issue_export_path, utc_now


ISSUE_EXPORT_SCHEMA_VERSION = "uxhc.issue_export.v1"


def export_issue_bundle(
    input_path: str,
    *,
    input_type: str = "auto",
    output_dir: str | None = None,
    output_format: str = "both",
) -> dict[str, Any]:
    path = Path(input_path).expanduser()
    text = path.read_text(encoding="utf-8")
    normalized_type = _infer_input_type(path, text, input_type)
    if normalized_type == "feedback_markdown":
        issues = _issues_from_feedback_markdown(text, source_path=str(path))
    else:
        issues = _issues_from_json_payload(text, source_path=str(path), source_type=normalized_type)
    bundle = {
        "schema_version": ISSUE_EXPORT_SCHEMA_VERSION,
        "created_at": utc_now(),
        "source_path": str(path),
        "source_type": normalized_type,
        "issue_count": len(issues),
        "issues": issues,
        "boundary": "Script/internal helper only; no public MCP tool is added.",
    }
    return _write_issue_bundle(bundle, output_dir=output_dir, output_format=output_format)


def _infer_input_type(path: Path, text: str, input_type: str) -> str:
    supplied = str(input_type or "auto").strip().lower()
    if supplied in {"feedback", "feedback_markdown", "markdown", "md"}:
        return "feedback_markdown"
    if supplied in {"run_summary", "report_payload", "json"}:
        return supplied
    if path.suffix.lower() in {".md", ".markdown"}:
        return "feedback_markdown"
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return "feedback_markdown"
    if isinstance(payload, dict) and payload.get("tool_name"):
        return "run_summary"
    if isinstance(payload, dict) and payload.get("ux_health_snapshot"):
        return "report_payload"
    return "json"


def _issues_from_feedback_markdown(text: str, *, source_path: str) -> list[dict[str, Any]]:
    headings = list(re.finditer(r"(?m)^(#{2,4})\s+(?P<title>.+?)\s*$", text))
    issues: list[dict[str, Any]] = []
    for index, heading in enumerate(headings):
        title = _clean_title(heading.group("title"))
        if not _looks_like_feedback_issue(title):
            continue
        start = heading.end()
        end = headings[index + 1].start() if index + 1 < len(headings) else len(text)
        body = text[start:end].strip()
        issues.append(_issue_record(title=title, body=body, source_path=source_path, source_type="feedback_markdown"))
    if not issues and text.strip():
        issues.append(
            _issue_record(
                title="Feedback report follow-up",
                body=text.strip(),
                source_path=source_path,
                source_type="feedback_markdown",
            )
        )
    return issues


def _issues_from_json_payload(text: str, *, source_path: str, source_type: str) -> list[dict[str, Any]]:
    payload = json.loads(text)
    records = payload if isinstance(payload, list) else [payload]
    issues: list[dict[str, Any]] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        source_kind = source_type
        blockers = record.get("blockers") or record.get("blocking_issues") or []
        warnings = record.get("warnings") or []
        for item in blockers:
            issues.append(_issue_record(title=_json_issue_title(item, "Blocking issue"), body=json.dumps(item, sort_keys=True), source_path=source_path, source_type=source_kind, severity="high"))
        for item in warnings:
            issues.append(_issue_record(title=_json_issue_title(item, "Warning"), body=json.dumps(item, sort_keys=True), source_path=source_path, source_type=source_kind, severity="medium"))
    return issues


def _clean_title(title: str) -> str:
    title = re.sub(r"^[^\w`[]+", "", title).strip()
    title = title.replace("—", "-").replace("–", "-")
    return re.sub(r"\s+", " ", title)


def _looks_like_feedback_issue(title: str) -> bool:
    lowered = title.lower()
    return any(token in lowered for token in ("bug", "flag", "observation", "issue", "uxhc-", "feedback"))


def _json_issue_title(item: Any, fallback: str) -> str:
    if isinstance(item, dict):
        return str(item.get("code") or item.get("message") or item.get("field") or fallback)
    return fallback


def _issue_record(
    *,
    title: str,
    body: str,
    source_path: str,
    source_type: str,
    severity: str | None = None,
) -> dict[str, Any]:
    digest = hashlib.sha1(f"{title}\n{body}".encode("utf-8")).hexdigest()[:10]
    severity_value = severity or _severity_for(title, body)
    affected = _affected_subsystem(title, body)
    return {
        "issue_id": f"UXHC-FEEDBACK-{digest}",
        "title": title,
        "source_path": source_path,
        "source_type": source_type,
        "severity": severity_value,
        "affected_tool_or_subsystem": affected,
        "status": "new",
        "body": _compact_body(body),
        "acceptance_test": f"Add or update a regression covering {affected}.",
    }


def _severity_for(title: str, body: str) -> str:
    text = f"{title}\n{body}".lower()
    if "p0" in text or "blocking" in text or "cannot" in text or "bug" in title.lower():
        return "high"
    if "warning" in text or "flag" in title.lower():
        return "medium"
    return "low"


def _affected_subsystem(title: str, body: str) -> str:
    text = f"{title}\n{body}".lower()
    candidates = [
        ("validate_ux_report_payload", ("validate_ux_report_payload", "validator", "repair_tasks", "repair tasks")),
        ("generate_ux_audit_report", ("generate_ux_audit_report", "report generation", "renderer", "html", "markdown")),
        ("quick_scan_ux", ("quick_scan_ux", "quick scan", "risk card")),
        ("audit_ux_surface", ("audit_ux_surface", "advanced audit", "checklist ratings")),
        ("hil", ("hil", "human-in-the-loop", "pause_required", "native ui")),
        ("visual_qa", ("visual qa", "playwright", "browser handoff")),
        ("evidence", ("evidence", "evidence ref", "screenshot", "traceability")),
    ]
    for subsystem, needles in candidates:
        if any(needle in text for needle in needles):
            return subsystem
    return "uxhc_runtime"


def _compact_body(body: str, limit: int = 1200) -> str:
    compact = re.sub(r"\s+", " ", body).strip()
    if len(compact) <= limit:
        return compact
    return compact[: limit - 20].rstrip() + " ... [truncated]"


def _write_issue_bundle(bundle: dict[str, Any], *, output_dir: str | None, output_format: str) -> dict[str, Any]:
    fmt = str(output_format or "both").strip().lower()
    if fmt not in {"both", "json", "md"}:
        fmt = "both"
    digest = hashlib.sha1(json.dumps(bundle, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:10]
    export_id = f"uxhc-feedback-issues-{digest}"
    root = Path(output_dir).expanduser() if output_dir else None
    paths: dict[str, str] = {}
    if fmt in {"both", "json"}:
        json_path = (root / f"{export_id}.json") if root else issue_export_path(export_id, ".json")
        json_path.parent.mkdir(parents=True, exist_ok=True)
        json_path.write_text(json.dumps(bundle, indent=2, sort_keys=True), encoding="utf-8")
        paths["json_path"] = str(json_path)
    if fmt in {"both", "md"}:
        md_path = (root / f"{export_id}.md") if root else issue_export_path(export_id, ".md")
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text(_issue_bundle_markdown(bundle), encoding="utf-8")
        paths["markdown_path"] = str(md_path)
    return {
        "schema_version": ISSUE_EXPORT_SCHEMA_VERSION,
        "status": "exported",
        "issue_count": bundle["issue_count"],
        "source_path": bundle["source_path"],
        "source_type": bundle["source_type"],
        "paths": paths,
        "public_tool_added": False,
    }


def _issue_bundle_markdown(bundle: dict[str, Any]) -> str:
    lines = [
        "# UXHC Feedback Issue Bundle",
        "",
        f"- Source: {bundle['source_path']}",
        f"- Source type: {bundle['source_type']}",
        f"- Issue count: {bundle['issue_count']}",
        "- Boundary: Script/internal helper only; no public MCP tool is added.",
        "",
    ]
    for issue in bundle["issues"]:
        lines.extend(
            [
                f"## {issue['issue_id']} - {issue['title']}",
                "",
                f"- Severity: {issue['severity']}",
                f"- Affected tool/subsystem: {issue['affected_tool_or_subsystem']}",
                f"- Status: {issue['status']}",
                f"- Acceptance test: {issue['acceptance_test']}",
                "",
                issue["body"] or "No body supplied.",
                "",
            ]
        )
    return "\n".join(lines).strip() + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Export UXHC feedback into JSON/Markdown issue bundles.")
    parser.add_argument("input_path", help="Feedback Markdown, run-summary JSON/JSONL, or report payload path.")
    parser.add_argument("--input-type", default="auto", choices=["auto", "feedback", "feedback_markdown", "markdown", "md", "run_summary", "report_payload", "json"])
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--format", default="both", choices=["both", "json", "md"])
    args = parser.parse_args(argv)
    result = export_issue_bundle(args.input_path, input_type=args.input_type, output_dir=args.output_dir, output_format=args.format)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "exported" else 1


if __name__ == "__main__":
    raise SystemExit(main())
