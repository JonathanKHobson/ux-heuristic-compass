from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
import re
from typing import Any


DATA_DIR = Path(__file__).with_name("data")


@lru_cache(maxsize=1)
def load_flow_library() -> dict[str, dict[str, Any]]:
    records = json.loads((DATA_DIR / "uxhc_flows.json").read_text(encoding="utf-8"))
    return {str(record["flow_id"]): dict(record) for record in records}


@lru_cache(maxsize=1)
def load_bias_registry() -> dict[str, dict[str, Any]]:
    records = json.loads((DATA_DIR / "evaluator_bias_registry.json").read_text(encoding="utf-8"))
    by_id: dict[str, dict[str, Any]] = {}
    for record in records:
        by_id[str(record["bias_id"])] = dict(record)
        by_id[str(record["slug"])] = dict(record)
    return by_id


@lru_cache(maxsize=1)
def load_activity_registry() -> dict[str, dict[str, Any]]:
    records = json.loads((DATA_DIR / "uxhc_activities.json").read_text(encoding="utf-8"))
    return {str(record["activity_id"]): dict(record) for record in records}


@lru_cache(maxsize=1)
def load_support_lens_registry() -> dict[str, dict[str, Any]]:
    records = json.loads((DATA_DIR / "uxhc_support_lenses.json").read_text(encoding="utf-8"))
    return {str(record["lens_id"]): dict(record) for record in records}


def flow_by_id(flow_id: str) -> dict[str, Any] | None:
    flow = load_flow_library().get(flow_id)
    return deepcopy(flow) if flow else None


def activity_by_id(activity_id: str) -> dict[str, Any] | None:
    activity = load_activity_registry().get(activity_id)
    return deepcopy(activity) if activity else None


def support_lens_by_id(lens_id: str) -> dict[str, Any] | None:
    lens = load_support_lens_registry().get(lens_id)
    return deepcopy(lens) if lens else None


def imported_static_metadata(
    source_entry_id: str | None,
    *,
    source_entry_ids: list[str] | None = None,
    source_status: str | None = None,
) -> dict[str, Any]:
    return {
        "policy": "hybrid_static_first",
        "status": "imported_static",
        "source_entry_id": source_entry_id or "",
        "source_entry_ids": source_entry_ids or ([source_entry_id] if source_entry_id else []),
        "source_status": source_status or "",
        "fallback_ready": True,
    }


def flow_suggestion(flow_id: str, *, heuristic_id: str, trigger_reason: str) -> dict[str, Any] | None:
    flow = flow_by_id(flow_id)
    if not flow:
        return None
    source_entry_id = str(flow.get("source_entry_id") or "")
    source_entry_ids = [str(item) for item in flow.get("source_entry_ids") or ([source_entry_id] if source_entry_id else [])]
    source_type = str(flow.get("source_type") or "")
    return {
        **flow,
        "heuristic_id": heuristic_id,
        "trigger_reason": trigger_reason,
        "source": "knowledge_atlas_adapted" if source_type == "knowledge_atlas_adapted" else "authored_uxhc_v1",
        "knowledge_atlas_enrichment": imported_static_metadata(
            source_entry_id,
            source_entry_ids=source_entry_ids,
            source_status=str(flow.get("source_status") or ""),
        ),
    }


def prioritization_flow() -> dict[str, Any]:
    flow = flow_suggestion(
        "ux_flow_rice_prioritization",
        heuristic_id="overall",
        trigger_reason="Overall grade is B or below, so findings need actionability triage.",
    )
    return flow or {}


def bias_record(bias_id_or_slug: str) -> dict[str, Any] | None:
    record = load_bias_registry().get(bias_id_or_slug)
    return deepcopy(record) if record else None


def activity_card(activity_id: str) -> dict[str, Any] | None:
    record = activity_by_id(activity_id)
    if not record:
        return None
    return {
        "schema_version": "uxhc.follow_up_activity_card.v1",
        "activity_id": record["activity_id"],
        "title": record["title"],
        "format": record.get("format", ""),
        "trigger": record.get("trigger", ""),
        "why_this_fits": record.get("why_this_fits", ""),
        "steps": deepcopy(record.get("steps") or []),
        "fit_check": record.get("fit_check", ""),
        "source": record.get("source", ""),
        "source_status": record.get("source_status", ""),
        "source_note": record.get("source_note", ""),
        **({"facilitation_note": record["facilitation_note"]} if record.get("facilitation_note") else {}),
    }


def bias_flag(bias_id_or_slug: str, *, relevance_note: str) -> dict[str, Any]:
    record = bias_record(bias_id_or_slug) or {
        "bias_id": bias_id_or_slug,
        "name": bias_id_or_slug,
        "mitigation": "",
    }
    return {
        "bias_id": record["bias_id"],
        "name": record["name"],
        "relevance_note": relevance_note,
        "mitigation": record.get("mitigation", ""),
    }


SUPPORT_LENS_REQUIRED_FIELDS = (
    "lens_id",
    "name",
    "lens_type",
    "family",
    "source_family",
    "source_refs",
    "source_status",
    "mapped_heuristic_ids",
    "checklist_text_patterns",
    "trigger_keywords",
    "audit_use",
    "caveat",
    "misuse_warning",
    "report_phrase",
    "score_policy",
)


CORPUS_FAMILY_POLICIES: dict[str, dict[str, Any]] = {
    "core": {
        "display_family": "UX/UI Support Lens",
        "source_quality": "Curated UXHC support reference adapted from UX/UI laws, HCI principles, standards, conventions, or external heuristic systems.",
        "applicability_note": "Use only when it helps explain an evidence-backed UXHC finding or bounded host observation.",
        "evidence_needed": "Visible interface evidence, source context, or a stated evidence limit must remain the basis for the finding.",
        "reporting_guardrail": "Support-only context; not a separate score, proof of user behavior, compliance claim, or replacement for the H01-H14 checklist.",
    },
    "cross_cultural": {
        "display_family": "Cultural Context Support",
        "source_quality": "Curated support reference adapted from non-Western, cross-cultural, Indigenous, decolonial, multilingual, and situated-access research packets.",
        "applicability_note": "Use only when interface evidence raises a culturally situated, language, access-context, authority, data-governance, or community-validation issue.",
        "evidence_needed": "Requires local context, affected-community review, language/script evidence, or a clear evidence limit before stronger claims.",
        "reporting_guardrail": "Support-only context guidance; not cultural certification, community approval, a universal claim about any culture, or a substitute for local/community review.",
    },
    "wcag": {
        "display_family": "WCAG Accessibility Support",
        "source_quality": "Curated WCAG 2.2 accessibility support reference adapted into UXHC's heuristic-review layer.",
        "applicability_note": "Use when evidence suggests a perceivable, operable, understandable, robust, component, keyboard, focus, contrast, media, authentication, or input-assistance risk.",
        "evidence_needed": "Requires rendered/code/manual accessibility evidence before any conformance-strength statement.",
        "reporting_guardrail": "Accessibility support guidance only; not WCAG, ADA, legal, procurement, compliance, conformance, or certification proof.",
    },
    "iso": {
        "display_family": "ISO UX/UI/HCI Support",
        "source_quality": "Curated ISO-informed UX/UI/HCI support reference adapted from usability, HCD, interaction, accessibility, quality-in-use, AI, privacy/security, workload, and operations standards.",
        "applicability_note": "Use when the finding benefits from ISO-informed framing around context of use, interaction quality, evidence traceability, process quality, or operational risk.",
        "evidence_needed": "Requires project, process, technical, or audit evidence before standards-strength claims.",
        "reporting_guardrail": "ISO-informed support reference only; not formal ISO standards compliance, conformance, certification, procurement proof, or legal assurance.",
    },
    "cx": {
        "display_family": "CX Service-Journey Support",
        "source_quality": "Curated CX/service-journey support reference adapted from customer experience, service recovery, omnichannel continuity, complaint handling, and customer-success concepts.",
        "applicability_note": "Use when the evidence concerns journey continuity, promise delivery, effort, recovery, complaint handling, handoff, or customer relationship clarity.",
        "evidence_needed": "Requires customer, journey, service, operational, or analytics evidence before any real-world outcome claim.",
        "reporting_guardrail": "CX support guidance only; no ROI, NPS, retention, loyalty, satisfaction, revenue, churn, or real-customer outcome claim unless supplied evidence supports it.",
    },
}


CORPUS_FORBIDDEN_CLAIM_PATTERNS: dict[str, tuple[str, ...]] = {
    "wcag": (
        r"\bwcag compliant\b",
        r"\bada compliant\b",
        r"\blegally compliant\b",
        r"\bcertified as\b",
        r"\bconforms? to (?:a|aa|aaa)\b",
        r"\bpasses? wcag\b",
        r"\baccessibility certified\b",
    ),
    "iso": (
        r"\biso compliant\b",
        r"\biso certified\b",
        r"\bconforms? to iso\b",
        r"\bprocurement ready\b",
        r"\b(?:provides|is|gives|guarantees) legal assurance\b",
    ),
    "cross_cultural": (
        r"\bculturally safe certified\b",
        r"\bdecolonized certified\b",
        r"\bcommunity-approved\b",
        r"\ball non-western users\b",
        r"\ball cultures\b",
    ),
    "cx": (
        r"\bproves loyalty\b",
        r"\bincreases retention\b",
        r"\bimproves nps\b",
        r"\bdrives roi\b",
        r"\breduces churn\b",
        r"\bproves customer satisfaction\b",
    ),
    "synthetic_research": (
        r"\breal users struggled\b",
        r"\bparticipants struggled\b",
        r"\buser tested\b",
        r"\bvalidated with users\b",
    ),
    "score_authority": (
        r"\bsupport lenses? changed\b",
        r"\blens(?:es)? changed the (?:score|grade|rating|severity|priority)\b",
        r"\bcorpus (?:score|grade)\b",
    ),
}


def corpus_family_key_for_lens(lens: dict[str, Any]) -> str:
    lens_id = str(lens.get("lens_id") or "").lower()
    source_family = str(lens.get("source_family") or "").lower()
    if lens_id.startswith("cross_cultural_"):
        return "cross_cultural"
    if lens_id.startswith("wcag_") or lens_id == "standard_wcag_pour" or "wcag" in source_family or "wai-aria" in source_family:
        return "wcag"
    if lens_id.startswith("iso_") or source_family == "iso":
        return "iso"
    if lens_id.startswith("cx_") or source_family == "cx":
        return "cx"
    return "core"


def corpus_family_policy_for_lens(lens: dict[str, Any]) -> dict[str, Any]:
    policy_key = corpus_family_key_for_lens(lens)
    return {"policy_key": policy_key, **deepcopy(CORPUS_FAMILY_POLICIES[policy_key])}


def corpus_policy_enrichment_for_lens(lens: dict[str, Any]) -> dict[str, Any]:
    policy = corpus_family_policy_for_lens(lens)
    return {
        "corpus_family": policy["policy_key"],
        "display_family": policy["display_family"],
        "source_quality": policy["source_quality"],
        "applicability_note": policy["applicability_note"],
        "evidence_needed": policy["evidence_needed"],
        "reporting_guardrail": policy["reporting_guardrail"],
    }


def corpus_overclaim_violations(value: Any) -> list[dict[str, str]]:
    serialized = value if isinstance(value, str) else json.dumps(value, default=str, ensure_ascii=True)
    lower = serialized.lower()
    violations: list[dict[str, str]] = []
    for category, patterns in CORPUS_FORBIDDEN_CLAIM_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, lower):
                violations.append({"category": category, "pattern": pattern, "issue": "forbidden_claim"})
    return violations


def validate_support_lens_registry() -> dict[str, Any]:
    from .rubric import checklist_item_by_id, heuristic_by_id

    blockers: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    allowed_statuses = {"adapted", "authored", "source", "draft"}
    for lens in load_support_lens_registry().values():
        lens_id = str(lens.get("lens_id") or "")
        for field in SUPPORT_LENS_REQUIRED_FIELDS:
            value = lens.get(field)
            if value in (None, "", []):
                blockers.append({"lens_id": lens_id, "field": field, "issue": "missing_or_empty"})
        if lens.get("score_policy") != "support_only":
            blockers.append({"lens_id": lens_id, "field": "score_policy", "issue": "must_be_support_only"})
        if str(lens.get("source_status") or "") not in allowed_statuses:
            blockers.append({"lens_id": lens_id, "field": "source_status", "issue": "invalid"})
        policy_key = corpus_family_key_for_lens(lens)
        if policy_key not in CORPUS_FAMILY_POLICIES:
            blockers.append({"lens_id": lens_id, "field": "corpus_family", "issue": "unknown_policy"})
        for violation in corpus_overclaim_violations(lens):
            blockers.append({"lens_id": lens_id, "field": "claim_language", **violation})
        if "nielsen" in f"{lens.get('name', '')} {lens.get('source_family', '')}".lower() and "jakob's law" not in str(lens.get("name", "")).lower():
            blockers.append({"lens_id": lens_id, "field": "source_family", "issue": "standalone_nielsen_system_disallowed"})
        for heuristic_id in lens.get("mapped_heuristic_ids") or []:
            if heuristic_by_id(str(heuristic_id)) is None:
                blockers.append({"lens_id": lens_id, "field": "mapped_heuristic_ids", "issue": f"unknown_heuristic:{heuristic_id}"})
        for checklist_id in lens.get("mapped_checklist_item_ids") or []:
            if checklist_item_by_id(str(checklist_id)) is None:
                blockers.append({"lens_id": lens_id, "field": "mapped_checklist_item_ids", "issue": f"unknown_checklist_item:{checklist_id}"})
        if not lens.get("mapped_checklist_item_ids"):
            warnings.append({"lens_id": lens_id, "field": "mapped_checklist_item_ids", "issue": "broad_heuristic_mapping_only"})
    return {
        "schema_version": "uxhc.support_lens_registry_validation.v1",
        "status": "ready" if not blockers else "blocked",
        "lens_count": len(load_support_lens_registry()),
        "required_fields": list(SUPPORT_LENS_REQUIRED_FIELDS),
        "blockers": blockers,
        "warnings": warnings,
        "score_policy": "support_only",
    }


def _normalize_text(value: Any) -> str:
    return " ".join(str(value or "").lower().replace("_", " ").replace("-", " ").split())


def _word_tokens(value: Any) -> list[str]:
    return re.findall(r"[a-z0-9]+", str(value or "").lower().replace("_", " ").replace("-", " "))


def _matches_support_phrase(haystack_tokens: list[str], needle: Any) -> bool:
    needle_tokens = _word_tokens(needle)
    if not needle_tokens:
        return False
    if len(needle_tokens) == 1:
        return needle_tokens[0] in set(haystack_tokens)
    return " ".join(needle_tokens) in " ".join(haystack_tokens)


def _support_lens_score(lens: dict[str, Any], finding: dict[str, Any]) -> tuple[int, list[str]]:
    heuristic_id = str(finding.get("heuristic_id") or "").lower()
    checklist_item_id = str(finding.get("checklist_item_id") or "").lower()
    lens_id = str(lens.get("lens_id") or "")
    haystack = _normalize_text(
        " ".join(
            str(item or "")
            for item in [
                finding.get("title"),
                finding.get("observed_issue"),
                finding.get("recommendation"),
                finding.get("user_impact"),
                finding.get("heuristic_name"),
                finding.get("checklist_text"),
                finding.get("checklist_item_id"),
                finding.get("evidence_ref"),
                finding.get("profile"),
            ]
        )
    )
    haystack_tokens = _word_tokens(haystack)
    score = 0
    reasons: list[str] = []
    trigger_reasons: list[str] = []
    if heuristic_id and heuristic_id in {str(item).lower() for item in lens.get("mapped_heuristic_ids") or []}:
        score += 5
        reasons.append(f"maps to {heuristic_id.upper()}")
    if checklist_item_id and checklist_item_id in {str(item).lower() for item in lens.get("mapped_checklist_item_ids") or []}:
        score += 8
        reason = f"maps to {checklist_item_id}"
        reasons.append(reason)
    for pattern in lens.get("checklist_text_patterns") or []:
        if _matches_support_phrase(haystack_tokens, pattern):
            score += 3
            reason = f"matches pattern '{pattern}'"
            reasons.append(reason)
            trigger_reasons.append(reason)
    for keyword in lens.get("trigger_keywords") or []:
        if _matches_support_phrase(haystack_tokens, keyword):
            score += 2
            reason = f"matches trigger '{keyword}'"
            reasons.append(reason)
            trigger_reasons.append(reason)
    if bool(lens.get("requires_context_trigger")) or lens_id.startswith("cross_cultural_"):
        if not trigger_reasons:
            return 0, []
    return score, reasons


def _support_lens_card(lens: dict[str, Any], *, finding: dict[str, Any], score: int, reasons: list[str]) -> dict[str, Any]:
    return {
        "schema_version": "uxhc.support_lens.v1",
        "lens_id": lens["lens_id"],
        "name": lens["name"],
        "lens_type": lens["lens_type"],
        "family": lens["family"],
        "source_family": lens["source_family"],
        "source_refs": deepcopy(lens.get("source_refs") or []),
        "source_status": lens["source_status"],
        "mapped_heuristic_ids": deepcopy(lens.get("mapped_heuristic_ids") or []),
        "mapped_checklist_item_ids": deepcopy(lens.get("mapped_checklist_item_ids") or []),
        "applies_to": {
            "finding_id": finding.get("finding_id", ""),
            "finding_signature": finding.get("finding_signature", ""),
            "heuristic_id": finding.get("heuristic_id", ""),
            "checklist_item_id": finding.get("checklist_item_id", ""),
            "evidence_ref": finding.get("evidence_ref", ""),
        },
        "why_applies": "; ".join(reasons[:3]) if reasons else "This lens maps to the finding's heuristic context.",
        "audit_use": lens["audit_use"],
        "caveat": lens["caveat"],
        "misuse_warning": lens["misuse_warning"],
        "report_phrase": lens["report_phrase"],
        **corpus_policy_enrichment_for_lens(lens),
        "selection_score": score,
        "score_policy": "support_only",
    }


def select_support_lenses_for_finding(finding: dict[str, Any], *, max_lenses: int = 2) -> list[dict[str, Any]]:
    ranked: list[tuple[int, str, dict[str, Any], list[str]]] = []
    for lens in load_support_lens_registry().values():
        score, reasons = _support_lens_score(lens, finding)
        if score <= 0:
            continue
        ranked.append((score, str(lens["lens_id"]), lens, reasons))
    ranked.sort(key=lambda item: (-item[0], item[1]))
    return [
        _support_lens_card(lens, finding=finding, score=score, reasons=reasons)
        for score, _lens_id, lens, reasons in ranked[: max(0, max_lenses)]
    ]


def attach_support_lenses_to_findings(findings: list[dict[str, Any]], *, max_per_finding: int = 2) -> list[dict[str, Any]]:
    enriched: list[dict[str, Any]] = []
    for finding in findings:
        lenses = select_support_lenses_for_finding(finding, max_lenses=max_per_finding)
        enriched.append({**finding, "support_lenses": lenses} if lenses else dict(finding))
    return enriched


def summarize_support_lenses(findings: list[dict[str, Any]], *, max_lenses: int = 6) -> list[dict[str, Any]]:
    by_id: dict[str, dict[str, Any]] = {}
    for finding in findings:
        for lens in finding.get("support_lenses") or []:
            lens_id = str(lens.get("lens_id") or "")
            if not lens_id:
                continue
            if lens_id not in by_id:
                by_id[lens_id] = {
                    "schema_version": "uxhc.support_lens_summary.v1",
                    "lens_id": lens_id,
                    "name": lens.get("name", ""),
                    "lens_type": lens.get("lens_type", ""),
                    "family": lens.get("family", ""),
                    "source_family": lens.get("source_family", ""),
                    "source_refs": deepcopy(lens.get("source_refs") or []),
                    "source_status": lens.get("source_status", ""),
                    "audit_use": lens.get("audit_use", ""),
                    "caveat": lens.get("caveat", ""),
                    "misuse_warning": lens.get("misuse_warning", ""),
                    "report_phrase": lens.get("report_phrase", ""),
                    "corpus_family": lens.get("corpus_family", corpus_family_key_for_lens(lens)),
                    "display_family": lens.get("display_family", lens.get("source_family", "")),
                    "source_quality": lens.get("source_quality", ""),
                    "applicability_note": lens.get("applicability_note", ""),
                    "evidence_needed": lens.get("evidence_needed", ""),
                    "reporting_guardrail": lens.get("reporting_guardrail", ""),
                    "score_policy": "support_only",
                    "trigger_count": 0,
                    "finding_refs": [],
                    "selection_score_total": 0,
                }
            by_id[lens_id]["trigger_count"] += 1
            by_id[lens_id]["selection_score_total"] += int(lens.get("selection_score") or 0)
            by_id[lens_id]["finding_refs"].append(
                {
                    "finding_id": lens.get("applies_to", {}).get("finding_id", ""),
                    "heuristic_id": lens.get("applies_to", {}).get("heuristic_id", ""),
                    "checklist_item_id": lens.get("applies_to", {}).get("checklist_item_id", ""),
                }
            )
    summaries = list(by_id.values())
    summaries.sort(key=lambda item: (-int(item["trigger_count"]), -int(item["selection_score_total"]), str(item["lens_id"])))
    return summaries[: max(0, max_lenses)]


def support_lens_catalog(*, detail_level: str = "summary") -> dict[str, Any]:
    registry = load_support_lens_registry()
    full_detail = str(detail_level or "summary").lower() in {"full", "support_lenses", "lenses", "lens_catalog"}
    families: dict[str, dict[str, Any]] = {}
    for lens in registry.values():
        policy = corpus_policy_enrichment_for_lens(lens)
        key = policy["corpus_family"]
        if key not in families:
            families[key] = {
                "corpus_family": key,
                "display_family": policy["display_family"],
                "source_quality": policy["source_quality"],
                "applicability_note": policy["applicability_note"],
                "evidence_needed": policy["evidence_needed"],
                "reporting_guardrail": policy["reporting_guardrail"],
                "lens_count": 0,
                "mapped_heuristic_ids": [],
                "sample_lens_ids": [],
            }
        family = families[key]
        family["lens_count"] += 1
        for heuristic_id in lens.get("mapped_heuristic_ids") or []:
            if heuristic_id not in family["mapped_heuristic_ids"]:
                family["mapped_heuristic_ids"].append(heuristic_id)
        if len(family["sample_lens_ids"]) < 6:
            family["sample_lens_ids"].append(lens["lens_id"])
    for family in families.values():
        family["mapped_heuristic_ids"] = sorted(family["mapped_heuristic_ids"])
    payload: dict[str, Any] = {
        "schema_version": "uxhc.support_lens_catalog.v1",
        "detail_level": "full" if full_detail else "summary",
        "lens_count": len(registry),
        "score_policy": "support_only",
        "selection_policy": "Support lenses may explain evidence-backed findings, guidance-only cues, validation nudges, and report phrasing; they never create scores or change H01-H14 checklist ratings.",
        "families": [families[key] for key in sorted(families)],
        "full_catalog_hint": "Call list_heuristics(topic='support_lenses') or list_heuristics(detail_level='support_lenses') for compact records for every support lens.",
    }
    if full_detail:
        payload["lenses"] = [
            {
                "lens_id": lens["lens_id"],
                "name": lens["name"],
                "lens_type": lens["lens_type"],
                "family": lens["family"],
                "source_family": lens["source_family"],
                "source_refs": deepcopy(lens.get("source_refs") or []),
                "source_status": lens["source_status"],
                "mapped_heuristic_ids": deepcopy(lens.get("mapped_heuristic_ids") or []),
                "mapped_checklist_item_ids": deepcopy(lens.get("mapped_checklist_item_ids") or []),
                "checklist_text_patterns": deepcopy(lens.get("checklist_text_patterns") or []),
                "trigger_keywords": deepcopy(lens.get("trigger_keywords") or []),
                "audit_use": lens["audit_use"],
                "report_phrase": lens["report_phrase"],
                "caveat": lens["caveat"],
                "misuse_warning": lens["misuse_warning"],
                **corpus_policy_enrichment_for_lens(lens),
                "score_policy": "support_only",
            }
            for lens in registry.values()
        ]
    return payload


__all__ = [
    "CORPUS_FAMILY_POLICIES",
    "CORPUS_FORBIDDEN_CLAIM_PATTERNS",
    "attach_support_lenses_to_findings",
    "activity_by_id",
    "activity_card",
    "bias_flag",
    "bias_record",
    "corpus_family_key_for_lens",
    "corpus_family_policy_for_lens",
    "corpus_overclaim_violations",
    "corpus_policy_enrichment_for_lens",
    "flow_by_id",
    "flow_suggestion",
    "imported_static_metadata",
    "load_activity_registry",
    "load_bias_registry",
    "load_flow_library",
    "load_support_lens_registry",
    "prioritization_flow",
    "select_support_lenses_for_finding",
    "summarize_support_lenses",
    "support_lens_catalog",
    "support_lens_by_id",
    "validate_support_lens_registry",
]
