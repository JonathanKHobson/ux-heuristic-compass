from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
from typing import Any


DATA_DIR = Path(__file__).with_name("data")


@lru_cache(maxsize=1)
def load_flow_library() -> dict[str, dict[str, Any]]:
    records = json.loads((DATA_DIR / "uxhc_flows.json").read_text(encoding="utf-8"))
    return {str(record["flow_id"]): dict(record) for record in records}


@lru_cache(maxsize=1)
def load_bias_registry() -> dict[str, dict[str, Any]]:
    records = json.loads((DATA_DIR / "evaluator_bias_registry.json").read_text(encoding="utf-8"))
    by_id: dict[str, dict[str, Any]] = {}
    for record in records:
        by_id[str(record["bias_id"])] = dict(record)
        by_id[str(record["slug"])] = dict(record)
    return by_id


@lru_cache(maxsize=1)
def load_activity_registry() -> dict[str, dict[str, Any]]:
    records = json.loads((DATA_DIR / "uxhc_activities.json").read_text(encoding="utf-8"))
    return {str(record["activity_id"]): dict(record) for record in records}


def flow_by_id(flow_id: str) -> dict[str, Any] | None:
    flow = load_flow_library().get(flow_id)
    return deepcopy(flow) if flow else None


def activity_by_id(activity_id: str) -> dict[str, Any] | None:
    activity = load_activity_registry().get(activity_id)
    return deepcopy(activity) if activity else None


def imported_static_metadata(
    source_entry_id: str | None,
    *,
    source_entry_ids: list[str] | None = None,
    source_status: str | None = None,
) -> dict[str, Any]:
    return {
        "policy": "hybrid_static_first",
        "status": "imported_static",
        "source_entry_id": source_entry_id or "",
        "source_entry_ids": source_entry_ids or ([source_entry_id] if source_entry_id else []),
        "source_status": source_status or "",
        "fallback_ready": True,
    }


def flow_suggestion(flow_id: str, *, heuristic_id: str, trigger_reason: str) -> dict[str, Any] | None:
    flow = flow_by_id(flow_id)
    if not flow:
        return None
    source_entry_id = str(flow.get("source_entry_id") or "")
    source_entry_ids = [str(item) for item in flow.get("source_entry_ids") or ([source_entry_id] if source_entry_id else [])]
    source_type = str(flow.get("source_type") or "")
    return {
        **flow,
        "heuristic_id": heuristic_id,
        "trigger_reason": trigger_reason,
        "source": "knowledge_atlas_adapted" if source_type == "knowledge_atlas_adapted" else "authored_uxhc_v1",
        "knowledge_atlas_enrichment": imported_static_metadata(
            source_entry_id,
            source_entry_ids=source_entry_ids,
            source_status=str(flow.get("source_status") or ""),
        ),
    }


def prioritization_flow() -> dict[str, Any]:
    flow = flow_suggestion(
        "ux_flow_rice_prioritization",
        heuristic_id="overall",
        trigger_reason="Overall grade is B or below, so findings need actionability triage.",
    )
    return flow or {}


def bias_record(bias_id_or_slug: str) -> dict[str, Any] | None:
    record = load_bias_registry().get(bias_id_or_slug)
    return deepcopy(record) if record else None


def activity_card(activity_id: str) -> dict[str, Any] | None:
    record = activity_by_id(activity_id)
    if not record:
        return None
    return {
        "schema_version": "uxhc.follow_up_activity_card.v1",
        "activity_id": record["activity_id"],
        "title": record["title"],
        "format": record.get("format", ""),
        "trigger": record.get("trigger", ""),
        "why_this_fits": record.get("why_this_fits", ""),
        "steps": deepcopy(record.get("steps") or []),
        "fit_check": record.get("fit_check", ""),
        "source": record.get("source", ""),
        "source_status": record.get("source_status", ""),
        "source_note": record.get("source_note", ""),
        **({"facilitation_note": record["facilitation_note"]} if record.get("facilitation_note") else {}),
    }


def bias_flag(bias_id_or_slug: str, *, relevance_note: str) -> dict[str, Any]:
    record = bias_record(bias_id_or_slug) or {
        "bias_id": bias_id_or_slug,
        "name": bias_id_or_slug,
        "mitigation": "",
    }
    return {
        "bias_id": record["bias_id"],
        "name": record["name"],
        "relevance_note": relevance_note,
        "mitigation": record.get("mitigation", ""),
    }


__all__ = [
    "activity_by_id",
    "activity_card",
    "bias_flag",
    "bias_record",
    "flow_by_id",
    "flow_suggestion",
    "imported_static_metadata",
    "load_activity_registry",
    "load_bias_registry",
    "load_flow_library",
    "prioritization_flow",
]
