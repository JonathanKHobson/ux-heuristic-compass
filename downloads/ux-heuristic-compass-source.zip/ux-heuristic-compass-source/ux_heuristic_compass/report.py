from __future__ import annotations

from datetime import datetime
from html import escape
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import tempfile
import textwrap
from typing import Any

from .behavior import REPORT_REQUIRED_FIELDS
from .knowledge import corpus_policy_enrichment_for_lens
from .state import report_artifact_path
from .tracing import attach_run_summary, payload_trace_context


REPORT_SCHEMA_VERSION = "uxhc.report.v2"
REPORT_DESIGN_SYSTEM_VERSION = "uxhc.report_design_system.v1"

CONTENT_SLOT_LIMITS: dict[str, dict[str, Any]] = {
    "plain_language_read": {
        "max_chars": 520,
        "max_sentences": 2,
        "repair": "Shorten to one or two nontechnical sentences that name the main UX risk and why it matters.",
    },
    "before_using_this_interface": {
        "max_chars": 420,
        "required_prefix": "Before using this interface,",
        "repair": "Start with the required prefix and keep the warning to one focused sentence.",
    },
    "one_recommendation": {
        "max_chars": 380,
        "repair": "Return one concrete fix or validation action, not a roadmap paragraph.",
    },
    "top_finding.title": {
        "max_chars": 120,
        "repair": "Use a short finding title that names the user-visible problem.",
    },
}

REPORT_HARNESS_HOST_INSTRUCTION = (
    "Repair the payload and retry validate_ux_report_payload or generate_ux_audit_report. "
    "Do not create standalone HTML, PDF, or a handmade report outside the UXHC renderer."
)

DRAFT_TEXT_PATTERNS = ("lorem ipsum", "todo", "tbd", "[placeholder]", "{{", "}}")
HUMAN_PANEL_PHRASES = (
    "blended (ai + human panel)",
    "ai + human panel",
    "human panel only",
    "ai vs human",
    "human evaluator chip",
)
FORBIDDEN_HTML_PATTERNS = ("<script", "<a ", " href=", " src=", "@import", "url(")
REDACTION_MODES = {"none", "local_paths", "public_safe"}
OWNER_ROLES = {"Designer", "Engineer", "Product", "Research"}
EVIDENCE_LIMIT_INLINE_ITEM_LIMIT = 4
EVIDENCE_LIMIT_INLINE_CHAR_LIMIT = 700
EVIDENCE_LIMIT_DETAIL_CHECKLIST_PREVIEW_LIMIT = 12
EVIDENCE_GALLERY_FINDING_LIMIT = 8
EVIDENCE_GALLERY_REF_LIMIT = 20

REQUIRED_CHECKLIST_RATING_FIELDS = [
    "checklist_item_id",
    "heuristic_id",
    "platform",
    "rating",
    "evidence_refs",
    "rationale",
    "confidence",
]


def _payload_digest(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _default_report_id(payload: dict[str, Any]) -> str:
    prefix = "uxhc-comparison-report" if _is_comparison_payload(payload) else "uxhc-audit-report"
    return f"{prefix}-{_payload_digest(payload)[:12]}"


def visual_qa_capability() -> dict[str, Any]:
    """Return visual-QA availability without launching a browser."""
    module_available = importlib.util.find_spec("playwright") is not None
    sync_available = importlib.util.find_spec("playwright.sync_api") is not None if module_available else False
    available = module_available and sync_available
    return {
        "schema_version": "uxhc.visual_qa_capability.v1",
        "runner": "playwright",
        "available": available,
        "status": "available" if available else "unavailable",
        "reason": "Playwright sync API is importable." if available else "Playwright sync API is not available in this runtime.",
        "mandatory_dependency": False,
        "browser_launch_attempted": False,
    }


def _visual_qa_status_for_request(requested: bool) -> dict[str, Any]:
    capability = visual_qa_capability()
    if not requested:
        return {
            "status": "not_requested",
            "reason": "Optional browser visual QA was not requested in this report call.",
            "browser_handoff_required": False,
            "capability": capability,
            "preflight": {"requested": False, "available": capability["available"], "browser_launch_attempted": False},
        }
    if not capability["available"]:
        return {
            "status": "unavailable",
            "reason": capability["reason"],
            "browser_handoff_required": False,
            "capability": capability,
            "preflight": {"requested": True, "available": False, "browser_launch_attempted": False},
            "warnings": ["Visual QA was requested, but Playwright is unavailable; no browser was launched."],
        }
    return {
        "status": "preflight_ready",
        "reason": "Visual QA was requested and Playwright is available.",
        "browser_handoff_required": True,
        "capability": capability,
        "preflight": {"requested": True, "available": True, "browser_launch_attempted": False},
    }


def _payload_path_blocked_result(*, code: str, message: str, repair: str, payload_path: str | None = None) -> dict[str, Any]:
    issue = _issue(code=code, field="payload_path", message=message, repair=repair)
    result = {
        "schema_version": REPORT_SCHEMA_VERSION,
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": "blocked",
        "validation_status": "blocked",
        "missing_report_fields": ["payload_path"],
        "blocking_issues": [issue],
        "repair_tasks": [
            _repair_task(
                slot="payload_path",
                issue=code,
                rewrite_prompt=repair,
                blocking=True,
            )
        ],
        "warnings": [message],
        "repair_instructions": [repair, REPORT_HARNESS_HOST_INSTRUCTION],
        "content_slot_limits": CONTENT_SLOT_LIMITS,
        "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
        "what_to_resubmit": [repair],
    }
    return attach_run_summary(
        result,
        "validate_ux_report_payload",
        inputs_summary={"payload_trace_context": payload_trace_context({}, payload_path=payload_path)},
    )


def _load_payload_path(payload_path: str) -> dict[str, Any]:
    return json.loads(Path(payload_path).expanduser().read_text(encoding="utf-8"))


def validate_ux_report_payload(payload: dict[str, Any] | None = None, *, payload_path: str | None = None) -> dict[str, Any]:
    trace_payload_path = str(Path(payload_path).expanduser()) if payload_path else None
    if payload is None and payload_path:
        try:
            payload = _load_payload_path(payload_path)
        except FileNotFoundError:
            return _payload_path_blocked_result(
                code="payload_path_not_found",
                message=f"Could not find payload_path: {payload_path}",
                repair="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                payload_path=trace_payload_path,
            )
        except json.JSONDecodeError as exc:
            return _payload_path_blocked_result(
                code="payload_path_invalid_json",
                message=f"Could not parse payload_path as JSON: {exc}",
                repair="Pass a valid JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                payload_path=trace_payload_path,
            )
        except Exception as exc:
            return _payload_path_blocked_result(
                code="payload_path_unreadable",
                message=f"Could not read payload_path: {exc}",
                repair="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                payload_path=trace_payload_path,
            )

    missing: list[str] = []
    warnings: list[str] = []
    blocking_issues: list[dict[str, Any]] = []

    if not isinstance(payload, dict):
        return attach_run_summary({
            "schema_version": REPORT_SCHEMA_VERSION,
            "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
            "qa_status": "blocked",
            "validation_status": "blocked",
            "missing_report_fields": ["payload"],
            "blocking_issues": [
                _issue(
                    code="payload_not_dictionary",
                    field="payload",
                    message="Report payload must be a dictionary.",
                    repair="Submit the report_ready_payload or payload_path returned by a scored UXHC audit.",
                )
            ],
            "repair_tasks": [
                _repair_task(
                    slot="payload",
                    issue="payload_not_dictionary",
                    rewrite_prompt="Submit the report_ready_payload or payload_path returned by a scored UXHC audit.",
                    blocking=True,
                )
            ],
            "warnings": [],
            "repair_instructions": ["Submit a dictionary payload returned by audit_ux_surface or quick_scan_ux."],
            "content_slot_limits": CONTENT_SLOT_LIMITS,
            "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
            "what_to_resubmit": ["Submit a dictionary payload returned by audit_ux_surface."],
        }, "validate_ux_report_payload", inputs_summary={"payload_trace_context": payload_trace_context({}, payload_path=trace_payload_path)})

    if _is_comparison_payload(payload):
        return _validate_comparison_report_payload(payload, payload_path=trace_payload_path)

    source = payload.get("source") or {}
    snapshot = payload.get("ux_health_snapshot") or {}
    scorecard = payload.get("scorecard") or {}
    checklist_ratings = payload.get("checklist_ratings") or scorecard.get("checklist_ratings") or []
    heuristic_scores = payload.get("heuristic_scores") or scorecard.get("heuristic_scores") or []

    if not source.get("source_id"):
        missing.append("source.source_id")
    if not source.get("status"):
        missing.append("source.status")
    elif source.get("status") == "blocked":
        missing.append("source.status")
    if not payload.get("platform"):
        missing.append("platform")
    if snapshot.get("display_state") != "scored":
        missing.append("ux_health_snapshot.display_state")
    if scorecard.get("score_status") != "scored":
        missing.append("scorecard.score_status")
    for field in ("core_quality_percentage", "core_grade", "core_descriptor", "overall_quality_percentage", "overall_grade", "overall_descriptor"):
        if scorecard.get(field) in (None, "", []):
            missing.append(f"scorecard.{field}")
    if not heuristic_scores:
        missing.append("heuristic_scores")
    if not checklist_ratings:
        missing.append("checklist_ratings")
    if snapshot.get("display_state") == "scored" or scorecard.get("score_status") == "scored":
        _validate_behavior_fields(payload, missing)

    for idx, rating in enumerate(checklist_ratings, start=1):
        for field in REQUIRED_CHECKLIST_RATING_FIELDS:
            if rating.get(field) in (None, "", []):
                if field == "evidence_refs" and rating.get("evidence_limits"):
                    continue
                missing.append(f"checklist_ratings[{idx}].{field}")
        if rating.get("rating") is not None and not (0 <= float(rating["rating"]) <= 4):
            missing.append(f"checklist_ratings[{idx}].rating")

    if any(profile in {"donor", "conversion", "donation", "fundraising"} for profile in (payload.get("profiles", {}).get("accepted") or [])):
        missing.append("profiles.accepted")
        warnings.append("Donor/conversion profiles are excluded from the baseline product.")

    content_missing, content_issues = _validate_content_slots(payload)
    missing.extend(content_missing)
    blocking_issues.extend(_blocking_issues_from_missing(missing))
    blocking_issues.extend(content_issues)

    status = "ready" if not blocking_issues else "blocked"
    repair_instructions = _repair_instructions(missing, blocking_issues)
    repair_tasks = _repair_tasks(payload, missing, blocking_issues)
    return attach_run_summary({
        "schema_version": REPORT_SCHEMA_VERSION,
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": status,
        "validation_status": status,
        "missing_report_fields": missing,
        "blocking_issues": blocking_issues,
        "repair_tasks": repair_tasks,
        "warnings": warnings,
        "repair_instructions": repair_instructions,
        "content_slot_limits": CONTENT_SLOT_LIMITS,
        "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION if status == "blocked" else "Payload is ready for the UXHC renderer.",
        "what_to_resubmit": repair_instructions,
    }, "validate_ux_report_payload", inputs_summary={"payload_trace_context": payload_trace_context(payload, payload_path=trace_payload_path)})


def _validate_behavior_fields(payload: dict[str, Any], missing: list[str]) -> None:
    for field in REPORT_REQUIRED_FIELDS:
        if field in {"heuristic_scores", "checklist_ratings", "evidence_limits"}:
            continue
        if payload.get(field) in (None, "", []):
            missing.append(field)
    plain_read = str(payload.get("plain_language_read") or "").strip()
    if plain_read and _sentence_count(plain_read) > 2:
        missing.append("plain_language_read.max_2_sentences")
    before = str(payload.get("before_using_this_interface") or "")
    if before and not before.startswith("Before using this interface,"):
        missing.append("before_using_this_interface.prefix")
    contract = payload.get("report_readiness_contract") or {}
    if not contract:
        missing.append("report_readiness_contract")
    elif contract.get("status") != "ready":
        missing.append("report_readiness_contract.status")


def _issue(*, code: str, field: str, message: str, repair: str) -> dict[str, str]:
    return {"code": code, "field": field, "message": message, "repair_instruction": repair}


def _get_path(payload: dict[str, Any], dotted_path: str) -> Any:
    value: Any = payload
    for part in dotted_path.split("."):
        if not isinstance(value, dict):
            return None
        value = value.get(part)
    return value


def _payload_has_human_panel(payload: dict[str, Any]) -> bool:
    return bool(
        payload.get("human_panel")
        or payload.get("human_evaluators")
        or payload.get("human_panel_scores")
        or payload.get("blended_scorecard")
    )


def _is_comparison_payload(payload: dict[str, Any]) -> bool:
    return bool(payload.get("report_type") == "comparison" or payload.get("schema_version") == "uxhc.comparison_report_payload.v1")


def _validate_comparison_report_payload(payload: dict[str, Any], *, payload_path: str | None = None) -> dict[str, Any]:
    missing: list[str] = []
    if payload.get("report_type") != "comparison":
        missing.append("report_type")
    for field in ("comparison_id", "baseline_label", "candidate_label", "summary", "next_action"):
        if payload.get(field) in (None, "", []):
            missing.append(field)
    summary = payload.get("summary") or {}
    for field in ("fixed_count", "new_count", "unresolved_count", "severity_changed_count"):
        if summary.get(field) in (None, "", []):
            missing.append(f"summary.{field}")
    blocking_issues = _blocking_issues_from_missing(missing)
    status = "ready" if not blocking_issues else "blocked"
    return attach_run_summary({
        "schema_version": REPORT_SCHEMA_VERSION,
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": status,
        "validation_status": status,
        "missing_report_fields": missing,
        "blocking_issues": blocking_issues,
        "repair_tasks": _repair_tasks(payload, missing, blocking_issues),
        "warnings": [],
        "repair_instructions": _repair_instructions(missing, blocking_issues),
        "content_slot_limits": CONTENT_SLOT_LIMITS,
        "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION if status == "blocked" else "Comparison payload is ready for the UXHC renderer.",
        "what_to_resubmit": _what_to_resubmit(missing),
    }, "validate_ux_report_payload", inputs_summary={"payload_trace_context": payload_trace_context(payload, payload_path=payload_path)})


def _scan_text_fields(payload: dict[str, Any]) -> list[tuple[str, str]]:
    fields = [
        "plain_language_read",
        "before_using_this_interface",
        "one_recommendation",
        "top_finding.title",
        "top_finding.observed_issue",
        "top_finding.recommendation",
    ]
    rows: list[tuple[str, str]] = []
    for field in fields:
        value = _get_path(payload, field) if "." in field else payload.get(field)
        if isinstance(value, str) and value.strip():
            rows.append((field, value))
    for idx, finding in enumerate(payload.get("findings") or [], start=1):
        if not isinstance(finding, dict):
            continue
        for key in ["title", "observed_issue", "recommendation", "user_impact"]:
            value = finding.get(key)
            if isinstance(value, str) and value.strip():
                rows.append((f"findings[{idx}].{key}", value))
    return rows


def _validate_content_slots(payload: dict[str, Any]) -> tuple[list[str], list[dict[str, Any]]]:
    missing: list[str] = []
    issues: list[dict[str, Any]] = []
    for field, limit in CONTENT_SLOT_LIMITS.items():
        value = _get_path(payload, field) if "." in field else payload.get(field)
        if not isinstance(value, str) or not value.strip():
            continue
        max_chars = int(limit.get("max_chars") or 0)
        if max_chars and len(value.strip()) > max_chars:
            missing.append(f"{field}.max_{max_chars}_chars")
            issues.append(
                _issue(
                    code="content_slot_too_long",
                    field=field,
                    message=f"{field} is {len(value.strip())} characters; limit is {max_chars}.",
                    repair=str(limit.get("repair") or "Shorten this content slot."),
                )
            )
    for field, value in _scan_text_fields(payload):
        lower = value.lower()
        if any(pattern in lower for pattern in DRAFT_TEXT_PATTERNS):
            missing.append(f"{field}.placeholder_text")
            issues.append(
                _issue(
                    code="placeholder_text",
                    field=field,
                    message="Report content contains placeholder text.",
                    repair="Replace placeholder text with evidence-bound report copy or omit the optional section.",
                )
            )
        if not _payload_has_human_panel(payload) and any(phrase in lower for phrase in HUMAN_PANEL_PHRASES):
            missing.append(f"{field}.human_panel_language")
            issues.append(
                _issue(
                    code="human_panel_language_without_data",
                    field=field,
                    message="Human-panel or blended-score language appeared without explicit human-panel payload data.",
                    repair="Use AI-only audit language unless the payload explicitly includes human-panel data.",
                )
            )
    return missing, issues


def _blocking_issues_from_missing(missing: list[str]) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for field in missing:
        if ".max_" in field or field.endswith(".placeholder_text") or field.endswith(".human_panel_language"):
            continue
        if field.endswith(".prefix"):
            repair = "Start before_using_this_interface exactly with 'Before using this interface,'."
            code = "invalid_prefix"
        elif field.endswith(".status"):
            repair = "Use the scored audit report_ready_payload after report_readiness_contract.status is ready."
            code = "invalid_status"
        elif field.startswith("checklist_ratings"):
            repair = "Use the checklist_ratings returned by UXHC scoring with checklist_item_id, rating, evidence_refs or evidence_limits, rationale, and confidence."
            code = "invalid_checklist_rating"
        else:
            repair = "Use report_ready_payload or repair the named field before generating the report."
            code = "missing_report_field"
        issues.append(_issue(code=code, field=field, message=f"Report payload is missing or invalid: {field}.", repair=repair))
    return issues


def _repair_instructions(missing: list[str], blocking_issues: list[dict[str, Any]]) -> list[str]:
    instructions = _what_to_resubmit(missing)
    for issue in blocking_issues:
        repair = str(issue.get("repair_instruction") or "").strip()
        if repair and repair not in instructions:
            instructions.append(repair)
    if blocking_issues and REPORT_HARNESS_HOST_INSTRUCTION not in instructions:
        instructions.append(REPORT_HARNESS_HOST_INSTRUCTION)
    return instructions


def _repair_task(
    *,
    slot: str,
    issue: str,
    rewrite_prompt: str,
    limit: Any = None,
    evidence_refs: list[str] | None = None,
    blocking: bool = True,
) -> dict[str, Any]:
    return {
        "slot": slot,
        "issue": issue,
        "limit": limit,
        "evidence_refs": evidence_refs or [],
        "rewrite_prompt": rewrite_prompt,
        "blocking": blocking,
    }


def _repair_tasks(payload: dict[str, Any], missing: list[str], blocking_issues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    tasks: list[dict[str, Any]] = []
    seen_slots: set[str] = set()

    def normalized_slot(slot: str) -> str:
        slot = str(slot or "payload")
        if ".max_" in slot:
            slot = slot.split(".max_", 1)[0]
        for suffix in (".prefix", ".placeholder_text", ".human_panel_language"):
            if slot.endswith(suffix):
                slot = slot[: -len(suffix)]
        return slot

    def add(slot: str, issue: str, prompt: str, limit: Any = None, refs: list[str] | None = None) -> None:
        key = normalized_slot(slot)
        if key in seen_slots:
            return
        seen_slots.add(key)
        tasks.append(_repair_task(slot=slot, issue=issue, limit=limit, evidence_refs=refs, rewrite_prompt=prompt, blocking=True))

    for field in missing:
        slot = field.split(".max_", 1)[0].replace(".prefix", "")
        if field.startswith("checklist_ratings"):
            add(
                slot=field,
                issue="invalid_checklist_rating",
                prompt="Repair this checklist rating with checklist_item_id, heuristic_id, platform, 0-4 rating, rationale, confidence, and evidence_refs or evidence_limits.",
            )
        elif ".max_" in field:
            base = field.split(".max_", 1)[0]
            limit = CONTENT_SLOT_LIMITS.get(base, {}).get("max_chars")
            add(
                slot=base,
                issue="content_slot_too_long",
                limit=limit,
                prompt=str(CONTENT_SLOT_LIMITS.get(base, {}).get("repair") or "Shorten this content slot and retry the UXHC renderer."),
            )
        elif field.endswith(".placeholder_text"):
            add(slot=slot.replace(".placeholder_text", ""), issue="placeholder_text", prompt="Replace placeholder text with evidence-bound report copy or omit the optional section.")
        elif field.endswith(".human_panel_language"):
            add(slot=slot.replace(".human_panel_language", ""), issue="human_panel_language_without_data", prompt="Use AI-only audit language unless the payload explicitly includes human-panel data.")
        elif field == "plain_language_read":
            add(slot=field, issue="missing", prompt="Write one or two nontechnical sentences that name the main UX risk and why it matters.")
        elif field == "one_recommendation":
            refs = []
            top = payload.get("top_finding") or {}
            if top.get("evidence_ref"):
                refs = [str(top["evidence_ref"])]
            add(slot=field, issue="missing", refs=refs, prompt="Write one concrete recommendation tied to the top finding and supplied evidence refs.")
        elif field == "before_using_this_interface" or field == "before_using_this_interface.prefix":
            add(slot="before_using_this_interface", issue="missing_or_invalid_prefix", prompt="Write one focused warning that starts exactly with 'Before using this interface,'.")
        else:
            add(slot=field, issue="missing_or_invalid", prompt="Repair this required report payload field, then retry validate_ux_report_payload.")

    for issue in blocking_issues:
        slot = str(issue.get("field") or "payload")
        code = str(issue.get("code") or "invalid")
        add(slot=slot, issue=code, prompt=str(issue.get("repair_instruction") or "Repair this report slot and retry the UXHC renderer."))
    return tasks


def _sentence_count(text: str) -> int:
    stripped = text.strip()
    if not stripped:
        return 0
    count = sum(stripped.count(mark) for mark in [".", "?", "!"])
    return max(1, count)


def _what_to_resubmit(missing: list[str]) -> list[str]:
    if not missing:
        return []
    hints: list[str] = []
    if any(item.startswith("source.") for item in missing):
        hints.append("Run prepare_ux_source with at least one usable screenshot/image or completed capture before generating a report.")
    if any(item.startswith("ux_health_snapshot") or item.startswith("scorecard") or item == "checklist_ratings" for item in missing):
        hints.append("Run audit_ux_surface or quick_scan_ux with complete checklist_ratings for every active checklist item.")
    if any(item.startswith("checklist_ratings") for item in missing):
        hints.append("Each checklist rating needs checklist_item_id, 0-4 rating, rationale, confidence, and evidence_refs or evidence_limits.")
    if "profiles.accepted" in missing:
        hints.append("Remove donor/conversion profile requests from the baseline payload.")
    behavior_fields = {"plain_language_read", "before_using_this_interface", "top_finding", "one_recommendation", "report_readiness_contract"}
    if any(item in behavior_fields or item.startswith("plain_language_read") or item.startswith("before_using_this_interface") or item.startswith("report_readiness_contract") for item in missing):
        hints.append("Resubmit the scored audit payload with report_readiness_contract, plain_language_read, before_using_this_interface, top_finding, and one_recommendation.")
    return hints


def _normalize_redaction_mode(value: str | None) -> str:
    mode = str(value or "none").strip().lower()
    return mode if mode in REDACTION_MODES else "none"


def _redaction_labels(payload: dict[str, Any], sensitive_labels: list[str] | str | None) -> list[str]:
    labels: list[str] = []
    report_options = payload.get("report_options") if isinstance(payload.get("report_options"), dict) else {}
    configured = report_options.get("sensitive_labels") if report_options else None
    for value in (sensitive_labels, configured):
        if value in (None, "", []):
            continue
        if isinstance(value, str):
            labels.append(value)
        elif isinstance(value, list):
            labels.extend(str(item) for item in value if str(item).strip())
    return sorted({label for label in labels if label.strip()}, key=len, reverse=True)


def _redact_text(text: str, *, mode: str, sensitive_labels: list[str] | str | None = None, payload: dict[str, Any] | None = None) -> str:
    redaction_mode = _normalize_redaction_mode(mode)
    if redaction_mode == "none":
        return text
    redacted = text
    redacted = re.sub(r"(?<!\w)/(Users|Volumes)/[^<>\n\r\")|]+", "[local path redacted]", redacted)
    if redaction_mode == "public_safe":
        redacted = re.sub(r"file://[^\s<>\")|]+", "[local file redacted]", redacted, flags=re.IGNORECASE)
        redacted = re.sub(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[0-1])\.\d+\.\d+)[^\s<>\")|]*", "[private url redacted]", redacted, flags=re.IGNORECASE)
        redacted = re.sub(r"(https?://[^\s<>\")|?]+)\?[^\s<>\")|]+", r"\1?[query redacted]", redacted, flags=re.IGNORECASE)
        redacted = re.sub(r"(?i)\b(token|secret|api[_-]?key|password|session|auth)=([^\s<>\")|&]+)", r"\1=[redacted]", redacted)
        redacted = re.sub(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", "[email redacted]", redacted)
        for label in _redaction_labels(payload or {}, sensitive_labels):
            redacted = re.sub(re.escape(label), "[sensitive label redacted]", redacted)
    return redacted


def _redaction_metadata(payload: dict[str, Any], *, mode: str, sensitive_labels: list[str] | str | None = None) -> dict[str, Any]:
    labels = _redaction_labels(payload, sensitive_labels)
    return {
        "schema_version": "uxhc.report_redaction.v1",
        "mode": _normalize_redaction_mode(mode),
        "applies_to": "rendered_artifacts_only",
        "raw_payload_mutated": False,
        "sensitive_label_count": len(labels),
    }


def generate_ux_audit_report(
    payload: dict[str, Any] | None = None,
    *,
    payload_path: str | None = None,
    output_path: str | None = None,
    viewer_path: str | None = None,
    include_viewer: bool = True,
    pdf_path: str | None = None,
    include_pdf: bool = False,
    response_mode: str = "full",
    report_title: str | None = None,
    run_visual_qa: bool = False,
    redaction_mode: str = "none",
    sensitive_labels: list[str] | str | None = None,
) -> dict[str, Any]:
    normalized_response_mode = str(response_mode or "full").strip().lower()
    if normalized_response_mode not in {"full", "compact"}:
        normalized_response_mode = "full"
    visual_qa_status: dict[str, Any] = _visual_qa_status_for_request(bool(run_visual_qa))

    def finalize(result: dict[str, Any]) -> dict[str, Any]:
        trace_payload_path = str(Path(payload_path).expanduser()) if payload_path else None
        return attach_run_summary(
            result,
            "generate_ux_audit_report",
            inputs_summary={
                "payload_path": bool(payload_path),
                "output_path": bool(output_path),
                "include_viewer": bool(include_viewer),
                "include_pdf": bool(include_pdf),
                "response_mode": normalized_response_mode,
                "run_visual_qa": bool(run_visual_qa),
                "redaction_mode": _normalize_redaction_mode(redaction_mode),
                "payload_trace_context": payload_trace_context(payload, payload_path=trace_payload_path),
            },
        )

    if payload is None and payload_path:
        try:
            payload = _load_payload_path(payload_path)
        except Exception as exc:
            return finalize({
                "schema_version": REPORT_SCHEMA_VERSION,
                "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
                "qa_status": "blocked",
                "validation_status": "blocked",
                "validation": {
                    "schema_version": REPORT_SCHEMA_VERSION,
                    "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
                    "qa_status": "blocked",
                    "validation_status": "blocked",
                    "missing_report_fields": ["payload_path"],
                    "blocking_issues": [
                        _issue(
                            code="payload_path_unreadable",
                            field="payload_path",
                            message=f"Could not read payload_path: {exc}",
                            repair="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                        )
                    ],
                    "repair_tasks": [
                        _repair_task(
                            slot="payload_path",
                            issue="payload_path_unreadable",
                            rewrite_prompt="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                            blocking=True,
                        )
                    ],
                    "warnings": [f"Could not read payload_path: {exc}"],
                    "repair_instructions": ["Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux."],
                    "content_slot_limits": CONTENT_SLOT_LIMITS,
                    "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
                    "what_to_resubmit": ["Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux."],
                },
                "blocking_issues": [
                    _issue(
                        code="payload_path_unreadable",
                        field="payload_path",
                        message=f"Could not read payload_path: {exc}",
                        repair="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                    )
                ],
                "repair_tasks": [
                    _repair_task(
                        slot="payload_path",
                        issue="payload_path_unreadable",
                        rewrite_prompt="Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux.",
                        blocking=True,
                    )
                ],
                "repair_instructions": ["Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux."],
                "content_slot_limits": CONTENT_SLOT_LIMITS,
                "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
                "visual_qa_status": visual_qa_status,
                "response_mode": normalized_response_mode,
                "markdown": "",
                "markdown_path": None,
                "viewer_path": None,
                "pdf_path": None,
            })
    payload = payload or {}
    report_options = payload.get("report_options") if isinstance(payload.get("report_options"), dict) else {}
    active_redaction_mode = _normalize_redaction_mode(redaction_mode if redaction_mode != "none" else report_options.get("redaction_mode"))
    redaction = _redaction_metadata(payload, mode=active_redaction_mode, sensitive_labels=sensitive_labels)
    validation = validate_ux_report_payload(payload, payload_path=str(Path(payload_path).expanduser()) if payload_path else None)
    if validation["qa_status"] != "ready":
        return finalize({
            "schema_version": REPORT_SCHEMA_VERSION,
            "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
            "qa_status": "blocked",
            "validation_status": "blocked",
            "validation": validation,
            "blocking_issues": validation.get("blocking_issues", []),
            "repair_tasks": validation.get("repair_tasks", []),
            "repair_instructions": validation.get("repair_instructions", []),
            "content_slot_limits": CONTENT_SLOT_LIMITS,
            "redaction": redaction,
            "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
            "visual_qa_status": visual_qa_status,
            "response_mode": normalized_response_mode,
            "markdown": "",
            "markdown_path": None,
            "viewer_path": None,
            "pdf_path": None,
        })

    if not output_path:
        output_path = str(report_artifact_path(_default_report_id(payload), ".md"))

    markdown = (
        _render_comparison_markdown(payload, report_title=report_title)
        if _is_comparison_payload(payload)
        else _render_markdown(payload, report_title=report_title)
    )
    markdown = _redact_text(markdown, mode=active_redaction_mode, sensitive_labels=sensitive_labels, payload=payload)
    viewer_html: str | None = None
    render_validation: dict[str, Any] = {
        "qa_status": "ready",
        "blocking_issues": [],
        "warnings": [],
    }
    if include_viewer and (viewer_path or output_path):
        viewer_html = (
            _render_comparison_viewer_html(payload, markdown, report_title=report_title)
            if _is_comparison_payload(payload)
            else _render_viewer_html(payload, markdown, report_title=report_title)
        )
        viewer_html = _redact_text(viewer_html, mode=active_redaction_mode, sensitive_labels=sensitive_labels, payload=payload)
        render_validation = _validate_static_html(
            viewer_html,
            human_panel_allowed=_payload_has_human_panel(payload),
            report_type="comparison" if _is_comparison_payload(payload) else "audit",
        )
        if render_validation["qa_status"] != "ready":
            return finalize({
                "schema_version": REPORT_SCHEMA_VERSION,
                "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
                "qa_status": "blocked",
                "validation_status": "blocked",
                "validation": validation,
                "render_validation": render_validation,
                "blocking_issues": render_validation.get("blocking_issues", []),
                "repair_tasks": _repair_tasks(payload, [], render_validation.get("blocking_issues", [])),
                "repair_instructions": [issue["repair_instruction"] for issue in render_validation.get("blocking_issues", [])],
                "content_slot_limits": CONTENT_SLOT_LIMITS,
                "redaction": redaction,
                "host_instruction": REPORT_HARNESS_HOST_INSTRUCTION,
                "visual_qa_status": visual_qa_status,
                "response_mode": normalized_response_mode,
                "markdown": "",
                "markdown_path": None,
                "viewer_path": None,
                "pdf_path": None,
            })
    saved_path: str | None = None
    saved_viewer_path: str | None = None
    saved_pdf_path: str | None = None
    pdf_rendering: dict[str, Any] = {"requested": bool(include_pdf), "renderer": None, "fallback_used": False, "file_size_bytes": None, "page_count_estimate": None}
    if output_path:
        path = Path(output_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(markdown, encoding="utf-8")
        saved_path = str(path)
        if include_viewer and not viewer_path:
            viewer_path = str(path.with_suffix(".html"))
        if include_pdf and not pdf_path:
            pdf_path = str(path.with_suffix(".pdf"))
    if include_viewer and viewer_path:
        viewer = Path(viewer_path).expanduser()
        viewer.parent.mkdir(parents=True, exist_ok=True)
        if viewer_html is None:
            viewer_html = (
                _render_comparison_viewer_html(payload, markdown, report_title=report_title)
                if _is_comparison_payload(payload)
                else _render_viewer_html(payload, markdown, report_title=report_title)
            )
            viewer_html = _redact_text(viewer_html, mode=active_redaction_mode, sensitive_labels=sensitive_labels, payload=payload)
            render_validation = _validate_static_html(
                viewer_html,
                human_panel_allowed=_payload_has_human_panel(payload),
                report_type="comparison" if _is_comparison_payload(payload) else "audit",
            )
        viewer.write_text(viewer_html, encoding="utf-8")
        saved_viewer_path = str(viewer)
    if include_pdf and pdf_path:
        pdf = Path(pdf_path).expanduser()
        pdf.parent.mkdir(parents=True, exist_ok=True)
        pdf_rendering = _render_pdf(markdown, pdf)
        saved_pdf_path = str(pdf)
    if run_visual_qa:
        if not visual_qa_status.get("capability", {}).get("available"):
            pass
        elif saved_viewer_path:
            visual_qa_status = _run_visual_qa(Path(saved_viewer_path))
        else:
            visual_qa_status = {
                "status": "skipped",
                "reason": "No HTML viewer path was generated for visual QA.",
                "browser_handoff_required": False,
            }
    qa_status = "ready_with_warnings" if pdf_rendering.get("fallback_used") else "ready"
    result = {
        "schema_version": REPORT_SCHEMA_VERSION,
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": qa_status,
        "validation_status": "ready",
        "validation": validation,
        "render_validation": render_validation,
        "blocking_issues": [],
        "repair_tasks": [],
        "repair_instructions": [],
        "content_slot_limits": CONTENT_SLOT_LIMITS,
        "redaction": redaction,
        "visual_qa_status": visual_qa_status,
        "markdown": markdown,
        "markdown_path": saved_path,
        "viewer_path": saved_viewer_path,
        "pdf_path": saved_pdf_path,
        "pdf_rendering": pdf_rendering,
        "response_mode": normalized_response_mode,
    }
    if normalized_response_mode == "compact" and (saved_path or saved_viewer_path or saved_pdf_path):
        result.pop("markdown", None)
        result["content_omitted"] = {
            "markdown": True,
            "reason": "response_mode='compact' omits rendered Markdown because artifacts were written to disk.",
            "access": "Open markdown_path or call generate_ux_audit_report with response_mode='full'.",
        }
    return finalize(result)


def _render_markdown(payload: dict[str, Any], *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Audit Report"
    snapshot = payload.get("ux_health_snapshot") or {}
    source = payload.get("source") or {}
    scorecard = payload.get("scorecard") or {}
    findings = payload.get("findings") or []
    heuristic_scores = payload.get("heuristic_scores") or []
    checklist_ratings = payload.get("checklist_ratings") or []
    evidence_limits = payload.get("evidence_limits") or []
    next_steps = payload.get("next_validation_steps") or []
    activity = payload.get("follow_up_activity") or {}
    extended_activities = payload.get("follow_up_activity_extended") or []
    reasoning_flows = payload.get("reasoning_flow_suggestions") or []
    prioritization = payload.get("prioritization_flow") or {}
    bias_advisories = payload.get("evaluator_bias_advisories") or []
    implementation_contract = payload.get("implementation_inspection_contract") or {}
    implementation_summary = payload.get("implementation_evidence_summary") or {}
    human_loop = payload.get("human_loop_host_action") or {}
    hil_compliance = payload.get("hil_compliance") or {}
    hil_report_summary = payload.get("hil_report_summary") or {}
    scope_lock = payload.get("audit_scope_lock") or {}
    active_scope = payload.get("active_scope_summary") or {}

    lines = [
        f"# {title}",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d')}",
        "",
        "## Executive Summary",
        "",
        f"- Platform: {payload.get('platform', '')}",
        f"- Core grade: {scorecard.get('core_grade', '')} ({scorecard.get('core_quality_percentage', '')}%) - {scorecard.get('core_descriptor', '')}",
        f"- Expanded grade: {scorecard.get('expanded_grade') or 'N/A'} ({scorecard.get('expanded_quality_percentage') or 'N/A'}%)",
        f"- Overall label: {snapshot.get('overall_label', '')}",
        f"- Plain-language read: {payload.get('plain_language_read', '')}",
        f"- Before using this interface: {payload.get('before_using_this_interface', '')}",
        f"- Top priority: {snapshot.get('top_priority', '')}",
        f"- One recommendation: {payload.get('one_recommendation', '')}",
        f"- Source status: {source.get('status', '')}",
        f"- Active scope: {active_scope.get('badge', payload.get('active_scope_badge', 'not supplied'))}",
        *[f"- {signal}" for signal in _corpus_top_signals(payload)],
        "",
        "## Heuristic Grade Table",
        "",
        "| Heuristic | Items | Avg Severity | Quality | Grade |",
        "|---|---:|---:|---:|---|",
    ]
    for score in heuristic_scores:
        lines.append(
            f"| {score.get('heuristic_name', score.get('heuristic_id', ''))} | {score.get('active_item_count', '')} | {score.get('average_item_severity', '')} | {score.get('quality_percentage', '')}% | {score.get('letter_grade', '')} |"
        )

    lines.extend(_scope_section_markdown(scope_lock, active_scope))

    lines.extend(["", "## Severity Summary", ""])
    counts = snapshot.get("severity_counts") or {}
    if counts:
        for level in ["4", "3", "2", "1", "0"]:
            lines.append(f"- Severity {level}: {counts.get(level, 0)}")
    else:
        lines.append("- No scored findings.")

    lines.extend(["", "## Top Findings", ""])
    if findings:
        for finding in sorted(findings, key=lambda item: (-item.get("severity", 0), item.get("heuristic_name", "")))[:10]:
            lines.extend(
                [
                    f"### {finding.get('title', 'Untitled finding')}",
                    "",
                    f"- Checklist item: {finding.get('checklist_item_id', '')}",
                    f"- Heuristic: {finding.get('heuristic_name', '')}",
                    f"- Severity: {finding.get('severity', '')} - {finding.get('severity_label', '')}",
                    f"- Evidence: {finding.get('evidence_ref', '')}",
                    f"- Confidence: {finding.get('confidence', '')}",
                    f"- Issue: {finding.get('observed_issue', '')}",
                    f"- Recommendation: {finding.get('recommendation', '')}",
                    f"- Supporting lenses: {_support_lens_names(finding.get('support_lenses') or [])}",
                    "",
                ]
            )
    else:
        lines.append("- No checklist items scored above 0.")

    lines.extend(_owner_triage_markdown(payload))

    lines.extend(["", "## Checklist Issue Ledger", ""])
    lines.extend(["| Item | Rating | Confidence | Evidence | Rationale |", "|---|---:|---|---|---|"])
    for rating in checklist_ratings:
        if float(rating.get("rating", 0)) <= 0:
            continue
        evidence = ", ".join(rating.get("evidence_refs") or [])
        rationale = str(rating.get("rationale") or "").replace("|", "\\|")
        lines.append(f"| {rating.get('checklist_item_id', '')} | {rating.get('rating', '')} | {rating.get('confidence', '')} | {evidence} | {rationale} |")
    lines.extend(["", "## Complete Checklist Scores", ""])
    lines.extend(_checklist_tables_markdown(checklist_ratings, heuristic_scores))

    lines.extend(_evidence_limits_markdown(evidence_limits))

    lines.extend(_corpus_advisories_markdown(payload))

    lines.extend(_evidence_gallery_markdown(payload))

    lines.extend(_evidence_appendix_markdown(payload))

    lines.extend(_support_lenses_markdown(payload))

    lines.extend(["", "## Follow-Up Activity", ""])
    if activity.get("try_this_next"):
        _append_activity(lines, "Try This Next", activity["try_this_next"])
        if activity.get("solo_activity"):
            _append_activity(lines, "Solo Activity", activity["solo_activity"])
        if activity.get("group_activity"):
            _append_activity(lines, "Group Activity", activity["group_activity"])
        if activity.get("fit_check"):
            lines.append(f"- Fit check: {activity['fit_check']}")
    else:
        lines.append("- No follow-up activity was generated.")

    if extended_activities:
        lines.extend(["", "## Additional Validation Activities", ""])
        for card in extended_activities:
            _append_activity(lines, card.get("title", "Activity"), card)
            if card.get("facilitation_note"):
                lines.append(f"- Facilitation note: {card['facilitation_note']}")

    lines.extend(["", "## Reasoning Flow Suggestions", ""])
    if reasoning_flows:
        for flow in reasoning_flows:
            lines.extend(
                [
                    f"### {flow.get('title', flow.get('flow_id', 'Reasoning flow'))}",
                    "",
                    f"- Heuristic: {flow.get('heuristic_id', '')}",
                    f"- Use when: {flow.get('use_when', '')}",
                    f"- Source: {flow.get('source', '')}",
                    "- Steps:",
                ]
            )
            lines.extend(f"  - {step}" for step in flow.get("steps") or [])
            if flow.get("facilitation_note"):
                lines.append(f"- Facilitation note: {flow['facilitation_note']}")
            enrichment = flow.get("knowledge_atlas_enrichment") or {}
            if enrichment:
                lines.append(f"- Atlas status: {enrichment.get('status', '')} ({enrichment.get('source_entry_id', '')})")
            lines.append("")
    else:
        lines.append("- No reasoning-flow suggestion was needed for this audit.")

    lines.extend(["", "## Evaluator Bias Advisories", ""])
    if bias_advisories:
        for advisory in bias_advisories:
            lines.append(f"- {advisory.get('name', advisory.get('bias_id', 'Bias advisory'))}: {advisory.get('relevance_note', '')} Mitigation: {advisory.get('mitigation', '')}")
    else:
        lines.append("- No evaluator bias advisory was triggered.")

    lines.extend(_implementation_readiness_markdown(payload))

    lines.extend(["", "## Prioritization Flow", ""])
    if prioritization:
        lines.extend(
            [
                f"### {prioritization.get('title', prioritization.get('flow_id', 'Prioritization flow'))}",
                "",
                f"- Use when: {prioritization.get('use_when', '')}",
                f"- Source: {prioritization.get('source_note', prioritization.get('source', ''))}",
                "- Steps:",
            ]
        )
        lines.extend(f"  - {step}" for step in prioritization.get("steps") or [])
    else:
        lines.append("- Not needed because the overall score is above B.")

    lines.extend(["", "## Human Review", ""])
    if hil_report_summary:
        lines.append(f"- HIL used: {hil_report_summary.get('enabled', False)}")
        lines.append(f"- Native question UI status: {hil_report_summary.get('host_question_ui_status', 'unknown')}")
        lines.append(f"- Outcome: {hil_report_summary.get('outcome', 'unknown')}")
        lines.append(f"- Resolved gates: {hil_report_summary.get('resolved_gate_count', 0)}")
        lines.append(f"- Unresolved gates: {hil_report_summary.get('unresolved_gate_count', 0)}")
        if hil_report_summary.get("report_note"):
            lines.append(f"- Note: {hil_report_summary['report_note']}")
    elif human_loop:
        lines.append(f"- Pause required: {human_loop.get('PAUSE_REQUIRED', False)}")
        lines.append(f"- Stage: {human_loop.get('stage', 'none')}")
        if hil_compliance:
            lines.append(f"- Native question UI status: {hil_compliance.get('host_question_ui_status', 'unknown')}")
            lines.append(f"- HIL blocked until native UI: {hil_compliance.get('HIL_BLOCKED_UNTIL_NATIVE_UI', False)}")
            lines.append(f"- Resolved gates: {', '.join(hil_compliance.get('resolved_gate_ids') or []) or 'none'}")
            lines.append(f"- Unresolved gates: {', '.join(hil_compliance.get('unresolved_gate_ids') or []) or 'none'}")
        questions = human_loop.get("questions_for_user") or []
        if questions:
            lines.append("- Questions:")
            for question in questions:
                lines.append(f"  - {question.get('question_id', '')}: {question.get('question', '')}")
    else:
        lines.append("- No human-loop action was supplied.")

    lines.extend(["", "## Recommended Next Validation", ""])
    if next_steps:
        lines.extend(f"- {item}" for item in next_steps)
    else:
        lines.append("- Re-run the audit after fixes or test the highest-risk task with users.")

    lines.extend(
        [
            "",
            "## Scope Note",
            "",
            "This report is a heuristic evaluation artifact. It does not replace usability testing, analytics, accessibility compliance review, or direct user research.",
        ]
    )
    return "\n".join(lines).strip() + "\n"


def _comparison_platform_contexts(payload: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    context = payload.get("platform_report_context") if isinstance(payload.get("platform_report_context"), dict) else {}
    if not context:
        return []
    mode = str(payload.get("comparison_mode") or "").lower()
    labels = _comparison_labels(payload)
    if mode == "desktop_mobile":
        order = [("Desktop", context.get("desktop") or {}), ("Mobile", context.get("mobile") or {})]
    else:
        order = [(labels["before_label"], context.get("baseline") or {}), (labels["after_label"], context.get("candidate") or {})]
    return [(label, ctx) for label, ctx in order if isinstance(ctx, dict) and ctx]


def _comparison_context_markdown(payload: dict[str, Any]) -> list[str]:
    contexts = _comparison_platform_contexts(payload)
    if not contexts:
        return []
    lines = ["", "## Platform Scope And Evidence", ""]
    for label, context in contexts:
        score = context.get("score") or {}
        scope = context.get("active_scope_summary") or {}
        checklist = context.get("checklist_visibility") or {}
        source = context.get("source") or {}
        hil = context.get("hil_report_summary") or {}
        evidence = context.get("evidence_appendix") or {}
        limits = context.get("evidence_limits") or []
        lines.extend(
            [
                f"### {label}",
                "",
                f"- Scope: {scope.get('badge') or 'not supplied'}",
                f"- Score: {score.get('overall_grade') or 'N/A'} ({score.get('overall_quality_percentage') or 'N/A'}%)",
                f"- Checklist visibility: {checklist.get('scored_checklist_item_count', 0)}/{checklist.get('active_checklist_item_count', 0)} scored; {checklist.get('issue_row_count', 0)} issue row(s).",
                f"- Source: {source.get('status', 'unknown')} with {source.get('item_count', 0)} item(s).",
                f"- HIL outcome: {hil.get('outcome', 'not supplied')}; unresolved gates: {hil.get('unresolved_gate_count', 0)}.",
                f"- Evidence refs: {evidence.get('evidence_ref_count', 0)} captured; {', '.join(evidence.get('evidence_refs') or []) or 'none listed'}.",
            ]
        )
        if limits:
            preview = [_evidence_limit_row_text(item)["text"] for item in limits[:3]]
            lines.append(f"- Evidence limits: {'; '.join(text for text in preview if text) or 'none listed'}.")
        lines.append("")
    return lines


def _comparison_evidence_appendix_markdown(payload: dict[str, Any]) -> list[str]:
    contexts = _comparison_platform_contexts(payload)
    rows: list[str] = []
    for label, context in contexts:
        evidence = context.get("evidence_appendix") or {}
        refs = evidence.get("evidence_refs") or []
        if refs:
            rows.append(f"| {label} | {evidence.get('evidence_ref_count', len(refs))} | {', '.join(str(ref) for ref in refs)} |")
    if not rows:
        return []
    return ["", "## Evidence Appendix", "", "| Platform | Evidence refs | Refs shown |", "|---|---:|---|", *rows]


def _comparison_context_html(payload: dict[str, Any]) -> str:
    contexts = _comparison_platform_contexts(payload)
    if not contexts:
        return ""
    cards: list[str] = []
    for label, context in contexts:
        score = context.get("score") or {}
        scope = context.get("active_scope_summary") or {}
        checklist = context.get("checklist_visibility") or {}
        source = context.get("source") or {}
        hil = context.get("hil_report_summary") or {}
        evidence = context.get("evidence_appendix") or {}
        cards.append(
            f"""
            <div class="summary-item">
              <div class="label">{escape(label)}</div>
              <div class="value">{escape(str(score.get('overall_grade') or 'N/A'))}</div>
              <p>{escape(str(scope.get('badge') or 'Scope not supplied'))}</p>
              <p>Checklist visibility: {escape(str(checklist.get('scored_checklist_item_count', 0)))}/{escape(str(checklist.get('active_checklist_item_count', 0)))} scored; {escape(str(checklist.get('issue_row_count', 0)))} issue row(s).</p>
              <p>Source: {escape(str(source.get('status', 'unknown')))} with {escape(str(source.get('item_count', 0)))} item(s).</p>
              <p>HIL outcome: {escape(str(hil.get('outcome', 'not supplied')))}; unresolved gates: {escape(str(hil.get('unresolved_gate_count', 0)))}.</p>
              <p>Evidence refs: {escape(str(evidence.get('evidence_ref_count', 0)))}.</p>
            </div>
            """
        )
    return f"""
    <section class="card">
      <h2>Platform Scope And Evidence</h2>
      <div class="summary-grid">{''.join(cards)}</div>
    </section>
    """


def _comparison_evidence_appendix_html(payload: dict[str, Any]) -> str:
    contexts = _comparison_platform_contexts(payload)
    row_html: list[str] = []
    for label, context in contexts:
        evidence = context.get("evidence_appendix") or {}
        refs = evidence.get("evidence_refs") or []
        if refs:
            row_html.append(
                "<tr>"
                f"<td>{escape(label)}</td>"
                f"<td>{escape(str(evidence.get('evidence_ref_count', len(refs))))}</td>"
                f"<td>{escape(', '.join(str(ref) for ref in refs))}</td>"
                "</tr>"
            )
    if not row_html:
        return ""
    return f"""
    <section class="card">
      <h2>Evidence Appendix</h2>
      <table>
        <thead><tr><th>Platform</th><th>Evidence refs</th><th>Refs shown</th></tr></thead>
        <tbody>{''.join(row_html)}</tbody>
      </table>
    </section>
    """


def _render_comparison_markdown(payload: dict[str, Any], *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Comparison Report"
    summary = payload.get("summary") or {}
    deltas = payload.get("grade_deltas") or {}
    comparison_labels = _comparison_labels(payload)
    lines = [
        f"# {title}",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d')}",
        "",
        "## Comparison Summary",
        "",
        f"- {comparison_labels['before_label']}: {payload.get('baseline_label', '')}",
        f"- {comparison_labels['after_label']}: {payload.get('candidate_label', '')}",
        f"- Comparison mode: {payload.get('comparison_mode', '')}",
        f"- Matching strategy: {payload.get('matching_strategy', '')}",
        f"- Fixed findings: {summary.get('fixed_count', 0)}",
        f"- New findings: {summary.get('new_count', 0)}",
        f"- Unresolved findings: {summary.get('unresolved_count', 0)}",
        f"- Severity-changed findings: {summary.get('severity_changed_count', 0)}",
        f"- Overall quality delta: {deltas.get('overall_quality_delta', 'N/A')}",
    ]
    lines.extend(_comparison_context_markdown(payload))
    lines.extend(["", "## Findings Delta", ""])
    sections = [
        ("Fixed", payload.get("fixed_findings") or []),
        ("New", payload.get("new_findings") or []),
        ("Unresolved", [item.get("candidate") or item for item in payload.get("unresolved_findings") or []]),
        ("Severity Changed", payload.get("severity_changed_findings") or []),
    ]
    for label, rows in sections:
        lines.extend([f"### {label}", ""])
        if not rows:
            lines.append("- None")
            lines.append("")
            continue
        lines.extend(["| Item | Heuristic | Severity | Evidence | Recommendation |", "|---|---|---:|---|---|"])
        for row in rows[:20]:
            record = row.get("candidate") or row.get("baseline") or row
            recommendation = str(record.get("recommendation") or record.get("title") or "").replace("|", "\\|")
            evidence = str(record.get("evidence_ref") or "").replace("|", "\\|")
            lines.append(f"| {record.get('checklist_item_id', '')} | {record.get('heuristic_id', '')} | {record.get('severity', '')} | {evidence} | {recommendation} |")
        lines.append("")
    lines.extend(
        [
            "## Evidence Limits",
            "",
        ]
    )
    limits = payload.get("evidence_limits") or []
    if limits:
        lines.extend(f"- {item}" for item in limits)
    else:
        lines.append("- No comparison-specific evidence limits were recorded.")
    lines.extend(_comparison_evidence_appendix_markdown(payload))
    lines.extend(
        [
            "",
            "## Comparison Next Action",
            "",
            f"- {payload.get('next_action', '')}",
            "",
            "## Scope Note",
            "",
            "This comparison report classifies changes between two UXHC audit payloads. It does not replace a fresh heuristic audit after material interface changes.",
        ]
    )
    return "\n".join(lines).strip() + "\n"


def _render_comparison_viewer_html(payload: dict[str, Any], markdown: str, *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Comparison Report"
    summary = payload.get("summary") or {}
    deltas = payload.get("grade_deltas") or {}
    comparison_labels = _comparison_labels(payload)

    def delta_table(label: str, rows: list[Any]) -> str:
        if not rows:
            body = "<tr><td colspan=\"5\">None</td></tr>"
        else:
            row_html = []
            for row in rows[:20]:
                record = row.get("candidate") or row.get("baseline") or row
                row_html.append(
                    "<tr>"
                    f"<td>{escape(str(record.get('checklist_item_id', '')))}</td>"
                    f"<td>{escape(str(record.get('heuristic_id', '')))}</td>"
                    f"<td>{escape(str(record.get('severity', '')))}</td>"
                    f"<td>{escape(str(record.get('evidence_ref', '')))}</td>"
                    f"<td>{escape(str(record.get('recommendation') or record.get('title') or ''))}</td>"
                    "</tr>"
                )
            body = "".join(row_html)
        return f"""
        <section class="card">
          <h2>{escape(label)}</h2>
          <table>
            <thead><tr><th>Item</th><th>Heuristic</th><th>Severity</th><th>Evidence</th><th>Recommendation</th></tr></thead>
            <tbody>{body}</tbody>
          </table>
        </section>
        """

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)}</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    :root {{ color-scheme: light; --uxhc-green: #0d6e6e; --ink: #24292e; --muted: #6a737d; --line: #e1e4e8; --soft-line: #f0f0f0; --bg: #f5f6fa; --panel: #ffffff; }}
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--bg); color: var(--ink); line-height: 1.6; }}
    .header {{ background: var(--uxhc-green); color: #ffffff; padding: 40px 48px; }}
    .header h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
    .header .meta {{ font-size: 14px; opacity: 0.9; }}
    .container {{ max-width: 1100px; margin: 0 auto; padding: 32px 24px; }}
    .card {{ background: var(--panel); border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); border: 1px solid var(--line); padding: 28px; margin-bottom: 24px; }}
    .card h2 {{ font-size: 18px; font-weight: 700; margin-bottom: 16px; color: var(--uxhc-green); border-bottom: 2px solid var(--line); padding-bottom: 10px; }}
    .summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; }}
    .summary-item {{ border: 1px solid var(--line); border-radius: 8px; padding: 14px; background: #f6f8fa; }}
    .summary-item .value {{ font-size: 26px; font-weight: 800; }}
    .summary-item .label {{ font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); }}
    .summary-item p {{ font-size: 12px; margin-top: 6px; color: var(--muted); }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }}
    th {{ text-align: left; padding: 10px 12px; background: #f6f8fa; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); border-bottom: 2px solid var(--line); }}
    td {{ padding: 10px 12px; border-bottom: 1px solid var(--soft-line); font-size: 13px; vertical-align: top; }}
    footer {{ background: var(--ink); color: #8b949e; text-align: center; padding: 24px; font-size: 12px; margin-top: 48px; }}
    @media (max-width: 700px) {{ .header {{ padding: 32px 24px; }} .container {{ padding: 24px 16px; }} table {{ display: block; overflow-x: auto; }} }}
  </style>
</head>
<body>
  <header class="header">
    <h1>{escape(title)}</h1>
    <div class="meta">{escape(comparison_labels['meta'])} - UXHC static comparison report</div>
  </header>
  <main class="container">
    <section class="card">
      <h2>Comparison Summary</h2>
      <div class="summary-grid">
        <div class="summary-item"><div class="value">{escape(str(summary.get('fixed_count', 0)))}</div><div class="label">Fixed</div></div>
        <div class="summary-item"><div class="value">{escape(str(summary.get('new_count', 0)))}</div><div class="label">New</div></div>
        <div class="summary-item"><div class="value">{escape(str(summary.get('unresolved_count', 0)))}</div><div class="label">Unresolved</div></div>
        <div class="summary-item"><div class="value">{escape(str(summary.get('severity_changed_count', 0)))}</div><div class="label">Severity Changed</div></div>
        <div class="summary-item"><div class="value">{escape(str(deltas.get('overall_quality_delta', 'N/A')))}</div><div class="label">Overall Delta</div></div>
      </div>
    </section>
    {_comparison_context_html(payload)}
    <section class="card">
      <h2>Findings Delta</h2>
      <p>{escape(comparison_labels['delta_copy'])}</p>
    </section>
    {delta_table('Fixed Findings', payload.get('fixed_findings') or [])}
    {delta_table('New Findings', payload.get('new_findings') or [])}
    {delta_table('Unresolved Findings', [item.get('candidate') or item for item in payload.get('unresolved_findings') or []])}
    {delta_table('Severity-Changed Findings', payload.get('severity_changed_findings') or [])}
    {_comparison_evidence_appendix_html(payload)}
    <section class="card">
      <h2>Comparison Next Action</h2>
      <p>{escape(str(payload.get('next_action', '')))}</p>
    </section>
  </main>
  <footer>UX Heuristic Compass - static one-page comparison report - no links, scripts, or external assets.</footer>
</body>
</html>
"""


def _scope_section_markdown(scope_lock: dict[str, Any], active_scope: dict[str, Any] | None = None) -> list[str]:
    if not scope_lock:
        return []
    active_scope = active_scope or {}
    omitted = scope_lock.get("omitted_optional_profiles") or []
    scored = scope_lock.get("scored_optional_profiles") or []
    scored_labels = [f"{item.get('profile')} ({item.get('heuristic_id')})" for item in scored]
    lines = [
        "",
        "## Audit Scope and Omitted Profiles",
        "",
        f"- Active scope: {active_scope.get('badge', 'not supplied')}",
        f"- Scope status: {scope_lock.get('status', '')}",
        f"- Optional profile mode: {scope_lock.get('optional_profile_mode', '')}",
        f"- Full advanced requested: {scope_lock.get('full_advanced_requested', False)}",
        f"- Scored optional profiles: {', '.join(scored_labels) or 'none'}",
    ]
    if omitted:
        lines.append("- Omitted optional profiles:")
        for item in omitted:
            lines.append(f"  - {item.get('profile')} ({item.get('heuristic_id')}): {item.get('heuristic_name')}")
        lines.append(f"- Rerun guidance: {scope_lock.get('rerun_guidance', '')}")
    else:
        lines.append("- Omitted optional profiles: none")
    return lines


def _evidence_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    source = payload.get("source") or {}
    graph = payload.get("evidence_graph") or source.get("evidence_graph") or {}
    items = {str(item.get("item_id")): item for item in source.get("items") or []}
    rows: list[dict[str, Any]] = []
    for ref in source.get("evidence_refs") or []:
        item_id = str(ref.get("item_id") or ref.get("evidence_ref") or "")
        item = items.get(item_id, {})
        rows.append(
            {
                "evidence_ref": ref.get("evidence_ref") or item_id,
                "label": ref.get("label") or item.get("state_label") or item.get("url") or item.get("input_path") or "",
                "source_type": ref.get("source_type") or item.get("source_type") or "",
                "quality": ref.get("quality") or item.get("quality") or "",
                "state_label": item.get("state_label") or ref.get("state_label") or "",
                "screenshot_path": item.get("screenshot_path") or "",
                "input_path": item.get("input_path") or "",
                "url": item.get("url") or "",
                "page_title": item.get("page_title") or "",
                "capture_metadata_path": item.get("capture_metadata_path") or "",
                "parent_ref": ref.get("parent_ref") or "",
                "bounds": ref.get("bounds") or "",
                "note": ref.get("note") or ref.get("notes") or "",
            }
        )
    known_refs = {str(row.get("evidence_ref")) for row in rows}
    for node in graph.get("nodes") or []:
        ref = str(node.get("evidence_ref") or "")
        if not ref or ref in known_refs:
            continue
        metadata = node.get("metadata") if isinstance(node.get("metadata"), dict) else {}
        rows.append(
            {
                "evidence_ref": ref,
                "label": node.get("label") or node.get("text") or "",
                "source_type": node.get("node_type") or "",
                "quality": node.get("quality") or "",
                "state_label": metadata.get("state_label") or "",
                "screenshot_path": node.get("path") or "",
                "input_path": node.get("path") or "",
                "url": node.get("url") or "",
                "page_title": metadata.get("page_title") or node.get("label") or "",
                "capture_metadata_path": metadata.get("capture_metadata_path") or "",
                "parent_ref": node.get("parent_ref") or "",
                "bounds": node.get("bounds") or metadata.get("bounds") or "",
                "note": node.get("note") or metadata.get("note") or metadata.get("notes") or "",
            }
        )
    return rows


def _bounds_note_text(row: dict[str, Any]) -> str:
    parts: list[str] = []
    bounds = row.get("bounds")
    if isinstance(bounds, dict) and bounds:
        ordered = ", ".join(f"{key}={bounds[key]}" for key in ("x", "y", "width", "height") if bounds.get(key) not in (None, "", []))
        if ordered:
            parts.append(ordered)
    elif bounds not in (None, "", []):
        parts.append(str(bounds))
    if row.get("note"):
        parts.append(str(row["note"]))
    return "; ".join(parts)


def _gallery_enabled(payload: dict[str, Any]) -> bool:
    options = payload.get("report_options") if isinstance(payload.get("report_options"), dict) else {}
    return options.get("include_evidence_gallery", True) is not False


def _finding_evidence_refs(finding: dict[str, Any]) -> list[str]:
    refs: list[str] = []
    raw_refs = finding.get("evidence_refs") or []
    if isinstance(raw_refs, str):
        refs.extend([raw_refs])
    elif isinstance(raw_refs, list):
        refs.extend(str(item) for item in raw_refs if item)
    if finding.get("evidence_ref"):
        refs.append(str(finding["evidence_ref"]))
    seen: set[str] = set()
    unique: list[str] = []
    for ref in refs:
        if ref and ref not in seen:
            seen.add(ref)
            unique.append(ref)
    return unique


def _evidence_gallery_groups(payload: dict[str, Any]) -> list[dict[str, Any]]:
    if not _gallery_enabled(payload):
        return []
    rows = _evidence_rows(payload)
    if not rows:
        return []
    rows_by_ref = {str(row.get("evidence_ref")): row for row in rows if row.get("evidence_ref")}
    groups: list[dict[str, Any]] = []
    used_refs: set[str] = set()
    remaining_budget = EVIDENCE_GALLERY_REF_LIMIT
    findings = sorted(payload.get("findings") or [], key=lambda item: (-int(float(item.get("severity") or 0)), str(item.get("title") or "")))
    for finding in findings[:EVIDENCE_GALLERY_FINDING_LIMIT]:
        refs = [ref for ref in _finding_evidence_refs(finding) if ref in rows_by_ref and ref not in used_refs]
        if not refs:
            continue
        selected_refs = refs[:remaining_budget]
        if not selected_refs:
            break
        used_refs.update(selected_refs)
        remaining_budget -= len(selected_refs)
        groups.append(
            {
                "title": finding.get("title") or finding.get("checklist_item_id") or "Finding",
                "linked_finding": f"{finding.get('heuristic_id', '')} / {finding.get('checklist_item_id', '')}".strip(" /"),
                "rows": [rows_by_ref[ref] for ref in selected_refs],
            }
        )
        if remaining_budget <= 0:
            break
    if remaining_budget > 0:
        unlinked = [row for row in rows if str(row.get("evidence_ref")) not in used_refs][:remaining_budget]
        if unlinked:
            groups.append({"title": "Additional Evidence", "linked_finding": "not linked to a top finding", "rows": unlinked})
    return groups


def _evidence_gallery_row_text(row: dict[str, Any]) -> str:
    path = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "")
    bits = [
        f"ref {row.get('evidence_ref', '')}",
        f"parent {row.get('parent_ref', '')}" if row.get("parent_ref") else "",
        f"type {row.get('source_type', '')}" if row.get("source_type") else "",
        f"quality {row.get('quality', '')}" if row.get("quality") else "",
        f"state {row.get('state_label', '')}" if row.get("state_label") else "",
        f"label {row.get('page_title') or row.get('label')}" if row.get("page_title") or row.get("label") else "",
        f"path {path}" if path else "",
        f"metadata {row.get('capture_metadata_path')}" if row.get("capture_metadata_path") else "",
        f"bounds/notes {_bounds_note_text(row)}" if _bounds_note_text(row) else "",
    ]
    return "; ".join(bit for bit in bits if bit)


def _evidence_gallery_markdown(payload: dict[str, Any]) -> list[str]:
    groups = _evidence_gallery_groups(payload)
    if not groups:
        return []
    lines = [
        "",
        "## Evidence Gallery",
        "",
        f"- Compact traceability view capped at {EVIDENCE_GALLERY_REF_LIMIT} evidence refs. Full detail remains in the Evidence Appendix.",
    ]
    for group in groups:
        lines.extend(["", f"### {group['title']}", "", f"- Linked finding: {group['linked_finding']}"])
        for row in group["rows"]:
            lines.append(f"- {_evidence_gallery_row_text(row)}")
    return lines


def _evidence_appendix_markdown(payload: dict[str, Any]) -> list[str]:
    rows = _evidence_rows(payload)
    lines = ["", "## Evidence Appendix", ""]
    if not rows:
        lines.append("- No evidence references were supplied.")
        return lines
    lines.extend(["| Evidence ref | Parent | Source type | Quality | Label/title | Bounds/notes | Screenshot | Metadata |", "|---|---|---|---|---|---|---|---|"])
    for row in rows:
        label = str(row.get("page_title") or row.get("label") or "").replace("|", "\\|")
        bounds = _bounds_note_text(row).replace("|", "\\|")
        screenshot = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "").replace("|", "\\|")
        metadata = str(row.get("capture_metadata_path") or "").replace("|", "\\|")
        lines.append(f"| {row.get('evidence_ref', '')} | {row.get('parent_ref', '')} | {row.get('source_type', '')} | {row.get('quality', '')} | {label} | {bounds} | {screenshot} | {metadata} |")
    return lines


def _owner_role_for_finding(finding: dict[str, Any]) -> tuple[str, str]:
    triage = finding.get("triage") if isinstance(finding.get("triage"), dict) else {}
    supplied = finding.get("owner_role") or finding.get("owner") or triage.get("owner_role")
    supplied_text = str(supplied or "").strip().title()
    if supplied_text in OWNER_ROLES:
        role = supplied_text
    elif str(finding.get("confidence") or "").lower() in {"low", "unknown"} or finding.get("evidence_limits"):
        role = "Research"
    else:
        heuristic_id = str(finding.get("heuristic_id") or "").lower()
        if heuristic_id in {"h08", "h12", "h14"}:
            role = "Designer"
        elif heuristic_id in {"h01", "h03", "h05", "h07", "h09", "h11"}:
            role = "Engineer"
        elif heuristic_id in {"h02", "h04", "h06", "h10", "h13"}:
            role = "Product"
        else:
            role = "Research"
    return role, f"role-{role.lower()}"


def _triage_row(finding: dict[str, Any]) -> dict[str, Any]:
    triage = finding.get("triage") if isinstance(finding.get("triage"), dict) else {}
    role, role_class = _owner_role_for_finding(finding)
    severity = int(float(finding.get("severity") or finding.get("rating") or 0))
    return {
        "owner_role": role,
        "role_class": role_class,
        "linked_finding": f"{finding.get('heuristic_id', '')} / {finding.get('checklist_item_id', '')}".strip(" /"),
        "next_action": triage.get("next_action") or finding.get("recommendation") or finding.get("title") or "Review this finding.",
        "impact": triage.get("impact") or finding.get("user_impact") or ("High" if severity >= 3 else "Medium" if severity == 2 else "Low"),
        "effort": triage.get("effort") or finding.get("effort") or ("Low-Medium" if severity >= 3 else "Low"),
        "confidence": triage.get("confidence") or finding.get("confidence") or "",
        "supporting_roles": triage.get("supporting_roles") or ("Research" if role != "Research" and str(finding.get("confidence") or "").lower() in {"low", "unknown"} else ""),
    }


def _owner_triage_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    findings = [finding for finding in payload.get("findings") or [] if int(float(finding.get("severity") or 0)) >= 1]
    return [_triage_row(finding) for finding in findings[:10]]


def _owner_triage_markdown(payload: dict[str, Any]) -> list[str]:
    rows = _owner_triage_rows(payload)
    lines = ["", "## Owner-Role Triage Matrix", ""]
    if not rows:
        lines.append("- No owner-role triage was needed because no checklist items scored above 0.")
        return lines
    lines.extend(["| Owner | Linked finding | Next action | Impact | Effort | Confidence | Supporting roles |", "|---|---|---|---|---|---|---|"])
    for row in rows:
        values = [
            row["owner_role"],
            row["linked_finding"],
            row["next_action"],
            row["impact"],
            row["effort"],
            row["confidence"],
            row["supporting_roles"],
        ]
        lines.append("| " + " | ".join(str(value).replace("|", "\\|") for value in values) + " |")
    return lines


def _implementation_readiness_markdown(payload: dict[str, Any]) -> list[str]:
    implementation_contract = payload.get("implementation_inspection_contract") or {}
    implementation_summary = payload.get("implementation_evidence_summary") or {}
    if not implementation_contract and not implementation_summary:
        return []
    lines = ["", "## Implementation Readiness Advisory", ""]
    lines.append("- Advisory role: support-only implementation evidence; it does not change checklist ratings or score authority.")
    if implementation_contract:
        lines.append(f"- Status: {implementation_contract.get('status', '')}")
        lines.append(f"- Route: {implementation_contract.get('route_id', '')}")
        lines.append(f"- Harness: {implementation_contract.get('ai_coding_harness', '')}")
        lines.append(f"- Purpose: {implementation_contract.get('purpose', '')}")
        lines.append(f"- Score policy: {(implementation_contract.get('external_result_policy') or {}).get('score_policy', '')}")
    if implementation_summary:
        lines.append(f"- Evidence summary status: {implementation_summary.get('status', '')}")
        if implementation_summary.get("score_policy"):
            lines.append(f"- Evidence score policy: {implementation_summary['score_policy']}")
        heuristics = ", ".join(implementation_summary.get("likely_affected_heuristics") or [])
        lines.append(f"- Likely affected heuristics: {heuristics or 'none detected'}")
        for source_item in implementation_summary.get("sources") or []:
            dimensions = ", ".join(source_item.get("matched_dimensions") or [])
            lines.append(f"- {source_item.get('source', 'source')}: {dimensions or 'no matched dimensions'} - {source_item.get('summary', '')}")
        if implementation_summary.get("evidence_limit"):
            lines.append(f"- Evidence limit: {implementation_summary['evidence_limit']}")
    else:
        lines.append("- Evidence summary: no implementation evidence was supplied yet.")
    return lines


def _append_activity(lines: list[str], label: str, card: dict[str, Any]) -> None:
    lines.extend(
        [
            f"### {label}: {card.get('title', '')}",
            "",
            f"- Why this fits: {card.get('why_this_fits', '')}",
            f"- Content focus: {card.get('content_focus', '')}",
            f"- Thinking focus: {card.get('thinking_focus', '')}",
            f"- Source note: {card.get('source_note', '')}",
            "- Steps:",
        ]
    )
    lines.extend(f"  - {step}" for step in card.get("steps") or [])
    lines.append("")


def _checklist_tables_markdown(checklist_ratings: list[dict[str, Any]], heuristic_scores: list[dict[str, Any]]) -> list[str]:
    if not checklist_ratings:
        return ["- No checklist ratings were supplied."]
    names = {str(score.get("heuristic_id")): str(score.get("heuristic_name") or score.get("heuristic_id")) for score in heuristic_scores}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rating in checklist_ratings:
        grouped.setdefault(str(rating.get("heuristic_id") or "unknown"), []).append(rating)
    lines: list[str] = []
    for heuristic_id, rows in sorted(grouped.items()):
        title = names.get(heuristic_id, heuristic_id)
        lines.extend(
            [
                f"<details>",
                f"<summary>{escape(title)} ({heuristic_id}) - {len(rows)} checklist items</summary>",
                "",
                "| Item | Checklist text | Score | Confidence | Severity basis | Evidence | Rationale |",
                "|---|---|---:|---|---|---|---|",
            ]
        )
        for row in rows:
            evidence = ", ".join(str(item) for item in row.get("evidence_refs") or [])
            severity_basis = _severity_basis_text(row.get("severity_basis") or {})
            text = str(row.get("checklist_text") or "").replace("|", "\\|")
            rationale = str(row.get("rationale") or "").replace("|", "\\|")
            lines.append(
                f"| {row.get('checklist_item_id', '')} | {text} | {row.get('rating', '')} | {row.get('confidence', '')} | {severity_basis} | {evidence} | {rationale} |"
            )
        lines.extend(["", "</details>", ""])
    return lines


def _checklist_tables_html(payload: dict[str, Any]) -> str:
    checklist_ratings = payload.get("checklist_ratings") or []
    heuristic_scores = payload.get("heuristic_scores") or []
    if not checklist_ratings:
        return "<p>No checklist ratings were supplied.</p>"
    names = {str(score.get("heuristic_id")): str(score.get("heuristic_name") or score.get("heuristic_id")) for score in heuristic_scores}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rating in checklist_ratings:
        grouped.setdefault(str(rating.get("heuristic_id") or "unknown"), []).append(rating)
    blocks: list[str] = []
    for heuristic_id, rows in sorted(grouped.items()):
        row_html = []
        for row in rows:
            evidence = ", ".join(str(item) for item in row.get("evidence_refs") or [])
            rating_value = float(row.get("rating") or 0)
            state_label = "Passed" if rating_value <= 0 else "Issue"
            if rating_value >= 3:
                state_label = "Major"
            severity_basis = _severity_basis_text(row.get("severity_basis") or {})
            row_html.append(
                f'<tr class="checklist-row checklist-state-{escape(state_label.lower())}">'
                f"<td>{escape(str(row.get('checklist_item_id', '')))}</td>"
                f"<td>{escape(str(row.get('checklist_text', '')))}</td>"
                f"<td><span class=\"score-pill severity-{int(round(rating_value))}\">{escape(str(row.get('rating', '')))}</span></td>"
                f"<td>{escape(state_label)}</td>"
                f"<td>{escape(str(row.get('confidence', '')))}</td>"
                f"<td>{escape(severity_basis)}</td>"
                f"<td>{escape(evidence)}</td>"
                f"<td>{escape(str(row.get('rationale', '')))}</td>"
                "</tr>"
            )
        blocks.append(
            f"""
            <details class="checklist-table">
              <summary>{escape(names.get(heuristic_id, heuristic_id))} ({escape(heuristic_id)}) - {len(rows)} checklist items</summary>
              <table>
                <thead><tr><th>Item</th><th>Checklist text</th><th>Score</th><th>Status</th><th>Confidence</th><th>Severity basis</th><th>Evidence</th><th>Rationale</th></tr></thead>
                <tbody>{''.join(row_html)}</tbody>
              </table>
            </details>
            """
        )
    legend = """
    <p class="section-intro">All checklist rows are shown. Use the Score and Status columns to scan Passed, Issue, and Major rows without JavaScript filters.</p>
    """
    return legend + "\n".join(blocks)


def _severity_basis_text(value: dict[str, Any]) -> str:
    if not isinstance(value, dict) or not value:
        return ""
    ordered = ["impact", "frequency", "persistence", "scope", "confidence", "evidence_strength"]
    return "; ".join(f"{key}: {value[key]}" for key in ordered if value.get(key) not in (None, "", []))


def _scope_section_html(scope_lock: dict[str, Any], active_scope: dict[str, Any] | None = None) -> str:
    if not scope_lock:
        return ""
    active_scope = active_scope or {}
    omitted = scope_lock.get("omitted_optional_profiles") or []
    scored = scope_lock.get("scored_optional_profiles") or []
    scored_text = ", ".join(f"{item.get('profile')} ({item.get('heuristic_id')})" for item in scored) or "none"
    omitted_items = "".join(f"<li>{escape(str(item.get('profile')))} ({escape(str(item.get('heuristic_id')))}): {escape(str(item.get('heuristic_name')))}</li>" for item in omitted)
    omitted_html = f"<ul>{omitted_items}</ul>" if omitted_items else "<p>None</p>"
    return f"""
    <section class="scope-lock">
      <h2>Audit Scope and Omitted Profiles</h2>
      <p><strong>Active scope:</strong> {escape(str(active_scope.get('badge') or 'not supplied'))}</p>
      <p><strong>Status:</strong> {escape(str(scope_lock.get('status', '')))}</p>
      <p><strong>Optional profile mode:</strong> {escape(str(scope_lock.get('optional_profile_mode', '')))}</p>
      <p><strong>Scored optional profiles:</strong> {escape(scored_text)}</p>
      <p><strong>Omitted optional profiles:</strong></p>
      {omitted_html}
      <p>{escape(str(scope_lock.get('rerun_guidance', '')))}</p>
    </section>
    """


def _evidence_appendix_html(payload: dict[str, Any]) -> str:
    rows = _evidence_rows(payload)
    if not rows:
        return "<section><h2>Evidence Appendix</h2><p>No evidence references were supplied.</p></section>"
    row_html = []
    for row in rows:
        screenshot = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "")
        metadata = str(row.get("capture_metadata_path") or "")
        row_html.append(
            "<tr>"
            f"<td>{escape(str(row.get('evidence_ref', '')))}</td>"
            f"<td>{escape(str(row.get('parent_ref', '')))}</td>"
            f"<td>{escape(str(row.get('source_type', '')))}</td>"
            f"<td>{escape(str(row.get('quality', '')))}</td>"
            f"<td>{escape(str(row.get('page_title') or row.get('label') or ''))}</td>"
            f"<td>{escape(_bounds_note_text(row))}</td>"
            f"<td>{escape(screenshot)}</td>"
            f"<td>{escape(metadata)}</td>"
            "</tr>"
        )
    return f"""
    <section>
      <h2>Evidence Appendix</h2>
      <table>
        <thead><tr><th>Evidence ref</th><th>Parent</th><th>Source type</th><th>Quality</th><th>Label/title</th><th>Bounds/notes</th><th>Screenshot/source</th><th>Metadata</th></tr></thead>
        <tbody>{''.join(row_html)}</tbody>
      </table>
    </section>
    """


def _evidence_gallery_html(payload: dict[str, Any]) -> str:
    groups = _evidence_gallery_groups(payload)
    if not groups:
        return ""
    group_html: list[str] = []
    for group in groups:
        row_cards: list[str] = []
        for row in group["rows"]:
            source_path = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "")
            metadata = str(row.get("capture_metadata_path") or "")
            row_cards.append(
                f"""
                <div class="evidence-card">
                  <div class="evidence-ref">{escape(str(row.get('evidence_ref', '')))}</div>
                  <div class="evidence-meta">{escape(str(row.get('source_type', '') or 'evidence'))} {escape(str(row.get('quality', '')))}</div>
                  <div class="evidence-label">{escape(str(row.get('page_title') or row.get('label') or row.get('state_label') or 'Evidence item'))}</div>
                  <dl>
                    <dt>Parent/region</dt><dd>{escape(str(row.get('parent_ref') or 'none'))}</dd>
                    <dt>State</dt><dd>{escape(str(row.get('state_label') or 'not supplied'))}</dd>
                    <dt>Source</dt><dd>{escape(source_path or 'not supplied')}</dd>
                    <dt>Metadata</dt><dd>{escape(metadata or 'not supplied')}</dd>
                    <dt>Bounds/notes</dt><dd>{escape(_bounds_note_text(row) or 'not supplied')}</dd>
                  </dl>
                </div>
                """
            )
        group_html.append(
            f"""
            <div class="evidence-group">
              <h3>{escape(str(group['title']))}</h3>
              <p class="section-intro">Linked finding: {escape(str(group['linked_finding']))}</p>
              <div class="evidence-gallery-grid">{''.join(row_cards)}</div>
            </div>
            """
        )
    return f"""
    <section class="card evidence-gallery">
      <h2>Evidence Gallery</h2>
      <p class="section-intro">Compact traceability view capped at {EVIDENCE_GALLERY_REF_LIMIT} evidence refs. Full detail remains in the Evidence Appendix.</p>
      {''.join(group_html)}
    </section>
    """


def _support_lens_names(lenses: list[dict[str, Any]]) -> str:
    names = [str(lens.get("name") or lens.get("lens_id") or "") for lens in lenses if lens]
    return ", ".join(name for name in names if name) or "none"


def _support_lens_rows(payload: dict[str, Any], *, limit: int = 10) -> list[dict[str, Any]]:
    suggestions = payload.get("support_lens_suggestions") or []
    if suggestions:
        return list(suggestions)[:limit]
    by_id: dict[str, dict[str, Any]] = {}
    for finding in payload.get("findings") or payload.get("top_findings") or []:
        for lens in finding.get("support_lenses") or []:
            lens_id = str(lens.get("lens_id") or "")
            if lens_id and lens_id not in by_id:
                by_id[lens_id] = dict(lens)
    return list(by_id.values())[:limit]


def _support_lens_applies_text(row: dict[str, Any]) -> str:
    refs = row.get("finding_refs") or []
    if refs:
        values = [
            f"{ref.get('heuristic_id', '')}/{ref.get('checklist_item_id', '')}".strip("/")
            for ref in refs[:3]
        ]
        return ", ".join(value for value in values if value)
    applies_to = row.get("applies_to") or {}
    return f"{applies_to.get('heuristic_id', '')}/{applies_to.get('checklist_item_id', '')}".strip("/")


def _support_lens_policy_row(row: dict[str, Any]) -> dict[str, Any]:
    enriched = corpus_policy_enrichment_for_lens(row)
    return {**enriched, **{key: value for key, value in row.items() if value not in (None, "", [])}}


def _support_lens_display_family(row: dict[str, Any]) -> str:
    row = _support_lens_policy_row(row)
    return str(row.get("display_family") or row.get("source_family") or "UX/UI Support Lens")


def _support_lens_context_text(row: dict[str, Any]) -> str:
    row = _support_lens_policy_row(row)
    phrase = str(row.get("report_phrase") or row.get("audit_use") or "")
    applicability = str(row.get("applicability_note") or "")
    if phrase and applicability:
        return f"{phrase} Applicability: {applicability}"
    return phrase or applicability


def _support_lens_caveat_text(row: dict[str, Any]) -> str:
    row = _support_lens_policy_row(row)
    caveat = str(row.get("caveat") or "")
    evidence_needed = str(row.get("evidence_needed") or "")
    if caveat and evidence_needed:
        return f"{caveat} Evidence needed: {evidence_needed}"
    return caveat or evidence_needed


def _support_lens_guardrails(rows: list[dict[str, Any]], *, limit: int = 5) -> list[str]:
    guardrails: list[str] = []
    seen: set[str] = set()
    for row in rows:
        policy_row = _support_lens_policy_row(row)
        for candidate in (policy_row.get("reporting_guardrail"), policy_row.get("misuse_warning")):
            text = " ".join(str(candidate or "").split())
            key = text.lower()
            if text and key not in seen:
                seen.add(key)
                guardrails.append(text)
            if len(guardrails) >= limit:
                return guardrails
    return guardrails


def _support_lenses_markdown(payload: dict[str, Any]) -> list[str]:
    rows = _support_lens_rows(payload)
    if not rows:
        return []
    lines = ["", "## Supporting UX Laws And Principles", ""]
    lines.append("- Role: support-only explanation. These lenses do not create findings, change 0-4 checklist ratings, or certify compliance.")
    lines.extend(["", "| Lens | Source family | Applies to | Why it matters | Caveat / evidence needed |", "|---|---|---|---|---|"])
    for row in rows:
        lines.append(
            "| "
            + " | ".join(
                str(value or "").replace("|", "\\|")
                for value in [
                    row.get("name") or row.get("lens_id"),
                    _support_lens_display_family(row),
                    _support_lens_applies_text(row),
                    _support_lens_context_text(row),
                    _support_lens_caveat_text(row),
                ]
            )
            + " |"
        )
    warnings = _support_lens_guardrails(rows)
    if warnings:
        lines.extend(["", "Misuse guardrails:"])
        lines.extend(f"- {warning}" for warning in warnings)
    return lines


def _support_lenses_html(payload: dict[str, Any]) -> str:
    rows = _support_lens_rows(payload)
    if not rows:
        return ""
    row_html = []
    for row in rows:
        row_html.append(
            f"""
            <tr>
              <td>{escape(str(row.get('name') or row.get('lens_id') or ''))}</td>
              <td>{escape(_support_lens_display_family(row))}</td>
              <td>{escape(_support_lens_applies_text(row))}</td>
              <td>{escape(_support_lens_context_text(row))}</td>
              <td>{escape(_support_lens_caveat_text(row))}</td>
            </tr>
            """
        )
    warnings = _support_lens_guardrails(rows)
    warning_html = "".join(f"<p>{escape(warning)}</p>" for warning in warnings)
    return f"""
    <section class="card">
      <h2>Supporting UX Laws And Principles</h2>
      <p class="section-intro">Support-only explanation. These lenses do not create findings, change 0-4 checklist ratings, or certify compliance.</p>
      <table>
        <thead><tr><th>Lens</th><th>Source family</th><th>Applies to</th><th>Why it matters</th><th>Caveat / evidence needed</th></tr></thead>
        <tbody>{''.join(row_html)}</tbody>
      </table>
      <div class="evidence-box support-lens-warnings">{warning_html or '<p>No misuse guardrail was supplied.</p>'}</div>
    </section>
    """


def _corpus_advisory_modules(payload: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        dict(module)
        for module in payload.get("corpus_advisory_modules") or []
        if isinstance(module, dict) and module.get("module_type") == "support_advisory"
    ][:3]


def _cultural_context_signal(payload: dict[str, Any]) -> str:
    signal = str(payload.get("cultural_context_signal") or "").strip()
    if signal:
        return signal
    for module in _corpus_advisory_modules(payload):
        if module.get("module_id") == "cultural_context_integrity" and module.get("top_signal"):
            return str(module["top_signal"])
    return ""


def _accessibility_readiness_signal(payload: dict[str, Any]) -> str:
    signal = str(payload.get("accessibility_readiness_signal") or "").strip()
    if signal:
        return signal
    for module in _corpus_advisory_modules(payload):
        if module.get("module_id") == "accessibility_readiness" and module.get("top_signal"):
            return str(module["top_signal"])
    return ""


def _corpus_top_signals(payload: dict[str, Any]) -> list[str]:
    signals: list[str] = []
    for signal in [_accessibility_readiness_signal(payload), _cultural_context_signal(payload)]:
        if signal and signal not in signals:
            signals.append(signal)
    return signals


def _corpus_advisories_markdown(payload: dict[str, Any]) -> list[str]:
    modules = _corpus_advisory_modules(payload)
    if not modules:
        return []
    lines: list[str] = []
    for module in modules:
        title = str(module.get("section_title") or "Support Advisory")
        rows = list(module.get("rows") or [])[:6]
        index_score = module.get("context_integrity_index", module.get("index_score"))
        level_signal = module.get("wcag_level_signal") or module.get("level_signal")
        score_text = "evidence-limited" if index_score in (None, "") else str(index_score)
        lines.extend(["", f"## {title}", ""])
        lines.append("- Role: support-only advisory. This section does not change H01-H14 scores, 0-4 checklist ratings, report readiness, or finding order.")
        if level_signal:
            lines.append(f"- {module.get('level_name', 'Level Signal')}: {level_signal}")
        else:
            lines.append(f"- {module.get('index_name', 'Advisory Index')}: {score_text} - {module.get('index_label', '')}")
        if module.get("top_signal"):
            lines.append(f"- Top signal: {module['top_signal']}")
        if module.get("caveat"):
            lines.append(f"- Caveat: {module['caveat']}")
        if rows:
            lines.extend(["", "| Lens / cue | Applies to | Evidence | Why it matters | Caveat |", "|---|---|---|---|---|"])
            for row in rows:
                applies_to = "/".join(str(value or "") for value in [row.get("heuristic_id"), row.get("checklist_item_id")] if value)
                lines.append(
                    "| "
                    + " | ".join(
                        str(value or "").replace("|", "\\|")
                        for value in [
                            row.get("lens_name") or row.get("title"),
                            applies_to,
                            row.get("evidence_ref"),
                            row.get("why_it_matters"),
                            row.get("caveat"),
                        ]
                    )
                    + " |"
                )
    return lines


def _corpus_advisories_html(payload: dict[str, Any]) -> str:
    modules = _corpus_advisory_modules(payload)
    if not modules:
        return ""
    blocks: list[str] = []
    for module in modules:
        rows = list(module.get("rows") or [])[:6]
        index_score = module.get("context_integrity_index", module.get("index_score"))
        level_signal = module.get("wcag_level_signal") or module.get("level_signal")
        score_text = "evidence-limited" if index_score in (None, "") else str(index_score)
        metric_label = module.get("level_name", "Level Signal") if level_signal else module.get("index_name", "Advisory Index")
        metric_value = str(level_signal) if level_signal else f"{score_text} - {module.get('index_label', '')}"
        row_html = []
        for row in rows:
            applies_to = "/".join(str(value or "") for value in [row.get("heuristic_id"), row.get("checklist_item_id")] if value)
            row_html.append(
                f"""
                <tr>
                  <td>{escape(str(row.get('lens_name') or row.get('title') or ''))}</td>
                  <td>{escape(applies_to)}</td>
                  <td>{escape(str(row.get('evidence_ref') or ''))}</td>
                  <td>{escape(str(row.get('why_it_matters') or ''))}</td>
                  <td>{escape(str(row.get('caveat') or ''))}</td>
                </tr>
                """
            )
        blocks.append(
            f"""
            <section class="card corpus-advisory">
              <h2>{escape(str(module.get('section_title') or 'Support Advisory'))}</h2>
              <p class="section-intro">Support-only advisory. This section does not change H01-H14 scores, 0-4 checklist ratings, report readiness, or finding order.</p>
              <div class="evidence-box">
                <p><strong>{escape(str(metric_label))}:</strong> {escape(str(metric_value))}</p>
                <p><strong>Top signal:</strong> {escape(str(module.get('top_signal') or ''))}</p>
                <p><strong>Caveat:</strong> {escape(str(module.get('caveat') or ''))}</p>
              </div>
              <table>
                <thead><tr><th>Lens / cue</th><th>Applies to</th><th>Evidence</th><th>Why it matters</th><th>Caveat</th></tr></thead>
                <tbody>{''.join(row_html)}</tbody>
              </table>
            </section>
            """
        )
    return "".join(blocks)


def _validate_static_html(html: str, *, human_panel_allowed: bool = False, report_type: str = "audit") -> dict[str, Any]:
    lower = html.lower()
    blocking_issues: list[dict[str, Any]] = []
    for pattern in FORBIDDEN_HTML_PATTERNS:
        if pattern in lower:
            blocking_issues.append(
                _issue(
                    code="forbidden_html_pattern",
                    field="html",
                    message=f"Generated HTML contains forbidden pattern: {pattern}.",
                    repair="Regenerate with the UXHC static no-JS, no-link, no-external-assets renderer.",
                )
            )
    if not human_panel_allowed and any(phrase in lower for phrase in HUMAN_PANEL_PHRASES):
        blocking_issues.append(
            _issue(
                code="human_panel_language_without_data",
                field="html",
                message="Generated HTML contains human-panel language without explicit human-panel payload data.",
                repair="Regenerate the report with AI-only audit language unless human-panel data is present.",
            )
        )
    required_sections = (
        ["Comparison Summary", "Findings Delta", "Comparison Next Action"]
        if report_type == "comparison"
        else ["Plain Language Read", "Heuristic Scorecard", "Findings", "Evidence Limits", "Recommended Next Validation Steps"]
    )
    for section in required_sections:
        if section.lower() not in lower:
            blocking_issues.append(
                _issue(
                    code="missing_required_section",
                    field="html",
                    message=f"Generated HTML is missing required section: {section}.",
                    repair="Regenerate the report through the UXHC renderer so required sections appear in order.",
                )
            )
    return {
        "schema_version": "uxhc.report_html_validation.v1",
        "design_system_version": REPORT_DESIGN_SYSTEM_VERSION,
        "qa_status": "blocked" if blocking_issues else "ready",
        "blocking_issues": blocking_issues,
        "warnings": [],
        "static_html_policy": {
            "one_page": True,
            "links_allowed": False,
            "external_assets_allowed": False,
            "scripts_allowed": False,
        },
    }


def _grade_color(grade: Any, percentage: Any = None) -> str:
    text = str(grade or "").upper()
    try:
        pct = float(percentage)
    except Exception:
        pct = None
    if text.startswith("A") or (pct is not None and pct >= 80):
        return "#22863a"
    if text.startswith("B+") or (pct is not None and pct >= 75):
        return "#5a7f3e"
    if text.startswith("B") or (pct is not None and pct >= 70):
        return "#7a8c3e"
    if text.startswith("C") or (pct is not None and pct >= 55):
        return "#c96a00"
    return "#cb2431"


def _severity_color(severity: Any) -> str:
    try:
        value = int(round(float(severity)))
    except Exception:
        value = 0
    if value >= 3:
        return "#cb2431" if value == 4 else "#c96a00"
    if value == 2:
        return "#b8860b"
    if value == 1:
        return "#5a7f3e"
    return "#6a737d"


def _severity_word(severity: Any) -> str:
    try:
        value = int(round(float(severity)))
    except Exception:
        value = 0
    if value >= 4:
        return "Critical"
    if value == 3:
        return "Major"
    if value == 2:
        return "Moderate"
    if value == 1:
        return "Minor"
    return "Passed"


def _top_finding_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    top = payload.get("top_finding") or {}
    if top.get("status") == "finding":
        return top
    findings = payload.get("findings") or []
    return findings[0] if findings else top


def _next_research_recommendation(payload: dict[str, Any]) -> str:
    next_steps = payload.get("next_validation_steps") or []
    if next_steps:
        return str(next_steps[0])
    activity = payload.get("follow_up_activity") or {}
    try_this = activity.get("try_this_next") or {}
    if try_this.get("title"):
        return f"Run {try_this['title']} against the top finding before treating the report as confirmed user evidence."
    top = _top_finding_from_payload(payload)
    title = top.get("title") or "the top finding"
    return f"Validate {title} with one focused task walkthrough before committing the fix plan."


def _html_paragraphs(items: list[Any]) -> str:
    if not items:
        return "<p>No entries were supplied.</p>"
    return "".join(f"<p>{escape(str(item))}</p>" for item in items)


def _comparison_labels(payload: dict[str, Any]) -> dict[str, str]:
    mode = str(payload.get("comparison_mode") or "").strip().lower()
    baseline = str(payload.get("baseline_label") or "baseline").strip()
    candidate = str(payload.get("candidate_label") or "candidate").strip()
    if mode == "desktop_mobile" or {baseline.lower(), candidate.lower()} & {"desktop", "mobile"}:
        mode_details = payload.get("mode_details") if isinstance(payload.get("mode_details"), dict) else {}
        desktop_label = str(payload.get("desktop_label") or mode_details.get("desktop_label") or baseline or "Desktop").strip()
        mobile_label = str(payload.get("mobile_label") or mode_details.get("mobile_label") or candidate or "Mobile").strip()
        return {
            "before_label": "Desktop",
            "after_label": "Mobile",
            "meta": f"{desktop_label} compared with {mobile_label}",
            "delta_copy": "Matched desktop and mobile checklist items are classified as desktop-only, mobile-only, shared unresolved, or severity changed. Existing comparison fields remain available in the payload.",
        }
    return {
        "before_label": "Baseline",
        "after_label": "Candidate",
        "meta": f"{baseline} compared with {candidate}",
        "delta_copy": "Matched checklist items are classified as fixed, new, unresolved, or severity changed. Existing comparison fields remain available in the payload.",
    }


def _evidence_limit_row_text(item: Any) -> dict[str, str]:
    if not isinstance(item, dict):
        return {
            "checklist_item_id": "",
            "reason": str(item),
            "confidence_impact": "",
            "text": str(item),
        }
    checklist_item_id = str(item.get("checklist_item_id") or item.get("source_id") or "source")
    reason = str(item.get("reason") or item.get("message") or "")
    confidence_impact = str(item.get("confidence_impact") or "").strip()
    suffix = f" ({confidence_impact})" if confidence_impact else ""
    return {
        "checklist_item_id": checklist_item_id,
        "reason": reason,
        "confidence_impact": confidence_impact,
        "text": f"{checklist_item_id}: {reason}{suffix}".strip(),
    }


def _unknown_evidence_ref(reason: str) -> str | None:
    match = re.search(r"evidence_ref ['\"]([^'\"]+)['\"] was not found in the AuditEvidenceGraph", reason)
    return match.group(1) if match else None


def _compact_evidence_limits(limits: list[Any]) -> dict[str, Any]:
    if not limits:
        return {
            "summary_rows": [],
            "visible_rows": [],
            "detail_rows": [],
            "compacted": False,
            "source_note_count": 0,
        }

    unknown_groups: dict[str, dict[str, Any]] = {}
    regular_rows: list[str] = []
    detail_rows: list[str] = []
    source_note_count = 0

    for item in limits:
        row = _evidence_limit_row_text(item)
        text = row["text"]
        if not text:
            continue
        source_note_count += 1
        unknown_ref = _unknown_evidence_ref(row["reason"])
        if unknown_ref:
            group = unknown_groups.setdefault(
                unknown_ref,
                {
                    "count": 0,
                    "checklist_item_ids": [],
                    "confidence_impact": row["confidence_impact"],
                },
            )
            group["count"] += 1
            if row["checklist_item_id"] and row["checklist_item_id"] not in group["checklist_item_ids"]:
                group["checklist_item_ids"].append(row["checklist_item_id"])
            if row["confidence_impact"] and not group["confidence_impact"]:
                group["confidence_impact"] = row["confidence_impact"]
            continue
        regular_rows.append(text)
        detail_rows.append(text)

    summary_rows = list(regular_rows)
    for ref, group in sorted(unknown_groups.items()):
        count = int(group["count"])
        impact = str(group.get("confidence_impact") or "traceability is reduced until the evidence graph includes this ref")
        summary_rows.append(f"{ref} missing across {count} checklist rating{'s' if count != 1 else ''}; {impact}.")
        ids = list(group.get("checklist_item_ids") or [])
        if ids:
            preview = ", ".join(ids[:EVIDENCE_LIMIT_DETAIL_CHECKLIST_PREVIEW_LIMIT])
            hidden_count = max(0, len(ids) - EVIDENCE_LIMIT_DETAIL_CHECKLIST_PREVIEW_LIMIT)
            suffix = f"; plus {hidden_count} more" if hidden_count else ""
            detail_rows.append(f"{ref}: {count} checklist rating{'s' if count != 1 else ''} cite this missing evidence ref. Affected items: {preview}{suffix}.")
        else:
            detail_rows.append(f"{ref}: {count} checklist rating{'s' if count != 1 else ''} cite this missing evidence ref.")

    total_chars = sum(len(row) for row in summary_rows)
    compacted = source_note_count > EVIDENCE_LIMIT_INLINE_ITEM_LIMIT or total_chars > EVIDENCE_LIMIT_INLINE_CHAR_LIMIT
    visible_rows = summary_rows[:EVIDENCE_LIMIT_INLINE_ITEM_LIMIT] if compacted else summary_rows
    if compacted and len(summary_rows) > EVIDENCE_LIMIT_INLINE_ITEM_LIMIT:
        visible_rows.append(f"{len(summary_rows) - EVIDENCE_LIMIT_INLINE_ITEM_LIMIT} additional evidence-limit summary row(s) are collapsed below.")
    return {
        "summary_rows": summary_rows,
        "visible_rows": visible_rows,
        "detail_rows": detail_rows,
        "compacted": compacted,
        "source_note_count": source_note_count,
    }


def _evidence_limits_markdown(limits: list[Any]) -> list[str]:
    rows = ["", "## Evidence Limits", ""]
    compact = _compact_evidence_limits(limits)
    if not compact["summary_rows"]:
        rows.append("- No major evidence limits were recorded.")
        return rows
    rows.extend(f"- {row}" for row in compact["visible_rows"])
    if compact["compacted"]:
        rows.extend(
            [
                "",
                f"<details><summary>Show detailed evidence-limit notes ({compact['source_note_count']} source notes)</summary>",
                "",
            ]
        )
        rows.extend(f"- {row}" for row in compact["detail_rows"])
        rows.extend(["", "</details>"])
    return rows


def _header_meta(payload: dict[str, Any]) -> str:
    scorecard = payload.get("scorecard") or {}
    source = payload.get("source") or {}
    bits = [
        "AI audit",
        str(payload.get("platform") or "").capitalize(),
        f"{len(source.get('items') or [])} source item(s)",
        f"{scorecard.get('active_checklist_item_count') or len(payload.get('checklist_ratings') or [])} checklist items",
    ]
    hil_report_summary = payload.get("hil_report_summary") or {}
    hil = payload.get("hil_compliance") or {}
    hil_status = hil_report_summary.get("host_question_ui_status") or hil.get("host_question_ui_status")
    if hil_report_summary.get("enabled") or hil.get("native_ui_confirmed") or hil_status in {"native_rendered", "fallback_text_used"}:
        bits.append(f"HIL {hil_status or 'used'}")
    return " - ".join(bit for bit in bits if bit)


def _mission_context_html(payload: dict[str, Any]) -> str:
    context = payload.get("audit_context") or {}
    text = (
        context.get("mission_context")
        or context.get("severity_context")
        or context.get("audience_context")
        or "Severity ratings reflect the supplied evidence, user goal, optional-profile scope, and any stated evidence limits. Support flows and activities should never outrank the checklist scorecard."
    )
    return f"""
    <section class="mission-box card">
      <h2>Mission Context</h2>
      <p>{escape(str(text))}</p>
    </section>
    """


def _overall_summary_html(payload: dict[str, Any]) -> str:
    scorecard = payload.get("scorecard") or {}
    grade = scorecard.get("overall_grade") or scorecard.get("core_grade") or ""
    pct = scorecard.get("overall_quality_percentage") or scorecard.get("core_quality_percentage") or ""
    descriptor = scorecard.get("overall_descriptor") or scorecard.get("core_descriptor") or ""
    before = str(payload.get("before_using_this_interface") or "")
    plain_read = str(payload.get("plain_language_read") or "No plain-language read was supplied.")
    signal_cards = []
    for signal in _corpus_top_signals(payload):
        label = "Accessibility Readiness Signal" if signal.startswith("Accessibility Readiness Signal:") else "Cultural Context Signal"
        signal_cards.append(
            f"""
            <div class="research-recommendation corpus-signal">
              <div class="label">{escape(label)}</div>
              <p>{escape(signal)}</p>
            </div>
            """
        )
    corpus_signal_html = "".join(signal_cards)
    return f"""
    <section class="overall-summary" aria-label="Overall audit summary">
      <div class="overall-grade-card">
        <div class="big-grade" style="color:{_grade_color(grade, pct)}">{escape(str(grade))}</div>
        <div class="pct">{escape(str(pct))}%</div>
        <div class="descriptor">{escape(str(descriptor))}</div>
      </div>
      <div class="plain-read">
        <div class="label">Plain Language Read</div>
        <p>{escape(plain_read)}</p>
        <div class="research-recommendation">
          <div class="label">Next Research Recommendation</div>
          <p>{escape(_next_research_recommendation(payload))}</p>
        </div>
        {corpus_signal_html}
        <p class="before">{escape(before)}</p>
      </div>
    </section>
    """


def _top_finding_alert_html(payload: dict[str, Any]) -> str:
    top = _top_finding_from_payload(payload)
    if not top or top.get("status") == "no_scored_findings":
        return """
        <section class="top-finding-alert top-finding-ok">
          <div class="label">Top Finding</div>
          <h3>No checklist items scored above 0</h3>
          <p>Use the evidence limits and validation steps before treating this as a complete usability claim.</p>
        </section>
        """
    title = top.get("title") or "Top UX finding"
    issue = top.get("observed_issue") or top.get("rationale") or top.get("summary") or payload.get("ux_health_snapshot", {}).get("top_priority") or ""
    severity = top.get("severity") or top.get("rating") or ""
    return f"""
    <section class="top-finding-alert">
      <div class="label">{escape(_severity_word(severity))} Finding - Immediate Attention</div>
      <h3>{escape(str(title))}</h3>
      <p>{escape(str(issue))}</p>
    </section>
    """


def _scorecard_html(payload: dict[str, Any]) -> str:
    scores = payload.get("heuristic_scores") or []
    count = len(scores)
    cards = []
    for score in scores:
        grade = score.get("letter_grade") or ""
        pct = score.get("quality_percentage") or ""
        cards.append(
            f"""
            <article class="score-item">
              <div class="grade" style="color:{_grade_color(grade, pct)}">{escape(str(grade))}</div>
              <div class="pct">{escape(str(pct))}% - avg severity {escape(str(score.get('average_item_severity', '')))}</div>
              <div class="name">{escape(str(score.get('heuristic_name') or score.get('heuristic_id') or 'Heuristic'))}</div>
              <div class="desc">{escape(str(score.get('descriptor') or ''))}</div>
            </article>
            """
        )
    return f"""
    <section class="card">
      <h2>Heuristic Scorecard - AI Audit, {count} Heuristics</h2>
      <div class="scorecard-grid">{''.join(cards) or '<p>No heuristic scores were supplied.</p>'}</div>
    </section>
    """


def _findings_html(payload: dict[str, Any]) -> str:
    findings = sorted(payload.get("findings") or [], key=lambda item: (-int(item.get("severity", 0)), item.get("heuristic_name", "")))[:10]
    if not findings:
        return """
        <section class="card">
          <h2>Findings - Prioritized Fix Order</h2>
          <p>No checklist items scored above 0.</p>
        </section>
        """
    blocks = []
    for idx, finding in enumerate(findings, start=1):
        severity = finding.get("severity", 0)
        blocks.append(
            f"""
            <article class="finding" style="border-left-color:{_severity_color(severity)}">
              <div class="finding-header">
                <div class="rank">{idx}</div>
                <div>
                  <div><span class="severity-badge" style="background:{_severity_color(severity)}">{escape(_severity_word(severity))}</span> <span class="heuristic-tag">{escape(str(finding.get('heuristic_name', '')))} - {escape(str(finding.get('checklist_item_id', '')))}</span></div>
                  <h3>{escape(str(finding.get('title', 'Untitled finding')))}</h3>
                </div>
              </div>
              <div class="section"><div class="section-label">Observed Issue</div><div class="section-content">{escape(str(finding.get('observed_issue', '')))}</div></div>
              <div class="section"><div class="section-label">Recommendation</div><div class="section-content">{escape(str(finding.get('recommendation', '')))}</div></div>
              <div class="mission-note">{escape(str(finding.get('user_impact') or 'This finding may increase user friction for the evaluated task.'))}</div>
              <div class="evidence-line">Supporting lenses: {escape(_support_lens_names(finding.get('support_lenses') or []))}</div>
              <div class="evidence-line">Evidence: {escape(str(finding.get('evidence_ref', '')))} - Confidence: {escape(str(finding.get('confidence', '')))}</div>
            </article>
            """
        )
    return f"""
    <section class="card">
      <h2>Findings - Prioritized Fix Order</h2>
      {''.join(blocks)}
    </section>
    """


def _working_well_html(payload: dict[str, Any]) -> str:
    strong = [score for score in payload.get("heuristic_scores") or [] if float(score.get("quality_percentage") or 0) >= 80][:8]
    if not strong:
        return """
        <section class="card">
          <h2>What Is Working Well</h2>
          <p>No heuristic scored at A- or above in this payload. Use this section after fixes to preserve strengths.</p>
        </section>
        """
    items = "".join(
        f"<li>{escape(str(score.get('heuristic_name') or score.get('heuristic_id')))} holds up with {escape(str(score.get('letter_grade')))} ({escape(str(score.get('quality_percentage')))}%).</li>"
        for score in strong
    )
    return f"""
    <section class="card">
      <h2>What Is Working Well</h2>
      <ul class="strengths-list">{items}</ul>
    </section>
    """


def _evidence_limits_html(payload: dict[str, Any]) -> str:
    limits = payload.get("evidence_limits") or []
    compact = _compact_evidence_limits(limits)
    if not compact["summary_rows"]:
        body = "<p>No major evidence limits were recorded.</p>"
    else:
        visible = "".join(f"<li>{escape(str(row))}</li>" for row in compact["visible_rows"])
        body = f"<ul class=\"evidence-limit-list\">{visible}</ul>"
        if compact["compacted"]:
            details = "".join(f"<li>{escape(str(row))}</li>" for row in compact["detail_rows"])
            body += (
                f"<details class=\"evidence-limit-details\">"
                f"<summary>Show detailed evidence-limit notes ({escape(str(compact['source_note_count']))} source notes)</summary>"
                f"<ul>{details}</ul>"
                f"</details>"
            )
    return f"""
    <section class="card">
      <h2>Evidence Limits</h2>
      <div class="evidence-box">{body}</div>
    </section>
    """


def _validation_steps_html(payload: dict[str, Any]) -> str:
    steps = list(payload.get("next_validation_steps") or [])
    if not steps:
        steps = ["Re-run the audit after fixes or test the highest-risk task with users."]
    cards = "".join(
        f"""
        <article class="validation-option">
          <div class="option-title">Validation Step {idx}</div>
          <div class="option-copy">{escape(str(step))}</div>
        </article>
        """
        for idx, step in enumerate(steps[:6], start=1)
    )
    return f"""
    <section class="card">
      <h2>Recommended Next Validation Steps</h2>
      <div class="validation-list">{cards}</div>
    </section>
    """


def _owner_triage_html(payload: dict[str, Any]) -> str:
    rows = _owner_triage_rows(payload)
    if not rows:
        body = "<p>No owner-role triage was needed because no checklist items scored above 0.</p>"
    else:
        row_html = []
        for row in rows:
            row_html.append(
                f"""
                <tr>
                  <td><span class="role-badge {escape(str(row['role_class']))}">{escape(str(row['owner_role']))}</span></td>
                  <td>{escape(str(row['linked_finding']))}</td>
                  <td>{escape(str(row['next_action']))}</td>
                  <td>{escape(str(row['impact']))}</td>
                  <td><span class="effort-pill">{escape(str(row['effort']))}</span></td>
                  <td>{escape(str(row['confidence']))}</td>
                  <td>{escape(str(row['supporting_roles']))}</td>
                </tr>
                """
            )
        body = f"""
        <table class="owner-triage-table">
          <thead><tr><th>Owner</th><th>Linked finding</th><th>Next action</th><th>Impact</th><th>Effort</th><th>Confidence</th><th>Supporting roles</th></tr></thead>
          <tbody>{''.join(row_html)}</tbody>
        </table>
        """
    return f"""
    <section class="card">
      <h2>Owner-Role Triage Matrix</h2>
      {body}
    </section>
    """


def _implementation_readiness_html(payload: dict[str, Any]) -> str:
    implementation_contract = payload.get("implementation_inspection_contract") or {}
    implementation_summary = payload.get("implementation_evidence_summary") or {}
    if not implementation_contract and not implementation_summary:
        return ""
    rows = [
        "Support-only implementation evidence; it does not change checklist ratings or score authority."
    ]
    if implementation_contract:
        rows.extend(
            [
                f"Status: {implementation_contract.get('status', '')}",
                f"Route: {implementation_contract.get('route_id', '')}",
                f"Harness: {implementation_contract.get('ai_coding_harness', '')}",
                f"Purpose: {implementation_contract.get('purpose', '')}",
                f"Score policy: {(implementation_contract.get('external_result_policy') or {}).get('score_policy', '')}",
            ]
        )
    if implementation_summary:
        heuristics = ", ".join(implementation_summary.get("likely_affected_heuristics") or [])
        rows.append(f"Evidence summary status: {implementation_summary.get('status', '')}")
        rows.append(f"Likely affected heuristics: {heuristics or 'none detected'}")
        if implementation_summary.get("score_policy"):
            rows.append(f"Evidence score policy: {implementation_summary['score_policy']}")
        for source_item in implementation_summary.get("sources") or []:
            dimensions = ", ".join(source_item.get("matched_dimensions") or [])
            rows.append(f"{source_item.get('source', 'source')}: {dimensions or 'no matched dimensions'} - {source_item.get('summary', '')}")
        if implementation_summary.get("evidence_limit"):
            rows.append(f"Evidence limit: {implementation_summary['evidence_limit']}")
    return f"""
    <section class="card">
      <h2>Implementation Readiness Advisory</h2>
      <div class="evidence-box">{_html_paragraphs(rows)}</div>
    </section>
    """


def _roadmap_html(payload: dict[str, Any]) -> str:
    findings = sorted(payload.get("findings") or [], key=lambda item: (-int(item.get("severity", 0)), item.get("heuristic_name", "")))[:12]
    if not findings:
        rows = "<tr><td>Later</td><td>Re-run the audit after evidence improves.</td></tr>"
    else:
        row_items = []
        for finding in findings:
            severity = int(finding.get("severity", 0))
            bucket = "Immediate" if severity >= 4 else "Sprint 1" if severity == 3 else "Sprint 2" if severity == 2 else "Sprint 3"
            row_items.append(
                f"<tr><td><span class=\"sprint-badge\" style=\"background:{_severity_color(severity)}\">{escape(bucket)}</span></td><td>{escape(str(finding.get('recommendation') or finding.get('title') or 'Fix finding'))}</td></tr>"
            )
        rows = "".join(row_items)
    return f"""
    <section class="card">
      <h2>Prioritized Fix Roadmap</h2>
      <table class="roadmap-table">
        <thead><tr><th>When</th><th>Recommended action</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </section>
    """


def _micro_solution_role(heuristic_id: str) -> tuple[str, str]:
    if heuristic_id in {"h01", "h03", "h05", "h07", "h09", "h11"}:
        return "Engineer", "role-engineer"
    if heuristic_id in {"h08", "h12", "h14"}:
        return "Designer", "role-designer"
    if heuristic_id in {"h02", "h04", "h06", "h10", "h13"}:
        return "Product", "role-product"
    return "Research", "role-research"


def _micro_solutions_html(payload: dict[str, Any]) -> str:
    findings = [finding for finding in payload.get("findings") or [] if int(finding.get("severity", 0)) >= 1][:6]
    if not findings:
        rows = "<tr><td>Research</td><td>Keep monitoring the current interface.</td><td>No issue finding</td><td>Maintains quality without inventing work.</td><td><span class=\"effort-pill\">Low</span></td></tr>"
    else:
        row_items = []
        for finding in findings:
            triage = _triage_row(finding)
            role = triage["owner_role"]
            role_class = triage["role_class"]
            effort = triage["effort"] if str(triage["effort"]).lower().startswith("low") else "Low-Medium"
            row_items.append(
                f"""
                <tr>
                  <td><span class="role-badge {role_class}">{escape(role)}</span></td>
                  <td>{escape(str(finding.get('recommendation') or finding.get('title') or 'Address the finding.'))}</td>
                  <td>{escape(str(finding.get('heuristic_id', '')))} / {escape(str(finding.get('checklist_item_id', '')))}</td>
                  <td>{escape(str(finding.get('user_impact') or 'Reduces friction in a visible task area.'))}</td>
                  <td><span class="effort-pill">{escape(effort)}</span></td>
                </tr>
                """
            )
        rows = "".join(row_items)
    return f"""
    <section class="card">
      <h2>High-Impact / Low-Effort Micro-Solutions</h2>
      <table class="micro-solution-table">
        <thead><tr><th>Role</th><th>Micro-solution</th><th>Linked finding</th><th>Why high impact</th><th>Estimated effort</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </section>
    """


def _render_viewer_html(payload: dict[str, Any], markdown: str, *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Audit Report"
    snapshot = payload.get("ux_health_snapshot") or {}
    scorecard = payload.get("scorecard") or {}
    scope_html = _scope_section_html(payload.get("audit_scope_lock") or {}, payload.get("active_scope_summary") or {})
    checklist_html = _checklist_tables_html(payload)
    evidence_gallery_html = _evidence_gallery_html(payload)
    evidence_html = _evidence_appendix_html(payload)
    grade = scorecard.get("overall_grade") or scorecard.get("core_grade") or ""
    pct = scorecard.get("overall_quality_percentage") or scorecard.get("core_quality_percentage") or ""
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)}</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    :root {{ color-scheme: light; --uxhc-green: #0d6e6e; --ink: #24292e; --muted: #6a737d; --line: #e1e4e8; --soft-line: #f0f0f0; --bg: #f5f6fa; --panel: #ffffff; --warning-bg: #fff8e1; --warning-line: #f9a825; --danger: #cb2431; --major: #c96a00; --medium: #b8860b; --success: #22863a; }}
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--bg); color: var(--ink); line-height: 1.6; }}
    .header {{ background: var(--uxhc-green); color: #ffffff; padding: 40px 48px; }}
    .header h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
    .header .meta {{ font-size: 14px; opacity: 0.86; margin-top: 4px; }}
    .header .grade-badge {{ display: inline-block; background: rgba(255,255,255,0.18); border: 2px solid #ffffff; border-radius: 8px; padding: 8px 20px; font-size: 32px; font-weight: 800; margin-top: 16px; }}
    .container {{ max-width: 1100px; margin: 0 auto; padding: 32px 24px; }}
    .card, .plain-read, .overall-grade-card, .finding, .top-finding-alert, .scope-lock {{ background: var(--panel); border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); border: 1px solid var(--line); }}
    .card, .scope-lock {{ padding: 28px; margin-bottom: 24px; }}
    .card h2, .scope-lock h2 {{ font-size: 18px; font-weight: 700; margin-bottom: 16px; color: var(--uxhc-green); border-bottom: 2px solid var(--line); padding-bottom: 10px; }}
    .mission-box {{ background: var(--warning-bg); border-left: 4px solid var(--warning-line); border-radius: 0 8px 8px 0; }}
    .mission-box h2 {{ color: #6d4c00; border-bottom-color: var(--warning-line); }}
    .mission-box p {{ color: #5d4037; font-size: 14px; }}
    .overall-summary {{ display: flex; gap: 24px; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; }}
    .overall-grade-card {{ padding: 24px 32px; text-align: center; min-width: 160px; align-self: flex-start; }}
    .overall-grade-card .big-grade {{ font-size: 64px; font-weight: 900; line-height: 1; }}
    .overall-grade-card .pct {{ font-size: 20px; font-weight: 600; color: var(--muted); margin-top: 4px; }}
    .overall-grade-card .descriptor {{ font-size: 13px; color: var(--muted); margin-top: 6px; max-width: 180px; }}
    .plain-read {{ padding: 24px; flex: 1; min-width: 300px; }}
    .label {{ font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--muted); margin-bottom: 10px; }}
    .plain-read p {{ font-size: 15px; color: var(--ink); line-height: 1.7; }}
    .plain-read .before {{ font-size: 13px; color: #586069; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--line); font-style: italic; }}
    .research-recommendation {{ background: #ffffff; border-radius: 12px; padding: 20px 24px; border: 1px solid #d0d7de; border-left: 4px solid var(--uxhc-green); margin-top: 16px; }}
    .research-recommendation .label {{ color: var(--uxhc-green); }}
    .research-recommendation p {{ font-size: 14px; }}
    .top-finding-alert {{ background: linear-gradient(135deg, #fff0f0, #fff8f0); border: 2px solid var(--danger); padding: 24px; margin-bottom: 24px; }}
    .top-finding-ok {{ background: #f6f8fa; border-color: var(--line); }}
    .top-finding-alert .label {{ color: var(--danger); }}
    .top-finding-alert h3 {{ font-size: 18px; font-weight: 700; margin-bottom: 8px; }}
    .top-finding-alert p {{ font-size: 14px; color: #444; }}
    .scorecard-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }}
    .score-item {{ border: 1px solid var(--line); border-radius: 8px; padding: 16px; }}
    .score-item .grade {{ font-size: 28px; font-weight: 800; }}
    .score-item .pct {{ font-size: 13px; color: var(--muted); }}
    .score-item .name {{ font-size: 13px; font-weight: 600; margin-top: 4px; }}
    .score-item .desc {{ font-size: 11px; color: var(--muted); margin-top: 2px; }}
    .finding {{ padding: 20px; margin-bottom: 16px; border-left: 4px solid var(--medium); }}
    .finding-header {{ display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; }}
    .rank {{ background: var(--uxhc-green); color: #ffffff; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 13px; flex-shrink: 0; margin-top: 2px; }}
    .severity-badge, .sprint-badge, .role-badge {{ display: inline-block; border-radius: 12px; padding: 3px 10px; font-size: 11px; font-weight: 700; color: #ffffff; white-space: nowrap; }}
    .heuristic-tag {{ font-size: 11px; color: var(--muted); margin-left: 4px; }}
    .finding h3 {{ font-size: 15px; font-weight: 700; margin-top: 4px; }}
    .section {{ margin-top: 10px; }}
    .section-label {{ font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); margin-bottom: 4px; }}
    .section-content {{ font-size: 13px; color: #444; background: #f6f8fa; padding: 10px 12px; border-radius: 6px; }}
    .mission-note {{ font-size: 12px; color: #856404; background: #fff3cd; padding: 8px 10px; border-radius: 6px; margin-top: 8px; border-left: 3px solid var(--warning-line); }}
    .evidence-line {{ margin-top: 8px; font-size: 11px; color: var(--muted); }}
    .strengths-list {{ list-style: none; }}
    .strengths-list li {{ padding: 8px 0; border-bottom: 1px solid var(--soft-line); font-size: 14px; }}
    .evidence-box {{ background: #f6f8fa; border: 1px solid var(--line); border-radius: 6px; padding: 16px; font-size: 13px; color: #586069; }}
    .evidence-limit-list {{ margin-left: 18px; }}
    .evidence-limit-list li {{ margin-bottom: 8px; }}
    .evidence-limit-details {{ margin-top: 12px; border-top: 1px solid var(--line); padding-top: 10px; }}
    .evidence-limit-details ul {{ margin: 10px 0 0 18px; }}
    .evidence-limit-details li {{ margin-bottom: 6px; }}
    .support-lens-warnings {{ margin-top: 14px; }}
    .evidence-gallery .evidence-group {{ margin-top: 18px; }}
    .evidence-gallery h3 {{ font-size: 15px; margin: 0 0 6px; color: var(--ink); }}
    .evidence-gallery-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; margin-top: 10px; }}
    .evidence-card {{ border: 1px solid var(--line); border-radius: 8px; background: #f6f8fa; padding: 14px; min-width: 0; }}
    .evidence-card .evidence-ref {{ font-weight: 800; color: var(--uxhc-green); }}
    .evidence-card .evidence-meta {{ font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.4px; margin-top: 2px; }}
    .evidence-card .evidence-label {{ font-size: 13px; font-weight: 700; margin: 8px 0; overflow-wrap: anywhere; }}
    .evidence-card dl {{ display: grid; grid-template-columns: 86px minmax(0, 1fr); gap: 4px 8px; font-size: 12px; }}
    .evidence-card dt {{ color: var(--muted); font-weight: 700; }}
    .evidence-card dd {{ overflow-wrap: anywhere; }}
    .validation-list {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; }}
    .validation-option {{ border: 1px solid #d0d7de; background: #f6f8fa; border-radius: 8px; padding: 14px; }}
    .option-title {{ font-size: 13px; font-weight: 700; margin-bottom: 4px; }}
    .option-copy {{ font-size: 12px; color: #57606a; line-height: 1.55; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }}
    th {{ text-align: left; padding: 10px 12px; background: #f6f8fa; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); border-bottom: 2px solid var(--line); }}
    td {{ padding: 10px 12px; border-bottom: 1px solid var(--soft-line); font-size: 13px; vertical-align: top; }}
    details {{ margin: 12px 0; }}
    summary {{ cursor: pointer; font-weight: 700; }}
    .section-intro {{ color: var(--muted); font-size: 13px; }}
    .score-pill {{ display: inline-block; min-width: 30px; text-align: center; border-radius: 999px; padding: 2px 8px; color: #ffffff; font-size: 11px; font-weight: 800; background: var(--muted); }}
    .severity-4, .severity-3 {{ background: var(--danger); }}
    .severity-2 {{ background: var(--medium); }}
    .severity-1 {{ background: var(--success); }}
    .severity-0 {{ background: var(--muted); }}
    .role-engineer {{ background: #0969da; }}
    .role-designer {{ background: #8250df; }}
    .role-product {{ background: var(--uxhc-green); }}
    .role-research {{ background: #6f42c1; }}
    .micro-solution-table th:last-child, .micro-solution-table td:last-child {{ min-width: 118px; white-space: nowrap; }}
    .effort-pill {{ display: inline-block; border: 1px solid #d0d7de; border-radius: 999px; padding: 2px 8px; font-size: 11px; font-weight: 700; color: #57606a; background: #ffffff; white-space: nowrap; }}
    footer {{ background: var(--ink); color: #8b949e; text-align: center; padding: 24px; font-size: 12px; margin-top: 48px; }}
    @media (max-width: 700px) {{ .header {{ padding: 32px 24px; }} .container {{ padding: 24px 16px; }} .scorecard-grid {{ grid-template-columns: 1fr; }} .plain-read {{ min-width: 100%; }} table {{ display: block; overflow-x: auto; }} }}
  </style>
</head>
<body>
  <header class="header">
    <h1>{escape(title)}</h1>
    <div class="meta">{escape(_header_meta(payload))}</div>
    <div class="meta">Generated: {escape(datetime.now().strftime('%Y-%m-%d'))} - UX Heuristic Compass report harness {escape(REPORT_DESIGN_SYSTEM_VERSION)}</div>
    <div class="grade-badge">{escape(str(grade))} - {escape(str(pct))}%</div>
  </header>
  <main class="container">
    {_mission_context_html(payload)}
    {_overall_summary_html(payload)}
    {_top_finding_alert_html(payload)}
    {_scorecard_html(payload)}
    {_findings_html(payload)}
    {_owner_triage_html(payload)}
    {_working_well_html(payload)}
    {_evidence_limits_html(payload)}
    {_corpus_advisories_html(payload)}
    {_validation_steps_html(payload)}
    {_support_lenses_html(payload)}
    {_implementation_readiness_html(payload)}
    {_roadmap_html(payload)}
    {_micro_solutions_html(payload)}
    {scope_html}
    {evidence_gallery_html}
    <section class="card">
      <h2>Complete Checklist Scores</h2>
      {checklist_html}
    </section>
    {evidence_html}
  </main>
  <footer>UX Heuristic Compass - static one-page report - no links, scripts, or external assets.</footer>
</body>
</html>
"""


def _run_visual_qa(viewer_path: Path) -> dict[str, Any]:
    capability = visual_qa_capability()
    if not capability["available"]:
        return {
            "status": "unavailable",
            "reason": capability["reason"],
            "browser_handoff_required": False,
            "capability": capability,
            "preflight": {"requested": True, "available": False, "browser_launch_attempted": False},
            "checks": [],
            "warnings": ["Visual QA was requested, but Playwright is unavailable; no browser was launched."],
        }
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:  # pragma: no cover - optional dependency
        return {
            "status": "unavailable",
            "reason": f"Playwright is not available in this runtime: {exc}",
            "browser_handoff_required": False,
            "capability": {**capability, "available": False, "status": "unavailable", "reason": str(exc)},
            "preflight": {"requested": True, "available": False, "browser_launch_attempted": False},
            "checks": [],
            "warnings": ["Visual QA was requested, but Playwright is unavailable; no browser was launched."],
        }

    checks: list[dict[str, Any]] = []
    context = None
    profile_dir: str | None = None
    handoff: dict[str, Any] = {
        "schema_version": "uxhc.browser_handoff.v2",
        "ownership_scope": "uxhc_visual_qa_temp_profile_only",
        "owned_browser": True,
        "owned_profile_dir": None,
        "owned_process_id": None,
        "owned_process_id_available": False,
        "launch_status": "not_started",
        "close_status": "not_started",
        "automation_browser_closed": False,
        "external_automation_policy": "External Chrome, Claude, and Playwright sessions are out of scope and must not be closed by UXHC visual QA.",
    }
    try:  # pragma: no cover - only runs where Playwright is installed
        with tempfile.TemporaryDirectory(prefix="uxhc-visual-qa-") as tmpdir:
            profile_dir = str(Path(tmpdir) / "chrome-profile")
            handoff["owned_profile_dir"] = profile_dir
            with sync_playwright() as p:
                handoff["launch_status"] = "launching"
                context = p.chromium.launch_persistent_context(
                    profile_dir,
                    headless=True,
                    viewport={"width": 1366, "height": 900},
                )
                handoff["launch_status"] = "launched"
                handoff["browser_name"] = "chromium"
                handoff["browser_version"] = context.browser.version if context.browser else ""
                handoff["context_mode"] = "persistent_context"
                for label, viewport in {
                    "desktop": {"width": 1366, "height": 900},
                    "mobile": {"width": 390, "height": 844},
                }.items():
                    page = context.new_page()
                    page.set_viewport_size(viewport)
                    page.goto(viewer_path.resolve().as_uri(), wait_until="load")
                    body_text = page.locator("body").inner_text(timeout=3000).strip()
                    overflow = page.evaluate("document.documentElement.scrollWidth > window.innerWidth + 4")
                    checks.append(
                        {
                            "viewport": label,
                            "nonblank": bool(body_text),
                            "horizontal_overflow": bool(overflow),
                        }
                    )
                    page.close()
                    handoff["viewport_checks"] = checks
                handoff["close_status"] = "closing"
                context.close()
                context = None
                handoff["close_status"] = "closed"
                handoff["automation_browser_closed"] = True
    except Exception as exc:  # pragma: no cover
        try:
            if context:
                context.close()
                handoff["close_status"] = "closed_after_error"
                handoff["automation_browser_closed"] = True
        except Exception:
            handoff["close_status"] = "close_failed_after_error"
        return {
            "status": "failed",
            "reason": str(exc),
            "browser_handoff_required": True,
            "capability": capability,
            "preflight": {"requested": True, "available": True, "browser_launch_attempted": handoff["launch_status"] != "not_started"},
            "browser_handoff": handoff,
            "checks": checks,
        }
    status = "passed" if checks and all(item["nonblank"] and not item["horizontal_overflow"] for item in checks) else "warnings"
    return {
        "status": status,
        "reason": "" if status == "passed" else "One or more visual QA checks reported blank content or horizontal overflow.",
        "browser_handoff_required": True,
        "capability": capability,
        "preflight": {"requested": True, "available": True, "browser_launch_attempted": True},
        "browser_handoff": handoff,
        "checks": checks,
    }


def _render_pdf(markdown: str, path: Path) -> dict[str, Any]:
    if os.environ.get("UXHC_FORCE_MINIMAL_PDF") == "1":
        return _render_minimal_pdf(markdown, path, reason="forced_by_environment")
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
    except Exception:  # pragma: no cover
        return _render_minimal_pdf(markdown, path, reason="reportlab_unavailable")

    page_width, page_height = letter
    margin = 54
    line_height = 13
    text_width = int((page_width - margin * 2) / 6.2)
    pdf = canvas.Canvas(str(path), pagesize=letter)
    y = page_height - margin
    page_count = 1

    def draw_line(line: str, *, bold: bool = False) -> None:
        nonlocal y, page_count
        if y < margin:
            pdf.showPage()
            page_count += 1
            y = page_height - margin
        pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 11 if not bold else 13)
        pdf.drawString(margin, y, line[:130])
        y -= line_height + (3 if bold else 0)

    for raw_line in markdown.splitlines():
        if not raw_line.strip():
            y -= line_height / 2
            continue
        if raw_line.startswith("# "):
            draw_line(raw_line[2:].strip(), bold=True)
            continue
        if raw_line.startswith("## "):
            y -= 4
            draw_line(raw_line[3:].strip(), bold=True)
            continue
        if raw_line.startswith("### "):
            draw_line(raw_line[4:].strip(), bold=True)
            continue
        indent = "  " if raw_line.startswith("- ") else ""
        content = raw_line[2:] if raw_line.startswith("- ") else raw_line
        prefix = "- " if raw_line.startswith("- ") else ""
        for wrapped in textwrap.wrap(content, width=text_width) or [""]:
            draw_line(f"{indent}{prefix}{wrapped}")
            prefix = "  " if prefix else ""
    pdf.save()
    return {
        "requested": True,
        "renderer": "reportlab",
        "fallback_used": False,
        "fallback_reason": "",
        "file_size_bytes": path.stat().st_size if path.exists() else None,
        "page_count_estimate": page_count,
    }


def _render_minimal_pdf(markdown: str, path: Path, *, reason: str = "fallback") -> dict[str, Any]:
    """Small dependency-free fallback for smoke environments without reportlab."""
    lines = []
    for raw in markdown.splitlines()[:60]:
        cleaned = raw.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        lines.append(cleaned[:95])
    content_lines = ["BT", "/F1 10 Tf", "54 744 Td"]
    for idx, line in enumerate(lines):
        if idx:
            content_lines.append("0 -13 Td")
        content_lines.append(f"({line}) Tj")
    content_lines.append("ET")
    stream = "\n".join(content_lines).encode("latin-1", errors="replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    output = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for idx, obj in enumerate(objects, start=1):
        offsets.append(len(output))
        output.extend(f"{idx} 0 obj\n".encode("ascii"))
        output.extend(obj)
        output.extend(b"\nendobj\n")
    xref_offset = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    output.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    output.extend(
        f"trailer << /Root 1 0 R /Size {len(objects) + 1} >>\nstartxref\n{xref_offset}\n%%EOF\n".encode("ascii")
    )
    path.write_bytes(bytes(output))
    return {
        "requested": True,
        "renderer": "minimal_pdf_fallback",
        "fallback_used": True,
        "fallback_reason": reason,
        "file_size_bytes": path.stat().st_size if path.exists() else None,
        "page_count_estimate": 1,
    }
