from __future__ import annotations

from datetime import datetime
from html import escape
import json
import os
from pathlib import Path
import textwrap
from typing import Any

from .behavior import REPORT_REQUIRED_FIELDS


REPORT_SCHEMA_VERSION = "uxhc.report.v2"

REQUIRED_CHECKLIST_RATING_FIELDS = [
    "checklist_item_id",
    "heuristic_id",
    "platform",
    "rating",
    "evidence_refs",
    "rationale",
    "confidence",
]


def validate_ux_report_payload(payload: dict[str, Any]) -> dict[str, Any]:
    missing: list[str] = []
    warnings: list[str] = []

    if not isinstance(payload, dict):
        return {
            "schema_version": REPORT_SCHEMA_VERSION,
            "qa_status": "blocked",
            "missing_report_fields": ["payload"],
            "warnings": [],
            "what_to_resubmit": ["Submit a dictionary payload returned by audit_ux_surface."],
        }

    source = payload.get("source") or {}
    snapshot = payload.get("ux_health_snapshot") or {}
    scorecard = payload.get("scorecard") or {}
    checklist_ratings = payload.get("checklist_ratings") or scorecard.get("checklist_ratings") or []
    heuristic_scores = payload.get("heuristic_scores") or scorecard.get("heuristic_scores") or []

    if not source.get("source_id"):
        missing.append("source.source_id")
    if not source.get("status"):
        missing.append("source.status")
    elif source.get("status") == "blocked":
        missing.append("source.status")
    if not payload.get("platform"):
        missing.append("platform")
    if snapshot.get("display_state") != "scored":
        missing.append("ux_health_snapshot.display_state")
    if scorecard.get("score_status") != "scored":
        missing.append("scorecard.score_status")
    for field in ("core_quality_percentage", "core_grade", "core_descriptor", "overall_quality_percentage", "overall_grade", "overall_descriptor"):
        if scorecard.get(field) in (None, "", []):
            missing.append(f"scorecard.{field}")
    if not heuristic_scores:
        missing.append("heuristic_scores")
    if not checklist_ratings:
        missing.append("checklist_ratings")
    if snapshot.get("display_state") == "scored" or scorecard.get("score_status") == "scored":
        _validate_behavior_fields(payload, missing)

    for idx, rating in enumerate(checklist_ratings, start=1):
        for field in REQUIRED_CHECKLIST_RATING_FIELDS:
            if rating.get(field) in (None, "", []):
                if field == "evidence_refs" and rating.get("evidence_limits"):
                    continue
                missing.append(f"checklist_ratings[{idx}].{field}")
        if rating.get("rating") is not None and not (0 <= float(rating["rating"]) <= 4):
            missing.append(f"checklist_ratings[{idx}].rating")

    if any(profile in {"donor", "conversion", "donation", "fundraising"} for profile in (payload.get("profiles", {}).get("accepted") or [])):
        missing.append("profiles.accepted")
        warnings.append("Donor/conversion profiles are excluded from the baseline product.")

    status = "ready" if not missing else "blocked"
    return {
        "schema_version": REPORT_SCHEMA_VERSION,
        "qa_status": status,
        "missing_report_fields": missing,
        "warnings": warnings,
        "what_to_resubmit": _what_to_resubmit(missing),
    }


def _validate_behavior_fields(payload: dict[str, Any], missing: list[str]) -> None:
    for field in REPORT_REQUIRED_FIELDS:
        if field in {"heuristic_scores", "checklist_ratings", "evidence_limits"}:
            continue
        if payload.get(field) in (None, "", []):
            missing.append(field)
    plain_read = str(payload.get("plain_language_read") or "").strip()
    if plain_read and _sentence_count(plain_read) > 2:
        missing.append("plain_language_read.max_2_sentences")
    before = str(payload.get("before_using_this_interface") or "")
    if before and not before.startswith("Before using this interface,"):
        missing.append("before_using_this_interface.prefix")
    contract = payload.get("report_readiness_contract") or {}
    if not contract:
        missing.append("report_readiness_contract")
    elif contract.get("status") != "ready":
        missing.append("report_readiness_contract.status")


def _sentence_count(text: str) -> int:
    stripped = text.strip()
    if not stripped:
        return 0
    count = sum(stripped.count(mark) for mark in [".", "?", "!"])
    return max(1, count)


def _what_to_resubmit(missing: list[str]) -> list[str]:
    if not missing:
        return []
    hints: list[str] = []
    if any(item.startswith("source.") for item in missing):
        hints.append("Run prepare_ux_source with at least one usable screenshot/image or completed capture before generating a report.")
    if any(item.startswith("ux_health_snapshot") or item.startswith("scorecard") or item == "checklist_ratings" for item in missing):
        hints.append("Run audit_ux_surface or quick_scan_ux with complete checklist_ratings for every active checklist item.")
    if any(item.startswith("checklist_ratings") for item in missing):
        hints.append("Each checklist rating needs checklist_item_id, 0-4 rating, rationale, confidence, and evidence_refs or evidence_limits.")
    if "profiles.accepted" in missing:
        hints.append("Remove donor/conversion profile requests from the baseline payload.")
    behavior_fields = {"plain_language_read", "before_using_this_interface", "top_finding", "one_recommendation", "report_readiness_contract"}
    if any(item in behavior_fields or item.startswith("plain_language_read") or item.startswith("before_using_this_interface") or item.startswith("report_readiness_contract") for item in missing):
        hints.append("Resubmit the scored audit payload with report_readiness_contract, plain_language_read, before_using_this_interface, top_finding, and one_recommendation.")
    return hints


def generate_ux_audit_report(
    payload: dict[str, Any] | None = None,
    *,
    payload_path: str | None = None,
    output_path: str | None = None,
    viewer_path: str | None = None,
    include_viewer: bool = True,
    pdf_path: str | None = None,
    include_pdf: bool = False,
    report_title: str | None = None,
) -> dict[str, Any]:
    if payload is None and payload_path:
        try:
            payload = json.loads(Path(payload_path).expanduser().read_text(encoding="utf-8"))
        except Exception as exc:
            return {
                "schema_version": REPORT_SCHEMA_VERSION,
                "qa_status": "blocked",
                "validation": {
                    "schema_version": REPORT_SCHEMA_VERSION,
                    "qa_status": "blocked",
                    "missing_report_fields": ["payload_path"],
                    "warnings": [f"Could not read payload_path: {exc}"],
                    "what_to_resubmit": ["Pass a readable JSON payload_path returned by audit_ux_surface or quick_scan_ux."],
                },
                "markdown": "",
                "markdown_path": None,
                "viewer_path": None,
                "pdf_path": None,
            }
    payload = payload or {}
    validation = validate_ux_report_payload(payload)
    if validation["qa_status"] != "ready":
        return {
            "schema_version": REPORT_SCHEMA_VERSION,
            "qa_status": "blocked",
            "validation": validation,
            "markdown": "",
            "markdown_path": None,
            "viewer_path": None,
            "pdf_path": None,
        }

    markdown = _render_markdown(payload, report_title=report_title)
    saved_path: str | None = None
    saved_viewer_path: str | None = None
    saved_pdf_path: str | None = None
    pdf_rendering: dict[str, Any] = {"requested": bool(include_pdf), "renderer": None, "fallback_used": False, "file_size_bytes": None, "page_count_estimate": None}
    if output_path:
        path = Path(output_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(markdown, encoding="utf-8")
        saved_path = str(path)
        if include_viewer and not viewer_path:
            viewer_path = str(path.with_suffix(".html"))
        if include_pdf and not pdf_path:
            pdf_path = str(path.with_suffix(".pdf"))
    if include_viewer and viewer_path:
        viewer = Path(viewer_path).expanduser()
        viewer.parent.mkdir(parents=True, exist_ok=True)
        viewer.write_text(_render_viewer_html(payload, markdown, report_title=report_title), encoding="utf-8")
        saved_viewer_path = str(viewer)
    if include_pdf and pdf_path:
        pdf = Path(pdf_path).expanduser()
        pdf.parent.mkdir(parents=True, exist_ok=True)
        pdf_rendering = _render_pdf(markdown, pdf)
        saved_pdf_path = str(pdf)
    qa_status = "ready_with_warnings" if pdf_rendering.get("fallback_used") else "ready"
    return {
        "schema_version": REPORT_SCHEMA_VERSION,
        "qa_status": qa_status,
        "validation": validation,
        "markdown": markdown,
        "markdown_path": saved_path,
        "viewer_path": saved_viewer_path,
        "pdf_path": saved_pdf_path,
        "pdf_rendering": pdf_rendering,
    }


def _render_markdown(payload: dict[str, Any], *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Audit Report"
    snapshot = payload.get("ux_health_snapshot") or {}
    source = payload.get("source") or {}
    scorecard = payload.get("scorecard") or {}
    findings = payload.get("findings") or []
    heuristic_scores = payload.get("heuristic_scores") or []
    checklist_ratings = payload.get("checklist_ratings") or []
    evidence_limits = payload.get("evidence_limits") or []
    next_steps = payload.get("next_validation_steps") or []
    activity = payload.get("follow_up_activity") or {}
    extended_activities = payload.get("follow_up_activity_extended") or []
    reasoning_flows = payload.get("reasoning_flow_suggestions") or []
    prioritization = payload.get("prioritization_flow") or {}
    bias_advisories = payload.get("evaluator_bias_advisories") or []
    implementation_contract = payload.get("implementation_inspection_contract") or {}
    implementation_summary = payload.get("implementation_evidence_summary") or {}
    human_loop = payload.get("human_loop_host_action") or {}
    hil_compliance = payload.get("hil_compliance") or {}
    scope_lock = payload.get("audit_scope_lock") or {}

    lines = [
        f"# {title}",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d')}",
        "",
        "## Executive Summary",
        "",
        f"- Platform: {payload.get('platform', '')}",
        f"- Core grade: {scorecard.get('core_grade', '')} ({scorecard.get('core_quality_percentage', '')}%) - {scorecard.get('core_descriptor', '')}",
        f"- Expanded grade: {scorecard.get('expanded_grade') or 'N/A'} ({scorecard.get('expanded_quality_percentage') or 'N/A'}%)",
        f"- Overall label: {snapshot.get('overall_label', '')}",
        f"- Plain-language read: {payload.get('plain_language_read', '')}",
        f"- Before using this interface: {payload.get('before_using_this_interface', '')}",
        f"- Top priority: {snapshot.get('top_priority', '')}",
        f"- One recommendation: {payload.get('one_recommendation', '')}",
        f"- Source status: {source.get('status', '')}",
        "",
        "## Heuristic Grade Table",
        "",
        "| Heuristic | Items | Avg Severity | Quality | Grade |",
        "|---|---:|---:|---:|---|",
    ]
    for score in heuristic_scores:
        lines.append(
            f"| {score.get('heuristic_name', score.get('heuristic_id', ''))} | {score.get('active_item_count', '')} | {score.get('average_item_severity', '')} | {score.get('quality_percentage', '')}% | {score.get('letter_grade', '')} |"
        )

    lines.extend(_scope_section_markdown(scope_lock))

    lines.extend(["", "## Severity Summary", ""])
    counts = snapshot.get("severity_counts") or {}
    if counts:
        for level in ["4", "3", "2", "1", "0"]:
            lines.append(f"- Severity {level}: {counts.get(level, 0)}")
    else:
        lines.append("- No scored findings.")

    lines.extend(["", "## Top Findings", ""])
    if findings:
        for finding in sorted(findings, key=lambda item: (-item.get("severity", 0), item.get("heuristic_name", "")))[:10]:
            lines.extend(
                [
                    f"### {finding.get('title', 'Untitled finding')}",
                    "",
                    f"- Checklist item: {finding.get('checklist_item_id', '')}",
                    f"- Heuristic: {finding.get('heuristic_name', '')}",
                    f"- Severity: {finding.get('severity', '')} - {finding.get('severity_label', '')}",
                    f"- Evidence: {finding.get('evidence_ref', '')}",
                    f"- Confidence: {finding.get('confidence', '')}",
                    f"- Issue: {finding.get('observed_issue', '')}",
                    f"- Recommendation: {finding.get('recommendation', '')}",
                    "",
                ]
            )
    else:
        lines.append("- No checklist items scored above 0.")

    lines.extend(["", "## Checklist Issue Ledger", ""])
    lines.extend(["| Item | Rating | Confidence | Evidence | Rationale |", "|---|---:|---|---|---|"])
    for rating in checklist_ratings:
        if float(rating.get("rating", 0)) <= 0:
            continue
        evidence = ", ".join(rating.get("evidence_refs") or [])
        rationale = str(rating.get("rationale") or "").replace("|", "\\|")
        lines.append(f"| {rating.get('checklist_item_id', '')} | {rating.get('rating', '')} | {rating.get('confidence', '')} | {evidence} | {rationale} |")
    lines.extend(["", "## Complete Checklist Scores", ""])
    lines.extend(_checklist_tables_markdown(checklist_ratings, heuristic_scores))

    lines.extend(["", "## Evidence Limits", ""])
    if evidence_limits:
        for item in evidence_limits:
            if isinstance(item, dict):
                lines.append(f"- {item.get('checklist_item_id', 'source')}: {item.get('reason', '')} ({item.get('confidence_impact', '')})")
            else:
                lines.append(f"- {item}")
    else:
        lines.append("- No major evidence limits were recorded.")

    lines.extend(_evidence_appendix_markdown(payload))

    lines.extend(["", "## Follow-Up Activity", ""])
    if activity.get("try_this_next"):
        _append_activity(lines, "Try This Next", activity["try_this_next"])
        if activity.get("solo_activity"):
            _append_activity(lines, "Solo Activity", activity["solo_activity"])
        if activity.get("group_activity"):
            _append_activity(lines, "Group Activity", activity["group_activity"])
        if activity.get("fit_check"):
            lines.append(f"- Fit check: {activity['fit_check']}")
    else:
        lines.append("- No follow-up activity was generated.")

    if extended_activities:
        lines.extend(["", "## Additional Validation Activities", ""])
        for card in extended_activities:
            _append_activity(lines, card.get("title", "Activity"), card)
            if card.get("facilitation_note"):
                lines.append(f"- Facilitation note: {card['facilitation_note']}")

    lines.extend(["", "## Reasoning Flow Suggestions", ""])
    if reasoning_flows:
        for flow in reasoning_flows:
            lines.extend(
                [
                    f"### {flow.get('title', flow.get('flow_id', 'Reasoning flow'))}",
                    "",
                    f"- Heuristic: {flow.get('heuristic_id', '')}",
                    f"- Use when: {flow.get('use_when', '')}",
                    f"- Source: {flow.get('source', '')}",
                    "- Steps:",
                ]
            )
            lines.extend(f"  - {step}" for step in flow.get("steps") or [])
            if flow.get("facilitation_note"):
                lines.append(f"- Facilitation note: {flow['facilitation_note']}")
            enrichment = flow.get("knowledge_atlas_enrichment") or {}
            if enrichment:
                lines.append(f"- Atlas status: {enrichment.get('status', '')} ({enrichment.get('source_entry_id', '')})")
            lines.append("")
    else:
        lines.append("- No reasoning-flow suggestion was needed for this audit.")

    lines.extend(["", "## Evaluator Bias Advisories", ""])
    if bias_advisories:
        for advisory in bias_advisories:
            lines.append(f"- {advisory.get('name', advisory.get('bias_id', 'Bias advisory'))}: {advisory.get('relevance_note', '')} Mitigation: {advisory.get('mitigation', '')}")
    else:
        lines.append("- No evaluator bias advisory was triggered.")

    lines.extend(["", "## Implementation-Aware Inspection", ""])
    if implementation_contract:
        lines.append(f"- Status: {implementation_contract.get('status', '')}")
        lines.append(f"- Route: {implementation_contract.get('route_id', '')}")
        lines.append(f"- Harness: {implementation_contract.get('ai_coding_harness', '')}")
        lines.append(f"- Purpose: {implementation_contract.get('purpose', '')}")
        lines.append(f"- Score policy: {(implementation_contract.get('external_result_policy') or {}).get('score_policy', '')}")
        if implementation_summary:
            lines.append(f"- Evidence summary status: {implementation_summary.get('status', '')}")
            if implementation_summary.get("score_policy"):
                lines.append(f"- Evidence score policy: {implementation_summary['score_policy']}")
            heuristics = ", ".join(implementation_summary.get("likely_affected_heuristics") or [])
            lines.append(f"- Likely affected heuristics: {heuristics or 'none detected'}")
            for source_item in implementation_summary.get("sources") or []:
                dimensions = ", ".join(source_item.get("matched_dimensions") or [])
                lines.append(f"- {source_item.get('source', 'source')}: {dimensions or 'no matched dimensions'} - {source_item.get('summary', '')}")
            if implementation_summary.get("evidence_limit"):
                lines.append(f"- Evidence limit: {implementation_summary['evidence_limit']}")
        else:
            lines.append("- Evidence summary: no implementation evidence was supplied yet.")
    else:
        lines.append("- Not requested for this audit.")

    lines.extend(["", "## Prioritization Flow", ""])
    if prioritization:
        lines.extend(
            [
                f"### {prioritization.get('title', prioritization.get('flow_id', 'Prioritization flow'))}",
                "",
                f"- Use when: {prioritization.get('use_when', '')}",
                f"- Source: {prioritization.get('source_note', prioritization.get('source', ''))}",
                "- Steps:",
            ]
        )
        lines.extend(f"  - {step}" for step in prioritization.get("steps") or [])
    else:
        lines.append("- Not needed because the overall score is above B.")

    lines.extend(["", "## Human Review", ""])
    if human_loop:
        lines.append(f"- Pause required: {human_loop.get('PAUSE_REQUIRED', False)}")
        lines.append(f"- Stage: {human_loop.get('stage', 'none')}")
        if hil_compliance:
            lines.append(f"- Native question UI status: {hil_compliance.get('host_question_ui_status', 'unknown')}")
            lines.append(f"- HIL blocked until native UI: {hil_compliance.get('HIL_BLOCKED_UNTIL_NATIVE_UI', False)}")
            lines.append(f"- Resolved gates: {', '.join(hil_compliance.get('resolved_gate_ids') or []) or 'none'}")
            lines.append(f"- Unresolved gates: {', '.join(hil_compliance.get('unresolved_gate_ids') or []) or 'none'}")
        questions = human_loop.get("questions_for_user") or []
        if questions:
            lines.append("- Questions:")
            for question in questions:
                lines.append(f"  - {question.get('question_id', '')}: {question.get('question', '')}")
    else:
        lines.append("- No human-loop action was supplied.")

    lines.extend(["", "## Recommended Next Validation", ""])
    if next_steps:
        lines.extend(f"- {item}" for item in next_steps)
    else:
        lines.append("- Re-run the audit after fixes or test the highest-risk task with users.")

    lines.extend(
        [
            "",
            "## Scope Note",
            "",
            "This report is a heuristic evaluation artifact. It does not replace usability testing, analytics, accessibility compliance review, or direct user research.",
        ]
    )
    return "\n".join(lines).strip() + "\n"


def _scope_section_markdown(scope_lock: dict[str, Any]) -> list[str]:
    if not scope_lock:
        return []
    omitted = scope_lock.get("omitted_optional_profiles") or []
    scored = scope_lock.get("scored_optional_profiles") or []
    scored_labels = [f"{item.get('profile')} ({item.get('heuristic_id')})" for item in scored]
    lines = [
        "",
        "## Audit Scope and Omitted Profiles",
        "",
        f"- Scope status: {scope_lock.get('status', '')}",
        f"- Optional profile mode: {scope_lock.get('optional_profile_mode', '')}",
        f"- Full advanced requested: {scope_lock.get('full_advanced_requested', False)}",
        f"- Scored optional profiles: {', '.join(scored_labels) or 'none'}",
    ]
    if omitted:
        lines.append("- Omitted optional profiles:")
        for item in omitted:
            lines.append(f"  - {item.get('profile')} ({item.get('heuristic_id')}): {item.get('heuristic_name')}")
        lines.append(f"- Rerun guidance: {scope_lock.get('rerun_guidance', '')}")
    else:
        lines.append("- Omitted optional profiles: none")
    return lines


def _evidence_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    source = payload.get("source") or {}
    items = {str(item.get("item_id")): item for item in source.get("items") or []}
    rows: list[dict[str, Any]] = []
    for ref in source.get("evidence_refs") or []:
        item_id = str(ref.get("item_id") or ref.get("evidence_ref") or "")
        item = items.get(item_id, {})
        rows.append(
            {
                "evidence_ref": ref.get("evidence_ref") or item_id,
                "label": ref.get("label") or item.get("state_label") or item.get("url") or item.get("input_path") or "",
                "source_type": ref.get("source_type") or item.get("source_type") or "",
                "quality": ref.get("quality") or item.get("quality") or "",
                "screenshot_path": item.get("screenshot_path") or "",
                "input_path": item.get("input_path") or "",
                "url": item.get("url") or "",
                "page_title": item.get("page_title") or "",
                "capture_metadata_path": item.get("capture_metadata_path") or "",
            }
        )
    return rows


def _evidence_appendix_markdown(payload: dict[str, Any]) -> list[str]:
    rows = _evidence_rows(payload)
    lines = ["", "## Evidence Appendix", ""]
    if not rows:
        lines.append("- No evidence references were supplied.")
        return lines
    lines.extend(["| Evidence ref | Source type | Quality | Label/title | Screenshot | Metadata |", "|---|---|---|---|---|---|"])
    for row in rows:
        label = str(row.get("page_title") or row.get("label") or "").replace("|", "\\|")
        screenshot = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "").replace("|", "\\|")
        metadata = str(row.get("capture_metadata_path") or "").replace("|", "\\|")
        lines.append(f"| {row.get('evidence_ref', '')} | {row.get('source_type', '')} | {row.get('quality', '')} | {label} | {screenshot} | {metadata} |")
    return lines


def _append_activity(lines: list[str], label: str, card: dict[str, Any]) -> None:
    lines.extend(
        [
            f"### {label}: {card.get('title', '')}",
            "",
            f"- Why this fits: {card.get('why_this_fits', '')}",
            f"- Content focus: {card.get('content_focus', '')}",
            f"- Thinking focus: {card.get('thinking_focus', '')}",
            f"- Source note: {card.get('source_note', '')}",
            "- Steps:",
        ]
    )
    lines.extend(f"  - {step}" for step in card.get("steps") or [])
    lines.append("")


def _checklist_tables_markdown(checklist_ratings: list[dict[str, Any]], heuristic_scores: list[dict[str, Any]]) -> list[str]:
    if not checklist_ratings:
        return ["- No checklist ratings were supplied."]
    names = {str(score.get("heuristic_id")): str(score.get("heuristic_name") or score.get("heuristic_id")) for score in heuristic_scores}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rating in checklist_ratings:
        grouped.setdefault(str(rating.get("heuristic_id") or "unknown"), []).append(rating)
    lines: list[str] = []
    for heuristic_id, rows in sorted(grouped.items()):
        title = names.get(heuristic_id, heuristic_id)
        lines.extend(
            [
                f"<details>",
                f"<summary>{escape(title)} ({heuristic_id}) - {len(rows)} checklist items</summary>",
                "",
                "| Item | Checklist text | Score | Confidence | Evidence | Rationale |",
                "|---|---|---:|---|---|---|",
            ]
        )
        for row in rows:
            evidence = ", ".join(str(item) for item in row.get("evidence_refs") or [])
            text = str(row.get("checklist_text") or "").replace("|", "\\|")
            rationale = str(row.get("rationale") or "").replace("|", "\\|")
            lines.append(
                f"| {row.get('checklist_item_id', '')} | {text} | {row.get('rating', '')} | {row.get('confidence', '')} | {evidence} | {rationale} |"
            )
        lines.extend(["", "</details>", ""])
    return lines


def _checklist_tables_html(payload: dict[str, Any]) -> str:
    checklist_ratings = payload.get("checklist_ratings") or []
    heuristic_scores = payload.get("heuristic_scores") or []
    if not checklist_ratings:
        return "<p>No checklist ratings were supplied.</p>"
    names = {str(score.get("heuristic_id")): str(score.get("heuristic_name") or score.get("heuristic_id")) for score in heuristic_scores}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rating in checklist_ratings:
        grouped.setdefault(str(rating.get("heuristic_id") or "unknown"), []).append(rating)
    blocks: list[str] = []
    for heuristic_id, rows in sorted(grouped.items()):
        row_html = []
        for row in rows:
            evidence = ", ".join(str(item) for item in row.get("evidence_refs") or [])
            rating_value = float(row.get("rating") or 0)
            row_html.append(
                f'<tr data-checklist-row="true" data-rating="{escape(str(row.get("rating", "")))}" data-state="{"passed" if rating_value <= 0 else "issue"}">'
                f"<td>{escape(str(row.get('checklist_item_id', '')))}</td>"
                f"<td>{escape(str(row.get('checklist_text', '')))}</td>"
                f"<td>{escape(str(row.get('rating', '')))}</td>"
                f"<td>{escape(str(row.get('confidence', '')))}</td>"
                f"<td>{escape(evidence)}</td>"
                f"<td>{escape(str(row.get('rationale', '')))}</td>"
                "</tr>"
            )
        blocks.append(
            f"""
            <details class="checklist-table">
              <summary>{escape(names.get(heuristic_id, heuristic_id))} ({escape(heuristic_id)}) - {len(rows)} checklist items</summary>
              <table>
                <thead><tr><th>Item</th><th>Checklist text</th><th>Score</th><th>Confidence</th><th>Evidence</th><th>Rationale</th></tr></thead>
                <tbody>{''.join(row_html)}</tbody>
              </table>
            </details>
            """
        )
    controls = """
    <div class="checklist-filters" aria-label="Checklist filters">
      <button type="button" data-filter="all" onclick="filterChecklist('all')">All</button>
      <button type="button" data-filter="issues" onclick="filterChecklist('issues')">Issues only</button>
      <button type="button" data-filter="major" onclick="filterChecklist('major')">Major only</button>
      <button type="button" data-filter="passed" onclick="filterChecklist('passed')">Passed</button>
    </div>
    """
    script = """
    <script>
      function filterChecklist(mode) {
        document.querySelectorAll('[data-checklist-row="true"]').forEach(function(row) {
          const rating = Number(row.getAttribute('data-rating') || '0');
          let show = true;
          if (mode === 'issues') show = rating > 0;
          if (mode === 'major') show = rating >= 3;
          if (mode === 'passed') show = rating <= 0;
          row.hidden = !show;
        });
      }
    </script>
    """
    return controls + "\n".join(blocks) + script


def _scope_section_html(scope_lock: dict[str, Any]) -> str:
    if not scope_lock:
        return ""
    omitted = scope_lock.get("omitted_optional_profiles") or []
    scored = scope_lock.get("scored_optional_profiles") or []
    scored_text = ", ".join(f"{item.get('profile')} ({item.get('heuristic_id')})" for item in scored) or "none"
    omitted_items = "".join(f"<li>{escape(str(item.get('profile')))} ({escape(str(item.get('heuristic_id')))}): {escape(str(item.get('heuristic_name')))}</li>" for item in omitted)
    omitted_html = f"<ul>{omitted_items}</ul>" if omitted_items else "<p>None</p>"
    return f"""
    <section class="scope-lock">
      <h2>Audit Scope and Omitted Profiles</h2>
      <p><strong>Status:</strong> {escape(str(scope_lock.get('status', '')))}</p>
      <p><strong>Optional profile mode:</strong> {escape(str(scope_lock.get('optional_profile_mode', '')))}</p>
      <p><strong>Scored optional profiles:</strong> {escape(scored_text)}</p>
      <p><strong>Omitted optional profiles:</strong></p>
      {omitted_html}
      <p>{escape(str(scope_lock.get('rerun_guidance', '')))}</p>
    </section>
    """


def _evidence_appendix_html(payload: dict[str, Any]) -> str:
    rows = _evidence_rows(payload)
    if not rows:
        return "<section><h2>Evidence Appendix</h2><p>No evidence references were supplied.</p></section>"
    row_html = []
    for row in rows:
        screenshot = str(row.get("screenshot_path") or row.get("input_path") or row.get("url") or "")
        metadata = str(row.get("capture_metadata_path") or "")
        screenshot_html = f'<a href="{escape(screenshot)}">{escape(screenshot)}</a>' if screenshot else ""
        metadata_html = f'<a href="{escape(metadata)}">{escape(metadata)}</a>' if metadata else ""
        row_html.append(
            "<tr>"
            f"<td>{escape(str(row.get('evidence_ref', '')))}</td>"
            f"<td>{escape(str(row.get('source_type', '')))}</td>"
            f"<td>{escape(str(row.get('quality', '')))}</td>"
            f"<td>{escape(str(row.get('page_title') or row.get('label') or ''))}</td>"
            f"<td>{screenshot_html}</td>"
            f"<td>{metadata_html}</td>"
            "</tr>"
        )
    return f"""
    <section>
      <h2>Evidence Appendix</h2>
      <table>
        <thead><tr><th>Evidence ref</th><th>Source type</th><th>Quality</th><th>Label/title</th><th>Screenshot/source</th><th>Metadata</th></tr></thead>
        <tbody>{''.join(row_html)}</tbody>
      </table>
    </section>
    """


def _render_viewer_html(payload: dict[str, Any], markdown: str, *, report_title: str | None = None) -> str:
    title = report_title or "UX Heuristic Compass Audit Report"
    snapshot = payload.get("ux_health_snapshot") or {}
    findings = payload.get("findings") or []
    source = payload.get("source") or {}
    scorecard = payload.get("scorecard") or {}
    plain_read = str(payload.get("plain_language_read") or "")
    before_using = str(payload.get("before_using_this_interface") or "")
    scope_html = _scope_section_html(payload.get("audit_scope_lock") or {})
    cards = []
    for finding in sorted(findings, key=lambda item: (-item.get("severity", 0), item.get("heuristic_name", ""))):
        cards.append(
            f"""
            <article class="finding severity-{int(finding.get('severity', 0))}">
              <div class="severity">Severity {escape(str(finding.get('severity', '')))}</div>
              <h3>{escape(str(finding.get('title', 'Untitled finding')))}</h3>
              <p><strong>Checklist:</strong> {escape(str(finding.get('checklist_item_id', '')))}</p>
              <p><strong>Heuristic:</strong> {escape(str(finding.get('heuristic_name', '')))}</p>
              <p><strong>Evidence:</strong> {escape(str(finding.get('evidence_ref', '')))}</p>
              <p><strong>Issue:</strong> {escape(str(finding.get('observed_issue', '')))}</p>
              <p><strong>Recommendation:</strong> {escape(str(finding.get('recommendation', '')))}</p>
            </article>
            """
        )
    cards_html = "\n".join(cards) or "<p>No checklist items scored above 0.</p>"
    checklist_html = _checklist_tables_html(payload)
    evidence_html = _evidence_appendix_html(payload)
    markdown_html = escape(markdown)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)}</title>
  <style>
    :root {{ color-scheme: light; --ink: #17202a; --muted: #5f6b7a; --line: #d8dee8; --bg: #f7f8fb; --panel: #ffffff; }}
    body {{ margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: var(--bg); color: var(--ink); }}
    main {{ max-width: 1080px; margin: 0 auto; padding: 32px 20px 48px; }}
    header {{ margin-bottom: 24px; }}
    h1 {{ font-size: 32px; line-height: 1.15; margin: 0 0 8px; }}
    h2 {{ font-size: 20px; margin-top: 28px; }}
    .summary, .finding, .checklist-table, .scope-lock, pre {{ background: var(--panel); border: 1px solid var(--line); border-radius: 8px; padding: 16px; }}
    .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; }}
    .metric span {{ display: block; color: var(--muted); font-size: 13px; margin-bottom: 4px; }}
    .finding {{ margin: 12px 0; }}
    .finding h3 {{ margin: 8px 0; font-size: 18px; }}
    .severity {{ display: inline-block; font-weight: 700; font-size: 13px; color: #ffffff; background: #536173; border-radius: 999px; padding: 4px 10px; }}
    .severity-3 .severity, .severity-4 .severity {{ background: #b42318; }}
    .severity-2 .severity {{ background: #b7791f; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }}
    th, td {{ border-top: 1px solid var(--line); padding: 8px; text-align: left; vertical-align: top; }}
    th {{ color: var(--muted); font-weight: 700; }}
    details {{ margin: 12px 0; }}
    summary {{ cursor: pointer; font-weight: 700; }}
    .checklist-filters {{ display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0; }}
    .checklist-filters button {{ border: 1px solid var(--line); background: var(--panel); border-radius: 6px; padding: 6px 10px; cursor: pointer; }}
    pre {{ overflow: auto; white-space: pre-wrap; line-height: 1.45; }}
  </style>
</head>
<body>
  <main>
    <header>
      <h1>{escape(title)}</h1>
      <p>Local read-only UX Heuristic Compass artifact viewer.</p>
    </header>
    <section class="summary" aria-label="Audit summary">
      <div class="metric"><span>Core grade</span>{escape(str(scorecard.get('core_grade', '')))} ({escape(str(scorecard.get('core_quality_percentage', '')))}%)</div>
      <div class="metric"><span>Overall</span>{escape(str(snapshot.get('overall_label', '')))}</div>
      <div class="metric"><span>Plain read</span>{escape(plain_read)}</div>
      <div class="metric"><span>Before using</span>{escape(before_using)}</div>
      <div class="metric"><span>Top priority</span>{escape(str(snapshot.get('top_priority', '')))}</div>
      <div class="metric"><span>Source status</span>{escape(str(source.get('status', '')))}</div>
      <div class="metric"><span>Findings</span>{len(findings)}</div>
    </section>
    {scope_html}
    <h2>Findings</h2>
    {cards_html}
    <h2>Complete Checklist Scores</h2>
    {checklist_html}
    {evidence_html}
    <h2>Markdown Source</h2>
    <pre>{markdown_html}</pre>
  </main>
</body>
</html>
"""


def _render_pdf(markdown: str, path: Path) -> dict[str, Any]:
    if os.environ.get("UXHC_FORCE_MINIMAL_PDF") == "1":
        return _render_minimal_pdf(markdown, path, reason="forced_by_environment")
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
    except Exception:  # pragma: no cover
        return _render_minimal_pdf(markdown, path, reason="reportlab_unavailable")

    page_width, page_height = letter
    margin = 54
    line_height = 13
    text_width = int((page_width - margin * 2) / 6.2)
    pdf = canvas.Canvas(str(path), pagesize=letter)
    y = page_height - margin
    page_count = 1

    def draw_line(line: str, *, bold: bool = False) -> None:
        nonlocal y, page_count
        if y < margin:
            pdf.showPage()
            page_count += 1
            y = page_height - margin
        pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 11 if not bold else 13)
        pdf.drawString(margin, y, line[:130])
        y -= line_height + (3 if bold else 0)

    for raw_line in markdown.splitlines():
        if not raw_line.strip():
            y -= line_height / 2
            continue
        if raw_line.startswith("# "):
            draw_line(raw_line[2:].strip(), bold=True)
            continue
        if raw_line.startswith("## "):
            y -= 4
            draw_line(raw_line[3:].strip(), bold=True)
            continue
        if raw_line.startswith("### "):
            draw_line(raw_line[4:].strip(), bold=True)
            continue
        indent = "  " if raw_line.startswith("- ") else ""
        content = raw_line[2:] if raw_line.startswith("- ") else raw_line
        prefix = "- " if raw_line.startswith("- ") else ""
        for wrapped in textwrap.wrap(content, width=text_width) or [""]:
            draw_line(f"{indent}{prefix}{wrapped}")
            prefix = "  " if prefix else ""
    pdf.save()
    return {
        "requested": True,
        "renderer": "reportlab",
        "fallback_used": False,
        "fallback_reason": "",
        "file_size_bytes": path.stat().st_size if path.exists() else None,
        "page_count_estimate": page_count,
    }


def _render_minimal_pdf(markdown: str, path: Path, *, reason: str = "fallback") -> dict[str, Any]:
    """Small dependency-free fallback for smoke environments without reportlab."""
    lines = []
    for raw in markdown.splitlines()[:60]:
        cleaned = raw.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        lines.append(cleaned[:95])
    content_lines = ["BT", "/F1 10 Tf", "54 744 Td"]
    for idx, line in enumerate(lines):
        if idx:
            content_lines.append("0 -13 Td")
        content_lines.append(f"({line}) Tj")
    content_lines.append("ET")
    stream = "\n".join(content_lines).encode("latin-1", errors="replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    output = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for idx, obj in enumerate(objects, start=1):
        offsets.append(len(output))
        output.extend(f"{idx} 0 obj\n".encode("ascii"))
        output.extend(obj)
        output.extend(b"\nendobj\n")
    xref_offset = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    output.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    output.extend(
        f"trailer << /Root 1 0 R /Size {len(objects) + 1} >>\nstartxref\n{xref_offset}\n%%EOF\n".encode("ascii")
    )
    path.write_bytes(bytes(output))
    return {
        "requested": True,
        "renderer": "minimal_pdf_fallback",
        "fallback_used": True,
        "fallback_reason": reason,
        "file_size_bytes": path.stat().st_size if path.exists() else None,
        "page_count_estimate": 1,
    }
