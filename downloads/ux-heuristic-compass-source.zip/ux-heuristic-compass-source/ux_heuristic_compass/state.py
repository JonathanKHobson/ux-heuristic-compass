from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .rubric import normalize_platform, normalize_profiles


STATE_SCHEMA_VERSION = "uxhc.state.v1"
PREFERENCES_SCHEMA_VERSION = "uxhc.preferences.v1"
DEFAULT_USER_ID = "local_default"

VALID_UX_LEVELS = {"beginner", "practitioner", "expert"}
VALID_HIL_DEFAULTS = {"enabled", "disabled", "ai_decides"}
VALID_AGENT_DEFAULTS = {"enabled", "disabled", "ask_each_time"}
VALID_PLATFORM_DEFAULTS = {"desktop", "mobile", "ask_each_time"}


ONBOARDING_QUESTIONS: list[dict[str, Any]] = [
    {
        "question_id": "onboarding_ux_level",
        "field": "ux_level",
        "question": "What is your UX evaluation experience level?",
        "widget_question_type": "single-select",
        "options": ["beginner", "practitioner", "expert"],
        "what_this_can_change": "Adjusts explanation depth and how much teaching context audit outputs include.",
        "what_this_cannot_change": "Does not change scoring thresholds or rubric criteria.",
    },
    {
        "question_id": "onboarding_hil_default",
        "field": "hil_default",
        "question": "How should human-in-the-loop review behave by default?",
        "widget_question_type": "single-select",
        "options": ["enabled", "disabled", "ai_decides"],
        "what_this_can_change": "Controls whether advanced audits pause for structured review gates by default.",
        "what_this_cannot_change": "Does not bypass report validation or required checklist ratings.",
    },
    {
        "question_id": "onboarding_agent_default",
        "field": "agent_default",
        "question": "How should Agent Mode behave by default?",
        "widget_question_type": "single-select",
        "options": ["enabled", "disabled", "ask_each_time"],
        "what_this_can_change": "Controls whether the host should offer agent workflows without re-asking each time.",
        "what_this_cannot_change": "Does not make UXHC autonomously interpret visuals or navigate unbounded flows.",
    },
    {
        "question_id": "onboarding_platform_default",
        "field": "platform_default",
        "question": "Which platform should audits default to?",
        "widget_question_type": "single-select",
        "options": ["desktop", "mobile", "ask_each_time"],
        "what_this_can_change": "Selects the default platform checklist IDs when the source does not already imply one.",
        "what_this_cannot_change": "Does not merge desktop and mobile scores into one session.",
    },
    {
        "question_id": "onboarding_optional_profiles",
        "field": "optional_profiles",
        "question": "Which optional heuristic profiles should be included by default?",
        "widget_question_type": "multi-select",
        "options": ["accessibility", "inclusion", "journey", "ux_writing", "none"],
        "what_this_can_change": "Adds opt-in H11-H14 profile scores and expanded grade fields.",
        "what_this_cannot_change": "Does not alter the H1-H10 core UX health grade.",
    },
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def state_dir() -> Path:
    configured = os.environ.get("UXHC_STATE_DIR")
    if configured:
        root = Path(configured).expanduser()
    else:
        root = Path.home() / ".local" / "share" / "ux-heuristic-compass" / "state"
    root.mkdir(parents=True, exist_ok=True)
    (root / "agent_runs").mkdir(parents=True, exist_ok=True)
    (root / "audit_checkpoints").mkdir(parents=True, exist_ok=True)
    (root / "issue_exports").mkdir(parents=True, exist_ok=True)
    (root / "report_payloads").mkdir(parents=True, exist_ok=True)
    (root / "reports").mkdir(parents=True, exist_ok=True)
    return root


def preferences_path(user_id: str = DEFAULT_USER_ID) -> Path:
    safe = _safe_id(user_id or DEFAULT_USER_ID)
    return state_dir() / f"preferences-{safe}.json"


def agent_run_path(agent_run_id: str) -> Path:
    return state_dir() / "agent_runs" / f"{_safe_id(agent_run_id)}.json"


def audit_checkpoint_path(resume_run_id: str) -> Path:
    return state_dir() / "audit_checkpoints" / f"{_safe_id(resume_run_id)}.json"


def report_payload_path(payload_id: str) -> Path:
    return state_dir() / "report_payloads" / f"{_safe_id(payload_id)}.json"


def report_artifact_path(report_id: str, suffix: str = ".md") -> Path:
    normalized_suffix = suffix if suffix.startswith(".") else f".{suffix}"
    return state_dir() / "reports" / f"{_safe_id(report_id)}{normalized_suffix}"


def issue_export_path(export_id: str, suffix: str = ".json") -> Path:
    normalized_suffix = suffix if suffix.startswith(".") else f".{suffix}"
    return state_dir() / "issue_exports" / f"{_safe_id(export_id)}{normalized_suffix}"


def _safe_id(value: str) -> str:
    allowed = [char if char.isalnum() or char in {"_", "-"} else "_" for char in value]
    return "".join(allowed).strip("_") or DEFAULT_USER_ID


def load_preferences(user_id: str = DEFAULT_USER_ID) -> dict[str, Any] | None:
    path = preferences_path(user_id)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def onboarding_contract(user_id: str = DEFAULT_USER_ID) -> dict[str, Any]:
    preference_record = load_preferences(user_id)
    if preference_record:
        return {
            "schema_version": "uxhc.onboarding.v1",
            "onboarding_required": False,
            "onboarding_status": "complete",
            "user_id": user_id or DEFAULT_USER_ID,
            "preferences_summary": {
                "ux_level": preference_record.get("ux_level"),
                "hil_default": preference_record.get("hil_default"),
                "agent_default": preference_record.get("agent_default"),
                "platform_default": preference_record.get("platform_default"),
                "optional_profiles": preference_record.get("optional_profiles") or [],
            },
            "quick_scan_mode_guidance": "quick_scan_ux without output_detail asks the host to choose guidance_only, status_only, compact, or full; use guidance_only for tiny non-scored refinement help.",
            "next_tool": "update_preferences",
        }
    return {
        "schema_version": "uxhc.onboarding.v1",
        "onboarding_required": True,
        "onboarding_status": "required",
        "user_id": user_id or DEFAULT_USER_ID,
        "questions": ONBOARDING_QUESTIONS,
        "next_tool": "save_preferences",
        "partial_exit_policy": "Incomplete onboarding writes no preference record and re-triggers on the next audit attempt.",
        "quick_scan_mode_guidance": "quick_scan_ux without output_detail asks the host to choose guidance_only, status_only, compact, or full; use guidance_only for tiny non-scored refinement help.",
    }


def save_preferences(
    *,
    user_id: str = DEFAULT_USER_ID,
    ux_level: str | None = None,
    hil_default: str | None = None,
    agent_default: str | None = None,
    platform_default: str | None = None,
    optional_profiles: list[str] | str | None = None,
) -> dict[str, Any]:
    missing = []
    if not ux_level:
        missing.append("ux_level")
    if not hil_default:
        missing.append("hil_default")
    if not agent_default:
        missing.append("agent_default")
    if not platform_default:
        missing.append("platform_default")
    if optional_profiles is None:
        missing.append("optional_profiles")

    accepted_profiles, rejected_profiles = normalize_profiles(optional_profiles)
    invalid: list[str] = []
    ux = (ux_level or "").lower()
    hil = (hil_default or "").lower()
    agent = (agent_default or "").lower()
    platform = (platform_default or "").lower()
    if ux and ux not in VALID_UX_LEVELS:
        invalid.append("ux_level")
    if hil and hil not in VALID_HIL_DEFAULTS:
        invalid.append("hil_default")
    if agent and agent not in VALID_AGENT_DEFAULTS:
        invalid.append("agent_default")
    if platform and platform not in VALID_PLATFORM_DEFAULTS:
        invalid.append("platform_default")
    if rejected_profiles:
        invalid.append("optional_profiles")

    if missing or invalid:
        return {
            "schema_version": PREFERENCES_SCHEMA_VERSION,
            "status": "incomplete",
            "saved": False,
            "preference_record": None,
            "missing_fields": missing,
            "invalid_fields": invalid,
            "rejected_optional_profiles": rejected_profiles,
            "partial_onboarding_policy": "No preference record was written. Re-trigger onboarding on the next audit attempt.",
        }

    now = utc_now()
    record = {
        "user_id": user_id or DEFAULT_USER_ID,
        "schema_version": PREFERENCES_SCHEMA_VERSION,
        "ux_level": ux,
        "hil_default": hil,
        "agent_default": agent,
        "platform_default": platform if platform == "ask_each_time" else normalize_platform(platform),
        "optional_profiles": accepted_profiles,
        "created_at": now,
        "updated_at": now,
    }
    path = preferences_path(user_id)
    existing = load_preferences(user_id)
    if existing and existing.get("created_at"):
        record["created_at"] = existing["created_at"]
    path.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
    return {
        "schema_version": PREFERENCES_SCHEMA_VERSION,
        "status": "saved",
        "saved": True,
        "preference_record": record,
        "path": str(path),
    }


def update_preferences(user_id: str = DEFAULT_USER_ID, **updates: Any) -> dict[str, Any]:
    existing = load_preferences(user_id)
    if existing is None:
        return {
            "schema_version": PREFERENCES_SCHEMA_VERSION,
            "status": "not_found",
            "updated": False,
            "error": "preferences_not_found",
            "next_action": "Run save_preferences with a complete onboarding record first.",
        }
    merged = dict(existing)
    changed: list[str] = []
    for key in ("ux_level", "hil_default", "agent_default", "platform_default", "optional_profiles"):
        if key in updates and updates[key] is not None:
            merged[key] = updates[key]
            changed.append(key)
    result = save_preferences(
        user_id=user_id,
        ux_level=merged.get("ux_level"),
        hil_default=merged.get("hil_default"),
        agent_default=merged.get("agent_default"),
        platform_default=merged.get("platform_default"),
        optional_profiles=merged.get("optional_profiles"),
    )
    result["updated"] = result.get("saved", False)
    result["changed_fields"] = changed if result.get("saved") else []
    return result


def save_agent_run(agent_run: dict[str, Any]) -> dict[str, Any]:
    agent_run_id = str(agent_run.get("agent_run_id") or "")
    if not agent_run_id:
        raise ValueError("agent_run_id is required")
    path = agent_run_path(agent_run_id)
    path.write_text(json.dumps(agent_run, indent=2, sort_keys=True), encoding="utf-8")
    return {"agent_run_id": agent_run_id, "path": str(path), "persisted": True}


def get_agent_run(agent_run_id: str) -> dict[str, Any]:
    if not agent_run_id or any(char in agent_run_id for char in {"/", "\\"}):
        return {"schema_version": STATE_SCHEMA_VERSION, "status": "error", "error": "invalid_agent_run_id"}
    path = agent_run_path(agent_run_id)
    if not path.exists():
        return {"schema_version": STATE_SCHEMA_VERSION, "status": "error", "error": "run_not_found", "agent_run_id": agent_run_id}
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {"schema_version": STATE_SCHEMA_VERSION, "status": "error", "error": "invalid_agent_run_record", "agent_run_id": agent_run_id}
    expires_at = record.get("expires_at")
    if expires_at:
        try:
            expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
            if expiry < datetime.now(timezone.utc):
                return {"schema_version": STATE_SCHEMA_VERSION, "status": "error", "error": "run_expired", "agent_run_id": agent_run_id}
        except ValueError:
            return {"schema_version": STATE_SCHEMA_VERSION, "status": "error", "error": "invalid_agent_run_record", "agent_run_id": agent_run_id}
    return {"schema_version": STATE_SCHEMA_VERSION, "status": "ready", "agent_run": record, "path": str(path)}
