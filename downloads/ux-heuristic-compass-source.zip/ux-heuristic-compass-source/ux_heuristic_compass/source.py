from __future__ import annotations

import hashlib
import html
import json
import re
import shutil
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from .evidence import adapter_evidence_summary, build_evidence_graph
from .tracing import attach_run_summary


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff"}
MAX_URLS = 10
CHROME_APP_BINARY = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _stable_id(prefix: str, value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=True, sort_keys=True, default=str).encode("utf-8")
    return f"{prefix}_{hashlib.sha256(encoded).hexdigest()[:12]}"


def _as_list(value: str | list[str] | tuple[str, ...] | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return [str(item) for item in value]


def _as_raw_list(value: Any) -> list[Any]:
    if value in (None, "", []):
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    if isinstance(value, dict) and isinstance(value.get("items"), list):
        return list(value["items"])
    return [value]


def _is_url(value: str) -> bool:
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _slug(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", value.lower()).strip("-")
    return slug[:60] or "capture"


def _state_match_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _hint_refs(value: Any) -> list[str]:
    if value in (None, "", []):
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple)):
        return [str(item) for item in value if item not in (None, "")]
    return [str(value)]


def _state_capture_tokens(items: list[dict[str, Any]], evidence_refs: list[dict[str, Any]]) -> set[str]:
    tokens: set[str] = set()
    for item in items:
        for key in ("item_id", "state_label", "page_title", "url", "input_path", "screenshot_path"):
            normalized = _state_match_key(item.get(key))
            if normalized:
                tokens.add(normalized)
    for ref in evidence_refs:
        for key in ("evidence_ref", "item_id", "label", "state_label"):
            normalized = _state_match_key(ref.get(key))
            if normalized:
                tokens.add(normalized)
    return tokens


def _normalize_interactive_state_hints(
    hints: Any,
    *,
    items: list[dict[str, Any]],
    evidence_refs: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    raw_hints = _as_raw_list(hints)
    if not raw_hints:
        return [], []

    capture_tokens = _state_capture_tokens(items, evidence_refs)
    evidence_ref_values = {str(ref.get("evidence_ref")) for ref in evidence_refs if ref.get("evidence_ref")}
    normalized_hints: list[dict[str, Any]] = []
    warnings: list[dict[str, str]] = []

    for index, raw in enumerate(raw_hints, start=1):
        if isinstance(raw, dict):
            label = str(raw.get("label") or raw.get("name") or raw.get("state_label") or raw.get("state_id") or f"state {index}").strip()
            state_id = str(raw.get("state_id") or raw.get("id") or _slug(label) or f"state-{index}").strip()
            state_type = str(raw.get("state_type") or raw.get("type") or "interactive_state").strip()
            trigger = str(raw.get("trigger") or raw.get("interaction") or raw.get("selector") or "").strip()
            source_ref = str(raw.get("source_ref") or raw.get("item_id") or raw.get("url") or "").strip()
            refs = _hint_refs(raw.get("evidence_refs") or raw.get("evidence_ref") or raw.get("ref"))
            notes = str(raw.get("notes") or raw.get("note") or raw.get("description") or "").strip()
        else:
            label = str(raw).strip() or f"state {index}"
            state_id = _slug(label) or f"state-{index}"
            state_type = "interactive_state"
            trigger = ""
            source_ref = ""
            refs = []
            notes = ""

        candidate_tokens = {
            _state_match_key(value)
            for value in [label, state_id, trigger, source_ref, *refs]
            if _state_match_key(value)
        }
        matched_refs = [ref for ref in refs if ref in evidence_ref_values]
        captured = bool(candidate_tokens & capture_tokens or matched_refs)
        capture_status = "captured" if captured else "hinted_not_captured"
        hint = {
            "state_id": state_id,
            "label": label,
            "state_type": state_type,
            "trigger": trigger,
            "source_ref": source_ref,
            "evidence_refs": refs,
            "capture_status": capture_status,
            "notes": notes,
            "score_authority": "evidence_limit_only" if not captured else "source_evidence",
        }
        normalized_hints.append(hint)
        if not captured:
            warnings.append(
                {
                    "code": "interactive_state_not_captured",
                    "message": f"Interactive state hint '{label}' was not matched to supplied state_labels or evidence refs; include a bounded rendered capture or carry this as an evidence limit.",
                }
            )

    return normalized_hints, warnings


def _viewport(value: str | dict[str, Any] | None) -> dict[str, Any]:
    if isinstance(value, dict):
        return {
            "device_class": value.get("device_class") or value.get("name") or "custom",
            "width": value.get("width"),
            "height": value.get("height"),
            "scale": value.get("scale", 1),
        }
    label = (value or "desktop").lower()
    if label == "mobile":
        return {"device_class": "mobile", "width": 390, "height": 844, "scale": 2}
    if label == "tablet":
        return {"device_class": "tablet", "width": 820, "height": 1180, "scale": 2}
    return {"device_class": "desktop", "width": 1440, "height": 1000, "scale": 1}


def _handoff_template() -> dict[str, Any]:
    return {
        "required": False,
        "performed": False,
        "status": "not_required",
        "automation_processes_remaining": [],
        "ownership_scope": "uxhc_temp_profile_only",
        "external_automation_policy": "UXHC only owns Chrome processes launched with its own uxhc-chrome-profile temp profile. External Playwright/Chrome sessions are advisory only and must not be killed by UXHC cleanup.",
        "external_automation_detected": [],
        "external_automation_blocking": False,
    }


def prepare_ux_source(
    sources: str | list[str] | tuple[str, ...] | None = None,
    *,
    source_type: str = "auto",
    viewport: str | dict[str, Any] | None = "desktop",
    task_flow: str | None = None,
    max_pages: int = MAX_URLS,
    visible_text_summaries: list[str] | str | None = None,
    state_labels: list[str] | str | None = None,
    capture_urls: bool = False,
    output_dir: str | None = None,
    render_wait_ms: int | str = 1000,
    external_evidence: Any = None,
    evidence_regions: Any = None,
    interactive_state_hints: Any = None,
) -> dict[str, Any]:
    """Prepare screenshots/images/URL references into a bounded source manifest.

    URL entries are capped at 1-10 explicit pages. By default they stay as
    deferred capture requests; `capture_urls=True` performs bounded
    screenshot/text capture without crawling, auth flows, or autonomous
    navigation.
    """

    source_values = _as_list(sources)
    text_summaries = _as_list(visible_text_summaries)
    labels = _as_list(state_labels)
    viewport_data = _viewport(viewport)
    warnings: list[dict[str, str]] = []
    items: list[dict[str, Any]] = []
    evidence_refs: list[dict[str, Any]] = []
    browser_handoff: dict[str, Any] = _handoff_template()

    if max_pages < 1:
        max_pages = 1
    requested_max_pages = max_pages
    bounded_max = min(max_pages, MAX_URLS)
    wait_ms = _bounded_wait_ms(render_wait_ms)
    if requested_max_pages > MAX_URLS:
        warnings.append(
            {
                "code": "max_pages_capped",
                "message": f"Requested max_pages={requested_max_pages}; UXHC bounded URL capture is capped at {MAX_URLS} explicit pages.",
            }
        )

    url_count = sum(1 for item in source_values if _is_url(item))
    if url_count > bounded_max:
        warnings.append(
            {
                "code": "url_limit_applied",
                "message": f"URL capture is bounded to {bounded_max} explicit pages; UXHC does not crawl, authenticate, or discover additional pages.",
            }
        )

    kept_urls = 0
    for index, raw in enumerate(source_values, start=1):
        summary = text_summaries[index - 1] if index - 1 < len(text_summaries) else ""
        state_label = labels[index - 1] if index - 1 < len(labels) else None
        if _is_url(raw):
            kept_urls += 1
            if kept_urls > bounded_max:
                continue
            item_id = f"url-{kept_urls}"
            if capture_urls:
                item, handoff = _capture_url_source(
                    raw,
                    item_id=item_id,
                    viewport=viewport_data,
                    state_label=state_label,
                    fallback_summary=summary,
                    output_dir=output_dir,
                    render_wait_ms=wait_ms,
                )
                browser_handoff = _merge_handoff(browser_handoff, handoff)
            else:
                item = {
                    "item_id": item_id,
                    "source_type": "url_capture",
                    "url": raw,
                    "input_path": None,
                    "viewport": viewport_data,
                    "screenshot_path": None,
                    "visible_text_summary": summary,
                    "page_title": None,
                    "state_label": state_label,
                    "quality": "partial",
                    "warnings": [
                        {
                            "code": "deferred_capture",
                            "message": "URL was recorded as a bounded capture request; no browser capture was performed by this tool.",
                        }
                    ],
                }
        else:
            path = Path(raw).expanduser()
            suffix = path.suffix.lower()
            item_id = f"img-{len([item for item in items if item['source_type'] == 'screenshot']) + 1}"
            item_warnings: list[dict[str, str]] = []
            quality = "ready"
            if not path.exists():
                quality = "blocked"
                item_warnings.append({"code": "missing_file", "message": f"File does not exist: {path}"})
            elif suffix not in IMAGE_EXTENSIONS:
                quality = "blocked"
                item_warnings.append({"code": "unsupported_file", "message": f"Unsupported screenshot/image extension: {suffix or '<none>'}"})
            item = {
                "item_id": item_id,
                "source_type": "screenshot",
                "url": None,
                "input_path": str(path),
                "viewport": viewport_data,
                "screenshot_path": str(path) if quality != "blocked" else None,
                "visible_text_summary": summary,
                "page_title": None,
                "state_label": state_label,
                "quality": quality,
                "warnings": item_warnings,
            }
        items.append(item)
        evidence_refs.append(
            {
                "evidence_ref": item["item_id"],
                "item_id": item["item_id"],
                "source_type": item["source_type"],
                "label": item.get("state_label") or item.get("url") or item.get("input_path"),
                "quality": item["quality"],
            }
        )

    if not source_values:
        warnings.append({"code": "no_sources", "message": "No screenshot, image, or URL source was provided."})

    normalized_state_hints, state_hint_warnings = _normalize_interactive_state_hints(
        interactive_state_hints,
        items=items,
        evidence_refs=evidence_refs,
    )
    warnings.extend(state_hint_warnings)
    captured_hint_count = sum(1 for hint in normalized_state_hints if hint.get("capture_status") == "captured")

    ready_count = sum(1 for item in items if item["quality"] == "ready")
    partial_count = sum(1 for item in items if item["quality"] == "partial")
    blocked_count = sum(1 for item in items if item["quality"] == "blocked")
    if ready_count == 0 and partial_count == 0:
        status = "blocked"
    elif blocked_count or partial_count:
        status = "partial"
    else:
        status = "ready"

    payload_seed = {
        "sources": source_values,
        "viewport": viewport_data,
        "task_flow": task_flow,
        "created_at": _utc_now(),
    }
    source_id = _stable_id("uxsrc", payload_seed)

    browser_handoff["external_automation_detected"] = _external_automation_processes()
    browser_handoff["external_automation_blocking"] = False

    result = {
        "schema_version": "v1",
        "source_id": source_id,
        "source_type": source_type,
        "created_at": payload_seed["created_at"],
        "status": status,
        "task_flow": task_flow,
        "items": items,
        "evidence_refs": evidence_refs,
        "warnings": warnings,
        "interactive_state_hints": normalized_state_hints,
        "interactive_state_summary": {
            "schema_version": "uxhc.interactive_state_summary.v1",
            "supplied_hint_count": len(normalized_state_hints),
            "captured_hint_count": captured_hint_count,
            "uncaptured_hint_count": max(0, len(normalized_state_hints) - captured_hint_count),
            "policy": "Host-supplied bounded state hints only; UXHC does not click, crawl, or discover hidden states in this path.",
        },
        "capture_policy": {
            "requested_max_pages": requested_max_pages,
            "effective_max_pages": bounded_max,
            "max_pages": bounded_max,
            "full_site_crawling": False,
            "authenticated_flows": False,
            "autonomous_browser_agent": False,
            "browser_capture_performed": browser_handoff["performed"],
            "render_wait_ms": wait_ms,
            "interactive_state_hints_supported": True,
        },
        "browser_handoff": browser_handoff,
    }
    evidence_graph = build_evidence_graph(result, external_evidence=external_evidence, evidence_regions=evidence_regions)
    result["evidence_graph"] = evidence_graph
    result["adapter_evidence_summary"] = adapter_evidence_summary(evidence_graph)
    return attach_run_summary(
        result,
        "prepare_ux_source",
        inputs_summary={
            "source_count": len(source_values),
            "source_type": source_type,
            "capture_urls": bool(capture_urls),
            "requested_max_pages": requested_max_pages,
        },
    )


def _capture_url_source(
    url: str,
    *,
    item_id: str,
    viewport: dict[str, Any],
    state_label: str | None,
    fallback_summary: str,
    output_dir: str | None,
    render_wait_ms: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    output_root = Path(output_dir).expanduser() if output_dir else Path(tempfile.mkdtemp(prefix="uxhc-captures-"))
    output_root.mkdir(parents=True, exist_ok=True)
    capture_dir = output_root / f"{item_id}-{_slug(urlparse(url).netloc + '-' + urlparse(url).path)}"
    capture_dir.mkdir(parents=True, exist_ok=True)

    page_title, visible_text, fetch_warning = _fetch_url_text(url)
    screenshot_path = capture_dir / "screenshot.png"
    html_path = capture_dir / "source.html"
    metadata_path = capture_dir / "capture-metadata.json"
    warnings: list[dict[str, str]] = []
    if fetch_warning:
        warnings.append(fetch_warning)
    if visible_text:
        html_path.write_text(visible_text, encoding="utf-8")

    handoff = _handoff_template()
    handoff.update({"required": True, "status": "not_started", "temp_profile": None})
    chrome_command = _chrome_command_prefix()
    if chrome_command:
        with tempfile.TemporaryDirectory(prefix="uxhc-chrome-profile-") as profile_dir:
            handoff["temp_profile"] = profile_dir
            command = [
                *chrome_command,
                "--headless=new",
                "--disable-gpu",
                "--disable-extensions",
                "--disable-background-networking",
                "--disable-component-update",
                "--disable-sync",
                "--hide-scrollbars",
                "--run-all-compositor-stages-before-draw",
                "--no-first-run",
                "--no-default-browser-check",
                "--use-mock-keychain",
                f"--virtual-time-budget={render_wait_ms}",
                f"--user-data-dir={profile_dir}",
                f"--window-size={int(viewport.get('width') or 1440)},{int(viewport.get('height') or 1000)}",
                f"--screenshot={screenshot_path}",
                url,
            ]
            _returncode, error_text = _run_chrome_screenshot(command, screenshot_path)
            handoff["performed"] = True
            remaining = _automation_processes(profile_dir)
            handoff["automation_processes_remaining"] = remaining
            handoff["status"] = "verified" if not remaining else "warning_processes_remaining"
            if not screenshot_path.exists():
                warnings.append(
                    {
                        "code": "browser_screenshot_failed",
                        "message": (error_text or "Headless Chrome did not produce a screenshot.")[:500],
                    }
                )
    else:
        handoff["status"] = "browser_unavailable"
        warnings.append({"code": "browser_unavailable", "message": "Google Chrome binary was not found; captured URL text only."})

    loading_warning = _loading_state_warning(page_title, visible_text)
    if loading_warning:
        warnings.append(loading_warning)
    quality = "ready" if screenshot_path.exists() or visible_text else "blocked"
    summary = fallback_summary or _summarize_visible_text(visible_text)
    metadata = {
        "url": url,
        "page_title": page_title,
        "viewport": viewport,
        "screenshot_path": str(screenshot_path) if screenshot_path.exists() else None,
        "visible_text_summary": summary,
        "browser_handoff": handoff,
        "warnings": warnings,
    }
    metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")
    return (
        {
            "item_id": item_id,
            "source_type": "url_capture",
            "url": url,
            "input_path": None,
            "viewport": viewport,
            "screenshot_path": str(screenshot_path) if screenshot_path.exists() else None,
            "visible_text_summary": summary,
            "page_title": page_title,
            "state_label": state_label,
            "quality": quality,
            "warnings": warnings,
            "capture_metadata_path": str(metadata_path),
        },
        handoff,
)


def _bounded_wait_ms(value: int | str) -> int:
    try:
        wait_ms = int(value)
    except (TypeError, ValueError):
        wait_ms = 1000
    return max(0, min(wait_ms, 10000))


def _loading_state_warning(page_title: str | None, visible_text: str | None) -> dict[str, str] | None:
    combined = f"{page_title or ''} {visible_text or ''}".lower()
    loading_tokens = ["loading |", "loading...", "loading", "app-root", "ng-version", "__next", "data-reactroot"]
    if any(token in combined for token in loading_tokens):
        return {
            "code": "client_rendered_or_loading_state",
            "message": "This URL may be a client-rendered app or loading state. Use Playwright/manual rendered evidence before final scoring if the screenshot does not show the usable interface.",
        }
    return None


def _fetch_url_text(url: str) -> tuple[str | None, str, dict[str, str] | None]:
    try:
        request = Request(url, headers={"User-Agent": "UXHeuristicCompass/0.1 local capture"})
        with urlopen(request, timeout=12) as response:
            content_type = response.headers.get("content-type", "")
            raw = response.read(500_000)
        encoding = "utf-8"
        match = re.search(r"charset=([^;]+)", content_type, flags=re.I)
        if match:
            encoding = match.group(1).strip()
        text = raw.decode(encoding, errors="replace")
    except Exception as exc:
        return None, "", {"code": "url_fetch_failed", "message": f"Could not fetch URL text: {exc}"}

    title_match = re.search(r"<title[^>]*>(.*?)</title>", text, flags=re.I | re.S)
    title = html.unescape(re.sub(r"\s+", " ", title_match.group(1)).strip()) if title_match else None
    visible = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", text)
    visible = re.sub(r"(?s)<[^>]+>", " ", visible)
    visible = html.unescape(re.sub(r"\s+", " ", visible)).strip()
    return title, visible[:8000], None


def _summarize_visible_text(text: str) -> str:
    if not text:
        return ""
    return text[:360].strip()


def _chrome_command_prefix() -> list[str] | None:
    if Path(CHROME_APP_BINARY).exists():
        arch = shutil.which("arch")
        if arch:
            return [arch, "-arm64", CHROME_APP_BINARY]
        return [CHROME_APP_BINARY]
    binary = shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chrome")
    return [binary] if binary else None


def _run_chrome_screenshot(command: list[str], screenshot_path: Path) -> tuple[int, str]:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    deadline = time.time() + 30
    screenshot_seen_at: float | None = None
    while time.time() < deadline:
        status = process.poll()
        if status is not None:
            stdout, stderr = process.communicate(timeout=1)
            return status, (stderr or stdout or "").strip()
        if screenshot_path.exists() and screenshot_seen_at is None:
            screenshot_seen_at = time.time()
        if screenshot_seen_at is not None and time.time() - screenshot_seen_at > 0.75:
            process.terminate()
            try:
                stdout, stderr = process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate(timeout=2)
            return 0, (stderr or stdout or "").strip()
        time.sleep(0.1)

    process.kill()
    stdout, stderr = process.communicate(timeout=2)
    return 124, (stderr or stdout or "Headless Chrome timed out before producing a screenshot.").strip()


def _automation_processes(profile_dir: str) -> list[str]:
    try:
        result = subprocess.run(["ps", "-axo", "pid,args"], capture_output=True, text=True, timeout=5, check=False)
    except Exception:
        return ["process_check_failed"]
    return [line.strip() for line in result.stdout.splitlines() if profile_dir in line]


def _external_automation_processes(profile_dir: str | None = None) -> list[str]:
    try:
        result = subprocess.run(["ps", "-axo", "pid,args"], capture_output=True, text=True, timeout=5, check=False)
    except Exception:
        return []
    tokens = ["ms-playwright", "playwright", "--remote-debugging-port", "--headless"]
    lines: list[str] = []
    for line in result.stdout.splitlines():
        stripped = line.strip()
        lower = stripped.lower()
        if profile_dir and profile_dir in stripped:
            continue
        if "uxhc-chrome-profile-" in stripped:
            continue
        if any(token in lower for token in tokens):
            lines.append(stripped)
    return lines[:10]


def _merge_handoff(current: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    remaining = list(current.get("automation_processes_remaining") or []) + list(new.get("automation_processes_remaining") or [])
    external = list(current.get("external_automation_detected") or []) + list(new.get("external_automation_detected") or [])
    return {
        "required": bool(current.get("required") or new.get("required")),
        "performed": bool(current.get("performed") or new.get("performed")),
        "status": "verified" if not remaining and (current.get("performed") or new.get("performed")) else new.get("status", current.get("status", "not_required")),
        "automation_processes_remaining": remaining,
        "ownership_scope": "uxhc_temp_profile_only",
        "external_automation_policy": current.get("external_automation_policy") or new.get("external_automation_policy") or _handoff_template()["external_automation_policy"],
        "external_automation_detected": external[:10],
        "external_automation_blocking": False,
    }
