from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from .behavior import build_behavior_fields, build_human_loop_host_action
from .rubric import CORE_HEURISTICS, get_active_checklist_items, heuristic_by_id, infer_heuristic, infer_platform_from_source, normalize_profiles
from .scoring import SEVERITY_LABELS, rating_label, score_checklist_ratings
from .source import prepare_ux_source
from .state import load_preferences, onboarding_contract, report_payload_path


AUDIT_ENGINE_VERSION = "uxhc-v2-checklist"
PRIMARY_BEHAVIOR_KEYS = [
    "top_finding",
    "plain_language_read",
    "before_using_this_interface",
    "one_recommendation",
    "overall_grade",
    "overall_percentage",
    "overall_descriptor",
]
PROFILE_HEURISTIC_MAP = {
    "accessibility": {"heuristic_id": "h11", "heuristic_name": "Accessibility and Ease of Access"},
    "inclusion": {"heuristic_id": "h12", "heuristic_name": "Empathetic Engagement and Inclusion"},
    "journey": {"heuristic_id": "h13", "heuristic_name": "Customer Journey and Satisfaction"},
    "ux_writing": {"heuristic_id": "h14", "heuristic_name": "UX Writing and Content Design"},
}
OPTIONAL_PROFILE_ORDER = ["accessibility", "inclusion", "journey", "ux_writing"]
OPTIONAL_PROFILE_MODES = {"core_only", "scoped", "all_optionals", "ask"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _split_behavior_fields(fields: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    primary = {key: fields[key] for key in PRIMARY_BEHAVIOR_KEYS if key in fields}
    support = {key: value for key, value in fields.items() if key not in primary}
    return primary, support


PROFILE_ALIASES = {
    "content_strategy": "ux_writing",
    "content_strategy_profile": "ux_writing",
    "content": "ux_writing",
    "content_tone": "ux_writing",
    "ux_content": "ux_writing",
    "microcopy": "ux_writing",
    "copy": "ux_writing",
    "copywriting": "ux_writing",
    "customer_experience": "journey",
    "cx": "journey",
    "empathy": "inclusion",
}


def _raw_profile_list(profiles: list[str] | str | None) -> list[str]:
    if profiles is None or profiles == "":
        return []
    if isinstance(profiles, str):
        return [part.strip() for part in profiles.replace(",", " ").split() if part.strip()]
    return [str(part).strip() for part in profiles if str(part).strip()]


def _profile_contract(accepted: list[str], rejected: list[str], requested_profiles: list[str] | str | None) -> dict[str, Any]:
    inactive = [profile for profile in PROFILE_HEURISTIC_MAP if profile not in accepted]
    suggestions = []
    for profile in rejected:
        key = str(profile).lower().replace("-", "_")
        if key in PROFILE_ALIASES:
            suggested = PROFILE_ALIASES[key]
            suggestions.append({"rejected": profile, "suggested_profile": suggested, "heuristic_id": PROFILE_HEURISTIC_MAP[suggested]["heuristic_id"]})
    normalized = []
    for profile in _raw_profile_list(requested_profiles):
        key = str(profile).lower().replace("-", "_")
        if key in PROFILE_ALIASES and PROFILE_ALIASES[key] in accepted:
            normalized.append({"requested": profile, "normalized_to": PROFILE_ALIASES[key], "heuristic_id": PROFILE_HEURISTIC_MAP[PROFILE_ALIASES[key]]["heuristic_id"]})
    return {
        "accepted": accepted,
        "rejected": rejected,
        "normalized_profiles": normalized,
        "profile_to_heuristic": PROFILE_HEURISTIC_MAP,
        "inactive_optional_profiles": [
            {
                "profile": profile,
                **PROFILE_HEURISTIC_MAP[profile],
                "activation": f'Add "{profile}" to profiles to include {PROFILE_HEURISTIC_MAP[profile]["heuristic_id"]}.',
            }
            for profile in inactive
        ],
        "suggestions": suggestions,
        "note": "Optional profiles add H11-H14 to the active checklist; rejected donor/conversion profiles remain excluded from the baseline rubric.",
    }


def _resolve_optional_profile_scope(
    *,
    accepted_profiles: list[str],
    optional_profile_mode: str | None,
    full_advanced: bool | None,
) -> tuple[list[str], str]:
    mode = str(optional_profile_mode or "scoped").strip().lower()
    if mode not in OPTIONAL_PROFILE_MODES:
        mode = "scoped"
    if full_advanced and set(accepted_profiles) != set(OPTIONAL_PROFILE_ORDER):
        mode = "ask"
    if mode == "core_only":
        return [], mode
    if mode == "all_optionals":
        return list(OPTIONAL_PROFILE_ORDER), mode
    return accepted_profiles, mode


def _profile_card(profile: str) -> dict[str, Any]:
    return {"profile": profile, **PROFILE_HEURISTIC_MAP[profile]}


def _heuristic_scope_cards(platform: str, accepted_profiles: list[str]) -> list[dict[str, Any]]:
    cards = [
        {
            "heuristic_id": heuristic["id"],
            "heuristic_name": heuristic["name"],
            "profile": "core",
            "platform": platform,
        }
        for heuristic in CORE_HEURISTICS
    ]
    for profile in accepted_profiles:
        info = PROFILE_HEURISTIC_MAP[profile]
        cards.append(
            {
                "heuristic_id": info["heuristic_id"],
                "heuristic_name": info["heuristic_name"],
                "profile": profile,
                "platform": platform,
            }
        )
    return cards


def _audit_scope_lock(
    *,
    platform: str,
    accepted_profiles: list[str],
    optional_profile_mode: str,
    full_advanced: bool | None,
    mode: str,
) -> dict[str, Any]:
    omitted = [profile for profile in OPTIONAL_PROFILE_ORDER if profile not in accepted_profiles]
    scored_optional = [_profile_card(profile) for profile in accepted_profiles]
    omitted_optional = [
        {
            **_profile_card(profile),
            "activation": f'Rerun with "{profile}" in profiles or optional_profile_mode="all_optionals" to include {PROFILE_HEURISTIC_MAP[profile]["heuristic_id"]}.',
        }
        for profile in omitted
    ]
    confirmation_required = bool((optional_profile_mode == "ask" or full_advanced) and omitted)
    if optional_profile_mode == "core_only":
        status = "core_only"
    elif not omitted:
        status = "all_optionals_active"
    elif confirmation_required:
        status = "confirmation_required"
    elif accepted_profiles:
        status = "scoped_partial"
    else:
        status = "core_scope_no_optionals"
    return {
        "schema_version": "uxhc.audit_scope_lock.v1",
        "status": status,
        "mode": mode,
        "optional_profile_mode": optional_profile_mode,
        "full_advanced_requested": bool(full_advanced),
        "confirmation_required": confirmation_required,
        "platform": platform,
        "scored_heuristics": _heuristic_scope_cards(platform, accepted_profiles),
        "scored_optional_profiles": scored_optional,
        "omitted_optional_profiles": omitted_optional,
        "rerun_profiles": list(OPTIONAL_PROFILE_ORDER),
        "rerun_guidance": "For a full advanced audit, rerun with optional_profile_mode='all_optionals' or profiles=['accessibility','inclusion','journey','ux_writing'].",
        "report_warning": "Optional heuristics not in scope should be named in the report so readers do not mistake the scorecard for all H1-H14 coverage.",
    }


def _large_output_guidance(payload_ref: dict[str, Any] | None) -> dict[str, Any]:
    guidance = {
        "primary_workflow": "Use compact audit output for review and pass payload_path to generate_ux_audit_report for artifact generation.",
        "jq_required": False,
    }
    if payload_ref:
        guidance["generate_report_call"] = {
            "tool": "generate_ux_audit_report",
            "arguments": {"payload_path": payload_ref.get("path"), "include_viewer": True},
        }
        guidance["payload_path"] = payload_ref.get("path")
        guidance["optional_debug_jq"] = f"jq '{{overall_grade, overall_percentage, plain_language_read, top_finding, one_recommendation}}' {payload_ref.get('path')}"
    return guidance


def _quick_hil_enabled(
    *,
    hil_enabled: bool | None,
    audit_context: dict[str, Any] | None,
    checklist_ratings: list[dict[str, Any]] | None,
    goal: str | None,
) -> bool:
    context = dict(audit_context or {})
    context_requested = bool(context.get("hil_enabled") or context.get("human_loop_requested"))
    has_context = bool(
        goal
        or context.get("goal")
        or context.get("audit_goal")
        or context.get("primary_task")
        or context.get("user_task")
        or context.get("task")
    )
    return bool(hil_enabled) or context_requested or not checklist_ratings or not has_context


def _as_observations(observations: list[Any] | str | None) -> list[dict[str, Any]]:
    if observations is None or observations == "":
        return []
    if isinstance(observations, str):
        return [{"text": observations}]
    normalized: list[dict[str, Any]] = []
    for item in observations:
        if isinstance(item, dict):
            normalized.append(dict(item))
        else:
            normalized.append({"text": str(item)})
    return normalized


def _infer_severity(text: str) -> int:
    lower = text.lower()
    if any(token in lower for token in ["blocked", "cannot", "impossible", "catastrophe", "dead end", "unusable"]):
        return 4
    if any(token in lower for token in ["major", "hidden", "unclear primary", "error", "confusing", "missing", "hard to find"]):
        return 3
    if any(token in lower for token in ["minor", "clutter", "crowded", "inconsistent", "ambiguous", "small"]):
        return 2
    if any(token in lower for token in ["cosmetic", "typo", "polish", "slight"]):
        return 1
    return 2


def _recommendation(text: str, heuristic_name: str) -> str:
    lower = text.lower()
    if "primary" in lower or "start" in lower or "cta" in lower:
        return "Make the primary next action visually dominant and label it with the user's task language."
    if "error" in lower or "invalid" in lower:
        return "Place a plain-language error message next to the affected control and state the next recovery step."
    if "hidden" in lower or "hard to find" in lower:
        return "Move the needed control or context into the visible task area and reduce dependence on memory."
    if "jargon" in lower or "label" in lower:
        return "Rewrite the label in user-facing language and keep terminology consistent across the screen."
    if "clutter" in lower or "crowded" in lower:
        return "Remove or demote secondary content so the core task and decision points are easier to scan."
    return f"Revise the interface so it better satisfies '{heuristic_name}' for the visible task."


def _finding_id(seed: str) -> str:
    return f"uxf_{hashlib.sha256(seed.encode('utf-8')).hexdigest()[:10]}"


def _checklist_finding_title(*, heuristic_id: str, checklist_text: str) -> str:
    lower = checklist_text.lower()
    if heuristic_id == "h01":
        if "value proposition" in lower:
            return "Value proposition is not clear enough"
        if "primary actions" in lower:
            return "Primary actions are not easy to identify"
        if "navigation" in lower:
            return "Current location is unclear in navigation"
        return "Page status and purpose need clearer cues"
    if heuristic_id == "h03":
        if "search" in lower:
            return "Missing search limits user control"
        if "exits" in lower or "back" in lower or "undo" in lower or "redo" in lower:
            return "Users may lack clear recovery paths"
        return "User control and recovery need strengthening"
    if heuristic_id == "h04":
        if "typographic" in lower or "spelling" in lower:
            return "Content quality may weaken trust"
        if "consistent" in lower or "standards" in lower:
            return "Inconsistent interface patterns may slow users"
        return "Consistency and trust cues need review"
    if heuristic_id == "h06":
        if "click here" in lower or "links" in lower:
            return "Link labels do not predict destinations"
        if "search suggestions" in lower or "filters" in lower:
            return "Search support may require too much recall"
        return "Interface relies too much on user memory"
    if heuristic_id == "h08":
        if "clutter" in lower or "attention" in lower or "irrelevant" in lower:
            return "Page clutter competing with primary actions"
        if "primary actions" in lower or "start" in lower:
            return "Primary action hierarchy is not clear"
        if "above the fold" in lower:
            return "Important information may appear too late"
        return "Visual hierarchy is not supporting the task"
    if heuristic_id == "h09":
        if "404" in lower:
            return "Missing-page recovery may leave users stuck"
        return "Error recovery instructions are not clear"
    if heuristic_id == "h11":
        if "operable" in lower or "touch" in lower or "keyboard" in lower:
            return "Interactive controls may exclude some users"
        if "perceivable" in lower or "alternatives" in lower:
            return "Content may not be perceivable for everyone"
        return "Surface accessibility needs targeted review"
    if heuristic_id == "h12":
        if "anxiety" in lower or "safe" in lower or "secure" in lower:
            return "Interface may increase user anxiety"
        if "control" in lower or "choice" in lower:
            return "Users may need more control and choice"
        return "Inclusion and emotional fit need review"
    if heuristic_id == "h14":
        if "calls to action" in lower or "cta" in lower:
            return "Calls to action need clearer language"
        if "jargon" in lower or "simple" in lower:
            return "Interface copy may be too hard to scan"
        if "labels" in lower:
            return "UI labels need simpler wording"
        return "UX writing needs a clarity pass"
    heuristic = heuristic_by_id(heuristic_id) or {"name": heuristic_id}
    return f"{heuristic['name']} needs targeted review"


def _checklist_recommendation(*, heuristic_id: str, checklist_text: str) -> str:
    lower = checklist_text.lower()
    if heuristic_id == "h01":
        if "value proposition" in lower:
            return "Rewrite the first-screen message so users can tell what the product offers and what to do next without extra explanation."
        if "primary actions" in lower:
            return "Make the primary action visually dominant and remove competing entry points from the first decision area."
        if "navigation" in lower:
            return "Mark the current page clearly in navigation and align link labels with destination page titles."
        return "Add clearer page titles, state cues, and primary-action emphasis so users know where they are and what is available."
    if heuristic_id == "h03":
        if "search" in lower:
            return "Add or expose search where users naturally look for it so they have a reliable recovery path."
        if "undo" in lower or "redo" in lower:
            return "Add undo or redo support for reversible actions, or clearly explain when an action cannot be reversed."
        return "Add or clarify exits, back behavior, and recovery controls so users can leave wrong paths without losing context."
    if heuristic_id == "h04":
        if "typographic" in lower or "spelling" in lower:
            return "Run a content QA pass on the affected screens and fix visible typos before stakeholder or user review."
        if "consistent" in lower or "style" in lower or "color" in lower:
            return "Standardize repeated components, labels, and visual treatments so the same action looks and behaves the same way everywhere."
        return "Audit repeated navigation, labels, components, and trust cues, then align any pattern that changes meaning across screens."
    if heuristic_id == "h06":
        if "click here" in lower or "links" in lower:
            return "Rewrite links so each label describes the destination or result before the user clicks."
        if "search suggestions" in lower or "filters" in lower:
            return "Add visible suggestions, filters, or recent choices so users can recognize options instead of remembering them."
        return "Expose the next useful choices on screen so users do not have to remember labels, paths, or previous states."
    if heuristic_id == "h08":
        if "clutter" in lower or "attention" in lower or "irrelevant" in lower:
            return "Audit the screen for competing visual elements and remove or demote anything that does not support the user's next action."
        if "primary actions" in lower or "start" in lower:
            return "Make the primary action the clearest visual starting point and reduce secondary actions around it."
        if "above the fold" in lower:
            return "Move the task-critical information above the fold and defer supporting details until after the first decision."
        return "Rework the visual hierarchy so the page guides users from the main purpose to the next action without extra scanning."
    if heuristic_id == "h09":
        if "404" in lower:
            return "Create a helpful missing-page state with plain language, search, home, and the most likely recovery links."
        return "Rewrite error messages to state what happened, what field or action is affected, and the next recovery step."
    if heuristic_id == "h11":
        if "touch" in lower or "keyboard" in lower or "operable" in lower:
            return "Check touch targets, focus access, and gesture requirements, then enlarge or simplify controls that exclude users."
        if "perceivable" in lower or "alternatives" in lower:
            return "Add text alternatives and non-color cues so critical content remains perceivable across assistive and display settings."
        return "Run a surface accessibility pass on the affected screen and fix the visible access barrier before deeper compliance review."
    if heuristic_id == "h12":
        if "anxiety" in lower or "safe" in lower or "secure" in lower:
            return "Remove pressure patterns and add calm, clear reassurance around permissions, consequences, and recovery options."
        if "control" in lower or "choice" in lower:
            return "Expose user controls for notifications, permissions, personalization, or recovery where users can find them quickly."
        return "Review the screen through emotional, cultural, and situational user contexts, then remove the highest-friction exclusion point."
    if heuristic_id == "h14":
        if "calls to action" in lower or "cta" in lower:
            return "Rewrite calls to action as specific verb-led labels and make the primary action clearly outrank secondary choices."
        if "jargon" in lower or "simple" in lower:
            return "Replace internal language with short, everyday wording that users can scan at the smallest supported viewport."
        if "labels" in lower:
            return "Shorten UI labels and test them in the narrowest viewport so the meaning stays complete and visible."
        return "Run a UX writing pass on labels, CTAs, errors, and empty states so each word helps users decide what to do next."
    heuristic = heuristic_by_id(heuristic_id) or {"name": heuristic_id}
    return f"Review the affected element against {heuristic['name']} and make the next user action clearer, safer, or easier to recover from."


def _normalize_finding(observation: dict[str, Any], index: int, default_evidence_ref: str) -> dict[str, Any]:
    text = str(observation.get("text") or observation.get("observed_issue") or observation.get("issue") or "").strip()
    heuristic = heuristic_by_id(str(observation.get("heuristic_id", ""))) if observation.get("heuristic_id") else None
    if heuristic is None:
        heuristic = infer_heuristic(text)
    severity = int(observation.get("severity", _infer_severity(text)))
    severity = max(0, min(4, severity))
    evidence_ref = str(observation.get("evidence_ref") or default_evidence_ref)
    title = str(observation.get("title") or text[:72] or f"UX observation {index}").strip()
    recommendation = str(observation.get("recommendation") or _recommendation(text, heuristic["name"]))
    confidence = str(observation.get("confidence") or "medium")
    profile = str(observation.get("profile") or heuristic.get("profile") or "core")
    return {
        "finding_id": str(observation.get("finding_id") or _finding_id(f"{index}:{text}:{heuristic['id']}")),
        "heuristic_id": heuristic["id"],
        "heuristic_name": heuristic["name"],
        "severity": severity,
        "severity_label": rating_label(severity),
        "title": title,
        "evidence_ref": evidence_ref,
        "observed_issue": text or title,
        "user_impact": str(observation.get("user_impact") or "This may increase friction, uncertainty, or effort for the visible task."),
        "recommendation": recommendation,
        "confidence": confidence,
        "source_limitations": observation.get("source_limitations") or ["Legacy observation mode: not a complete checklist-level score."],
        "profile": profile,
        "legacy_observation": True,
    }


def _findings_from_checklist(scorecard: dict[str, Any]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for rating in scorecard.get("checklist_ratings") or []:
        severity = float(rating.get("rating", 0))
        if severity <= 0:
            continue
        heuristic = heuristic_by_id(rating["heuristic_id"]) or {"name": rating["heuristic_id"], "profile": "core"}
        severity_int = int(round(severity))
        evidence_refs = rating.get("evidence_refs") or []
        evidence_ref = evidence_refs[0] if evidence_refs else rating["checklist_item_id"]
        issue = rating.get("rationale") or f"Checklist item needs attention: {rating.get('checklist_text', '')}"
        checklist_text = str(rating.get("checklist_text", ""))
        title = str(rating.get("finding_title") or "").strip() or _checklist_finding_title(heuristic_id=str(rating["heuristic_id"]), checklist_text=checklist_text)
        recommendation = str(rating.get("recommendation") or "").strip() or _checklist_recommendation(heuristic_id=str(rating["heuristic_id"]), checklist_text=checklist_text)
        findings.append(
            {
                "finding_id": _finding_id(f"{rating['checklist_item_id']}:{severity}:{issue}"),
                "checklist_item_id": rating["checklist_item_id"],
                "heuristic_id": rating["heuristic_id"],
                "heuristic_name": heuristic["name"],
                "severity": max(0, min(4, severity_int)),
                "severity_label": rating_label(severity),
                "title": title,
                "evidence_ref": evidence_ref,
                "observed_issue": issue,
                "user_impact": "This checklist item indicates measurable heuristic friction for the evaluated surface.",
                "recommendation": recommendation,
                "confidence": rating.get("confidence", "medium"),
                "source_limitations": rating.get("evidence_limits") or [],
                "profile": heuristic.get("profile", "core"),
                "legacy_observation": False,
            }
        )
    return sorted(findings, key=lambda item: (-int(item["severity"]), item["heuristic_name"], item["title"]))


def _source_summary(prepared_source: dict[str, Any]) -> dict[str, Any]:
    return {
        "source_id": prepared_source.get("source_id"),
        "status": prepared_source.get("status"),
        "item_count": len(prepared_source.get("items") or []),
        "items": [
            {
                "item_id": item.get("item_id"),
                "source_type": item.get("source_type"),
                "url": item.get("url"),
                "input_path": item.get("input_path"),
                "screenshot_path": item.get("screenshot_path"),
                "page_title": item.get("page_title"),
                "state_label": item.get("state_label"),
                "quality": item.get("quality"),
                "capture_metadata_path": item.get("capture_metadata_path"),
                "warnings": item.get("warnings") or [],
            }
            for item in prepared_source.get("items") or []
        ],
        "evidence_refs": prepared_source.get("evidence_refs") or [],
        "warnings": prepared_source.get("warnings") or [],
        "capture_policy": prepared_source.get("capture_policy") or {},
        "browser_handoff": prepared_source.get("browser_handoff") or {},
    }


def _default_ref(prepared_source: dict[str, Any]) -> str:
    evidence_refs = prepared_source.get("evidence_refs") or []
    return evidence_refs[0]["evidence_ref"] if evidence_refs else "source"


def _health_snapshot(
    *,
    display_state: str,
    source_status: str,
    findings: list[dict[str, Any]],
    scorecard: dict[str, Any] | None,
    platform: str,
) -> dict[str, Any]:
    if source_status == "blocked":
        return {
            "display_state": "insufficient_evidence",
            "platform": platform,
            "top_priority": "Source preparation is blocked; no fair heuristic score can be produced.",
            "severity_counts": {},
            "heuristic_health": [],
            "overall_label": "Insufficient evidence",
            "comparability_warning": "No usable source evidence was prepared.",
        }
    if display_state == "needs_checklist_ratings":
        return {
            "display_state": "needs_checklist_ratings",
            "platform": platform,
            "top_priority": "Checklist ratings are required before UX Health Snapshot scoring is ready.",
            "severity_counts": {},
            "heuristic_health": [],
            "overall_label": "Checklist ratings needed",
            "comparability_warning": "Observation-only output is not comparable to scored checklist audits.",
        }
    if scorecard and scorecard.get("score_status") == "scored":
        counts = {str(level): sum(1 for row in scorecard["checklist_ratings"] if int(round(float(row["rating"]))) == level) for level in range(5)}
        top = findings[0] if findings else None
        return {
            "display_state": "scored",
            "platform": platform,
            "core_quality_percentage": scorecard["core_quality_percentage"],
            "core_grade": scorecard["core_grade"],
            "core_descriptor": scorecard["core_descriptor"],
            "expanded_quality_percentage": scorecard["expanded_quality_percentage"],
            "expanded_grade": scorecard["expanded_grade"],
            "expanded_descriptor": scorecard["expanded_descriptor"],
            "overall_quality_percentage": scorecard["overall_quality_percentage"],
            "overall_grade": scorecard["overall_grade"],
            "overall_descriptor": scorecard["overall_descriptor"],
            "top_priority": f"{top['heuristic_name']}: {top['title']}" if top else "No checklist issues scored above 0.",
            "severity_counts": counts,
            "heuristic_health": [
                {
                    "heuristic_id": score["heuristic_id"],
                    "heuristic_name": score["heuristic_name"],
                    "active_item_count": score["active_item_count"],
                    "average_item_severity": score["average_item_severity"],
                    "quality_percentage": score["quality_percentage"],
                    "letter_grade": score["letter_grade"],
                    "descriptor": score["descriptor"],
                }
                for score in scorecard["heuristic_scores"]
            ],
            "overall_label": f"{scorecard['overall_grade']} - {scorecard['overall_descriptor']}",
            "comparability_warning": "",
        }
    return {
        "display_state": "profile_only",
        "platform": platform,
        "top_priority": "No scored checklist issues were supplied.",
        "severity_counts": {},
        "heuristic_health": [],
        "overall_label": "Profile only",
        "comparability_warning": "A visual or browser-capable host must provide checklist ratings for a scored audit.",
    }


def _checklist_contract(platform: str, profiles: list[str]) -> dict[str, Any]:
    items = get_active_checklist_items(platform, profiles=profiles)
    return {
        "status": "required",
        "platform": platform,
        "active_checklist_item_count": len(items),
        "required_checklist_item_ids": [item["id"] for item in items],
        "required_fields": ["checklist_item_id", "rating", "evidence_refs", "rationale", "confidence"],
        "optional_fields_filled_by_uxhc_when_possible": ["heuristic_id", "platform", "checklist_text"],
        "rating_scale": {
            "0": "no visible issue",
            "1": "minor polish/friction",
            "2": "moderate friction",
            "3": "major friction or likely task risk",
            "4": "catastrophic blocker or severe trust/recovery risk",
        },
        "example_rating": {
            "checklist_item_id": items[0]["id"] if items else "h01_d_01",
            "heuristic_id": items[0]["heuristic_id"] if items else "h01",
            "platform": platform,
            "rating": 2,
            "evidence_refs": ["img-1"],
            "rationale": "Visible evidence for the rating.",
            "confidence": "medium",
            "evidence_limits": [],
        },
    }


def _report_ready_payload(result: dict[str, Any]) -> dict[str, Any] | None:
    scorecard = result.get("scorecard") or {}
    if scorecard.get("score_status") != "scored":
        return None
    keys = [
        "schema_version",
        "tool",
        "audit_metadata",
        "goal",
        "audit_context",
        "platform",
        "mode",
        "source",
        "audit_scope_lock",
        "profiles",
        "preferences_snapshot",
        "onboarding",
        "hil_state",
        "hil_gates",
        "resolved_gates",
        "unresolved_gates",
        "hil_compliance",
        "HIL_BLOCKED_UNTIL_NATIVE_UI",
        "human_loop_host_action",
        "ux_health_snapshot",
        "scorecard",
        "heuristic_scores",
        "checklist_ratings",
        "top_finding",
        "overall_grade",
        "overall_percentage",
        "overall_descriptor",
        "plain_language_read",
        "before_using_this_interface",
        "one_recommendation",
        "top_findings",
        "findings",
        "evidence_limits",
        "next_validation_steps",
        "follow_up_activity",
        "follow_up_activity_extended",
        "reasoning_flow_suggestions",
        "evaluator_bias_advisories",
        "prioritization_flow",
        "implementation_inspection_contract",
        "implementation_evidence_summary",
        "report_readiness_contract",
    ]
    return {key: result[key] for key in keys if key in result and result[key] is not None}


def _write_report_payload_ref(payload: dict[str, Any] | None) -> dict[str, Any] | None:
    if not payload:
        return None
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, default=str).encode("utf-8")
    digest = hashlib.sha256(encoded).hexdigest()
    payload_id = f"uxhc_report_payload_{digest[:12]}"
    path = report_payload_path(payload_id)
    if not path.exists():
        path.write_bytes(encoded)
    return {
        "schema_version": "uxhc.report_payload_ref.v1",
        "payload_id": payload_id,
        "path": str(path),
        "sha256": digest,
        "use_with": "generate_ux_audit_report(payload_path=path)",
    }


def _compact_audit_response(result: dict[str, Any]) -> dict[str, Any]:
    compact_keys = [
        "schema_version",
        "tool",
        "audit_metadata",
        "goal",
        "audit_context",
        "platform",
        "mode",
        "source",
        "audit_scope_lock",
        "profiles",
        "onboarding",
        "hil_state",
        "hil_gates",
        "resolved_gates",
        "unresolved_gates",
        "hil_compliance",
        "HIL_BLOCKED_UNTIL_NATIVE_UI",
        "human_loop_host_action",
        "PAUSE_REQUIRED",
        "ux_health_snapshot",
        "scorecard",
        "heuristic_scores",
        "top_finding",
        "plain_language_read",
        "before_using_this_interface",
        "one_recommendation",
        "top_findings",
        "checklist_rating_contract",
        "evidence_limits",
        "next_validation_steps",
        "follow_up_activity",
        "follow_up_activity_extended",
        "reasoning_flow_suggestions",
        "evaluator_bias_advisories",
        "prioritization_flow",
        "implementation_inspection_contract",
        "implementation_evidence_summary",
        "report_readiness_contract",
        "report_payload_ref",
        "large_output_guidance",
    ]
    compact = {key: result[key] for key in compact_keys if key in result and result[key] is not None}
    if "scorecard" in compact:
        compact["scorecard"] = _compact_scorecard(compact["scorecard"])
    compact["output_detail"] = "compact"
    if "checklist_ratings" in result:
        compact["checklist_ratings_omitted"] = {
            "count": len(result.get("checklist_ratings") or []),
            "reason": "Compact output omits per-item rows to keep MCP context usable.",
            "access": "Use report_payload_ref.path with generate_ux_audit_report or request output_detail='full'.",
        }
    return compact


def _compact_scorecard(scorecard: dict[str, Any]) -> dict[str, Any]:
    allowed = [
        "score_status",
        "core_quality_percentage",
        "core_grade",
        "core_descriptor",
        "expanded_quality_percentage",
        "expanded_grade",
        "expanded_descriptor",
        "overall_quality_percentage",
        "overall_grade",
        "overall_descriptor",
        "active_item_count",
        "core_item_count",
        "optional_item_count",
    ]
    return {key: scorecard.get(key) for key in allowed if key in scorecard}


def _source_evidence_limits(prepared_source: dict[str, Any]) -> list[dict[str, Any]]:
    limits: list[dict[str, Any]] = []
    if prepared_source.get("status") != "ready":
        limits.append(
            {
                "checklist_item_id": "source",
                "reason": "source preparation was partial or blocked",
                "confidence_impact": "ratings may be incomplete or unavailable",
                "evaluatable": False,
            }
        )
    if any(item.get("source_type") == "url_capture" and not item.get("screenshot_path") for item in prepared_source.get("items") or []):
        limits.append(
            {
                "checklist_item_id": "source",
                "reason": "URL entries were recorded without a browser screenshot",
                "confidence_impact": "visual and interaction-state ratings are limited",
                "evaluatable": False,
            }
        )
    return limits


def _next_steps(snapshot: dict[str, Any], scorecard: dict[str, Any] | None) -> list[str]:
    if snapshot["display_state"] == "needs_checklist_ratings":
        return ["Submit checklist_ratings for every active checklist item, or use quick_scan_ux as a checklist-rating contract generator first."]
    if snapshot["display_state"] != "scored":
        return ["Supply a usable source and checklist-level ratings before generating a scored report."]
    if scorecard and any(float(row["rating"]) >= 3 for row in scorecard.get("checklist_ratings") or []):
        return ["Fix severity 3-4 checklist items first, then rerun the same source state for comparison."]
    return ["Address the highest-friction checklist items and validate with at least one representative user task."]


def _hil_is_enabled(hil_enabled: bool | None, preference_record: dict[str, Any] | None) -> bool:
    if hil_enabled is not None:
        return bool(hil_enabled)
    return (preference_record or {}).get("hil_default") == "enabled"


def _hil_gates(*, enabled: bool, display_state: str, scorecard: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not enabled:
        return []
    gates: list[dict[str, Any]] = []
    if display_state == "needs_checklist_ratings":
        gates.append(
            {
                "gate_id": "hil_gate_collect_ratings",
                "trigger": "missing_checklist_ratings",
                "heuristics_in_scope": ["all_active"],
                "prompt": "Collect or confirm checklist ratings for every active item before scoring this audit.",
                "override_allowed": False,
            }
        )
        return gates
    if scorecard and scorecard.get("score_status") == "scored":
        for score in scorecard.get("heuristic_scores") or []:
            if float(score.get("quality_percentage", 100)) < 65:
                gates.append(
                    {
                        "gate_id": f"hil_gate_below_threshold_{score['heuristic_id']}",
                        "trigger": "below_threshold",
                        "threshold": "below_b_minus",
                        "threshold_quality_percentage": 65,
                        "heuristics_in_scope": [score["heuristic_id"]],
                        "prompt": f"Review {score['heuristic_name']} before reporting because it scored below B-.",
                        "override_allowed": True,
                    }
                )
        gates.append(
            {
                "gate_id": "hil_gate_final_review",
                "trigger": "final_review",
                "heuristics_in_scope": ["all"],
                "prompt": "Review the completed scorecard. You may override any rating before the report is generated.",
                "override_allowed": True,
            }
        )
    return gates


def _extract_gate_ids(value: Any) -> set[str]:
    ids: set[str] = set()
    if value in (None, "", []):
        return ids
    if isinstance(value, str):
        ids.add(value)
        return ids
    if isinstance(value, dict):
        for key in ("gate_id", "resolved_gate_id"):
            if value.get(key):
                ids.add(str(value[key]))
        for key in ("resolved_gate_ids", "gate_ids"):
            nested = value.get(key)
            if isinstance(nested, list):
                ids.update(str(item) for item in nested if str(item))
            elif nested:
                ids.add(str(nested))
        for key in ("answers", "hil_answers"):
            ids.update(_extract_gate_ids(value.get(key)))
        return ids
    if isinstance(value, list):
        for item in value:
            ids.update(_extract_gate_ids(item))
    return ids


def _resolve_hil_gates(
    hil_gates: list[dict[str, Any]],
    *,
    hil_answers: Any = None,
    resolved_gate_ids: list[str] | str | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    resolved_ids = _extract_gate_ids(resolved_gate_ids) | _extract_gate_ids(hil_answers)
    if "hil_gate_batched_below_threshold" in resolved_ids:
        resolved_ids.update(str(gate.get("gate_id")) for gate in hil_gates if gate.get("trigger") == "below_threshold")
    resolved: list[dict[str, Any]] = []
    unresolved: list[dict[str, Any]] = []
    for gate in hil_gates:
        if str(gate.get("gate_id")) in resolved_ids:
            resolved.append(gate)
        else:
            unresolved.append(gate)
    return resolved, unresolved


def _hil_compliance(
    *,
    human_loop: dict[str, Any],
    host_question_ui_status: str | None,
    resolved_gates: list[dict[str, Any]],
    unresolved_gates: list[dict[str, Any]],
    rating_overrides: Any,
) -> dict[str, Any]:
    status = str(host_question_ui_status or "unknown").strip().lower() or "unknown"
    allowed = {"native_rendered", "fallback_text_used", "unavailable", "skipped", "unknown"}
    if status not in allowed:
        status = "unknown"
    native_required = bool(human_loop.get("PAUSE_REQUIRED") and human_loop.get("required_surface") == "native_question_ui")
    native_confirmed = status == "native_rendered"
    blocked = bool(native_required and not native_confirmed)
    return {
        "schema_version": "uxhc.hil_compliance.v1",
        "host_question_ui_status": status,
        "native_ui_required": native_required,
        "native_ui_confirmed": native_confirmed,
        "text_fallback_used": status == "fallback_text_used",
        "HIL_BLOCKED_UNTIL_NATIVE_UI": blocked,
        "resolved_gate_count": len(resolved_gates),
        "unresolved_gate_count": len(unresolved_gates),
        "resolved_gate_ids": [str(gate.get("gate_id")) for gate in resolved_gates],
        "unresolved_gate_ids": [str(gate.get("gate_id")) for gate in unresolved_gates],
        "rating_overrides_received": bool(rating_overrides),
    }


def audit_ux_surface(
    prepared_source: dict[str, Any] | None = None,
    *,
    sources: str | list[str] | None = None,
    observations: list[Any] | str | None = None,
    checklist_ratings: list[dict[str, Any]] | None = None,
    profiles: list[str] | str | None = None,
    platform: str | None = None,
    goal: str | None = None,
    user_id: str = "local_default",
    hil_enabled: bool | None = None,
    audit_context: dict[str, Any] | None = None,
    optional_profile_mode: str | None = None,
    full_advanced: bool | None = None,
    hil_answers: Any = None,
    host_question_ui_status: str | None = None,
    rating_overrides: Any = None,
    resolved_gate_ids: list[str] | str | None = None,
    output_detail: str = "full",
) -> dict[str, Any]:
    if prepared_source is None:
        prepared_source = prepare_ux_source(sources)

    preference_record = load_preferences(user_id)
    if platform is None and preference_record and preference_record.get("platform_default") not in {None, "ask_each_time"}:
        platform = preference_record["platform_default"]
    platform_key = infer_platform_from_source(prepared_source, platform)
    if profiles is None and preference_record:
        profiles = preference_record.get("optional_profiles") or []
    accepted_profiles, rejected_profiles = normalize_profiles(profiles)
    accepted_profiles, resolved_profile_mode = _resolve_optional_profile_scope(
        accepted_profiles=accepted_profiles,
        optional_profile_mode=optional_profile_mode,
        full_advanced=full_advanced,
    )
    scope_lock = _audit_scope_lock(
        platform=platform_key,
        accepted_profiles=accepted_profiles,
        optional_profile_mode=resolved_profile_mode,
        full_advanced=full_advanced,
        mode="advanced",
    )
    normalized_observations = _as_observations(observations)
    legacy_findings = [
        _normalize_finding(obs, idx, _default_ref(prepared_source))
        for idx, obs in enumerate(normalized_observations, start=1)
    ]
    legacy_findings = sorted(legacy_findings, key=lambda item: (-item["severity"], item["heuristic_name"], item["title"]))

    scorecard = score_checklist_ratings(checklist_ratings, platform=platform_key, profiles=accepted_profiles) if checklist_ratings else None
    if prepared_source.get("status") == "blocked":
        display_state = "insufficient_evidence"
        findings = legacy_findings
    elif scorecard and scorecard.get("score_status") == "scored":
        display_state = "scored"
        findings = _findings_from_checklist(scorecard)
    else:
        display_state = "needs_checklist_ratings"
        findings = legacy_findings

    snapshot = _health_snapshot(
        display_state=display_state,
        source_status=str(prepared_source.get("status") or "blocked"),
        findings=findings,
        scorecard=scorecard,
        platform=platform_key,
    )
    evidence_limits = _source_evidence_limits(prepared_source)
    if scorecard:
        evidence_limits.extend(scorecard.get("evidence_limits") or [])
    if display_state == "needs_checklist_ratings" and not scorecard:
        evidence_limits.append(
            {
                "checklist_item_id": "all_active_items",
                "reason": "checklist ratings were not supplied",
                "confidence_impact": "audit can provide a contract but not a full score",
                "evaluatable": False,
            }
        )

    hil_enabled_value = _hil_is_enabled(hil_enabled, preference_record)
    behavior_context = dict(audit_context or {})
    behavior_context.setdefault("source_quality", prepared_source.get("status"))
    behavior_context.setdefault("ux_level", (preference_record or {}).get("ux_level"))
    behavior_context.setdefault("hil_enabled", hil_enabled_value)
    behavior_context.setdefault("optional_profile_mode", resolved_profile_mode)
    behavior_context.setdefault("full_advanced", bool(full_advanced))
    behavior_context.setdefault("audit_scope_lock_status", scope_lock.get("status"))
    hil_gates = _hil_gates(enabled=hil_enabled_value, display_state=display_state, scorecard=scorecard)
    resolved_gates, unresolved_gates = _resolve_hil_gates(
        hil_gates,
        hil_answers=hil_answers,
        resolved_gate_ids=resolved_gate_ids,
    )
    threshold_gate_count = sum(1 for gate in hil_gates if gate.get("trigger") == "below_threshold")
    hil_state = {
        "enabled": hil_enabled_value,
        "default_policy": "Prompt after any heuristic below B-, plus final review.",
        "gate_recommended": bool(hil_gates),
        "gate_reason": "One or more heuristic grades fell below B-." if threshold_gate_count else "Checklist ratings require human confirmation." if hil_gates and display_state == "needs_checklist_ratings" else "Final review is available." if hil_gates else "",
        "gate_count": len(hil_gates),
        "resolved_gate_count": len(resolved_gates),
        "unresolved_gate_count": len(unresolved_gates),
        "host_question_ui_status": str(host_question_ui_status or "unknown"),
    }
    heuristic_scores = (scorecard or {}).get("heuristic_scores") or []
    checklist_rows = (scorecard or {}).get("checklist_ratings") or []
    behavior_fields = build_behavior_fields(
        display_state=display_state,
        mode="advanced",
        platform=platform_key,
        scorecard=scorecard,
        snapshot=snapshot,
        findings=findings,
        heuristic_scores=heuristic_scores,
        checklist_ratings=checklist_rows,
        evidence_limits=evidence_limits,
        audit_context=behavior_context,
        preferences_snapshot=preference_record or {},
    )
    human_loop = build_human_loop_host_action(
        enabled=hil_enabled_value,
        mode="advanced",
        display_state=display_state,
        platform=platform_key,
        profiles=accepted_profiles,
        hil_gates=unresolved_gates,
        onboarding=onboarding_contract(user_id),
        host_question_ui_status=host_question_ui_status,
    )
    hil_compliance = _hil_compliance(
        human_loop=human_loop,
        host_question_ui_status=host_question_ui_status,
        resolved_gates=resolved_gates,
        unresolved_gates=unresolved_gates,
        rating_overrides=rating_overrides,
    )
    primary_behavior_fields, support_behavior_fields = _split_behavior_fields(behavior_fields)

    result = {
        "schema_version": "uxhc.audit.v2",
        "tool": "audit_ux_surface",
        "audit_metadata": {
            "audit_engine_version": AUDIT_ENGINE_VERSION,
            "generated_at": _utc_now(),
            "baseline_heuristic_count": len(CORE_HEURISTICS),
            "project_specific_addons_included": False,
        },
        "goal": goal or "",
        "audit_context": behavior_context,
        "platform": platform_key,
        "mode": "advanced",
        "source": _source_summary(prepared_source),
        "profiles": {
            **_profile_contract(accepted_profiles, rejected_profiles, profiles),
        },
        "audit_scope_lock": scope_lock,
        "preferences_snapshot": preference_record or {},
        "onboarding": onboarding_contract(user_id),
        "hil_state": hil_state,
        "hil_gates": hil_gates,
        "resolved_gates": resolved_gates,
        "unresolved_gates": unresolved_gates,
        "hil_compliance": hil_compliance,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": hil_compliance["HIL_BLOCKED_UNTIL_NATIVE_UI"],
        "human_loop_host_action": human_loop,
        "PAUSE_REQUIRED": human_loop["PAUSE_REQUIRED"],
        "ux_health_snapshot": snapshot,
        "scorecard": scorecard or {"score_status": "needs_checklist_ratings"},
        "heuristic_scores": heuristic_scores,
        "checklist_ratings": checklist_rows,
        **primary_behavior_fields,
        "checklist_rating_contract": _checklist_contract(platform_key, accepted_profiles) if display_state == "needs_checklist_ratings" else None,
        "findings": findings,
        "legacy_observation_findings": legacy_findings,
        "top_findings": findings[:5],
        "evidence_limits": evidence_limits,
        "next_validation_steps": _next_steps(snapshot, scorecard),
        **support_behavior_fields,
    }
    report_payload = _report_ready_payload(result)
    payload_ref = _write_report_payload_ref(report_payload)
    if report_payload:
        result["report_ready_payload"] = report_payload
    if payload_ref:
        result["report_payload_ref"] = payload_ref
    result["large_output_guidance"] = _large_output_guidance(payload_ref)
    result["output_detail"] = "full"
    if str(output_detail or "full").lower() == "compact":
        return _compact_audit_response(result)
    return result


def quick_scan_ux(
    prepared_source: dict[str, Any] | None = None,
    *,
    sources: str | list[str] | None = None,
    observations: list[Any] | str | None = None,
    checklist_ratings: list[dict[str, Any]] | None = None,
    profiles: list[str] | str | None = None,
    platform: str | None = None,
    goal: str | None = None,
    user_id: str = "local_default",
    hil_enabled: bool | None = None,
    audit_context: dict[str, Any] | None = None,
    optional_profile_mode: str | None = None,
    full_advanced: bool | None = None,
    hil_answers: Any = None,
    host_question_ui_status: str | None = None,
    rating_overrides: Any = None,
    resolved_gate_ids: list[str] | str | None = None,
    output_detail: str = "full",
) -> dict[str, Any]:
    audit = audit_ux_surface(
        prepared_source,
        sources=sources,
        observations=observations,
        checklist_ratings=checklist_ratings,
        profiles=profiles,
        platform=platform,
        goal=goal,
        user_id=user_id,
        hil_enabled=False,
        audit_context=audit_context,
        optional_profile_mode=optional_profile_mode,
        full_advanced=full_advanced,
        hil_answers=hil_answers,
        host_question_ui_status=host_question_ui_status,
        rating_overrides=rating_overrides,
        resolved_gate_ids=resolved_gate_ids,
        output_detail="full",
    )
    quick_behavior_fields = build_behavior_fields(
        display_state=audit["ux_health_snapshot"]["display_state"],
        mode="quick",
        platform=audit["platform"],
        scorecard=audit["scorecard"] if audit["scorecard"].get("score_status") == "scored" else None,
        snapshot=audit["ux_health_snapshot"],
        findings=audit["findings"],
        heuristic_scores=audit["heuristic_scores"],
        checklist_ratings=audit["checklist_ratings"],
        evidence_limits=audit["evidence_limits"],
        audit_context=audit.get("audit_context") or audit_context,
        preferences_snapshot=audit.get("preferences_snapshot") or {},
    )
    quick_hil = _quick_hil_enabled(
        hil_enabled=hil_enabled,
        audit_context=audit.get("audit_context") or audit_context,
        checklist_ratings=checklist_ratings,
        goal=goal,
    )
    quick_gates = [
        {
            "gate_id": "quick_context_check",
            "trigger": "quick_context",
            "heuristics_in_scope": ["all_active"],
            "prompt": "Collect lightweight context before quick checklist-guided scoring.",
            "override_allowed": False,
        }
    ] if quick_hil else []
    resolved_gates, unresolved_gates = _resolve_hil_gates(
        quick_gates,
        hil_answers=hil_answers,
        resolved_gate_ids=resolved_gate_ids,
    )
    human_loop = build_human_loop_host_action(
        enabled=bool(unresolved_gates),
        mode="quick",
        display_state=audit["ux_health_snapshot"]["display_state"],
        platform=audit["platform"],
        profiles=audit["profiles"]["accepted"],
        hil_gates=unresolved_gates,
        onboarding=audit["onboarding"],
        host_question_ui_status=host_question_ui_status,
    )
    hil_compliance = _hil_compliance(
        human_loop=human_loop,
        host_question_ui_status=host_question_ui_status,
        resolved_gates=resolved_gates,
        unresolved_gates=unresolved_gates,
        rating_overrides=rating_overrides,
    )
    primary_behavior_fields, support_behavior_fields = _split_behavior_fields(quick_behavior_fields)
    result = {
        "schema_version": "uxhc.quick_scan.v2",
        "tool": "quick_scan_ux",
        "goal": audit["goal"],
        "audit_context": audit.get("audit_context") or {},
        "platform": audit["platform"],
        "source": audit["source"],
        "profiles": audit["profiles"],
        "audit_scope_lock": {**audit["audit_scope_lock"], "mode": "quick"},
        "mode": "quick",
        "onboarding": audit["onboarding"],
        "hil_state": {
            "enabled": bool(quick_hil),
            "gate_recommended": bool(quick_gates),
            "gate_count": len(quick_gates),
            "resolved_gate_count": len(resolved_gates),
            "unresolved_gate_count": len(unresolved_gates),
            "host_question_ui_status": str(host_question_ui_status or "unknown"),
        },
        "hil_gates": quick_gates,
        "resolved_gates": resolved_gates,
        "unresolved_gates": unresolved_gates,
        "hil_compliance": hil_compliance,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": hil_compliance["HIL_BLOCKED_UNTIL_NATIVE_UI"],
        "human_loop_host_action": human_loop,
        "PAUSE_REQUIRED": human_loop["PAUSE_REQUIRED"],
        "ux_health_snapshot": audit["ux_health_snapshot"],
        "scorecard": audit["scorecard"],
        "heuristic_scores": audit["heuristic_scores"],
        "checklist_ratings": audit["checklist_ratings"],
        **primary_behavior_fields,
        "top_findings": audit["top_findings"][:3],
        "checklist_rating_contract": audit["checklist_rating_contract"],
        "evidence_limits": audit["evidence_limits"],
        "summary": audit["ux_health_snapshot"].get("overall_label", ""),
        "next_action": audit["next_validation_steps"][0] if audit["next_validation_steps"] else "",
        **support_behavior_fields,
    }
    report_payload = _report_ready_payload(result)
    payload_ref = _write_report_payload_ref(report_payload)
    if report_payload:
        result["report_ready_payload"] = report_payload
    if payload_ref:
        result["report_payload_ref"] = payload_ref
    result["large_output_guidance"] = _large_output_guidance(payload_ref)
    result["output_detail"] = "full"
    if str(output_detail or "full").lower() == "compact":
        return _compact_audit_response(result)
    return result
