from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from .behavior import build_behavior_fields, build_human_loop_host_action
from .corpus_advisories import build_accessibility_readiness_advisory, build_cultural_context_advisory
from .evidence import adapter_evidence_summary, build_evidence_graph, validate_evidence_refs
from .knowledge import attach_support_lenses_to_findings, select_support_lenses_for_finding, summarize_support_lenses
from .rubric import CORE_HEURISTICS, get_active_checklist_items, heuristic_by_id, infer_heuristic, infer_platform_from_source, normalize_profiles
from .scoring import SEVERITY_LABELS, rating_label, score_checklist_ratings
from .source import prepare_ux_source
from .state import audit_checkpoint_path, load_preferences, onboarding_contract, report_payload_path
from .tracing import attach_run_summary, payload_trace_context


AUDIT_ENGINE_VERSION = "uxhc-v2-checklist"
AUDIT_CHECKPOINT_SCHEMA_VERSION = "uxhc.audit_checkpoint.v1"
PRIMARY_BEHAVIOR_KEYS = [
    "top_finding",
    "plain_language_read",
    "before_using_this_interface",
    "one_recommendation",
    "overall_grade",
    "overall_percentage",
    "overall_descriptor",
]
PROFILE_HEURISTIC_MAP = {
    "accessibility": {"heuristic_id": "h11", "heuristic_name": "Accessibility and Ease of Access"},
    "inclusion": {"heuristic_id": "h12", "heuristic_name": "Empathetic Engagement and Inclusion"},
    "journey": {"heuristic_id": "h13", "heuristic_name": "Customer Journey and Satisfaction"},
    "ux_writing": {"heuristic_id": "h14", "heuristic_name": "UX Writing and Content Design"},
}
OPTIONAL_PROFILE_ORDER = ["accessibility", "inclusion", "journey", "ux_writing"]
OPTIONAL_PROFILE_MODES = {"core_only", "scoped", "all_optionals", "ask"}
GUIDANCE_ONLY_MODES = {"guidance_only", "guidance", "ultra_quick", "ultra-quick", "ultraquick"}
QUICK_SCAN_MODE_GATE_VALUES = {None, "", "auto", "ask", "choose", "mode_gate"}
GUIDANCE_INTENTS = {"direct_fix", "fix_prompt", "micro_plan", "name_the_problem"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _split_behavior_fields(fields: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    primary = {key: fields[key] for key in PRIMARY_BEHAVIOR_KEYS if key in fields}
    support = {key: value for key, value in fields.items() if key not in primary}
    return primary, support


def _derived_source_status(prepared_source: dict[str, Any]) -> str:
    explicit = prepared_source.get("status")
    if explicit not in (None, "", []):
        return str(explicit)
    items = prepared_source.get("items") or []
    if items:
        ready_count = sum(1 for item in items if item.get("quality") == "ready")
        partial_count = sum(1 for item in items if item.get("quality") == "partial")
        blocked_count = sum(1 for item in items if item.get("quality") == "blocked")
        if ready_count == 0 and partial_count == 0 and blocked_count:
            return "blocked"
        if blocked_count or partial_count:
            return "partial"
        return "ready"
    if prepared_source.get("source_id") or prepared_source.get("evidence_refs"):
        return "partial"
    return "not_supplied"


PROFILE_ALIASES = {
    "content_strategy": "ux_writing",
    "content_strategy_profile": "ux_writing",
    "content": "ux_writing",
    "content_tone": "ux_writing",
    "ux_content": "ux_writing",
    "microcopy": "ux_writing",
    "copy": "ux_writing",
    "copywriting": "ux_writing",
    "customer_experience": "journey",
    "cx": "journey",
    "empathy": "inclusion",
}


def _raw_profile_list(profiles: list[str] | str | None) -> list[str]:
    if profiles is None or profiles == "":
        return []
    if isinstance(profiles, str):
        return [part.strip() for part in profiles.replace(",", " ").split() if part.strip()]
    return [str(part).strip() for part in profiles if str(part).strip()]


def _profile_contract(accepted: list[str], rejected: list[str], requested_profiles: list[str] | str | None) -> dict[str, Any]:
    inactive = [profile for profile in PROFILE_HEURISTIC_MAP if profile not in accepted]
    suggestions = []
    for profile in rejected:
        key = str(profile).lower().replace("-", "_")
        if key in PROFILE_ALIASES:
            suggested = PROFILE_ALIASES[key]
            suggestions.append({"rejected": profile, "suggested_profile": suggested, "heuristic_id": PROFILE_HEURISTIC_MAP[suggested]["heuristic_id"]})
    normalized = []
    for profile in _raw_profile_list(requested_profiles):
        key = str(profile).lower().replace("-", "_")
        if key in PROFILE_ALIASES and PROFILE_ALIASES[key] in accepted:
            normalized.append({"requested": profile, "normalized_to": PROFILE_ALIASES[key], "heuristic_id": PROFILE_HEURISTIC_MAP[PROFILE_ALIASES[key]]["heuristic_id"]})
    return {
        "accepted": accepted,
        "rejected": rejected,
        "normalized_profiles": normalized,
        "profile_to_heuristic": PROFILE_HEURISTIC_MAP,
        "inactive_optional_profiles": [
            {
                "profile": profile,
                **PROFILE_HEURISTIC_MAP[profile],
                "activation": f'Add "{profile}" to profiles to include {PROFILE_HEURISTIC_MAP[profile]["heuristic_id"]}.',
            }
            for profile in inactive
        ],
        "suggestions": suggestions,
        "note": "Optional profiles add H11-H14 to the active checklist; rejected donor/conversion profiles remain excluded from the baseline rubric.",
    }


def _resolve_optional_profile_scope(
    *,
    accepted_profiles: list[str],
    optional_profile_mode: str | None,
    full_advanced: bool | None,
) -> tuple[list[str], str]:
    mode = str(optional_profile_mode or "scoped").strip().lower()
    if mode not in OPTIONAL_PROFILE_MODES:
        mode = "scoped"
    if full_advanced and set(accepted_profiles) != set(OPTIONAL_PROFILE_ORDER):
        mode = "ask"
    if mode == "core_only":
        return [], mode
    if mode == "all_optionals":
        return list(OPTIONAL_PROFILE_ORDER), mode
    return accepted_profiles, mode


def _profile_card(profile: str) -> dict[str, Any]:
    return {"profile": profile, **PROFILE_HEURISTIC_MAP[profile]}


def _heuristic_scope_cards(platform: str, accepted_profiles: list[str]) -> list[dict[str, Any]]:
    cards = [
        {
            "heuristic_id": heuristic["id"],
            "heuristic_name": heuristic["name"],
            "profile": "core",
            "platform": platform,
        }
        for heuristic in CORE_HEURISTICS
    ]
    for profile in accepted_profiles:
        info = PROFILE_HEURISTIC_MAP[profile]
        cards.append(
            {
                "heuristic_id": info["heuristic_id"],
                "heuristic_name": info["heuristic_name"],
                "profile": profile,
                "platform": platform,
            }
        )
    return cards


def _audit_scope_lock(
    *,
    platform: str,
    accepted_profiles: list[str],
    optional_profile_mode: str,
    full_advanced: bool | None,
    mode: str,
) -> dict[str, Any]:
    omitted = [profile for profile in OPTIONAL_PROFILE_ORDER if profile not in accepted_profiles]
    scored_optional = [_profile_card(profile) for profile in accepted_profiles]
    omitted_optional = [
        {
            **_profile_card(profile),
            "activation": f'Rerun with "{profile}" in profiles or optional_profile_mode="all_optionals" to include {PROFILE_HEURISTIC_MAP[profile]["heuristic_id"]}.',
        }
        for profile in omitted
    ]
    confirmation_required = bool((optional_profile_mode == "ask" or full_advanced) and omitted)
    if optional_profile_mode == "core_only":
        status = "core_only"
    elif not omitted:
        status = "all_optionals_active"
    elif confirmation_required:
        status = "confirmation_required"
    elif accepted_profiles:
        status = "scoped_partial"
    else:
        status = "core_scope_no_optionals"
    return {
        "schema_version": "uxhc.audit_scope_lock.v1",
        "status": status,
        "mode": mode,
        "optional_profile_mode": optional_profile_mode,
        "full_advanced_requested": bool(full_advanced),
        "confirmation_required": confirmation_required,
        "platform": platform,
        "scored_heuristics": _heuristic_scope_cards(platform, accepted_profiles),
        "scored_optional_profiles": scored_optional,
        "omitted_optional_profiles": omitted_optional,
        "rerun_profiles": list(OPTIONAL_PROFILE_ORDER),
        "rerun_guidance": "For a full advanced audit, rerun with optional_profile_mode='all_optionals' or profiles=['accessibility','inclusion','journey','ux_writing'].",
        "report_warning": "Optional heuristics not in scope should be named in the report so readers do not mistake the scorecard for all H1-H14 coverage.",
    }


def _heuristic_scope_label(heuristic_ids: list[str]) -> str:
    normalized = [str(item).upper().replace("H0", "H") for item in heuristic_ids if item]
    if normalized == [f"H{idx}" for idx in range(1, 15)]:
        return "H1-H14"
    if normalized == [f"H{idx}" for idx in range(1, 11)]:
        return "H1-H10"
    return ", ".join(normalized) or "No active heuristics"


def _active_scope_summary(
    *,
    platform: str,
    scope_lock: dict[str, Any],
    scorecard: dict[str, Any] | None,
    checklist_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    heuristic_ids = [str(item.get("heuristic_id") or "") for item in scope_lock.get("scored_heuristics") or []]
    active_count = int((scorecard or {}).get("active_checklist_item_count") or len(checklist_rows) or 0)
    scored_count = len(checklist_rows) if (scorecard or {}).get("score_status") == "scored" else 0
    scope_label = _heuristic_scope_label(heuristic_ids)
    return {
        "schema_version": "uxhc.active_scope_summary.v1",
        "platform": platform,
        "scope_label": scope_label,
        "badge": f"Active scope: {scope_label}, {scored_count}/{active_count} scored",
        "score_status": (scorecard or {}).get("score_status") or "needs_checklist_ratings",
        "active_checklist_item_count": active_count,
        "scored_checklist_item_count": scored_count,
        "active_heuristic_count": len(heuristic_ids),
        "scored_heuristic_count": len((scorecard or {}).get("heuristic_scores") or []),
        "optional_profile_mode": scope_lock.get("optional_profile_mode"),
        "scope_status": scope_lock.get("status"),
        "omitted_optional_profile_count": len(scope_lock.get("omitted_optional_profiles") or []),
        "score_policy": "Scope summary is report/status metadata only and does not alter canonical 0-4 checklist ratings.",
    }


def _large_output_guidance(payload_ref: dict[str, Any] | None) -> dict[str, Any]:
    guidance = {
        "primary_workflow": "Use status-only audit output for orchestration, validate payload_path, then generate report artifacts with response_mode='compact'.",
        "jq_required": False,
    }
    if payload_ref:
        guidance["validate_payload_call"] = {
            "tool": "validate_ux_report_payload",
            "arguments": {"payload_path": payload_ref.get("path")},
        }
        guidance["generate_report_call"] = {
            "tool": "generate_ux_audit_report",
            "arguments": {"payload_path": payload_ref.get("path"), "include_viewer": True, "response_mode": "compact"},
        }
        guidance["payload_path"] = payload_ref.get("path")
        guidance["optional_debug_jq"] = f"jq '{{overall_grade, overall_percentage, plain_language_read, top_finding, one_recommendation}}' {payload_ref.get('path')}"
    return guidance


def _quick_hil_enabled(
    *,
    hil_enabled: bool | None,
    audit_context: dict[str, Any] | None,
    checklist_ratings: list[dict[str, Any]] | None,
    goal: str | None,
) -> bool:
    context = dict(audit_context or {})
    context_requested = bool(context.get("hil_enabled") or context.get("human_loop_requested"))
    has_context = bool(
        goal
        or context.get("goal")
        or context.get("audit_goal")
        or context.get("primary_task")
        or context.get("user_task")
        or context.get("task")
    )
    return bool(hil_enabled) or context_requested or not checklist_ratings or not has_context


def _as_observations(observations: list[Any] | str | None) -> list[dict[str, Any]]:
    if observations is None or observations == "":
        return []
    if isinstance(observations, str):
        return [{"text": observations}]
    normalized: list[dict[str, Any]] = []
    for item in observations:
        if isinstance(item, dict):
            normalized.append(dict(item))
        else:
            normalized.append({"text": str(item)})
    return normalized


def _infer_severity(text: str) -> int:
    lower = text.lower()
    if any(token in lower for token in ["blocked", "cannot", "impossible", "catastrophe", "dead end", "unusable"]):
        return 4
    if any(token in lower for token in ["major", "hidden", "unclear primary", "error", "confusing", "missing", "hard to find"]):
        return 3
    if any(token in lower for token in ["minor", "clutter", "crowded", "inconsistent", "ambiguous", "small"]):
        return 2
    if any(token in lower for token in ["cosmetic", "typo", "polish", "slight"]):
        return 1
    return 2


def _recommendation(text: str, heuristic_name: str) -> str:
    lower = text.lower()
    if "primary" in lower or "start" in lower or "cta" in lower:
        return "Make the primary next action visually dominant and label it with the user's task language."
    if "error" in lower or "invalid" in lower:
        return "Place a plain-language error message next to the affected control and state the next recovery step."
    if "hidden" in lower or "hard to find" in lower:
        return "Move the needed control or context into the visible task area and reduce dependence on memory."
    if "jargon" in lower or "label" in lower:
        return "Rewrite the label in user-facing language and keep terminology consistent across the screen."
    if "clutter" in lower or "crowded" in lower:
        return "Remove or demote secondary content so the core task and decision points are easier to scan."
    return f"Revise the interface so it better satisfies '{heuristic_name}' for the visible task."


def _finding_id(seed: str) -> str:
    return f"uxf_{hashlib.sha256(seed.encode('utf-8')).hexdigest()[:10]}"


def _finding_signature(*, heuristic_id: str, checklist_item_id: str | None, title: str, evidence_refs: list[str]) -> str:
    seed = "|".join(
        [
            str(heuristic_id or ""),
            str(checklist_item_id or ""),
            str(title or "").strip().lower(),
            ",".join(sorted(str(ref) for ref in evidence_refs if str(ref))),
        ]
    )
    return "uxsig_" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:12]


def _default_owner_role(heuristic_id: str) -> str:
    if heuristic_id in {"h08", "h14"}:
        return "Designer"
    if heuristic_id == "h04":
        return "Product"
    if heuristic_id in {"h03", "h05", "h09", "h11"}:
        return "Engineer"
    if heuristic_id in {"h12", "h13"}:
        return "Research"
    return "Product"


def _default_effort(heuristic_id: str, severity: int) -> str:
    if heuristic_id in {"h04", "h08", "h14"} and severity <= 3:
        return "Low"
    if heuristic_id in {"h03", "h05", "h09", "h11"}:
        return "Medium"
    return "Low-Medium" if severity <= 3 else "Medium"


def _default_triage(
    *,
    heuristic_id: str,
    severity: int,
    confidence: str,
    recommendation: str,
    severity_basis: dict[str, Any] | None = None,
    owner_role: str | None = None,
) -> dict[str, Any]:
    basis = severity_basis or {}
    evidence_strength = str(basis.get("evidence_strength") or confidence or "medium")
    impact = str(basis.get("impact") or ("high" if severity >= 3 else "medium" if severity == 2 else "low"))
    priority = "high" if severity >= 3 and evidence_strength.lower() not in {"low", "weak"} else "medium" if severity >= 2 else "low"
    return {
        "severity": severity,
        "confidence": confidence or "medium",
        "effort": str(basis.get("effort") or _default_effort(heuristic_id, severity)),
        "reach": str(basis.get("scope") or basis.get("reach") or "visible_task"),
        "scope": str(basis.get("scope") or "visible_task"),
        "owner_role": owner_role or _default_owner_role(heuristic_id),
        "evidence_strength": evidence_strength,
        "impact": impact,
        "recommended_priority": priority,
        "validation_step": "Validate this as a likely usability risk with a focused task check or participant review before making user-research claims.",
        "next_action": recommendation,
        "score_policy": "Triage fields support prioritization and do not alter the canonical 0-4 checklist rating.",
    }


def _checklist_finding_title(*, heuristic_id: str, checklist_text: str) -> str:
    lower = checklist_text.lower()
    if heuristic_id == "h01":
        if "value proposition" in lower:
            return "Value proposition is not clear enough"
        if "primary actions" in lower:
            return "Primary actions are not easy to identify"
        if "navigation" in lower:
            return "Current location is unclear in navigation"
        return "Page status and purpose need clearer cues"
    if heuristic_id == "h03":
        if "search" in lower:
            return "Missing search limits user control"
        if "exits" in lower or "back" in lower or "undo" in lower or "redo" in lower:
            return "Users may lack clear recovery paths"
        return "User control and recovery need strengthening"
    if heuristic_id == "h04":
        if "typographic" in lower or "spelling" in lower:
            return "Content quality may weaken trust"
        if "consistent" in lower or "standards" in lower:
            return "Inconsistent interface patterns may slow users"
        return "Consistency and trust cues need review"
    if heuristic_id == "h06":
        if "click here" in lower or "links" in lower:
            return "Link labels do not predict destinations"
        if "search suggestions" in lower or "filters" in lower:
            return "Search support may require too much recall"
        return "Interface relies too much on user memory"
    if heuristic_id == "h08":
        if "clutter" in lower or "attention" in lower or "irrelevant" in lower:
            return "Page clutter competing with primary actions"
        if "primary actions" in lower or "start" in lower:
            return "Primary action hierarchy is not clear"
        if "above the fold" in lower:
            return "Important information may appear too late"
        return "Visual hierarchy is not supporting the task"
    if heuristic_id == "h09":
        if "404" in lower:
            return "Missing-page recovery may leave users stuck"
        return "Error recovery instructions are not clear"
    if heuristic_id == "h11":
        if "operable" in lower or "touch" in lower or "keyboard" in lower:
            return "Interactive controls may exclude some users"
        if "perceivable" in lower or "alternatives" in lower:
            return "Content may not be perceivable for everyone"
        return "Surface accessibility needs targeted review"
    if heuristic_id == "h12":
        if "anxiety" in lower or "safe" in lower or "secure" in lower:
            return "Interface may increase user anxiety"
        if "control" in lower or "choice" in lower:
            return "Users may need more control and choice"
        return "Inclusion and emotional fit need review"
    if heuristic_id == "h14":
        if "calls to action" in lower or "cta" in lower:
            return "Calls to action need clearer language"
        if "jargon" in lower or "simple" in lower:
            return "Interface copy may be too hard to scan"
        if "labels" in lower:
            return "UI labels need simpler wording"
        return "UX writing needs a clarity pass"
    heuristic = heuristic_by_id(heuristic_id) or {"name": heuristic_id}
    return f"{heuristic['name']} needs targeted review"


def _checklist_recommendation(*, heuristic_id: str, checklist_text: str) -> str:
    lower = checklist_text.lower()
    if heuristic_id == "h01":
        if "value proposition" in lower:
            return "Rewrite the first-screen message so users can tell what the product offers and what to do next without extra explanation."
        if "primary actions" in lower:
            return "Make the primary action visually dominant and remove competing entry points from the first decision area."
        if "navigation" in lower:
            return "Mark the current page clearly in navigation and align link labels with destination page titles."
        return "Add clearer page titles, state cues, and primary-action emphasis so users know where they are and what is available."
    if heuristic_id == "h03":
        if "search" in lower:
            return "Add or expose search where users naturally look for it so they have a reliable recovery path."
        if "undo" in lower or "redo" in lower:
            return "Add undo or redo support for reversible actions, or clearly explain when an action cannot be reversed."
        return "Add or clarify exits, back behavior, and recovery controls so users can leave wrong paths without losing context."
    if heuristic_id == "h04":
        if "typographic" in lower or "spelling" in lower:
            return "Run a content QA pass on the affected screens and fix visible typos before stakeholder or user review."
        if "consistent" in lower or "style" in lower or "color" in lower:
            return "Standardize repeated components, labels, and visual treatments so the same action looks and behaves the same way everywhere."
        return "Audit repeated navigation, labels, components, and trust cues, then align any pattern that changes meaning across screens."
    if heuristic_id == "h06":
        if "click here" in lower or "links" in lower:
            return "Rewrite links so each label describes the destination or result before the user clicks."
        if "search suggestions" in lower or "filters" in lower:
            return "Add visible suggestions, filters, or recent choices so users can recognize options instead of remembering them."
        return "Expose the next useful choices on screen so users do not have to remember labels, paths, or previous states."
    if heuristic_id == "h08":
        if "clutter" in lower or "attention" in lower or "irrelevant" in lower:
            return "Audit the screen for competing visual elements and remove or demote anything that does not support the user's next action."
        if "primary actions" in lower or "start" in lower:
            return "Make the primary action the clearest visual starting point and reduce secondary actions around it."
        if "above the fold" in lower:
            return "Move the task-critical information above the fold and defer supporting details until after the first decision."
        return "Rework the visual hierarchy so the page guides users from the main purpose to the next action without extra scanning."
    if heuristic_id == "h09":
        if "404" in lower:
            return "Create a helpful missing-page state with plain language, search, home, and the most likely recovery links."
        return "Rewrite error messages to state what happened, what field or action is affected, and the next recovery step."
    if heuristic_id == "h11":
        if "touch" in lower or "keyboard" in lower or "operable" in lower:
            return "Check touch targets, focus access, and gesture requirements, then enlarge or simplify controls that exclude users."
        if "perceivable" in lower or "alternatives" in lower:
            return "Add text alternatives and non-color cues so critical content remains perceivable across assistive and display settings."
        return "Run a surface accessibility pass on the affected screen and fix the visible access barrier before deeper compliance review."
    if heuristic_id == "h12":
        if "anxiety" in lower or "safe" in lower or "secure" in lower:
            return "Remove pressure patterns and add calm, clear reassurance around permissions, consequences, and recovery options."
        if "control" in lower or "choice" in lower:
            return "Expose user controls for notifications, permissions, personalization, or recovery where users can find them quickly."
        return "Review the screen through emotional, cultural, and situational user contexts, then remove the highest-friction exclusion point."
    if heuristic_id == "h14":
        if "calls to action" in lower or "cta" in lower:
            return "Rewrite calls to action as specific verb-led labels and make the primary action clearly outrank secondary choices."
        if "jargon" in lower or "simple" in lower:
            return "Replace internal language with short, everyday wording that users can scan at the smallest supported viewport."
        if "labels" in lower:
            return "Shorten UI labels and test them in the narrowest viewport so the meaning stays complete and visible."
        return "Run a UX writing pass on labels, CTAs, errors, and empty states so each word helps users decide what to do next."
    heuristic = heuristic_by_id(heuristic_id) or {"name": heuristic_id}
    return f"Review the affected element against {heuristic['name']} and make the next user action clearer, safer, or easier to recover from."


def _normalize_finding(observation: dict[str, Any], index: int, default_evidence_ref: str) -> dict[str, Any]:
    text = str(observation.get("text") or observation.get("observed_issue") or observation.get("issue") or "").strip()
    heuristic = heuristic_by_id(str(observation.get("heuristic_id", ""))) if observation.get("heuristic_id") else None
    if heuristic is None:
        heuristic = infer_heuristic(text)
    severity = int(observation.get("severity", _infer_severity(text)))
    severity = max(0, min(4, severity))
    evidence_ref = str(observation.get("evidence_ref") or default_evidence_ref)
    explicit_title = str(observation.get("title") or "").strip()
    no_traceable_evidence = evidence_ref in {"", "source", None}
    title = explicit_title or ("No evidence - audit preparation required" if no_traceable_evidence else text[:72] or f"UX observation {index}")
    title = str(title).strip()
    recommendation = str(observation.get("recommendation") or _recommendation(text, heuristic["name"]))
    confidence = str(observation.get("confidence") or "medium")
    profile = str(observation.get("profile") or heuristic.get("profile") or "core")
    evidence_refs = [evidence_ref] if evidence_ref else []
    owner_role = str(observation.get("owner_role") or observation.get("owner") or _default_owner_role(str(heuristic["id"])))
    triage = {
        **_default_triage(
            heuristic_id=str(heuristic["id"]),
            severity=severity,
            confidence=confidence,
            recommendation=recommendation,
            severity_basis=observation.get("severity_basis") if isinstance(observation.get("severity_basis"), dict) else None,
            owner_role=owner_role,
        ),
        **(observation.get("triage") if isinstance(observation.get("triage"), dict) else {}),
    }
    return {
        "finding_id": str(observation.get("finding_id") or _finding_id(f"{index}:{text}:{heuristic['id']}")),
        "finding_signature": str(observation.get("finding_signature") or _finding_signature(heuristic_id=str(heuristic["id"]), checklist_item_id=None, title=title, evidence_refs=evidence_refs)),
        "heuristic_id": heuristic["id"],
        "heuristic_name": heuristic["name"],
        "severity": severity,
        "severity_label": rating_label(severity),
        "title": title,
        "evidence_ref": evidence_ref,
        "observed_issue": text or title,
        "user_impact": str(observation.get("user_impact") or "This may increase friction, uncertainty, or effort for the visible task."),
        "recommendation": recommendation,
        "confidence": confidence,
        "owner_role": owner_role,
        "triage": triage,
        "source_limitations": observation.get("source_limitations") or ["Legacy observation mode: not a complete checklist-level score."],
        "profile": profile,
        "legacy_observation": True,
    }


def _findings_from_checklist(scorecard: dict[str, Any]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for rating in scorecard.get("checklist_ratings") or []:
        severity = float(rating.get("rating", 0))
        if severity <= 0:
            continue
        heuristic = heuristic_by_id(rating["heuristic_id"]) or {"name": rating["heuristic_id"], "profile": "core"}
        severity_int = int(round(severity))
        evidence_refs = rating.get("evidence_refs") or []
        evidence_ref = evidence_refs[0] if evidence_refs else rating["checklist_item_id"]
        issue = rating.get("rationale") or f"Checklist item needs attention: {rating.get('checklist_text', '')}"
        checklist_text = str(rating.get("checklist_text", ""))
        title = str(rating.get("finding_title") or "").strip() or _checklist_finding_title(heuristic_id=str(rating["heuristic_id"]), checklist_text=checklist_text)
        recommendation = str(rating.get("recommendation") or "").strip() or _checklist_recommendation(heuristic_id=str(rating["heuristic_id"]), checklist_text=checklist_text)
        source_limitations = list(rating.get("evidence_limits") or [])
        severity_basis = rating.get("severity_basis") or {}
        if isinstance(severity_basis, dict) and str(severity_basis.get("evidence_strength", "")).lower() in {"low", "weak", "thin"}:
            source_limitations.append("Severity basis marks evidence_strength as low; treat this finding as a hypothesis until confirmed.")
        supplied_triage = rating.get("triage") if isinstance(rating.get("triage"), dict) else {}
        owner_role = str(rating.get("owner_role") or supplied_triage.get("owner_role") or _default_owner_role(str(rating["heuristic_id"])))
        triage = {
            **_default_triage(
                heuristic_id=str(rating["heuristic_id"]),
                severity=max(0, min(4, severity_int)),
                confidence=str(rating.get("confidence", "medium")),
                recommendation=recommendation,
                severity_basis=severity_basis if isinstance(severity_basis, dict) else None,
                owner_role=owner_role,
            ),
            **supplied_triage,
        }
        findings.append(
            {
                "finding_id": _finding_id(f"{rating['checklist_item_id']}:{severity}:{issue}"),
                "finding_signature": _finding_signature(heuristic_id=str(rating["heuristic_id"]), checklist_item_id=str(rating["checklist_item_id"]), title=title, evidence_refs=[str(ref) for ref in evidence_refs]),
                "checklist_item_id": rating["checklist_item_id"],
                "heuristic_id": rating["heuristic_id"],
                "heuristic_name": heuristic["name"],
                "severity": max(0, min(4, severity_int)),
                "severity_label": rating_label(severity),
                "title": title,
                "evidence_ref": evidence_ref,
                "observed_issue": issue,
                "checklist_text": checklist_text,
                "user_impact": "This checklist item indicates measurable heuristic friction for the evaluated surface.",
                "recommendation": recommendation,
                "confidence": rating.get("confidence", "medium"),
                "owner_role": owner_role,
                "triage": triage,
                "source_limitations": source_limitations,
                **({"severity_basis": severity_basis} if severity_basis else {}),
                "profile": heuristic.get("profile", "core"),
                "legacy_observation": False,
            }
        )
    return sorted(findings, key=lambda item: (-int(item["severity"]), item["heuristic_name"], item["title"]))


def _source_summary(prepared_source: dict[str, Any]) -> dict[str, Any]:
    source_status = _derived_source_status(prepared_source)
    return {
        "source_id": prepared_source.get("source_id"),
        "status": source_status,
        "item_count": len(prepared_source.get("items") or []),
        "items": [
            {
                "item_id": item.get("item_id"),
                "source_type": item.get("source_type"),
                "url": item.get("url"),
                "input_path": item.get("input_path"),
                "screenshot_path": item.get("screenshot_path"),
                "page_title": item.get("page_title"),
                "state_label": item.get("state_label"),
                "quality": item.get("quality"),
                "capture_metadata_path": item.get("capture_metadata_path"),
                "warnings": item.get("warnings") or [],
            }
            for item in prepared_source.get("items") or []
        ],
        "evidence_refs": prepared_source.get("evidence_refs") or [],
        "warnings": prepared_source.get("warnings") or [],
        "interactive_state_hints": prepared_source.get("interactive_state_hints") or [],
        "interactive_state_summary": prepared_source.get("interactive_state_summary") or {},
        "capture_policy": prepared_source.get("capture_policy") or {},
        "browser_handoff": prepared_source.get("browser_handoff") or {},
        "evidence_graph": prepared_source.get("evidence_graph") or {},
        "adapter_evidence_summary": prepared_source.get("adapter_evidence_summary") or {},
    }


def _default_ref(prepared_source: dict[str, Any]) -> str:
    evidence_refs = prepared_source.get("evidence_refs") or []
    return evidence_refs[0]["evidence_ref"] if evidence_refs else "source"


def _health_snapshot(
    *,
    display_state: str,
    source_status: str,
    findings: list[dict[str, Any]],
    scorecard: dict[str, Any] | None,
    platform: str,
) -> dict[str, Any]:
    if source_status == "blocked":
        return {
            "display_state": "insufficient_evidence",
            "platform": platform,
            "top_priority": "Source preparation is blocked; no fair heuristic score can be produced.",
            "severity_counts": {},
            "heuristic_health": [],
            "overall_label": "Insufficient evidence",
            "comparability_warning": "No usable source evidence was prepared.",
        }
    if display_state == "needs_checklist_ratings":
        return {
            "display_state": "needs_checklist_ratings",
            "platform": platform,
            "top_priority": "Checklist ratings are required before UX Health Snapshot scoring is ready.",
            "severity_counts": {},
            "heuristic_health": [],
            "overall_label": "Checklist ratings needed",
            "comparability_warning": "Observation-only output is not comparable to scored checklist audits.",
        }
    if scorecard and scorecard.get("score_status") == "scored":
        counts = {str(level): sum(1 for row in scorecard["checklist_ratings"] if int(round(float(row["rating"]))) == level) for level in range(5)}
        top = findings[0] if findings else None
        return {
            "display_state": "scored",
            "platform": platform,
            "core_quality_percentage": scorecard["core_quality_percentage"],
            "core_grade": scorecard["core_grade"],
            "core_descriptor": scorecard["core_descriptor"],
            "expanded_quality_percentage": scorecard["expanded_quality_percentage"],
            "expanded_grade": scorecard["expanded_grade"],
            "expanded_descriptor": scorecard["expanded_descriptor"],
            "overall_quality_percentage": scorecard["overall_quality_percentage"],
            "overall_grade": scorecard["overall_grade"],
            "overall_descriptor": scorecard["overall_descriptor"],
            "top_priority": f"{top['heuristic_name']}: {top['title']}" if top else "No checklist issues scored above 0.",
            "severity_counts": counts,
            "heuristic_health": [
                {
                    "heuristic_id": score["heuristic_id"],
                    "heuristic_name": score["heuristic_name"],
                    "active_item_count": score["active_item_count"],
                    "average_item_severity": score["average_item_severity"],
                    "quality_percentage": score["quality_percentage"],
                    "letter_grade": score["letter_grade"],
                    "descriptor": score["descriptor"],
                }
                for score in scorecard["heuristic_scores"]
            ],
            "overall_label": f"{scorecard['overall_grade']} - {scorecard['overall_descriptor']}",
            "comparability_warning": "",
        }
    return {
        "display_state": "profile_only",
        "platform": platform,
        "top_priority": "No scored checklist issues were supplied.",
        "severity_counts": {},
        "heuristic_health": [],
        "overall_label": "Profile only",
        "comparability_warning": "A visual or browser-capable host must provide checklist ratings for a scored audit.",
    }


def _checklist_contract(platform: str, profiles: list[str]) -> dict[str, Any]:
    items = get_active_checklist_items(platform, profiles=profiles)
    return {
        "status": "required",
        "platform": platform,
        "active_checklist_item_count": len(items),
        "required_checklist_item_ids": [item["id"] for item in items],
        "required_fields": ["checklist_item_id", "rating", "evidence_refs", "rationale", "confidence"],
        "optional_fields_filled_by_uxhc_when_possible": ["heuristic_id", "platform", "checklist_text"],
        "field_policy": {
            "heuristic_id": "Optional host input; UXHC normalizes this from checklist_item_id when possible.",
            "platform": "Optional host input; UXHC applies the selected audit platform contract.",
            "checklist_text": "Optional host input; UXHC fills canonical checklist text from the rubric.",
            "evidence_limits": "Optional per rating; use when evidence is thin or missing. Evidence refs remain the normal required support field.",
        },
        "rating_scale": {
            "0": "no visible issue",
            "1": "minor polish/friction",
            "2": "moderate friction",
            "3": "major friction or likely task risk",
            "4": "catastrophic blocker or severe trust/recovery risk",
        },
        "example_rating": {
            "checklist_item_id": items[0]["id"] if items else "h01_d_01",
            "heuristic_id": items[0]["heuristic_id"] if items else "h01",
            "platform": platform,
            "rating": 2,
            "evidence_refs": ["img-1"],
            "rationale": "Visible evidence for the rating.",
            "confidence": "medium",
            "evidence_limits": [],
        },
    }


def _report_ready_payload(result: dict[str, Any]) -> dict[str, Any] | None:
    scorecard = result.get("scorecard") or {}
    if scorecard.get("score_status") != "scored":
        return None
    keys = [
        "schema_version",
        "tool",
        "audit_metadata",
        "goal",
        "audit_context",
        "platform",
        "mode",
        "source",
        "audit_scope_lock",
        "active_scope_summary",
        "active_scope_badge",
        "profiles",
        "preferences_snapshot",
        "onboarding",
        "hil_report_summary",
        "ux_health_snapshot",
        "scorecard",
        "heuristic_scores",
        "checklist_ratings",
        "top_finding",
        "overall_grade",
        "overall_percentage",
        "overall_descriptor",
        "plain_language_read",
        "before_using_this_interface",
        "one_recommendation",
        "top_findings",
        "findings",
        "evidence_limits",
        "next_validation_steps",
        "follow_up_activity",
        "follow_up_activity_extended",
        "reasoning_flow_suggestions",
        "evaluator_bias_advisories",
        "prioritization_flow",
        "implementation_inspection_contract",
        "implementation_evidence_summary",
        "quick_ux_risk_card",
        "support_lens_suggestions",
        "corpus_advisory_modules",
        "cultural_context_signal",
        "accessibility_readiness_signal",
        "evidence_graph",
        "evidence_ref_validation",
        "adapter_evidence_summary",
        "report_readiness_contract",
    ]
    payload = {key: result[key] for key in keys if key in result and result[key] is not None}
    payload["hil_report_summary"] = _hil_report_summary(result)
    return payload


def _hil_report_summary(result: dict[str, Any]) -> dict[str, Any]:
    hil_state = result.get("hil_state") or {}
    compliance = result.get("hil_compliance") or {}
    human_loop = result.get("human_loop_host_action") or {}
    enabled = bool(hil_state.get("enabled"))
    status = str(compliance.get("host_question_ui_status") or hil_state.get("host_question_ui_status") or "unknown")
    native_confirmed = bool(compliance.get("native_ui_confirmed"))
    text_fallback_used = bool(compliance.get("text_fallback_used"))
    fallback_resolved = bool(compliance.get("fallback_resolved"))
    unavailable_resolved = bool(compliance.get("unavailable_resolved"))
    blocked = bool(compliance.get("HIL_BLOCKED_UNTIL_NATIVE_UI"))
    if not enabled:
        outcome = "skipped"
        note = "HIL was not used for this report payload."
    elif native_confirmed:
        outcome = "native_rendered"
        note = "HIL gates were handled through the host native question UI."
    elif text_fallback_used and fallback_resolved:
        outcome = "fallback_text_used"
        note = "HIL gates were resolved through a structured text fallback because native UI was not used."
    elif unavailable_resolved:
        outcome = "unavailable_resolved"
        note = "HIL gates were resolved after the host reported native question UI was unavailable."
    elif blocked:
        outcome = "blocked_until_native_ui"
        note = "HIL required native UI confirmation during audit orchestration; this report payload records the outcome but does not carry native UI control fields."
    else:
        outcome = status
        note = "HIL outcome metadata is report-only and does not control report generation."
    return {
        "schema_version": "uxhc.hil_report_summary.v1",
        "enabled": enabled,
        "host_question_ui_status": status,
        "outcome": outcome,
        "native_ui_required": bool(compliance.get("native_ui_required")),
        "native_ui_confirmed": native_confirmed,
        "text_fallback_used": text_fallback_used,
        "fallback_resolved": fallback_resolved,
        "unavailable_resolved": unavailable_resolved,
        "blocked_until_native_ui": blocked,
        "pause_required_at_audit": bool(human_loop.get("PAUSE_REQUIRED")),
        "resolved_gate_count": int(hil_state.get("resolved_gate_count") or compliance.get("resolved_gate_count") or 0),
        "unresolved_gate_count": int(hil_state.get("unresolved_gate_count") or compliance.get("unresolved_gate_count") or 0),
        "report_note": note,
    }


def _report_payload_blocking_fields(payload: dict[str, Any]) -> list[str]:
    source = payload.get("source") or {}
    snapshot = payload.get("ux_health_snapshot") or {}
    scorecard = payload.get("scorecard") or {}
    blocking: list[str] = []
    if not source.get("source_id"):
        blocking.append("source.source_id")
    if source.get("status") in (None, "", [], "blocked"):
        blocking.append("source.status")
    if not payload.get("platform"):
        blocking.append("platform")
    if snapshot.get("display_state") != "scored":
        blocking.append("ux_health_snapshot.display_state")
    if scorecard.get("score_status") != "scored":
        blocking.append("scorecard.score_status")
    for field in ("core_quality_percentage", "core_grade", "core_descriptor", "overall_quality_percentage", "overall_grade", "overall_descriptor"):
        if scorecard.get(field) in (None, "", []):
            blocking.append(f"scorecard.{field}")
    for field in ("heuristic_scores", "checklist_ratings", "plain_language_read", "before_using_this_interface", "top_finding", "one_recommendation", "report_readiness_contract"):
        if payload.get(field) in (None, "", []):
            blocking.append(field)
    return blocking


def _finalize_report_ready_payload(result: dict[str, Any]) -> dict[str, Any] | None:
    payload = _report_ready_payload(result)
    if not payload:
        return None
    blocking_fields = _report_payload_blocking_fields(payload)
    contract = dict(payload.get("report_readiness_contract") or {})
    contract["status"] = "blocked" if blocking_fields else "ready"
    contract["blocking_fields"] = blocking_fields
    contract["ready_means"] = "This exact report_ready_payload is expected to pass validate_ux_report_payload." if not blocking_fields else "Repair blocking_fields before passing this payload to the report renderer."
    payload["report_readiness_contract"] = contract
    if isinstance(result.get("report_readiness_contract"), dict):
        result["report_readiness_contract"] = {**result["report_readiness_contract"], **contract}
    return payload


def _write_report_payload_ref(payload: dict[str, Any] | None) -> dict[str, Any] | None:
    if not payload:
        return None
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, default=str).encode("utf-8")
    digest = hashlib.sha256(encoded).hexdigest()
    payload_id = f"uxhc_report_payload_{digest[:12]}"
    path = report_payload_path(payload_id)
    if not path.exists():
        path.write_bytes(encoded)
    return {
        "schema_version": "uxhc.report_payload_ref.v1",
        "payload_id": payload_id,
        "path": str(path),
        "sha256": digest,
        "use_with": "generate_ux_audit_report(payload_path=path)",
    }


def _checkpoint_id(result: dict[str, Any]) -> str:
    seed = json.dumps(
        {
            "tool": result.get("tool"),
            "generated_at": (result.get("audit_metadata") or {}).get("generated_at"),
            "source_id": (result.get("source") or {}).get("source_id"),
            "platform": result.get("platform"),
            "checklist_count": len(result.get("checklist_ratings") or []),
            "gate_ids": [str(gate.get("gate_id")) for gate in result.get("hil_gates") or []],
        },
        sort_keys=True,
        default=str,
    )
    return "uxhc_resume_" + hashlib.sha256(f"{seed}:{_utc_now()}".encode("utf-8")).hexdigest()[:16]


def _save_audit_checkpoint(
    *,
    result: dict[str, Any],
    prepared_source: dict[str, Any],
    report_payload: dict[str, Any] | None,
    payload_ref: dict[str, Any] | None,
    resumed_from: str | None = None,
) -> dict[str, Any] | None:
    if not result.get("PAUSE_REQUIRED"):
        return None
    resume_run_id = _checkpoint_id(result)
    path = audit_checkpoint_path(resume_run_id)
    record = {
        "schema_version": AUDIT_CHECKPOINT_SCHEMA_VERSION,
        "resume_run_id": resume_run_id,
        "created_at": _utc_now(),
        "resumed_from": resumed_from or "",
        "tool": result.get("tool"),
        "mode": result.get("mode"),
        "prepared_source": prepared_source,
        "source": result.get("source") or {},
        "platform": result.get("platform"),
        "profiles": result.get("profiles") or {},
        "goal": result.get("goal") or "",
        "audit_context": result.get("audit_context") or {},
        "checklist_ratings": result.get("checklist_ratings") or [],
        "scorecard": result.get("scorecard") or {},
        "heuristic_scores": result.get("heuristic_scores") or [],
        "findings": result.get("findings") or [],
        "top_findings": result.get("top_findings") or [],
        "evidence_limits": result.get("evidence_limits") or [],
        "hil_state": result.get("hil_state") or {},
        "hil_gates": result.get("hil_gates") or [],
        "resolved_gates": result.get("resolved_gates") or [],
        "unresolved_gates": result.get("unresolved_gates") or [],
        "hil_compliance": result.get("hil_compliance") or {},
        "hil_report_summary": _hil_report_summary(result),
        "report_ready_payload": report_payload or {},
        "report_payload_ref": payload_ref or {},
        "checkpoint_policy": {
            "state_authority": "checkpoint",
            "host_resume_fields": ["resume_run_id", "hil_answers", "resolved_gate_ids", "host_question_ui_status", "rating_overrides", "output_detail"],
            "note": "Local beta checkpoint snapshots are resumable audit state, not a long-term session database.",
        },
    }
    path.write_text(json.dumps(record, indent=2, sort_keys=True, default=str), encoding="utf-8")
    return {
        "schema_version": "uxhc.audit_checkpoint_ref.v1",
        "resume_run_id": resume_run_id,
        "path": str(path),
        "created_at": record["created_at"],
        "use_with": "audit_ux_surface(resume_run_id=resume_run_id, hil_answers=..., resolved_gate_ids=...)",
        "checkpoint_policy": record["checkpoint_policy"],
    }


def _load_audit_checkpoint(resume_run_id: str) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    path = audit_checkpoint_path(resume_run_id)
    if not path.exists():
        return None, _resume_error(
            resume_run_id=resume_run_id,
            code="resume_checkpoint_not_found",
            message="No local audit checkpoint exists for this resume_run_id.",
            checkpoint_path=str(path),
        )
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return None, _resume_error(
            resume_run_id=resume_run_id,
            code="resume_checkpoint_unreadable",
            message=f"Checkpoint JSON could not be parsed: {exc}",
            checkpoint_path=str(path),
        )
    except OSError as exc:
        return None, _resume_error(
            resume_run_id=resume_run_id,
            code="resume_checkpoint_unreadable",
            message=f"Checkpoint could not be read: {exc}",
            checkpoint_path=str(path),
        )
    if record.get("schema_version") != AUDIT_CHECKPOINT_SCHEMA_VERSION:
        return None, _resume_error(
            resume_run_id=resume_run_id,
            code="resume_checkpoint_schema_mismatch",
            message=f"Expected {AUDIT_CHECKPOINT_SCHEMA_VERSION}, got {record.get('schema_version') or 'missing'}.",
            checkpoint_path=str(path),
        )
    return record, None


def _resume_error(*, resume_run_id: str, code: str, message: str, checkpoint_path: str) -> dict[str, Any]:
    return {
        "schema_version": "uxhc.audit_resume_error.v1",
        "tool": "audit_ux_surface",
        "status": "blocked",
        "resume_run_id": resume_run_id,
        "checkpoint_path": checkpoint_path,
        "error_code": code,
        "blocking_issues": [{"code": code, "message": message, "slot": "resume_run_id"}],
        "repair_tasks": [
            {
                "slot": "resume_run_id",
                "issue": code,
                "rewrite_prompt": "Use the latest audit_checkpoint_ref.resume_run_id from the paused audit response, or rerun the audit to create a fresh checkpoint.",
                "required": True,
            }
        ],
        "next_host_action": "Retry the existing audit tool with a valid resume_run_id, or rerun the audit to create a new local checkpoint.",
    }


def _normalized_rating_overrides(rating_overrides: Any) -> list[dict[str, Any]]:
    if rating_overrides in (None, "", []):
        return []
    if isinstance(rating_overrides, dict):
        for key in ("rating_overrides", "overrides"):
            nested = rating_overrides.get(key)
            if nested not in (None, "", []):
                return _normalized_rating_overrides(nested)
        return [rating_overrides]
    if isinstance(rating_overrides, list):
        normalized = []
        for item in rating_overrides:
            if isinstance(item, dict):
                normalized.append(item)
        return normalized
    return []


def _apply_rating_overrides(
    checklist_ratings: list[dict[str, Any]] | None,
    rating_overrides: Any,
) -> tuple[list[dict[str, Any]] | None, dict[str, Any]]:
    rows = [dict(row) for row in checklist_ratings or []]
    overrides = _normalized_rating_overrides(rating_overrides)
    if not rows or not overrides:
        return checklist_ratings, {
            "schema_version": "uxhc.rating_override_summary.v1",
            "applied_count": 0,
            "unknown_checklist_item_ids": [],
            "score_policy": "Rating overrides only update explicit checklist rows and then UXHC recomputes the canonical 0-4 scorecard.",
        }
    by_id = {str(row.get("checklist_item_id")): row for row in rows if row.get("checklist_item_id")}
    applied = 0
    unknown: list[str] = []
    allowed_fields = {
        "rating",
        "evidence_refs",
        "rationale",
        "confidence",
        "evidence_limits",
        "severity_basis",
        "recommendation",
        "finding_title",
        "owner_role",
        "triage",
    }
    for override in overrides:
        item_id = str(override.get("checklist_item_id") or override.get("item_id") or "").strip()
        if not item_id or item_id not in by_id:
            if item_id:
                unknown.append(item_id)
            continue
        row = by_id[item_id]
        for field in allowed_fields:
            if field in override:
                row[field] = override[field]
        applied += 1
    return rows, {
        "schema_version": "uxhc.rating_override_summary.v1",
        "applied_count": applied,
        "unknown_checklist_item_ids": sorted(set(unknown)),
        "score_policy": "Rating overrides only update explicit checklist rows and then UXHC recomputes the canonical 0-4 scorecard.",
    }


def _compact_audit_response(result: dict[str, Any]) -> dict[str, Any]:
    compact_keys = [
        "schema_version",
        "tool",
        "audit_metadata",
        "goal",
        "audit_context",
        "platform",
        "mode",
        "source",
        "audit_scope_lock",
        "active_scope_summary",
        "active_scope_badge",
        "profiles",
        "onboarding",
        "hil_state",
        "hil_gates",
        "resolved_gates",
        "unresolved_gates",
        "hil_compliance",
        "hil_report_summary",
        "HIL_BLOCKED_UNTIL_NATIVE_UI",
        "human_loop_host_action",
        "PAUSE_REQUIRED",
        "ux_health_snapshot",
        "scorecard",
        "heuristic_scores",
        "top_finding",
        "plain_language_read",
        "before_using_this_interface",
        "one_recommendation",
        "top_findings",
        "checklist_rating_contract",
        "evidence_limits",
        "next_validation_steps",
        "follow_up_activity",
        "follow_up_activity_extended",
        "reasoning_flow_suggestions",
        "evaluator_bias_advisories",
        "prioritization_flow",
        "implementation_inspection_contract",
        "implementation_evidence_summary",
        "quick_ux_risk_card",
        "support_lens_suggestions",
        "corpus_advisory_modules",
        "cultural_context_signal",
        "accessibility_readiness_signal",
        "evidence_graph",
        "evidence_ref_validation",
        "adapter_evidence_summary",
        "report_readiness_contract",
        "report_payload_ref",
        "resume_run_id",
        "resumed_from",
        "resume_status",
        "audit_checkpoint_ref",
        "rating_override_summary",
        "large_output_guidance",
    ]
    compact = {key: result[key] for key in compact_keys if key in result and result[key] is not None}
    if "scorecard" in compact:
        compact["scorecard"] = _compact_scorecard(compact["scorecard"])
    compact["output_detail"] = "compact"
    if "checklist_ratings" in result:
        compact["checklist_ratings_omitted"] = {
            "count": len(result.get("checklist_ratings") or []),
            "reason": "Compact output omits per-item rows to keep MCP context usable.",
            "access": "Use report_payload_ref.path with generate_ux_audit_report or request output_detail='full'.",
        }
    return compact


def _status_only_audit_response(result: dict[str, Any]) -> dict[str, Any]:
    source = result.get("source") or {}
    scorecard = result.get("scorecard") or {}
    snapshot = result.get("ux_health_snapshot") or {}
    hil_state = result.get("hil_state") or {}
    scope_lock = result.get("audit_scope_lock") or {}
    active_scope_summary = result.get("active_scope_summary") or {}
    payload_ref = result.get("report_payload_ref")
    readiness = result.get("report_readiness_contract") or {}
    pause_required = bool(result.get("PAUSE_REQUIRED"))
    display_state = str(snapshot.get("display_state") or "")
    score_status = str(scorecard.get("score_status") or "needs_checklist_ratings")
    if pause_required:
        next_action = "Resolve HIL gates using the native question UI, then retry the audit call with resume_run_id plus hil_answers or resolved_gate_ids."
    elif payload_ref and readiness.get("status") == "ready":
        next_action = "Call validate_ux_report_payload(payload_path=...) and then generate_ux_audit_report(payload_path=..., response_mode='compact')."
    elif score_status != "scored":
        next_action = "Collect checklist_ratings for every active checklist item and rerun the audit."
    else:
        next_action = "Repair report readiness blockers before generating the report."
    return {
        "schema_version": result.get("schema_version"),
        "tool": result.get("tool"),
        "mode": result.get("mode"),
        "output_detail": "status_only",
        "platform": result.get("platform"),
        "display_state": display_state,
        "score_status": score_status,
        "overall_grade": scorecard.get("overall_grade") or scorecard.get("core_grade"),
        "overall_percentage": scorecard.get("overall_quality_percentage") or scorecard.get("core_quality_percentage"),
        "overall_descriptor": scorecard.get("overall_descriptor") or scorecard.get("core_descriptor"),
        "source": {
            "source_id": source.get("source_id"),
            "status": source.get("status"),
            "item_count": source.get("item_count"),
            "evidence_ref_count": len(source.get("evidence_refs") or []),
        },
        "audit_scope_summary": {
            "status": scope_lock.get("status"),
            "confirmation_required": bool(scope_lock.get("confirmation_required")),
            "scored_heuristic_count": len(scope_lock.get("scored_heuristics") or []),
            "omitted_optional_profile_count": len(scope_lock.get("omitted_optional_profiles") or []),
        },
        "active_scope_badge": active_scope_summary.get("badge") or result.get("active_scope_badge"),
        "active_scope_summary": active_scope_summary,
        "hil_state": {
            "enabled": bool(hil_state.get("enabled")),
            "gate_recommended": bool(hil_state.get("gate_recommended")),
            "gate_count": int(hil_state.get("gate_count") or 0),
            "resolved_gate_count": int(hil_state.get("resolved_gate_count") or 0),
            "unresolved_gate_count": int(hil_state.get("unresolved_gate_count") or 0),
            "host_question_ui_status": hil_state.get("host_question_ui_status"),
        },
        "PAUSE_REQUIRED": pause_required,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": bool(result.get("HIL_BLOCKED_UNTIL_NATIVE_UI")),
        "resume_run_id": result.get("resume_run_id"),
        "resumed_from": result.get("resumed_from"),
        "resume_status": result.get("resume_status"),
        "audit_checkpoint_ref": result.get("audit_checkpoint_ref"),
        "rating_override_summary": result.get("rating_override_summary"),
        "report_readiness_status": readiness.get("status"),
        "report_payload_ref": payload_ref,
        "large_output_guidance": _large_output_guidance(payload_ref),
        "next_host_action": next_action,
    }


def _normalize_quick_scan_output_detail(output_detail: str | None) -> str:
    if output_detail is None:
        return "mode_gate"
    detail = str(output_detail or "").strip().lower().replace(" ", "_")
    if detail in QUICK_SCAN_MODE_GATE_VALUES:
        return "mode_gate"
    if detail in GUIDANCE_ONLY_MODES:
        return "guidance_only"
    if detail in {"status_only", "compact", "full"}:
        return detail
    return "mode_gate"


def _normalize_guidance_intent(guidance_intent: str | None) -> str:
    intent = str(guidance_intent or "direct_fix").strip().lower().replace(" ", "_").replace("-", "_")
    return intent if intent in GUIDANCE_INTENTS else "direct_fix"


def _quick_scan_mode_gate(*, platform: str | None, guidance_intent: str | None) -> dict[str, Any]:
    intent = _normalize_guidance_intent(guidance_intent)
    options = [
        {
            "value": "guidance_only",
            "label": "Ultra-quick guidance",
            "recommended_when": "Small component, UI code, screenshot, or prompt refinement where the host needs UXHC cues but no audit.",
            "returns": "A tiny guidance_only_card with heuristic/support-lens cues, evidence limits, and next action.",
        },
        {
            "value": "status_only",
            "label": "Status-only audit",
            "recommended_when": "Checklist ratings are ready and the host wants a small orchestration response plus payload path.",
            "returns": "Grade/status/HIL counts/source status/report readiness without large findings or checklist rows.",
        },
        {
            "value": "compact",
            "label": "Compact diagnostics",
            "recommended_when": "The host needs top findings, quick risk card, or compact audit context in chat.",
            "returns": "Compact audit fields with large checklist rows omitted.",
        },
        {
            "value": "full",
            "label": "Full diagnostic audit",
            "recommended_when": "The host explicitly needs the full audit object for debugging or fixture work.",
            "returns": "Full audit response, including large arrays and report-ready payload fields when available.",
        },
    ]
    return {
        "schema_version": "uxhc.quick_scan_mode_gate.v1",
        "tool": "quick_scan_ux",
        "mode": "quick",
        "status": "needs_quick_scan_mode_choice",
        "output_detail": "mode_gate",
        "platform": platform,
        "PAUSE_REQUIRED": True,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": False,
        "quick_scan_mode_gate": {
            "gate_type": "quick_scan_mode_choice",
            "question": "Which quick_scan_ux mode should UXHC use for this request?",
            "recommended_default": "guidance_only",
            "secondary_default": "status_only",
            "guidance_intent": intent,
            "options": options,
            "ask_user_question_call": {
                "tool_name": "AskUserQuestion",
                "arguments": {
                    "question": "Which quick-scan mode should I use?",
                    "multiSelect": False,
                    "options": [
                        {
                            "label": option["label"],
                            "value": option["value"],
                            "description": option["recommended_when"],
                        }
                        for option in options
                    ],
                },
            },
            "host_instruction": "Ask only this lightweight mode-choice question, then rerun quick_scan_ux with the selected output_detail. Use guidance_only for direct edits or fix prompts; use status_only for scored audit orchestration.",
        },
        "next_host_action": "Rerun quick_scan_ux with output_detail='guidance_only', 'status_only', 'compact', or 'full'.",
        "claim_boundaries": [
            "This is only a mode chooser; it is not a UX audit.",
            "Do not present a grade, scorecard, compliance claim, or user-testing claim from this response.",
        ],
    }


def _guidance_context_text(
    prepared_source: dict[str, Any],
    *,
    observations: list[Any] | str | None,
    goal: str | None,
    audit_context: dict[str, Any] | None,
) -> str:
    parts: list[str] = []
    for observation in _as_observations(observations):
        parts.append(str(observation.get("text") or observation.get("observed_issue") or observation.get("issue") or observation.get("title") or ""))
    if goal:
        parts.append(str(goal))
    context = audit_context or {}
    for key in ("primary_task", "user_task", "task", "audit_goal", "component", "component_name", "visible_text_summary"):
        if context.get(key):
            parts.append(str(context[key]))
    for item in prepared_source.get("items") or []:
        for key in ("visible_text_summary", "page_title", "state_label", "url", "input_path"):
            if item.get(key):
                parts.append(str(item[key]))
    return " ".join(part.strip() for part in parts if str(part or "").strip()).strip()


def _guidance_refinement_directions(finding: dict[str, Any] | None, *, intent: str) -> list[str]:
    recommendation = str((finding or {}).get("recommendation") or "").strip()
    heuristic_name = str((finding or {}).get("heuristic_name") or "the relevant UX heuristic").strip()
    if intent == "fix_prompt":
        base = recommendation or f"Ask the coding or design agent to improve the element against {heuristic_name} without changing unrelated behavior."
        return [
            f"Ask the coding or design agent to: {base}",
            "Ask for rendered verification when layout, focus, responsive behavior, or interaction state matters.",
        ]
    if intent == "micro_plan":
        return [
            "Name the user goal and the element that feels off.",
            recommendation or f"Make one small change that improves {heuristic_name}.",
            "Recheck the changed state with the same evidence boundary before expanding scope.",
        ]
    if intent == "name_the_problem":
        return [
            f"Describe the issue as a possible {heuristic_name} mismatch, not as a scored defect.",
            "Use the supporting lens names only to clarify the design principle at stake.",
        ]
    return [
        recommendation or f"Make the next user action clearer, safer, or easier to recover from using {heuristic_name} as the guide.",
        "Keep the edit local to the visible component or state unless the user asks for a broader audit.",
    ]


def _guidance_only_response(
    prepared_source: dict[str, Any] | None,
    *,
    sources: str | list[str] | None,
    observations: list[Any] | str | None,
    platform: str | None,
    goal: str | None,
    audit_context: dict[str, Any] | None,
    guidance_intent: str | None,
) -> dict[str, Any]:
    if prepared_source is None:
        prepared_source = prepare_ux_source(sources)
    source = dict(prepared_source or {})
    audit_context_in = dict(audit_context or {})
    if "evidence_graph" not in source:
        graph = build_evidence_graph(
            source,
            external_evidence=_external_evidence_from_context(audit_context_in),
            evidence_regions=_evidence_regions_from_context(audit_context_in),
        )
        source["evidence_graph"] = graph
        source["adapter_evidence_summary"] = adapter_evidence_summary(graph)
    source_status = _derived_source_status(source)
    platform_key = infer_platform_from_source(source, platform)
    intent = _normalize_guidance_intent(guidance_intent)
    evidence_refs = _evidence_ref_values(source)
    context_text = _guidance_context_text(source, observations=observations, goal=goal, audit_context=audit_context_in)
    evidence_limits = _source_evidence_limits(source)
    if not evidence_refs:
        evidence_limits.append(
            {
                "checklist_item_id": "source",
                "reason": "No traceable evidence refs are available for guidance-only mode",
                "confidence_impact": "guidance can name review angles but not claim visual confirmation",
                "evaluatable": False,
            }
        )

    finding: dict[str, Any] | None = None
    support_lenses: list[dict[str, Any]] = []
    if context_text:
        finding = _normalize_finding({"text": context_text, "title": "Guidance-only refinement target", "evidence_ref": evidence_refs[0] if evidence_refs else ""}, 1, evidence_refs[0] if evidence_refs else "")
        support_lenses = select_support_lenses_for_finding(finding, max_lenses=3)

    heuristic_cues = []
    if finding:
        heuristic_cues.append(
            {
                "heuristic_id": finding.get("heuristic_id"),
                "heuristic_name": finding.get("heuristic_name"),
                "why_relevant": "Selected from the supplied observation, goal, source labels, or visible text summary.",
                "score_policy": "guidance_only_no_rating",
            }
        )

    lens_cues = [
        {
            "lens_id": lens.get("lens_id"),
            "name": lens.get("name"),
            "family": lens.get("family"),
            "why_applies": lens.get("why_applies"),
            "caveat": lens.get("caveat"),
            "score_policy": "support_only",
        }
        for lens in support_lenses[:3]
    ]

    if finding:
        likely_problem = f"Possible {finding.get('heuristic_name')} friction: {finding.get('observed_issue') or finding.get('title')}."
        validation_nudge = "After the edit, rerun rendered or screenshot evidence for the same state and only escalate to scoring if complete checklist ratings are supplied."
    elif source_status == "blocked":
        likely_problem = "No supported UI problem can be named yet because UXHC does not have usable evidence or a concrete observation."
        validation_nudge = "Prepare a screenshot, rendered browser capture, source manifest, or concrete observation before relying on this guidance."
    else:
        likely_problem = "Use the prepared evidence as a narrow refinement target, but do not name a specific UX problem until the host supplies an observation or checklist ratings."
        validation_nudge = "Have the host inspect the rendered or screenshot evidence, then rerun guidance_only with the observed friction."

    return {
        "schema_version": "uxhc.quick_scan_guidance_only.v1",
        "tool": "quick_scan_ux",
        "mode": "quick",
        "output_detail": "guidance_only",
        "platform": platform_key,
        "status": "ready",
        "source": {
            "source_id": source.get("source_id"),
            "status": source_status,
            "item_count": len(source.get("items") or []),
            "evidence_ref_count": len(evidence_refs),
        },
        "guidance_only_card": {
            "schema_version": "uxhc.guidance_only_card.v1",
            "display_state": "guidance_only",
            "score_authority": "none",
            "guidance_intent": intent,
            "likely_problem_language": likely_problem,
            "heuristic_cues": heuristic_cues[:3],
            "support_lens_cues": lens_cues,
            "suggested_refinement_directions": _guidance_refinement_directions(finding, intent=intent),
            "validation_nudge": validation_nudge,
            "evidence_refs": evidence_refs[:8],
            "evidence_limits": evidence_limits[:8],
            "next_host_action": {
                "direct_fix": "Use these cues to make a small direct edit, then recheck the same visible state.",
                "fix_prompt": "Turn these cues into a narrow implementation prompt; ask the coding agent for rendered verification when relevant.",
                "micro_plan": "Use the three-step refinement direction as the next micro-plan.",
                "name_the_problem": "Use the likely problem language as a non-scored way to describe what feels wrong.",
            }[intent],
            "claim_boundaries": [
                "No grade, scorecard, checklist completion, report payload, artifact, compliance claim, or user-testing claim is produced by guidance-only mode.",
                "Support lenses explain the review angle only and remain score_policy=support_only.",
                "Escalate to status_only, compact, full, or audit_ux_surface only when checklist ratings or report artifacts are needed.",
            ],
        },
    }


def _external_evidence_from_context(audit_context: dict[str, Any] | None) -> Any:
    context = audit_context or {}
    for key in ("external_evidence", "external_adapter_results", "adapter_results", "evidence_nodes"):
        if context.get(key) not in (None, "", []):
            return context.get(key)
    return None


def _evidence_regions_from_context(audit_context: dict[str, Any] | None) -> Any:
    context = audit_context or {}
    for key in ("evidence_regions", "screenshot_regions", "regions"):
        if context.get(key) not in (None, "", []):
            return context.get(key)
    return None


def _compact_scorecard(scorecard: dict[str, Any]) -> dict[str, Any]:
    allowed = [
        "score_status",
        "core_quality_percentage",
        "core_grade",
        "core_descriptor",
        "expanded_quality_percentage",
        "expanded_grade",
        "expanded_descriptor",
        "overall_quality_percentage",
        "overall_grade",
        "overall_descriptor",
        "active_item_count",
        "active_checklist_item_count",
        "core_item_count",
        "optional_item_count",
    ]
    return {key: scorecard.get(key) for key in allowed if key in scorecard}


def _source_evidence_limits(prepared_source: dict[str, Any]) -> list[dict[str, Any]]:
    limits: list[dict[str, Any]] = []
    source_status = _derived_source_status(prepared_source)
    if source_status != "ready":
        limits.append(
            {
                "checklist_item_id": "source",
                "reason": f"source preparation status was {source_status}",
                "confidence_impact": "ratings may be incomplete or unavailable",
                "evaluatable": False,
            }
        )
    if any(item.get("source_type") == "url_capture" and not item.get("screenshot_path") for item in prepared_source.get("items") or []):
        limits.append(
            {
                "checklist_item_id": "source",
                "reason": "URL entries were recorded without a browser screenshot",
                "confidence_impact": "visual and interaction-state ratings are limited",
                "evaluatable": False,
            }
        )
    for hint in prepared_source.get("interactive_state_hints") or []:
        if not isinstance(hint, dict) or hint.get("capture_status") == "captured":
            continue
        label = str(hint.get("label") or hint.get("state_id") or "interactive state").strip()
        state_type = str(hint.get("state_type") or "interactive_state").strip()
        limits.append(
            {
                "checklist_item_id": "source",
                "reason": f"Interactive state hint '{label}' ({state_type}) was not captured as evidence",
                "confidence_impact": "ratings for hidden tabs, toggles, modals, or alternate states may be incomplete",
                "evaluatable": False,
                "state_id": hint.get("state_id"),
            }
        )
    return limits


def _next_steps(snapshot: dict[str, Any], scorecard: dict[str, Any] | None) -> list[str]:
    if snapshot["display_state"] == "needs_checklist_ratings":
        return ["Submit checklist_ratings for every active checklist item, or use quick_scan_ux as a checklist-rating contract generator first."]
    if snapshot["display_state"] != "scored":
        return ["Supply a usable source and checklist-level ratings before generating a scored report."]
    if scorecard and any(float(row["rating"]) >= 3 for row in scorecard.get("checklist_ratings") or []):
        return ["Fix severity 3-4 checklist items first, then rerun the same source state for comparison."]
    return ["Address the highest-friction checklist items and validate with at least one representative user task."]


def _evidence_ref_values(source: dict[str, Any]) -> list[str]:
    graph_refs = [
        str(node.get("evidence_ref"))
        for node in (source.get("evidence_graph") or {}).get("nodes") or []
        if node.get("evidence_ref")
    ]
    if graph_refs:
        return sorted(set(graph_refs))
    return [
        str(ref.get("evidence_ref"))
        for ref in source.get("evidence_refs") or []
        if isinstance(ref, dict) and ref.get("evidence_ref")
    ]


def _quick_ux_risk_card(audit: dict[str, Any], quick_behavior_fields: dict[str, Any]) -> dict[str, Any]:
    snapshot = audit.get("ux_health_snapshot") or {}
    display_state = str(snapshot.get("display_state") or "needs_checklist_ratings")
    scorecard = audit.get("scorecard") or {}
    scored = bool(display_state == "scored" and scorecard.get("score_status") == "scored")
    source = audit.get("source") or {}
    evidence_refs = _evidence_ref_values(source)
    top_finding = (audit.get("top_findings") or [None])[0] or quick_behavior_fields.get("top_finding") or {}
    heuristic_refs = []
    if isinstance(top_finding, dict) and top_finding.get("heuristic_id"):
        heuristic_refs.append(str(top_finding["heuristic_id"]))
    if scored:
        card_state = "scored_quick_audit"
        top_risk = str((top_finding or {}).get("title") or snapshot.get("top_priority") or "No high-severity UX risk was scored.")
        why = str((top_finding or {}).get("user_impact") or "The quick scan has complete checklist ratings, so this risk is supported by UXHC scoring.")
        recommended_fix = str((top_finding or {}).get("recommendation") or quick_behavior_fields.get("one_recommendation") or "Address the highest-severity checklist item first.")
        next_host_action = "Use audit_ux_surface for full detail or generate_ux_audit_report with the report payload."
    elif display_state == "insufficient_evidence":
        card_state = "insufficient_evidence"
        top_risk = "UXHC cannot name a supported UX risk until bounded interface evidence is available."
        why = "This prevents the host from turning a missing or blocked source into a false UX judgment."
        recommended_fix = "Prepare a screenshot, rendered page capture, image bundle, or bounded source manifest before rating heuristics."
        next_host_action = "Call prepare_ux_source with usable interface evidence, then rerun quick_scan_ux."
    else:
        card_state = "unscored_risk_snapshot"
        if isinstance(top_finding, dict) and top_finding.get("title"):
            top_risk = str(top_finding["title"])
            why = str(top_finding.get("user_impact") or "This is an evidence-bound host observation, not a completed UXHC score.")
            recommended_fix = str(top_finding.get("recommendation") or quick_behavior_fields.get("one_recommendation") or "Collect checklist ratings before prioritizing the fix.")
        else:
            top_risk = "Visible evidence is prepared, but UXHC still needs host checklist ratings before it can score or rank UX risk."
            why = "A screenshot or adapter record can support review, but UXHC does not invent visual judgments or complete grades without checklist ratings."
            recommended_fix = "Have the host evaluate each active checklist item with 0-4 ratings, rationales, confidence, and evidence refs."
        next_host_action = "Submit complete checklist_ratings to quick_scan_ux or audit_ux_surface before presenting grades."
    validation_step = (
        quick_behavior_fields.get("follow_up_activity", {}).get("title")
        if isinstance(quick_behavior_fields.get("follow_up_activity"), dict)
        else ""
    ) or (audit.get("next_validation_steps") or ["Collect complete checklist ratings, then validate with a focused user task or first-click check."])[0]
    card = {
        "schema_version": "uxhc.quick_ux_risk_card.v1",
        "display_state": card_state,
        "score_authority": "unscored" if not scored else "checklist_ratings",
        "top_risk": top_risk,
        "why_it_matters": why,
        "heuristic_refs": heuristic_refs,
        "recommended_fix": recommended_fix,
        "validation_step": validation_step,
        "evidence_limits": audit.get("evidence_limits") or [],
        "next_host_action": next_host_action,
        "claim_boundaries": [
            "Do not present this as a complete scorecard unless display_state is scored_quick_audit.",
            "Do not claim compliance certification from quick-scan output.",
            "Do not call this real user research unless real participant evidence is supplied.",
        ],
    }
    if evidence_refs:
        card["evidence_refs"] = evidence_refs[:12]
    else:
        card["evidence_missing"] = "No traceable evidence refs are available for this quick risk card."
    return card


def _hil_is_enabled(hil_enabled: bool | None, preference_record: dict[str, Any] | None) -> bool:
    if hil_enabled is not None:
        return bool(hil_enabled)
    return (preference_record or {}).get("hil_default") == "enabled"


def _hil_gates(*, enabled: bool, display_state: str, scorecard: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not enabled:
        return []
    gates: list[dict[str, Any]] = []
    if display_state == "needs_checklist_ratings":
        gates.append(
            {
                "gate_id": "hil_gate_collect_ratings",
                "trigger": "missing_checklist_ratings",
                "heuristics_in_scope": ["all_active"],
                "prompt": "Collect or confirm checklist ratings for every active item before scoring this audit.",
                "override_allowed": False,
            }
        )
        return gates
    if scorecard and scorecard.get("score_status") == "scored":
        for score in scorecard.get("heuristic_scores") or []:
            if float(score.get("quality_percentage", 100)) < 65:
                gates.append(
                    {
                        "gate_id": f"hil_gate_below_threshold_{score['heuristic_id']}",
                        "trigger": "below_threshold",
                        "threshold": "below_b_minus",
                        "threshold_quality_percentage": 65,
                        "heuristics_in_scope": [score["heuristic_id"]],
                        "prompt": f"Review {score['heuristic_name']} before reporting because it scored below B-.",
                        "override_allowed": True,
                    }
                )
        gates.append(
            {
                "gate_id": "hil_gate_final_review",
                "trigger": "final_review",
                "heuristics_in_scope": ["all"],
                "prompt": "Review the completed scorecard. You may override any rating before the report is generated.",
                "override_allowed": True,
            }
        )
    return gates


def _extract_gate_ids(value: Any) -> set[str]:
    ids: set[str] = set()
    if value in (None, "", []):
        return ids
    if isinstance(value, str):
        ids.add(value)
        return ids
    if isinstance(value, dict):
        for key in ("gate_id", "resolved_gate_id"):
            if value.get(key):
                ids.add(str(value[key]))
        for key in ("resolved_gate_ids", "gate_ids"):
            nested = value.get(key)
            if isinstance(nested, list):
                ids.update(str(item) for item in nested if str(item))
            elif nested:
                ids.add(str(nested))
        for key in ("answers", "hil_answers"):
            ids.update(_extract_gate_ids(value.get(key)))
        return ids
    if isinstance(value, list):
        for item in value:
            ids.update(_extract_gate_ids(item))
    return ids


def _resolve_hil_gates(
    hil_gates: list[dict[str, Any]],
    *,
    hil_answers: Any = None,
    resolved_gate_ids: list[str] | str | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    resolved_ids = _extract_gate_ids(resolved_gate_ids) | _extract_gate_ids(hil_answers)
    if "hil_gate_batched_below_threshold" in resolved_ids:
        resolved_ids.update(str(gate.get("gate_id")) for gate in hil_gates if gate.get("trigger") == "below_threshold")
    resolved: list[dict[str, Any]] = []
    unresolved: list[dict[str, Any]] = []
    for gate in hil_gates:
        if str(gate.get("gate_id")) in resolved_ids:
            resolved.append(gate)
        else:
            unresolved.append(gate)
    return resolved, unresolved


def _hil_compliance(
    *,
    human_loop: dict[str, Any],
    host_question_ui_status: str | None,
    resolved_gates: list[dict[str, Any]],
    unresolved_gates: list[dict[str, Any]],
    rating_overrides: Any,
) -> dict[str, Any]:
    status = str(host_question_ui_status or "unknown").strip().lower() or "unknown"
    allowed = {"native_rendered", "fallback_text_used", "unavailable", "skipped", "unknown"}
    if status not in allowed:
        status = "unknown"
    native_required = bool(human_loop.get("PAUSE_REQUIRED") and human_loop.get("required_surface") == "native_question_ui")
    native_confirmed = status == "native_rendered"
    fallback_resolved = bool(status in {"fallback_text_used", "unavailable"} and resolved_gates and not unresolved_gates)
    unavailable_resolved = bool(status == "unavailable" and resolved_gates and not unresolved_gates)
    blocked = bool(native_required and not native_confirmed and not fallback_resolved)
    return {
        "schema_version": "uxhc.hil_compliance.v1",
        "trace_type": "HILComplianceTrace",
        "host_question_ui_status": status,
        "native_ui_required": native_required,
        "native_ui_confirmed": native_confirmed,
        "text_fallback_used": status == "fallback_text_used",
        "fallback_resolved": fallback_resolved,
        "unavailable_resolved": unavailable_resolved,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": blocked,
        "elicitation_request_present": bool(human_loop.get("elicitation_request")),
        "plain_text_questions_valid": not native_required or fallback_resolved,
        "resolved_gate_count": len(resolved_gates),
        "unresolved_gate_count": len(unresolved_gates),
        "resolved_gate_ids": [str(gate.get("gate_id")) for gate in resolved_gates],
        "unresolved_gate_ids": [str(gate.get("gate_id")) for gate in unresolved_gates],
        "rating_overrides_received": bool(rating_overrides),
    }


def audit_ux_surface(
    prepared_source: dict[str, Any] | None = None,
    *,
    sources: str | list[str] | None = None,
    observations: list[Any] | str | None = None,
    checklist_ratings: list[dict[str, Any]] | None = None,
    profiles: list[str] | str | None = None,
    platform: str | None = None,
    goal: str | None = None,
    user_id: str = "local_default",
    hil_enabled: bool | None = None,
    audit_context: dict[str, Any] | None = None,
    optional_profile_mode: str | None = None,
    full_advanced: bool | None = None,
    hil_answers: Any = None,
    host_question_ui_status: str | None = None,
    rating_overrides: Any = None,
    resolved_gate_ids: list[str] | str | None = None,
    resume_run_id: str | None = None,
    output_detail: str = "full",
) -> dict[str, Any]:
    resume_checkpoint: dict[str, Any] | None = None
    if resume_run_id:
        resume_checkpoint, resume_error = _load_audit_checkpoint(str(resume_run_id))
        if resume_error:
            return attach_run_summary(
                resume_error,
                "audit_ux_surface",
                inputs_summary={"resume_run_id": resume_run_id, "resume_status": "blocked"},
            )
        prepared_source = dict(resume_checkpoint.get("prepared_source") or {})
        checklist_ratings = list(resume_checkpoint.get("checklist_ratings") or [])
        profiles = list((resume_checkpoint.get("profiles") or {}).get("accepted") or [])
        platform = str(resume_checkpoint.get("platform") or platform or "")
        goal = str(resume_checkpoint.get("goal") or goal or "")
        audit_context = dict(resume_checkpoint.get("audit_context") or {})
        user_id = str((resume_checkpoint.get("audit_context") or {}).get("user_id") or user_id)
        if hil_enabled is None:
            hil_enabled = bool((resume_checkpoint.get("hil_state") or {}).get("enabled"))
        optional_profile_mode = str((resume_checkpoint.get("audit_context") or {}).get("optional_profile_mode") or optional_profile_mode or "scoped")
        full_advanced = bool((resume_checkpoint.get("audit_context") or {}).get("full_advanced")) if full_advanced is None else full_advanced

    if prepared_source is None:
        prepared_source = prepare_ux_source(sources)
    source_status = _derived_source_status(prepared_source)
    prepared_source = {**prepared_source, "status": source_status}
    audit_context_in = dict(audit_context or {})
    evidence_graph = build_evidence_graph(
        prepared_source,
        external_evidence=_external_evidence_from_context(audit_context_in),
        evidence_regions=_evidence_regions_from_context(audit_context_in),
    )
    prepared_source = {**prepared_source, "evidence_graph": evidence_graph, "adapter_evidence_summary": adapter_evidence_summary(evidence_graph)}

    preference_record = load_preferences(user_id)
    if platform is None and preference_record and preference_record.get("platform_default") not in {None, "ask_each_time"}:
        platform = preference_record["platform_default"]
    platform_key = infer_platform_from_source(prepared_source, platform)
    if profiles is None and preference_record:
        profiles = preference_record.get("optional_profiles") or []
    accepted_profiles, rejected_profiles = normalize_profiles(profiles)
    accepted_profiles, resolved_profile_mode = _resolve_optional_profile_scope(
        accepted_profiles=accepted_profiles,
        optional_profile_mode=optional_profile_mode,
        full_advanced=full_advanced,
    )
    scope_lock = _audit_scope_lock(
        platform=platform_key,
        accepted_profiles=accepted_profiles,
        optional_profile_mode=resolved_profile_mode,
        full_advanced=full_advanced,
        mode="advanced",
    )
    normalized_observations = _as_observations(observations)
    legacy_findings = [
        _normalize_finding(obs, idx, _default_ref(prepared_source))
        for idx, obs in enumerate(normalized_observations, start=1)
    ]
    legacy_findings = sorted(legacy_findings, key=lambda item: (-item["severity"], item["heuristic_name"], item["title"]))
    legacy_findings = attach_support_lenses_to_findings(legacy_findings)

    rating_override_summary: dict[str, Any] | None = None
    if resume_checkpoint is not None:
        checklist_ratings, rating_override_summary = _apply_rating_overrides(checklist_ratings, rating_overrides)
    scorecard = score_checklist_ratings(checklist_ratings, platform=platform_key, profiles=accepted_profiles) if checklist_ratings else None
    evidence_ref_validation = validate_evidence_refs(
        (scorecard or {}).get("checklist_ratings") or [],
        evidence_graph,
        strict=bool(audit_context_in.get("strict_evidence_refs")),
    )
    if source_status == "blocked":
        display_state = "insufficient_evidence"
        findings = legacy_findings
    elif scorecard and scorecard.get("score_status") == "scored":
        display_state = "scored"
        findings = attach_support_lenses_to_findings(_findings_from_checklist(scorecard))
    else:
        display_state = "needs_checklist_ratings"
        findings = legacy_findings
    support_lens_suggestions = summarize_support_lenses(findings)

    snapshot = _health_snapshot(
        display_state=display_state,
        source_status=source_status,
        findings=findings,
        scorecard=scorecard,
        platform=platform_key,
    )
    evidence_limits = _source_evidence_limits(prepared_source)
    if scorecard:
        evidence_limits.extend(scorecard.get("evidence_limits") or [])
    evidence_limits.extend(evidence_ref_validation.get("evidence_limits") or [])
    if display_state == "needs_checklist_ratings" and not scorecard:
        evidence_limits.append(
            {
                "checklist_item_id": "all_active_items",
                "reason": "checklist ratings were not supplied",
                "confidence_impact": "audit can provide a contract but not a full score",
                "evaluatable": False,
            }
        )
    accessibility_readiness_advisory = build_accessibility_readiness_advisory(findings, evidence_limits)
    cultural_context_advisory = build_cultural_context_advisory(findings, evidence_limits)
    corpus_advisory_modules = [
        module
        for module in [accessibility_readiness_advisory, cultural_context_advisory]
        if module
    ]

    hil_enabled_value = _hil_is_enabled(hil_enabled, preference_record)
    behavior_context = audit_context_in
    behavior_context.setdefault("source_quality", source_status)
    behavior_context.setdefault("user_id", user_id)
    behavior_context.setdefault("ux_level", (preference_record or {}).get("ux_level"))
    behavior_context.setdefault("hil_enabled", hil_enabled_value)
    behavior_context.setdefault("optional_profile_mode", resolved_profile_mode)
    behavior_context.setdefault("full_advanced", bool(full_advanced))
    behavior_context.setdefault("audit_scope_lock_status", scope_lock.get("status"))
    hil_gates = _hil_gates(enabled=hil_enabled_value, display_state=display_state, scorecard=scorecard)
    resolved_gates, unresolved_gates = _resolve_hil_gates(
        hil_gates,
        hil_answers=hil_answers,
        resolved_gate_ids=resolved_gate_ids,
    )
    threshold_gate_count = sum(1 for gate in hil_gates if gate.get("trigger") == "below_threshold")
    hil_state = {
        "enabled": hil_enabled_value,
        "default_policy": "Prompt after any heuristic below B-, plus final review.",
        "gate_recommended": bool(hil_gates),
        "gate_reason": "One or more heuristic grades fell below B-." if threshold_gate_count else "Checklist ratings require human confirmation." if hil_gates and display_state == "needs_checklist_ratings" else "Final review is available." if hil_gates else "",
        "gate_count": len(hil_gates),
        "resolved_gate_count": len(resolved_gates),
        "unresolved_gate_count": len(unresolved_gates),
        "host_question_ui_status": str(host_question_ui_status or "unknown"),
    }
    heuristic_scores = (scorecard or {}).get("heuristic_scores") or []
    checklist_rows = (scorecard or {}).get("checklist_ratings") or []
    active_scope_summary = _active_scope_summary(
        platform=platform_key,
        scope_lock=scope_lock,
        scorecard=scorecard,
        checklist_rows=checklist_rows,
    )
    behavior_fields = build_behavior_fields(
        display_state=display_state,
        mode="advanced",
        platform=platform_key,
        scorecard=scorecard,
        snapshot=snapshot,
        findings=findings,
        heuristic_scores=heuristic_scores,
        checklist_ratings=checklist_rows,
        evidence_limits=evidence_limits,
        audit_context=behavior_context,
        preferences_snapshot=preference_record or {},
    )
    human_loop = build_human_loop_host_action(
        enabled=hil_enabled_value,
        mode="advanced",
        display_state=display_state,
        platform=platform_key,
        profiles=accepted_profiles,
        hil_gates=unresolved_gates,
        onboarding=onboarding_contract(user_id),
        host_question_ui_status=host_question_ui_status,
    )
    hil_compliance = _hil_compliance(
        human_loop=human_loop,
        host_question_ui_status=host_question_ui_status,
        resolved_gates=resolved_gates,
        unresolved_gates=unresolved_gates,
        rating_overrides=rating_overrides,
    )
    primary_behavior_fields, support_behavior_fields = _split_behavior_fields(behavior_fields)

    result = {
        "schema_version": "uxhc.audit.v2",
        "tool": "audit_ux_surface",
        "audit_metadata": {
            "audit_engine_version": AUDIT_ENGINE_VERSION,
            "generated_at": _utc_now(),
            "baseline_heuristic_count": len(CORE_HEURISTICS),
            "project_specific_addons_included": False,
        },
        **({"resumed_from": resume_run_id, "resume_status": "resumed"} if resume_checkpoint is not None else {}),
        "goal": goal or "",
        "audit_context": behavior_context,
        "platform": platform_key,
        "mode": "advanced",
        "source": _source_summary(prepared_source),
        "evidence_graph": evidence_graph,
        "evidence_ref_validation": evidence_ref_validation,
        "adapter_evidence_summary": adapter_evidence_summary(evidence_graph),
        "profiles": {
            **_profile_contract(accepted_profiles, rejected_profiles, profiles),
        },
        "audit_scope_lock": scope_lock,
        "active_scope_summary": active_scope_summary,
        "active_scope_badge": active_scope_summary["badge"],
        "preferences_snapshot": preference_record or {},
        "onboarding": onboarding_contract(user_id),
        "hil_state": hil_state,
        "hil_gates": hil_gates,
        "resolved_gates": resolved_gates,
        "unresolved_gates": unresolved_gates,
        "hil_compliance": hil_compliance,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": hil_compliance["HIL_BLOCKED_UNTIL_NATIVE_UI"],
        "human_loop_host_action": human_loop,
        "PAUSE_REQUIRED": human_loop["PAUSE_REQUIRED"],
        "ux_health_snapshot": snapshot,
        "scorecard": scorecard or {"score_status": "needs_checklist_ratings"},
        "heuristic_scores": heuristic_scores,
        "checklist_ratings": checklist_rows,
        **primary_behavior_fields,
        "checklist_rating_contract": _checklist_contract(platform_key, accepted_profiles) if display_state == "needs_checklist_ratings" else None,
        "findings": findings,
        "legacy_observation_findings": legacy_findings,
        "top_findings": findings[:5],
        "evidence_limits": evidence_limits,
        "next_validation_steps": _next_steps(snapshot, scorecard),
        "support_lens_suggestions": support_lens_suggestions,
        **({"corpus_advisory_modules": corpus_advisory_modules} if corpus_advisory_modules else {}),
        **({"accessibility_readiness_signal": accessibility_readiness_advisory["top_signal"]} if accessibility_readiness_advisory else {}),
        **({"cultural_context_signal": cultural_context_advisory["top_signal"]} if cultural_context_advisory else {}),
        **({"rating_override_summary": rating_override_summary} if rating_override_summary else {}),
        **support_behavior_fields,
    }
    result["hil_report_summary"] = _hil_report_summary(result)
    report_payload = _finalize_report_ready_payload(result)
    payload_ref = _write_report_payload_ref(report_payload)
    if report_payload:
        result["report_ready_payload"] = report_payload
    if payload_ref:
        result["report_payload_ref"] = payload_ref
    checkpoint_ref = _save_audit_checkpoint(
        result=result,
        prepared_source=prepared_source,
        report_payload=report_payload,
        payload_ref=payload_ref,
        resumed_from=str(resume_run_id) if resume_checkpoint is not None and resume_run_id else None,
    )
    if checkpoint_ref:
        result["audit_checkpoint_ref"] = checkpoint_ref
        result["resume_run_id"] = checkpoint_ref["resume_run_id"]
        result["hil_state"] = {
            **(result.get("hil_state") or {}),
            "resume_run_id": checkpoint_ref["resume_run_id"],
            "checkpoint_path": checkpoint_ref["path"],
        }
    result["large_output_guidance"] = _large_output_guidance(payload_ref)
    result["output_detail"] = "full"
    trace_context = payload_trace_context(report_payload, payload_path=(payload_ref or {}).get("path"))
    detail = str(output_detail or "full").lower()
    if detail == "status_only":
        return attach_run_summary(
            _status_only_audit_response(result),
            "audit_ux_surface",
            inputs_summary={"mode": "advanced", "output_detail": "status_only", "platform": platform_key, "payload_trace_context": trace_context},
        )
    if detail == "compact":
        return attach_run_summary(
            _compact_audit_response(result),
            "audit_ux_surface",
            inputs_summary={"mode": "advanced", "output_detail": "compact", "platform": platform_key, "payload_trace_context": trace_context},
        )
    return attach_run_summary(
        result,
        "audit_ux_surface",
        inputs_summary={"mode": "advanced", "output_detail": "full", "platform": platform_key, "payload_trace_context": trace_context},
    )


def quick_scan_ux(
    prepared_source: dict[str, Any] | None = None,
    *,
    sources: str | list[str] | None = None,
    observations: list[Any] | str | None = None,
    checklist_ratings: list[dict[str, Any]] | None = None,
    profiles: list[str] | str | None = None,
    platform: str | None = None,
    goal: str | None = None,
    user_id: str = "local_default",
    hil_enabled: bool | None = None,
    audit_context: dict[str, Any] | None = None,
    optional_profile_mode: str | None = None,
    full_advanced: bool | None = None,
    hil_answers: Any = None,
    host_question_ui_status: str | None = None,
    rating_overrides: Any = None,
    resolved_gate_ids: list[str] | str | None = None,
    resume_run_id: str | None = None,
    output_detail: str | None = None,
    guidance_intent: str | None = "direct_fix",
) -> dict[str, Any]:
    detail = _normalize_quick_scan_output_detail(output_detail)
    if detail == "mode_gate" and not resume_run_id:
        return attach_run_summary(
            _quick_scan_mode_gate(platform=platform, guidance_intent=guidance_intent),
            "quick_scan_ux",
            inputs_summary={"mode": "quick", "output_detail": "mode_gate", "guidance_intent": _normalize_guidance_intent(guidance_intent)},
        )
    if detail == "guidance_only" and not resume_run_id:
        return attach_run_summary(
            _guidance_only_response(
                prepared_source,
                sources=sources,
                observations=observations,
                platform=platform,
                goal=goal,
                audit_context=audit_context,
                guidance_intent=guidance_intent,
            ),
            "quick_scan_ux",
            inputs_summary={"mode": "quick", "output_detail": "guidance_only", "guidance_intent": _normalize_guidance_intent(guidance_intent)},
        )

    audit = audit_ux_surface(
        prepared_source,
        sources=sources,
        observations=observations,
        checklist_ratings=checklist_ratings,
        profiles=profiles,
        platform=platform,
        goal=goal,
        user_id=user_id,
        hil_enabled=None if resume_run_id else False,
        audit_context=audit_context,
        optional_profile_mode=optional_profile_mode,
        full_advanced=full_advanced,
        hil_answers=hil_answers,
        host_question_ui_status=host_question_ui_status,
        rating_overrides=rating_overrides,
        resolved_gate_ids=resolved_gate_ids,
        resume_run_id=resume_run_id,
        output_detail="full",
    )
    if audit.get("status") == "blocked" and audit.get("error_code", "").startswith("resume_checkpoint_"):
        audit["tool"] = "quick_scan_ux"
        return attach_run_summary(
            audit,
            "quick_scan_ux",
            inputs_summary={"mode": "quick", "output_detail": output_detail, "resume_run_id": resume_run_id, "resume_status": "blocked"},
        )
    quick_hil = _quick_hil_enabled(
        hil_enabled=hil_enabled,
        audit_context=audit.get("audit_context") or audit_context,
        checklist_ratings=checklist_ratings,
        goal=goal,
    )
    quick_context = dict(audit.get("audit_context") or audit_context or {})
    quick_context["hil_enabled"] = bool(quick_hil)
    quick_behavior_fields = build_behavior_fields(
        display_state=audit["ux_health_snapshot"]["display_state"],
        mode="quick",
        platform=audit["platform"],
        scorecard=audit["scorecard"] if audit["scorecard"].get("score_status") == "scored" else None,
        snapshot=audit["ux_health_snapshot"],
        findings=audit["findings"],
        heuristic_scores=audit["heuristic_scores"],
        checklist_ratings=audit["checklist_ratings"],
        evidence_limits=audit["evidence_limits"],
        audit_context=quick_context,
        preferences_snapshot=audit.get("preferences_snapshot") or {},
    )
    quick_gates = [
        {
            "gate_id": "quick_context_check",
            "trigger": "quick_context",
            "heuristics_in_scope": ["all_active"],
            "prompt": "Collect lightweight context before quick checklist-guided scoring.",
            "override_allowed": False,
        }
    ] if quick_hil else []
    resolved_gates, unresolved_gates = _resolve_hil_gates(
        quick_gates,
        hil_answers=hil_answers,
        resolved_gate_ids=resolved_gate_ids,
    )
    human_loop = build_human_loop_host_action(
        enabled=bool(unresolved_gates),
        mode="quick",
        display_state=audit["ux_health_snapshot"]["display_state"],
        platform=audit["platform"],
        profiles=audit["profiles"]["accepted"],
        hil_gates=unresolved_gates,
        onboarding=audit["onboarding"],
        host_question_ui_status=host_question_ui_status,
    )
    hil_compliance = _hil_compliance(
        human_loop=human_loop,
        host_question_ui_status=host_question_ui_status,
        resolved_gates=resolved_gates,
        unresolved_gates=unresolved_gates,
        rating_overrides=rating_overrides,
    )
    primary_behavior_fields, support_behavior_fields = _split_behavior_fields(quick_behavior_fields)
    quick_risk_card = _quick_ux_risk_card(audit, quick_behavior_fields)
    result = {
        "schema_version": "uxhc.quick_scan.v2",
        "tool": "quick_scan_ux",
        **({"resumed_from": resume_run_id, "resume_status": "resumed"} if resume_run_id and audit.get("resume_status") == "resumed" else {}),
        "goal": audit["goal"],
        "audit_context": quick_context,
        "platform": audit["platform"],
        "source": audit["source"],
        "evidence_graph": audit.get("evidence_graph") or {},
        "evidence_ref_validation": audit.get("evidence_ref_validation") or {},
        "adapter_evidence_summary": audit.get("adapter_evidence_summary") or {},
        "profiles": audit["profiles"],
        "audit_scope_lock": {**audit["audit_scope_lock"], "mode": "quick"},
        "active_scope_summary": audit.get("active_scope_summary") or {},
        "active_scope_badge": audit.get("active_scope_badge") or "",
        "mode": "quick",
        "onboarding": audit["onboarding"],
        "hil_state": {
            "enabled": bool(quick_hil),
            "gate_recommended": bool(quick_gates),
            "gate_count": len(quick_gates),
            "resolved_gate_count": len(resolved_gates),
            "unresolved_gate_count": len(unresolved_gates),
            "host_question_ui_status": str(host_question_ui_status or "unknown"),
        },
        "hil_gates": quick_gates,
        "resolved_gates": resolved_gates,
        "unresolved_gates": unresolved_gates,
        "hil_compliance": hil_compliance,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": hil_compliance["HIL_BLOCKED_UNTIL_NATIVE_UI"],
        "human_loop_host_action": human_loop,
        "PAUSE_REQUIRED": human_loop["PAUSE_REQUIRED"],
        "ux_health_snapshot": audit["ux_health_snapshot"],
        "scorecard": audit["scorecard"],
        "heuristic_scores": audit["heuristic_scores"],
        "checklist_ratings": audit["checklist_ratings"],
        "quick_ux_risk_card": quick_risk_card,
        **primary_behavior_fields,
        "top_findings": audit["top_findings"][:3],
        "support_lens_suggestions": audit.get("support_lens_suggestions") or [],
        **({"corpus_advisory_modules": audit.get("corpus_advisory_modules")} if audit.get("corpus_advisory_modules") else {}),
        **({"accessibility_readiness_signal": audit.get("accessibility_readiness_signal")} if audit.get("accessibility_readiness_signal") else {}),
        **({"cultural_context_signal": audit.get("cultural_context_signal")} if audit.get("cultural_context_signal") else {}),
        **({"rating_override_summary": audit.get("rating_override_summary")} if audit.get("rating_override_summary") else {}),
        "checklist_rating_contract": audit["checklist_rating_contract"],
        "evidence_limits": audit["evidence_limits"],
        "summary": audit["ux_health_snapshot"].get("overall_label", ""),
        "next_action": audit["next_validation_steps"][0] if audit["next_validation_steps"] else "",
        **support_behavior_fields,
    }
    result["hil_report_summary"] = _hil_report_summary(result)
    report_payload = _finalize_report_ready_payload(result)
    payload_ref = _write_report_payload_ref(report_payload)
    if report_payload:
        result["report_ready_payload"] = report_payload
    if payload_ref:
        result["report_payload_ref"] = payload_ref
    checkpoint_ref = _save_audit_checkpoint(
        result=result,
        prepared_source=prepared_source if prepared_source is not None else (audit.get("source") or {}),
        report_payload=report_payload,
        payload_ref=payload_ref,
        resumed_from=str(resume_run_id) if resume_run_id else None,
    )
    if checkpoint_ref:
        result["audit_checkpoint_ref"] = checkpoint_ref
        result["resume_run_id"] = checkpoint_ref["resume_run_id"]
        result["hil_state"] = {
            **(result.get("hil_state") or {}),
            "resume_run_id": checkpoint_ref["resume_run_id"],
            "checkpoint_path": checkpoint_ref["path"],
        }
    result["large_output_guidance"] = _large_output_guidance(payload_ref)
    result["output_detail"] = "full"
    trace_context = payload_trace_context(report_payload, payload_path=(payload_ref or {}).get("path"))
    if detail == "status_only":
        return attach_run_summary(
            _status_only_audit_response(result),
            "quick_scan_ux",
            inputs_summary={"mode": "quick", "output_detail": "status_only", "platform": audit["platform"], "payload_trace_context": trace_context},
        )
    if detail == "compact":
        return attach_run_summary(
            _compact_audit_response(result),
            "quick_scan_ux",
            inputs_summary={"mode": "quick", "output_detail": "compact", "platform": audit["platform"], "payload_trace_context": trace_context},
        )
    return attach_run_summary(
        result,
        "quick_scan_ux",
        inputs_summary={"mode": "quick", "output_detail": "full", "platform": audit["platform"], "payload_trace_context": trace_context},
    )
