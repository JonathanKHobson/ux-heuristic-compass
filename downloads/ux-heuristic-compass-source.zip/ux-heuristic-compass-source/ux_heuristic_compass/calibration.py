from __future__ import annotations

from copy import deepcopy
from typing import Any

from .scoring import score_checklist_ratings


SEVERITY_CALIBRATION_FIXTURES: list[dict[str, Any]] = [
    {
        "fixture_id": "cal_critical_dead_end",
        "description": "A user reaches a task dead end with no visible recovery path.",
        "checklist_rating": {
            "checklist_item_id": "h03_d_02",
            "rating": 4,
            "evidence_refs": ["cal-1"],
            "rationale": "No clearly marked exit exists for the current task.",
            "confidence": "high",
        },
        "expected": {"severity_min": 4, "severity_max": 4, "heuristic_id": "h03"},
        "human_review_focus": "Confirm this is truly task-blocking, not only confusing.",
    },
    {
        "fixture_id": "cal_hidden_primary_action",
        "description": "A primary action is visible only after extra search or is visually buried.",
        "checklist_rating": {
            "checklist_item_id": "h08_d_02",
            "rating": 3,
            "evidence_refs": ["cal-1"],
            "rationale": "Primary actions are difficult to find and understand.",
            "confidence": "high",
        },
        "expected": {"severity_min": 3, "severity_max": 3, "heuristic_id": "h08"},
        "human_review_focus": "Check whether task completion is delayed enough to justify major severity.",
    },
    {
        "fixture_id": "cal_crowded_secondary_content",
        "description": "The screen is dense and scanning is slower, but the task remains possible.",
        "checklist_rating": {
            "checklist_item_id": "h08_d_03",
            "rating": 2,
            "evidence_refs": ["cal-1"],
            "rationale": "Page clutter slows scanning but does not block the task.",
            "confidence": "medium",
        },
        "expected": {"severity_min": 2, "severity_max": 2, "heuristic_id": "h08"},
        "human_review_focus": "Confirm the issue is friction, not a launch-blocking failure.",
    },
    {
        "fixture_id": "cal_minor_polish_typo",
        "description": "A small copy polish issue with limited task impact.",
        "checklist_rating": {
            "checklist_item_id": "h04_d_16",
            "rating": 1,
            "evidence_refs": ["cal-1"],
            "rationale": "A typo exists but does not materially block task completion.",
            "confidence": "medium",
        },
        "expected": {"severity_min": 1, "severity_max": 1, "heuristic_id": "h04"},
        "human_review_focus": "Do not over-prioritize issues that do not materially affect the task.",
    },
]


HUMAN_REVIEW_RUBRIC: list[dict[str, Any]] = [
    {
        "criterion": "Evidence-bound",
        "score_range": "1-5",
        "question": "Does the rating point to visible source evidence or a clear evidence limitation?",
    },
    {
        "criterion": "Checklist fit",
        "score_range": "1-5",
        "question": "Does the checklist item match the observed issue?",
    },
    {
        "criterion": "Severity fit",
        "score_range": "1-5",
        "question": "Is the 0-4 rating neither exaggerated nor minimized?",
    },
    {
        "criterion": "Recommendation usefulness",
        "score_range": "1-5",
        "question": "Is the recommendation concrete enough for a designer or developer to act on?",
    },
    {
        "criterion": "Plain-language clarity",
        "score_range": "1-5",
        "question": "Can a stakeholder understand the issue without UX jargon?",
    },
]


def calibrate_ux_sensitivity(fixtures: list[dict[str, Any]] | None = None, tolerance: int = 0) -> dict[str, Any]:
    selected = deepcopy(fixtures) if fixtures is not None else deepcopy(SEVERITY_CALIBRATION_FIXTURES)
    tolerance = max(0, min(2, int(tolerance)))
    results: list[dict[str, Any]] = []
    for fixture in selected:
        rating = fixture["checklist_rating"]
        expected = fixture["expected"]
        severity = int(rating["rating"])
        expected_min = max(0, int(expected["severity_min"]) - tolerance)
        expected_max = min(4, int(expected["severity_max"]) + tolerance)
        passed = expected_min <= severity <= expected_max and str(rating["checklist_item_id"]).startswith(expected["heuristic_id"])
        results.append(
            {
                "fixture_id": fixture["fixture_id"],
                "status": "passed" if passed else "failed",
                "expected_severity_range": [expected_min, expected_max],
                "actual_severity": severity,
                "expected_heuristic_id": expected["heuristic_id"],
                "actual_checklist_item_id": rating["checklist_item_id"],
                "rationale": rating["rationale"],
                "human_review_focus": fixture["human_review_focus"],
            }
        )

    failed = [item for item in results if item["status"] != "passed"]
    sample_score = score_checklist_ratings([item["checklist_rating"] for item in selected], platform="desktop")
    return {
        "schema_version": "uxhc.calibration.v2",
        "tool": "calibrate_ux_sensitivity",
        "calibration_status": "passed" if not failed else "needs_review",
        "fixture_count": len(results),
        "failed_count": len(failed),
        "tolerance": tolerance,
        "results": results,
        "human_review_rubric": deepcopy(HUMAN_REVIEW_RUBRIC),
        "checklist_contract_status": sample_score["score_status"],
        "compatibility_alias": "calibrate_ux_severity",
    }


def calibrate_ux_severity(fixtures: list[dict[str, Any]] | None = None, tolerance: int = 0) -> dict[str, Any]:
    result = calibrate_ux_sensitivity(fixtures=fixtures, tolerance=tolerance)
    result["tool"] = "calibrate_ux_severity"
    result["canonical_tool"] = "calibrate_ux_sensitivity"
    return result
