from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from .state import state_dir, utc_now


RUN_SUMMARY_SCHEMA_VERSION = "uxhc.run_summary.v1"


def run_summary_path(created_at: str | None = None) -> Path:
    date = str(created_at or utc_now()).split("T", 1)[0]
    root = state_dir() / "runs"
    root.mkdir(parents=True, exist_ok=True)
    return root / f"{date}.jsonl"


def _as_list(value: Any) -> list[Any]:
    if value in (None, "", []):
        return []
    if isinstance(value, list):
        return value
    return [value]


def _status_from_result(result: dict[str, Any]) -> str:
    for key in ("qa_status", "validation_status", "status", "prepared_status"):
        if result.get(key):
            value = str(result[key])
            if value in {"blocked", "error", "invalid_personas", "needs_agent_scorecards"}:
                return "blocked"
            if value in {"ready", "ready_with_warnings", "scored", "saved"}:
                return "ready"
            return value
    snapshot = result.get("ux_health_snapshot") or {}
    if snapshot.get("display_state"):
        return str(snapshot["display_state"])
    return "ready"


def _blockers(result: dict[str, Any]) -> list[Any]:
    blockers: list[Any] = []
    for key in ("blocking_issues", "blockers", "validation_errors"):
        blockers.extend(_as_list(result.get(key)))
    validation = result.get("validation") or {}
    blockers.extend(_as_list(validation.get("blocking_issues")))
    render_validation = result.get("render_validation") or {}
    blockers.extend(_as_list(render_validation.get("blocking_issues")))
    if result.get("HIL_BLOCKED_UNTIL_NATIVE_UI"):
        blockers.append({"code": "HIL_BLOCKED_UNTIL_NATIVE_UI", "message": "Native question UI was required but not confirmed."})
    return blockers


def _warnings(result: dict[str, Any]) -> list[Any]:
    warnings: list[Any] = []
    for key in ("warnings",):
        warnings.extend(_as_list(result.get(key)))
    source = result.get("source") or {}
    warnings.extend(_as_list(source.get("warnings")))
    validation = result.get("validation") or {}
    warnings.extend(_as_list(validation.get("warnings")))
    evidence_validation = result.get("evidence_ref_validation") or {}
    warnings.extend(_as_list(evidence_validation.get("warnings")))
    adapter_summary = result.get("adapter_evidence_summary") or {}
    warnings.extend(_as_list(adapter_summary.get("warnings")))
    return warnings


def _source_ids(result: dict[str, Any]) -> list[str]:
    ids: list[str] = []
    if result.get("source_id"):
        ids.append(str(result["source_id"]))
    source = result.get("source") or {}
    if source.get("source_id"):
        ids.append(str(source["source_id"]))
    graph = result.get("evidence_graph") or source.get("evidence_graph") or {}
    if graph.get("source_id"):
        ids.append(str(graph["source_id"]))
    return sorted(set(ids))


def _payload_paths(result: dict[str, Any]) -> dict[str, Any]:
    paths: dict[str, Any] = {}
    if result.get("report_payload_ref"):
        paths["report_payload"] = (result.get("report_payload_ref") or {}).get("path")
    if result.get("audit_checkpoint_ref"):
        paths["audit_checkpoint"] = (result.get("audit_checkpoint_ref") or {}).get("path")
    for key in ("markdown_path", "viewer_path", "pdf_path", "path"):
        if result.get(key):
            paths[key] = result[key]
    return {key: value for key, value in paths.items() if value}


def payload_trace_context(payload: dict[str, Any] | None, *, payload_path: str | None = None) -> dict[str, Any]:
    """Build compact trace metadata from a report payload without storing payload content."""
    payload = payload or {}
    source = payload.get("source") or {}
    graph = payload.get("evidence_graph") or source.get("evidence_graph") or {}
    checklist = payload.get("checklist_ratings") or (payload.get("scorecard") or {}).get("checklist_ratings") or []
    scorecard = payload.get("scorecard") or {}
    adapter_summary = payload.get("adapter_evidence_summary") or source.get("adapter_evidence_summary") or {}
    hil_summary = payload.get("hil_report_summary") or {}
    hil_state = payload.get("hil_state") or {}
    hil_compliance = payload.get("hil_compliance") or {}
    payload_paths: dict[str, Any] = {}
    if payload_path:
        payload_paths["input_payload"] = payload_path
    if payload.get("report_payload_ref"):
        payload_paths["report_payload"] = (payload.get("report_payload_ref") or {}).get("path")
    return {
        "source_ids": _source_ids(payload),
        "evidence_ref_count": int(graph.get("node_count") or len(source.get("evidence_refs") or [])),
        "adapter_sources": adapter_summary.get("adapter_sources") or graph.get("adapter_sources") or [],
        "checklist_rating_count": len(checklist),
        "missing_rating_count": len(scorecard.get("missing_checklist_item_ids") or []),
        "payload_paths": {key: value for key, value in payload_paths.items() if value},
        "hil_state": {
            "enabled": hil_summary.get("enabled", hil_state.get("enabled")),
            "PAUSE_REQUIRED": hil_summary.get("pause_required_at_audit"),
            "host_question_ui_status": hil_summary.get("host_question_ui_status") or hil_compliance.get("host_question_ui_status") or hil_state.get("host_question_ui_status"),
            "HIL_BLOCKED_UNTIL_NATIVE_UI": hil_summary.get("blocked_until_native_ui"),
        },
    }


def build_run_summary(tool_name: str, result: dict[str, Any], *, inputs_summary: dict[str, Any] | None = None) -> dict[str, Any]:
    created_at = utc_now()
    trace_context = (inputs_summary or {}).get("payload_trace_context") if isinstance(inputs_summary, dict) else {}
    trace_context = trace_context if isinstance(trace_context, dict) else {}
    source = result.get("source") or {}
    graph = result.get("evidence_graph") or source.get("evidence_graph") or {}
    checklist = result.get("checklist_ratings") or (result.get("scorecard") or {}).get("checklist_ratings") or []
    scorecard = result.get("scorecard") or {}
    hil_state = result.get("hil_state") or {}
    hil_compliance = result.get("hil_compliance") or {}
    trace_hil = trace_context.get("hil_state") or {}
    adapter_summary = result.get("adapter_evidence_summary") or source.get("adapter_evidence_summary") or {}
    blockers = _blockers(result)
    warnings = _warnings(result)
    payload_paths = {**(trace_context.get("payload_paths") or {}), **_payload_paths(result)}
    source_ids = _source_ids(result) or list(trace_context.get("source_ids") or [])
    evidence_ref_count = int(graph.get("node_count") or len(source.get("evidence_refs") or []) or trace_context.get("evidence_ref_count") or 0)
    checklist_rating_count = len(checklist) if checklist else int(trace_context.get("checklist_rating_count") or 0)
    return {
        "schema_version": RUN_SUMMARY_SCHEMA_VERSION,
        "run_id": "uxhc_run_" + uuid.uuid4().hex[:16],
        "tool_name": tool_name,
        "created_at": created_at,
        "completed_at": created_at,
        "status": _status_from_result(result),
        "source_ids": sorted(set(str(item) for item in source_ids if str(item))),
        "evidence_ref_count": evidence_ref_count,
        "adapter_sources": adapter_summary.get("adapter_sources") or graph.get("adapter_sources") or trace_context.get("adapter_sources") or [],
        "checklist_rating_count": checklist_rating_count,
        "missing_rating_count": len(scorecard.get("missing_checklist_item_ids") or []) if scorecard else int(trace_context.get("missing_rating_count") or 0),
        "validation_status": result.get("validation_status") or result.get("qa_status") or result.get("status") or "",
        "blocker_count": len(blockers),
        "warning_count": len(warnings),
        "blockers": blockers[:10],
        "warnings": warnings[:10],
        "payload_paths": {key: value for key, value in payload_paths.items() if value},
        "report_paths": {key: result.get(key) for key in ("markdown_path", "viewer_path", "pdf_path") if result.get(key)},
        "hil_state": {
            "enabled": hil_state.get("enabled", trace_hil.get("enabled")),
            "PAUSE_REQUIRED": result.get("PAUSE_REQUIRED", trace_hil.get("PAUSE_REQUIRED")),
            "host_question_ui_status": hil_compliance.get("host_question_ui_status") or hil_state.get("host_question_ui_status") or trace_hil.get("host_question_ui_status"),
            "HIL_BLOCKED_UNTIL_NATIVE_UI": result.get("HIL_BLOCKED_UNTIL_NATIVE_UI") or hil_compliance.get("HIL_BLOCKED_UNTIL_NATIVE_UI") or trace_hil.get("HIL_BLOCKED_UNTIL_NATIVE_UI"),
        },
        "inputs_summary": inputs_summary or {},
    }


def write_run_summary(summary: dict[str, Any]) -> dict[str, Any]:
    path = run_summary_path(summary.get("created_at"))
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(summary, ensure_ascii=True, sort_keys=True, default=str) + "\n")
    return {"path": str(path), "persisted": True}


def attach_run_summary(
    result: dict[str, Any],
    tool_name: str,
    *,
    inputs_summary: dict[str, Any] | None = None,
    persist: bool = True,
) -> dict[str, Any]:
    if not isinstance(result, dict):
        return result
    existing = result.get("run_summary")
    if isinstance(existing, dict) and existing.get("tool_name") == tool_name and existing.get("run_id"):
        return result
    summary = build_run_summary(tool_name, result, inputs_summary=inputs_summary)
    if persist:
        try:
            summary["persistence"] = write_run_summary(summary)
        except Exception as exc:  # pragma: no cover - trace persistence must not break tools
            summary["persistence"] = {"persisted": False, "error": str(exc)}
    result["run_summary"] = summary
    return result
