from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any


EVIDENCE_GRAPH_SCHEMA_VERSION = "uxhc.evidence_graph.v1"
EVIDENCE_REF_VALIDATION_SCHEMA_VERSION = "uxhc.evidence_ref_validation.v1"
EXTERNAL_ADAPTER_SCHEMA_VERSION = "uxhc.external_evidence_adapter.v1"

SUPPORTED_ADAPTERS = {
    "playwright_mcp",
    "chrome_devtools_mcp",
    "axe_core_playwright",
    "lighthouse",
    "figma_mcp",
    "host_supplied",
}

ADAPTER_ALIASES = {
    "playwright": "playwright_mcp",
    "playwright_mcp": "playwright_mcp",
    "playwright_snapshot": "playwright_mcp",
    "chrome_devtools": "chrome_devtools_mcp",
    "chrome_devtools_mcp": "chrome_devtools_mcp",
    "devtools": "chrome_devtools_mcp",
    "axe": "axe_core_playwright",
    "axe_core": "axe_core_playwright",
    "axe_core_playwright": "axe_core_playwright",
    "lighthouse": "lighthouse",
    "figma": "figma_mcp",
    "figma_mcp": "figma_mcp",
    "figma_dev_mode": "figma_mcp",
    "figma_node": "figma_mcp",
    "figma_frame": "figma_mcp",
    "figma_component": "figma_mcp",
    "figma_variant": "figma_mcp",
    "figma_screenshot": "figma_mcp",
    "figma_file": "figma_mcp",
    "figma_plugin": "figma_mcp",
    "prototype_frame": "figma_mcp",
    "design_token_note": "figma_mcp",
}

NODE_TYPE_ALIASES = {
    "a11y_snapshot": "accessibility_snapshot",
    "accessibility_tree": "accessibility_snapshot",
    "dom": "dom_snippet",
    "devtools": "devtools_trace",
    "code": "code_component",
    "component": "code_component",
    "text": "visible_text_summary",
    "note": "human_note",
    "screenshotregion": "screenshot_region",
    "screenshot-region": "screenshot_region",
    "region": "screenshot_region",
    "figma": "figma_node",
    "figma-file": "figma_file",
    "figma_file": "figma_file",
    "figma-node": "figma_node",
    "figma_node": "figma_node",
    "figma-frame": "figma_frame",
    "figma_frame": "figma_frame",
    "figma-component": "figma_component",
    "figma_component": "figma_component",
    "figma-variant": "figma_variant",
    "figma_variant": "figma_variant",
    "figma-screenshot": "figma_screenshot",
    "figma_screenshot": "figma_screenshot",
    "prototype-frame": "prototype_frame",
    "prototype_frame": "prototype_frame",
    "design-token-note": "design_token_note",
    "design_token_note": "design_token_note",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def stable_graph_id(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=True, sort_keys=True, default=str).encode("utf-8")
    return "uxhc_evidence_graph_" + hashlib.sha256(encoded).hexdigest()[:12]


def normalize_node_type(value: Any, fallback: str = "host_observation") -> str:
    key = str(value or fallback).strip().lower().replace("-", "_").replace(" ", "_")
    return NODE_TYPE_ALIASES.get(key, key or fallback)


def normalize_external_evidence(external_evidence: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    """Normalize optional host/adapter evidence into evidence graph nodes.

    This accepts a few friendly shapes so hosts can pass Playwright, DevTools,
    axe, Lighthouse, Figma, or hand-authored evidence without UXHC becoming
    dependent on any of those tools.
    """

    nodes: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    adapter_sources: list[str] = []

    def add_warning(code: str, message: str) -> None:
        warnings.append({"code": code, "message": message})

    def normalize_adapter(adapter: Any) -> str:
        adapter_name = str(adapter or "host_supplied").strip().lower().replace("-", "_").replace(" ", "_")
        adapter_name = ADAPTER_ALIASES.get(adapter_name, adapter_name)
        if adapter_name not in SUPPORTED_ADAPTERS:
            add_warning(
                "unknown_external_adapter",
                f"External evidence adapter '{adapter_name}' is not a known UXHC adapter; treating it as host_supplied evidence.",
            )
            return "host_supplied"
        return adapter_name

    def add_node(raw: dict[str, Any], *, adapter_name: str, default_index: int) -> None:
        evidence_ref = str(raw.get("evidence_ref") or raw.get("ref") or raw.get("id") or f"{adapter_name}-{default_index}").strip()
        if not evidence_ref:
            evidence_ref = f"{adapter_name}-{default_index}"
        parent_ref = raw.get("parent_ref")
        if not parent_ref and ":" in evidence_ref:
            parent_ref = evidence_ref.split(":", 1)[0]
        node = {
            "evidence_ref": evidence_ref,
            "node_type": normalize_node_type(raw.get("node_type") or raw.get("evidence_type") or raw.get("source_type")),
            "source_id": raw.get("source_id"),
            "parent_ref": parent_ref,
            "label": raw.get("label") or raw.get("title") or raw.get("name") or raw.get("component") or raw.get("selector") or raw.get("node_name"),
            "bounds": raw.get("bounds")
            or {
                key: raw.get(key)
                for key in ("x", "y", "width", "height")
                if raw.get(key) not in (None, "", [])
            }
            or None,
            "selector": raw.get("selector"),
            "note": raw.get("note") or raw.get("notes"),
            "quality": raw.get("quality") or "ready",
            "path": raw.get("path") or raw.get("screenshot_path") or raw.get("input_path") or raw.get("file_path"),
            "url": raw.get("url"),
            "text": raw.get("text") or raw.get("visible_text") or raw.get("summary") or raw.get("description"),
            "adapter": adapter_name,
            "adapter_source": raw.get("adapter_source") or adapter_name,
            "score_authority": "evidence_only",
            "metadata": {
                key: value
                for key, value in raw.items()
                if key
                not in {
                    "evidence_ref",
                    "ref",
                    "id",
                    "node_type",
                    "evidence_type",
                    "source_type",
                    "source_id",
                    "parent_ref",
                    "label",
                    "title",
                    "name",
                    "node_name",
                    "component",
                    "selector",
                    "bounds",
                    "x",
                    "y",
                    "width",
                    "height",
                    "note",
                    "notes",
                    "quality",
                    "path",
                    "screenshot_path",
                    "input_path",
                    "file_path",
                    "url",
                    "text",
                    "visible_text",
                    "summary",
                    "description",
                    "adapter_source",
                }
            },
            "warnings": raw.get("warnings") or [],
        }
        nodes.append(node)

    def consume(value: Any, *, adapter_name: str = "host_supplied") -> None:
        if value in (None, "", []):
            return
        if isinstance(value, list):
            for item in value:
                consume(item, adapter_name=adapter_name)
            return
        if not isinstance(value, dict):
            add_node({"text": str(value), "node_type": "host_observation"}, adapter_name=adapter_name, default_index=len(nodes) + 1)
            return

        adapter = normalize_adapter(value.get("adapter_name") or value.get("adapter") or value.get("source_adapter") or adapter_name)
        if adapter not in adapter_sources:
            adapter_sources.append(adapter)

        nested_items = value.get("items") or value.get("evidence_nodes") or value.get("nodes") or value.get("results")
        if nested_items is not None and not value.get("evidence_ref"):
            consume(nested_items, adapter_name=adapter)
            return
        add_node(value, adapter_name=adapter, default_index=len(nodes) + 1)

    consume(external_evidence)
    return nodes, warnings, adapter_sources


def build_evidence_graph(
    prepared_source: dict[str, Any] | None = None,
    *,
    external_evidence: Any = None,
    evidence_regions: Any = None,
) -> dict[str, Any]:
    source = prepared_source or {}
    source_id = source.get("source_id")
    nodes_by_ref: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    def add_node(node: dict[str, Any]) -> None:
        ref = str(node.get("evidence_ref") or "").strip()
        if not ref:
            return
        normalized = dict(node)
        normalized["evidence_ref"] = ref
        normalized.setdefault("source_id", source_id)
        normalized["node_type"] = normalize_node_type(normalized.get("node_type") or normalized.get("source_type"))
        normalized.setdefault("quality", "ready")
        normalized.setdefault("score_authority", "source_evidence")
        normalized.setdefault("warnings", [])
        if ref in nodes_by_ref:
            merged = {**nodes_by_ref[ref], **{key: value for key, value in normalized.items() if value not in (None, "", [])}}
            nodes_by_ref[ref] = merged
        else:
            nodes_by_ref[ref] = normalized

        parent_ref = normalized.get("parent_ref")
        if not parent_ref and ":" in ref:
            parent_ref = ref.split(":", 1)[0]
            nodes_by_ref[ref]["parent_ref"] = parent_ref
        if parent_ref:
            edges.append({"edge_type": "region_of", "from_ref": ref, "to_ref": str(parent_ref)})

    items_by_id = {str(item.get("item_id")): item for item in source.get("items") or []}
    for node in (source.get("evidence_graph") or {}).get("nodes") or []:
        if isinstance(node, dict):
            add_node(node)
    for ref in source.get("evidence_refs") or []:
        item_id = str(ref.get("item_id") or ref.get("evidence_ref") or "")
        item = items_by_id.get(item_id, {})
        add_node(
            {
                "evidence_ref": ref.get("evidence_ref") or item_id,
                "node_type": ref.get("source_type") or item.get("source_type") or "source",
                "source_type": ref.get("source_type") or item.get("source_type"),
                "label": ref.get("label") or item.get("state_label") or item.get("page_title"),
                "quality": ref.get("quality") or item.get("quality"),
                "path": item.get("screenshot_path") or item.get("input_path"),
                "url": item.get("url"),
                "text": item.get("visible_text_summary"),
                "metadata": {
                    "page_title": item.get("page_title"),
                    "capture_metadata_path": item.get("capture_metadata_path"),
                    "viewport": item.get("viewport"),
                },
                "warnings": item.get("warnings") or [],
            }
        )

    external_nodes, external_warnings, adapter_sources = normalize_external_evidence(external_evidence)
    warnings.extend(external_warnings)
    for node in external_nodes:
        add_node(node)

    region_nodes, region_warnings, region_adapters = normalize_external_evidence(
        {"adapter_name": "host_supplied", "evidence_nodes": evidence_regions}
        if evidence_regions not in (None, "", [])
        else None
    )
    warnings.extend(region_warnings)
    for adapter in region_adapters:
        if adapter not in adapter_sources:
            adapter_sources.append(adapter)
    for node in region_nodes:
        node["node_type"] = "screenshot_region"
        add_node(node)

    refs = set(nodes_by_ref)
    for edge in edges:
        if edge["to_ref"] and edge["to_ref"] not in refs:
            warnings.append(
                {
                    "code": "missing_parent_evidence_ref",
                    "message": f"{edge['from_ref']} references missing parent evidence ref {edge['to_ref']}.",
                }
            )

    nodes = [nodes_by_ref[ref] for ref in sorted(nodes_by_ref)]
    graph_seed = {"source_id": source_id, "refs": [node["evidence_ref"] for node in nodes]}
    all_adapter_sources = sorted({str(node.get("adapter")) for node in nodes if node.get("adapter")} | set(adapter_sources))
    return {
        "schema_version": EVIDENCE_GRAPH_SCHEMA_VERSION,
        "graph_id": stable_graph_id(graph_seed),
        "created_at": utc_now(),
        "source_id": source_id,
        "node_count": len(nodes),
        "edge_count": len(edges),
        "nodes": nodes,
        "edges": edges,
        "adapter_sources": all_adapter_sources,
        "warnings": warnings,
        "score_policy": "Evidence graph nodes support checklist interpretation; they never set UXHC scores without checklist_ratings.",
    }


def evidence_refs(graph: dict[str, Any] | None) -> set[str]:
    return {str(node.get("evidence_ref")) for node in (graph or {}).get("nodes") or [] if node.get("evidence_ref")}


def validate_evidence_refs(
    checklist_ratings: list[dict[str, Any]] | None,
    evidence_graph: dict[str, Any] | None,
    *,
    strict: bool = False,
) -> dict[str, Any]:
    known = evidence_refs(evidence_graph)
    unknown_rows: list[dict[str, Any]] = []
    graph_warnings = (evidence_graph or {}).get("warnings") or []
    parent_warnings = [warning for warning in graph_warnings if warning.get("code") == "missing_parent_evidence_ref"]
    checked_count = 0
    for row in checklist_ratings or []:
        refs = [str(ref) for ref in row.get("evidence_refs") or [] if str(ref)]
        for ref in refs:
            checked_count += 1
            if ref not in known:
                unknown_rows.append(
                    {
                        "checklist_item_id": row.get("checklist_item_id"),
                        "heuristic_id": row.get("heuristic_id"),
                        "evidence_ref": ref,
                    }
                )
    status = "ready"
    if unknown_rows or parent_warnings:
        status = "blocked" if strict else "warning"
    evidence_limits = [
        {
            "checklist_item_id": row.get("checklist_item_id") or "unknown",
            "reason": f"evidence_ref '{row.get('evidence_ref')}' was not found in the AuditEvidenceGraph",
            "confidence_impact": "rating remains usable but traceability is reduced" if not strict else "rating must be repaired before strict evidence reporting",
            "evaluatable": not strict,
        }
        for row in unknown_rows
    ]
    return {
        "schema_version": EVIDENCE_REF_VALIDATION_SCHEMA_VERSION,
        "status": status,
        "strict": bool(strict),
        "known_evidence_ref_count": len(known),
        "checked_evidence_ref_count": checked_count,
        "unknown_evidence_refs": unknown_rows,
        "warnings": [
            {
                "code": "unknown_evidence_ref",
                "message": f"{len(unknown_rows)} checklist evidence reference(s) were not present in the evidence graph.",
            }
        ]
        if unknown_rows and not strict
        else [],
        "graph_warnings": graph_warnings,
        "blockers": (
            [
                {
                    "code": "unknown_evidence_ref_strict",
                    "message": f"{len(unknown_rows)} checklist evidence reference(s) must be repaired before strict evidence reporting.",
                }
            ]
            if unknown_rows and strict
            else []
        )
        + (
            [
                {
                    "code": "missing_parent_evidence_ref_strict",
                    "message": warning.get("message", "A screenshot-region evidence ref points to a missing parent screenshot."),
                }
                for warning in parent_warnings
            ]
            if parent_warnings and strict
            else []
        ),
        "graph_blockers": [
            {
                "code": "missing_parent_evidence_ref_strict",
                "message": warning.get("message", "A screenshot-region evidence ref points to a missing parent screenshot."),
            }
            for warning in parent_warnings
        ]
        if parent_warnings and strict
        else [],
        "evidence_limits": evidence_limits,
    }


def adapter_evidence_summary(evidence_graph: dict[str, Any] | None) -> dict[str, Any]:
    graph = evidence_graph or {}
    nodes = graph.get("nodes") or []
    adapter_nodes = [node for node in nodes if node.get("adapter")]
    adapter_sources = sorted({str(node.get("adapter") or "host_supplied") for node in adapter_nodes})
    type_counts: dict[str, int] = {}
    for node in adapter_nodes:
        node_type = str(node.get("node_type") or "unknown")
        type_counts[node_type] = type_counts.get(node_type, 0) + 1
    figma_nodes = [node for node in adapter_nodes if node.get("adapter") == "figma_mcp"]
    boundary_notes: list[str] = []
    if {"axe_core_playwright", "lighthouse"} & set(adapter_sources):
        boundary_notes.append("Automated-tool signal: axe/Lighthouse evidence can identify likely accessibility or quality issues, but manual review is needed and UXHC does not certify accessibility.")
    if "figma_mcp" in adapter_sources:
        boundary_notes.append("Figma records are design evidence, not runtime observed interaction evidence or participant evidence.")
    if "chrome_devtools_mcp" in adapter_sources:
        boundary_notes.append("Chrome DevTools traces are runtime/debug evidence; console or network errors are implementation advisory until visible user impact is evidenced.")
    if "playwright_mcp" in adapter_sources:
        boundary_notes.append("Playwright accessibility snapshots validate evidence refs and page structure, but they do not auto-assign UXHC ratings.")
    if adapter_nodes:
        boundary_notes.append("All adapter outputs are evidence-only and cannot directly set UXHC scores.")
    return {
        "schema_version": EXTERNAL_ADAPTER_SCHEMA_VERSION,
        "status": "evidence_received" if adapter_nodes else "not_supplied",
        "adapter_sources": adapter_sources,
        "adapter_node_count": len(adapter_nodes),
        "node_type_counts": type_counts,
        "figma_node_count": len(figma_nodes),
        "figma_node_type_counts": {
            node_type: count
            for node_type, count in type_counts.items()
            if node_type.startswith("figma_") or node_type in {"prototype_frame", "design_token_note"}
        },
        "score_authority": "evidence_only",
        "score_policy": "Adapter outputs can support checklist interpretation but cannot directly set UXHC ratings.",
        "boundary_notes": boundary_notes,
        "warnings": graph.get("warnings") or [],
    }
