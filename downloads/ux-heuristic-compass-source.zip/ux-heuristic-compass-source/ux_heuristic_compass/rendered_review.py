from __future__ import annotations

from typing import Any


RENDERED_REVIEW_TOPIC_ALIASES = {
    "rendered_review",
    "playwright",
    "browser_review",
    "html_review",
    "visual_review",
    "rendered_browser_review",
    "local_preview",
    "ui_code_review",
}


def _normalize_topic(topic: str | None) -> str:
    return (topic or "").strip().lower().replace("-", "_").replace(" ", "_")


def is_rendered_review_topic(topic: str | None) -> bool:
    return _normalize_topic(topic) in RENDERED_REVIEW_TOPIC_ALIASES


def rendered_review_hint() -> dict[str, Any]:
    return {
        "schema_version": "uxhc.rendered_review_hint.v1",
        "message": "When the evidence is browser-compatible HTML, UI code, or a local preview, prefer rendered browser evidence before final UX claims.",
        "deeper_guidance": "Call get_started(topic=\"rendered_review\") for Playwright/local-server evidence guidance.",
        "score_policy": "Rendered-review evidence supports checklist interpretation but never auto-assigns UXHC scores.",
    }


def rendered_review_guidance(topic: str | None) -> dict[str, Any] | None:
    if not is_rendered_review_topic(topic):
        return None
    return {
        "schema_version": "uxhc.rendered_review_guidance.v1",
        "topic": "rendered_review",
        "aliases": sorted(RENDERED_REVIEW_TOPIC_ALIASES),
        "purpose": "Help cold hosts choose rendered browser review when HTML, UI code, or a local preview could behave differently from static source code.",
        "when_to_use": [
            "The user supplies HTML/CSS/JS, React/Vue/Svelte output, or browser-compatible UI code.",
            "The user asks for UX review of a local report, web page, app screen, prototype preview, or generated HTML artifact.",
            "The finding depends on layout, focus, responsive behavior, loading, click/submit states, or visible copy after rendering.",
        ],
        "local_server_guidance": [
            "Serve local HTML through HTTP/local server for browser review; avoid file:// unless the artifact is explicitly static-file safe.",
            "Use the app's existing dev server when available, otherwise a bounded local static server is enough for plain HTML.",
            "Keep the reviewed URL local or explicitly user-approved; do not crawl, authenticate, or navigate beyond the requested scope.",
        ],
        "playwright_capture_checklist": [
            "Capture the visible page state after a bounded wait.",
            "Record viewport size and platform context.",
            "Capture an accessibility snapshot when the host Playwright tool supports it.",
            "Check relevant interaction states such as focus, hover, click, submit, error, loading, and responsive layout.",
            "Note console or network issues only when they have a user-visible consequence.",
            "Return evidence refs and evidence limits so UXHC can keep scores evidence-bound.",
        ],
        "playwright_unavailable_policy": "If Playwright or browser automation is unavailable, tell the user and continue as code-only, screenshot-only, or observation-only review with explicit evidence limits.",
        "evidence_policy": {
            "score_authority": "evidence_only",
            "host_owns": "The host gathers and interprets rendered evidence.",
            "uxhc_owns": "UXHC validates evidence refs, checklist ratings, report readiness, and rendered report artifacts.",
            "no_auto_scoring": "Playwright snapshots, screenshots, and console observations can support ratings but must not directly set 0-4 checklist scores.",
        },
        "boundaries": [
            "UXHC does not install Playwright or require it.",
            "UXHC does not run a crawler or authenticated browser workflow.",
            "Rendered review is not WCAG certification, compliance proof, or real user testing.",
            "Do not use file:// as the normal route for browser review of local HTML; prefer an HTTP local server.",
        ],
        "next_host_action": "If rendered evidence is needed, gather it with host-owned Playwright/browser tooling, pass observations or adapter output into prepare_ux_source/external_evidence, then run quick_scan_ux or audit_ux_surface with evidence limits.",
    }
