from __future__ import annotations

from copy import deepcopy
from typing import Any

from .rubric import (
    GRADE_TABLE,
    canonical_checklist_item_id,
    checklist_item_by_id,
    deprecated_checklist_item_reason,
    get_active_checklist_items,
    heuristic_by_id,
    normalize_platform,
    normalize_profiles,
)


SCORING_SCHEMA_VERSION = "uxhc.scoring.v2"

SEVERITY_LABELS = {
    0: "No issue - heuristic passed",
    1: "Cosmetic - fix if time permits",
    2: "Minor - low priority fix",
    3: "Major - high priority fix",
    4: "Catastrophic - must fix immediately",
}


def rating_label(rating: float | int) -> str:
    value = int(round(float(rating)))
    value = max(0, min(4, value))
    return SEVERITY_LABELS[value]


def grade_for_percentage(percentage: float) -> dict[str, Any]:
    value = max(0.0, min(100.0, float(percentage)))
    for row in GRADE_TABLE:
        if value >= float(row["min"]):
            return {
                "letter_grade": row["letter_grade"],
                "descriptor": row["descriptor"],
                "percentage": round(value, 2),
            }
    return {"letter_grade": "F", "descriptor": "Failing - unusable or near-unusable", "percentage": round(value, 2)}


def quality_percentage_from_scores(scores: list[float | int]) -> float:
    if not scores:
        return 0.0
    total = sum(float(score) for score in scores)
    possible = len(scores) * 4
    return round((1 - (total / possible)) * 100, 2)


def _as_list(value: Any) -> list[Any]:
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _normalize_rating_value(value: Any) -> float:
    rating = float(value)
    if rating < 0:
        return 0.0
    if rating > 4:
        return 4.0
    return round(rating, 2)


def _rating_checklist_text(raw: dict[str, Any]) -> str:
    return str(raw.get("checklist_text") or raw.get("text") or raw.get("label") or "")


def _rating_map(checklist_ratings: list[dict[str, Any]] | None) -> tuple[dict[str, dict[str, Any]], list[str], list[str], list[dict[str, str]]]:
    mapped: dict[str, dict[str, Any]] = {}
    duplicates: list[str] = []
    unknown: list[str] = []
    deprecated: list[dict[str, str]] = []
    for raw in checklist_ratings or []:
        supplied_id = str(raw.get("checklist_item_id") or raw.get("id") or "").strip().lower()
        if not supplied_id:
            unknown.append("<missing_id>")
            continue
        deprecated_reason = deprecated_checklist_item_reason(supplied_id, _rating_checklist_text(raw))
        if deprecated_reason:
            deprecated.append({"checklist_item_id": supplied_id, "reason": deprecated_reason})
            continue
        item_id = canonical_checklist_item_id(supplied_id, _rating_checklist_text(raw))
        if checklist_item_by_id(item_id) is None:
            unknown.append(item_id)
            continue
        if item_id in mapped:
            duplicates.append(item_id)
        normalized_raw = dict(raw)
        if item_id != supplied_id:
            normalized_raw["legacy_checklist_item_id"] = supplied_id
        mapped[item_id] = normalized_raw
    return mapped, duplicates, unknown, deprecated


def normalize_checklist_ratings(checklist_ratings: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    for raw in checklist_ratings or []:
        supplied_id = str(raw.get("checklist_item_id") or raw.get("id") or "").strip().lower()
        if deprecated_checklist_item_reason(supplied_id, _rating_checklist_text(raw)):
            continue
        item_id = canonical_checklist_item_id(supplied_id, _rating_checklist_text(raw))
        item = checklist_item_by_id(item_id)
        if item is None or raw.get("rating") in (None, ""):
            continue
        rating = _normalize_rating_value(raw["rating"])
        evidence_refs = [str(ref) for ref in _as_list(raw.get("evidence_refs") or raw.get("evidence_ref")) if str(ref)]
        normalized_row = {
            "checklist_item_id": item["id"],
            "heuristic_id": item["heuristic_id"],
            "platform": item["platform"],
            "rating": rating,
            "rating_label": str(raw.get("rating_label") or rating_label(rating)),
            "checklist_text": item["text"],
            "source": item["source"],
            "evidence_refs": evidence_refs,
            "rationale": str(raw.get("rationale") or raw.get("reason") or ""),
            "confidence": str(raw.get("confidence") or "medium"),
            "evidence_limits": deepcopy(raw.get("evidence_limits") or []),
        }
        if raw.get("finding_title"):
            normalized_row["finding_title"] = str(raw["finding_title"])
        if raw.get("recommendation"):
            normalized_row["recommendation"] = str(raw["recommendation"])
        normalized.append(normalized_row)
    return normalized


def score_checklist_ratings(
    checklist_ratings: list[dict[str, Any]] | None,
    *,
    platform: str = "desktop",
    profiles: list[str] | str | None = None,
) -> dict[str, Any]:
    platform_key = normalize_platform(platform)
    accepted_profiles, rejected_profiles = normalize_profiles(profiles)
    active_items = get_active_checklist_items(platform_key, profiles=accepted_profiles)
    active_ids = [item["id"] for item in active_items]
    active_by_id = {item["id"]: item for item in active_items}
    supplied, duplicate_ids, unknown_ids, deprecated_ids = _rating_map(checklist_ratings)
    missing_ids = [item_id for item_id in active_ids if item_id not in supplied or supplied[item_id].get("rating") in (None, "")]

    if missing_ids:
        return {
            "schema_version": SCORING_SCHEMA_VERSION,
            "score_status": "needs_checklist_ratings",
            "platform": platform_key,
            "profiles": {"accepted": accepted_profiles, "rejected": rejected_profiles},
            "active_checklist_item_count": len(active_items),
            "required_checklist_item_ids": active_ids,
            "missing_checklist_item_ids": missing_ids,
            "duplicate_checklist_item_ids": duplicate_ids,
            "unknown_checklist_item_ids": unknown_ids,
            "deprecated_checklist_item_ids": deprecated_ids,
            "heuristic_scores": [],
            "checklist_ratings": [],
            "evidence_limits": [
                {
                    "checklist_item_id": item_id,
                    "reason": "checklist rating not supplied",
                    "confidence_impact": "audit cannot compute a complete score",
                    "evaluatable": False,
                }
                for item_id in missing_ids
            ]
            + [
                {
                    "checklist_item_id": item["checklist_item_id"],
                    "reason": item["reason"],
                    "confidence_impact": "deprecated H9 description ratings are ignored",
                    "evaluatable": False,
                }
                for item in deprecated_ids
            ],
        }

    normalized_ratings: list[dict[str, Any]] = []
    for item_id in active_ids:
        raw = supplied[item_id]
        item = active_by_id[item_id]
        rating = _normalize_rating_value(raw["rating"])
        evidence_refs = [str(ref) for ref in _as_list(raw.get("evidence_refs") or raw.get("evidence_ref")) if str(ref)]
        evidence_limits = deepcopy(raw.get("evidence_limits") or [])
        normalized_row = {
            "checklist_item_id": item_id,
            "heuristic_id": item["heuristic_id"],
            "platform": platform_key,
            "rating": rating,
            "rating_label": str(raw.get("rating_label") or rating_label(rating)),
            "checklist_text": item["text"],
            "source": item["source"],
            "evidence_refs": evidence_refs,
            "rationale": str(raw.get("rationale") or raw.get("reason") or ""),
            "confidence": str(raw.get("confidence") or "medium"),
            "evidence_limits": evidence_limits,
        }
        if raw.get("finding_title"):
            normalized_row["finding_title"] = str(raw["finding_title"])
        if raw.get("recommendation"):
            normalized_row["recommendation"] = str(raw["recommendation"])
        normalized_ratings.append(normalized_row)

    heuristic_scores = _heuristic_scores(normalized_ratings, platform_key)
    core_scores = [score for score in heuristic_scores if int(score["heuristic_id"][1:]) <= 10]
    expanded_scores = heuristic_scores
    core_quality = _average_quality(core_scores)
    expanded_quality = _average_quality(expanded_scores)
    core_grade = grade_for_percentage(core_quality)
    expanded_grade = grade_for_percentage(expanded_quality)
    optional_scores = [score for score in heuristic_scores if int(score["heuristic_id"][1:]) > 10]

    return {
        "schema_version": SCORING_SCHEMA_VERSION,
        "score_status": "scored",
        "platform": platform_key,
        "profiles": {"accepted": accepted_profiles, "rejected": rejected_profiles},
        "active_checklist_item_count": len(active_items),
        "required_checklist_item_ids": active_ids,
        "missing_checklist_item_ids": [],
        "duplicate_checklist_item_ids": duplicate_ids,
        "unknown_checklist_item_ids": unknown_ids,
        "deprecated_checklist_item_ids": deprecated_ids,
        "heuristic_scores": heuristic_scores,
        "optional_profile_scores": optional_scores,
        "checklist_ratings": normalized_ratings,
        "core_quality_percentage": core_quality,
        "core_grade": core_grade["letter_grade"],
        "core_descriptor": core_grade["descriptor"],
        "expanded_quality_percentage": expanded_quality if optional_scores else None,
        "expanded_grade": expanded_grade["letter_grade"] if optional_scores else None,
        "expanded_descriptor": expanded_grade["descriptor"] if optional_scores else None,
        "overall_quality_percentage": expanded_quality if optional_scores else core_quality,
        "overall_grade": expanded_grade["letter_grade"] if optional_scores else core_grade["letter_grade"],
        "overall_descriptor": expanded_grade["descriptor"] if optional_scores else core_grade["descriptor"],
        "evidence_limits": _aggregate_evidence_limits(normalized_ratings),
    }


def _heuristic_scores(ratings: list[dict[str, Any]], platform: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rating in ratings:
        grouped.setdefault(str(rating["heuristic_id"]), []).append(rating)
    scores: list[dict[str, Any]] = []
    for heuristic_id in sorted(grouped):
        heuristic = heuristic_by_id(heuristic_id) or {"name": heuristic_id, "profile": "core"}
        rows = grouped[heuristic_id]
        rating_values = [float(row["rating"]) for row in rows]
        quality = quality_percentage_from_scores(rating_values)
        grade = grade_for_percentage(quality)
        scores.append(
            {
                "heuristic_id": heuristic_id,
                "heuristic_name": heuristic["name"],
                "profile": heuristic.get("profile", "core"),
                "platform": platform,
                "active_item_count": len(rows),
                "sum_item_scores": round(sum(rating_values), 2),
                "average_item_severity": round(sum(rating_values) / len(rows), 2),
                "quality_percentage": quality,
                "letter_grade": grade["letter_grade"],
                "descriptor": grade["descriptor"],
                "checklist_ratings": rows,
                "evidence_limits": _aggregate_evidence_limits(rows),
            }
        )
    return scores


def _aggregate_evidence_limits(ratings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    limits: list[dict[str, Any]] = []
    for rating in ratings:
        if not rating.get("evidence_refs") and not rating.get("evidence_limits"):
            limits.append(
                {
                    "checklist_item_id": rating["checklist_item_id"],
                    "reason": "no evidence reference supplied for checklist rating",
                    "confidence_impact": "rating may be difficult to audit later",
                    "evaluatable": True,
                }
            )
        for limit in rating.get("evidence_limits") or []:
            if isinstance(limit, dict):
                merged = dict(limit)
                merged.setdefault("checklist_item_id", rating["checklist_item_id"])
                merged.setdefault("evaluatable", False)
                limits.append(merged)
            else:
                limits.append(
                    {
                        "checklist_item_id": rating["checklist_item_id"],
                        "reason": str(limit),
                        "confidence_impact": "rating confidence is reduced",
                        "evaluatable": False,
                    }
                )
    return limits


def _average_quality(scores: list[dict[str, Any]]) -> float:
    if not scores:
        return 0.0
    return round(sum(float(score["quality_percentage"]) for score in scores) / len(scores), 2)
