from __future__ import annotations

import hashlib
from copy import deepcopy
from typing import Any

from .knowledge import bias_flag, flow_suggestion
from .rubric import get_active_checklist_items, normalize_platform
from .scoring import score_checklist_ratings
from .state import get_agent_run, save_agent_run, utc_now


AGENT_SCHEMA_VERSION = "uxhc.agent_run.v1"


DEFAULT_RESEARCHER_PERSONAS: list[dict[str, Any]] = [
    {
        "agent_id": "agent_a",
        "name": "Generalist UX Researcher",
        "persona": "Generalist UX researcher with 3-5 years of consumer web experience.",
        "lens": ["task clarity", "navigation", "flow friction"],
    },
    {
        "agent_id": "agent_b",
        "name": "Senior Accessibility Specialist",
        "persona": "Senior accessibility specialist with WCAG expertise and assistive technology lens.",
        "lens": ["accessibility", "assistive technology", "motor and cognitive access"],
    },
    {
        "agent_id": "agent_c",
        "name": "Content Strategist / UX Writer",
        "persona": "Content strategist and UX writer focused on information architecture, labels, and tone.",
        "lens": ["content clarity", "information architecture", "calls to action"],
    },
]


def _agent_run_id(seed: Any) -> str:
    encoded = repr(seed).encode("utf-8")
    return "uxhc_agent_run_" + hashlib.sha256(encoded).hexdigest()[:12]


def _personas(personas: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    if not personas:
        return deepcopy(DEFAULT_RESEARCHER_PERSONAS)
    merged: list[dict[str, Any]] = []
    defaults = {item["agent_id"]: item for item in DEFAULT_RESEARCHER_PERSONAS}
    for idx, persona in enumerate(personas, start=1):
        agent_id = str(persona.get("agent_id") or f"agent_{idx}").strip()
        base = dict(defaults.get(agent_id, {}))
        base.update(persona)
        base.setdefault("agent_id", agent_id)
        base.setdefault("name", f"Agent {idx}")
        base.setdefault("persona", base["name"])
        base.setdefault("lens", [])
        merged.append(base)
    return merged


def _contract(platform: str, profiles: list[str] | str | None) -> dict[str, Any]:
    items = get_active_checklist_items(platform, profiles=profiles)
    return {
        "status": "required",
        "required_agent_count": 3,
        "default_personas": deepcopy(DEFAULT_RESEARCHER_PERSONAS),
        "personas_input_contract": {
            "required_shape": "list of persona dictionaries, not strings",
            "example_personas": [
                {
                    "agent_id": "agent_a",
                    "name": "Generalist UX Researcher",
                    "persona": "Generalist UX researcher focused on task clarity and navigation.",
                    "lens": ["task clarity", "navigation", "flow friction"],
                }
            ],
        },
        "active_checklist_item_count": len(items),
        "required_checklist_item_ids": [item["id"] for item in items],
        "example_agent_scorecard": {
            "agent_id": "agent_a",
            "checklist_ratings": [
                {
                    "checklist_item_id": items[0]["id"] if items else "h01_d_01",
                    "rating": 2,
                    "evidence_refs": ["img-1"],
                    "rationale": "Agent-specific evidence-based rationale.",
                    "confidence": "medium",
                }
            ],
        },
        "next_step": "After the host AI fills per_agent_scorecards, call audit_ux_surface with the averaged checklist_ratings or the selected per-agent checklist_ratings to produce the final scored audit report.",
    }


def _invalid_personas(personas: Any) -> bool:
    if personas in (None, "", []):
        return False
    if not isinstance(personas, list):
        return True
    return any(not isinstance(persona, dict) for persona in personas)


def _top_findings(agent_scorecard: dict[str, Any]) -> list[dict[str, Any]]:
    rows = [
        row
        for row in agent_scorecard.get("checklist_ratings") or []
        if float(row.get("rating", 0)) > 0
    ]
    rows = sorted(rows, key=lambda item: (-float(item.get("rating", 0)), str(item.get("checklist_item_id", ""))))[:3]
    return [
        {
            "checklist_item_id": row["checklist_item_id"],
            "rating": row["rating"],
            "rationale": row.get("rationale", ""),
            "voice": agent_scorecard.get("persona", {}).get("name", agent_scorecard.get("agent_id", "")),
        }
        for row in rows
    ]


def _disagreement_flags(per_agent_scorecards: list[dict[str, Any]]) -> list[dict[str, Any]]:
    values_by_item: dict[str, dict[str, float]] = {}
    for scorecard in per_agent_scorecards:
        agent_id = scorecard["agent_id"]
        for row in scorecard.get("checklist_ratings") or []:
            values_by_item.setdefault(row["checklist_item_id"], {})[agent_id] = float(row["rating"])
    flags: list[dict[str, Any]] = []
    for item_id, agent_ratings in sorted(values_by_item.items()):
        if len(agent_ratings) < 2:
            continue
        values = list(agent_ratings.values())
        spread = max(values) - min(values)
        if spread >= 2:
            min_rating = min(values)
            max_rating = max(values)
            bias_context = [
                bias_flag(
                    "framing_effect",
                    relevance_note="Agents may have interpreted the checklist item wording differently. Review the item text before accepting either rating.",
                )
            ]
            if min_rating == 0 and max_rating >= 3:
                bias_context.append(
                    bias_flag(
                        "confirmation_bias",
                        relevance_note="One agent saw no issue while another saw a major issue. Check whether either score is anchored to prior impressions instead of shared evidence.",
                    )
                )
            if item_id.startswith("h04_"):
                bias_context.append(
                    bias_flag(
                        "anchoring_bias",
                        relevance_note="This H4 disagreement appears inside a long checklist section. Review whether early item ratings anchored later judgments.",
                    )
                )
            flags.append(
                {
                    "checklist_item_id": item_id,
                    "agent_ratings": agent_ratings,
                    "min_rating": round(min_rating, 2),
                    "max_rating": round(max_rating, 2),
                    "delta": round(spread, 2),
                    "spread": round(spread, 2),
                    "reason_to_review": "Agent ratings diverged by 2 or more points.",
                    "bias_context": bias_context,
                }
            )
    return flags


def _average_scorecard(per_agent_scorecards: list[dict[str, Any]], platform: str, profiles: list[str] | str | None) -> dict[str, Any]:
    sums: dict[str, list[float]] = {}
    evidence: dict[str, list[str]] = {}
    for scorecard in per_agent_scorecards:
        for row in scorecard.get("checklist_ratings") or []:
            item_id = row["checklist_item_id"]
            sums.setdefault(item_id, []).append(float(row["rating"]))
            evidence.setdefault(item_id, [])
            for ref in row.get("evidence_refs") or []:
                if ref not in evidence[item_id]:
                    evidence[item_id].append(ref)
    averaged = [
        {
            "checklist_item_id": item_id,
            "rating": round(sum(values) / len(values), 2),
            "evidence_refs": evidence.get(item_id, []),
            "rationale": f"Average of {len(values)} researcher persona ratings.",
            "confidence": "medium",
        }
        for item_id, values in sorted(sums.items())
    ]
    return score_checklist_ratings(averaged, platform=platform, profiles=profiles)


def run_agent_audit(
    *,
    audit_session: dict[str, Any] | None = None,
    source_manifest: dict[str, Any] | None = None,
    per_agent_scorecards: list[dict[str, Any]] | None = None,
    personas: list[Any] | None = None,
    platform: str = "desktop",
    profiles: list[str] | str | None = None,
) -> dict[str, Any]:
    platform_key = normalize_platform(platform or (audit_session or {}).get("platform"))
    if _invalid_personas(personas):
        return {
            "schema_version": AGENT_SCHEMA_VERSION,
            "status": "invalid_personas",
            "user_facing_mode_name": "Researcher persona scorecard aggregation",
            "execution_mode": "host_ai_executes",
            "autonomous_execution": False,
            "persisted": False,
            "error": "personas_must_be_dictionaries",
            "received_type": type(personas).__name__,
            "agent_scorecard_contract": _contract(platform_key, profiles),
        }
    selected_personas = _personas(personas)
    agent_frame = flow_suggestion(
        "ux_flow_six_hats_review",
        heuristic_id="agent_mode_1",
        trigger_reason="Agent Mode 1 is active, so researcher personas should evaluate from intentionally different hats.",
    )
    if not per_agent_scorecards:
        return {
            "schema_version": AGENT_SCHEMA_VERSION,
            "status": "agent_run_contract_ready",
            "user_facing_mode_name": "Researcher persona scorecard aggregation",
            "execution_mode": "host_ai_executes",
            "autonomous_execution": False,
            "persisted": False,
            "agent_frame_suggestion": agent_frame,
            "agent_scorecard_contract": _contract(platform_key, profiles),
            "next_step": "Host AI should execute the persona reviews, fill per_agent_scorecards, then call run_agent_audit again. To generate the final audit report, pass the completed checklist_ratings to audit_ux_surface.",
        }

    persona_by_id = {persona["agent_id"]: persona for persona in selected_personas}
    scored_agents: list[dict[str, Any]] = []
    validation_errors: list[dict[str, Any]] = []
    for idx, raw in enumerate(per_agent_scorecards, start=1):
        agent_id = str(raw.get("agent_id") or f"agent_{idx}")
        persona = persona_by_id.get(agent_id) or (selected_personas[idx - 1] if idx - 1 < len(selected_personas) else {"agent_id": agent_id, "name": agent_id})
        score = score_checklist_ratings(raw.get("checklist_ratings") or [], platform=platform_key, profiles=profiles)
        if score["score_status"] != "scored":
            validation_errors.append({"agent_id": agent_id, "score_status": score["score_status"], "missing_checklist_item_ids": score.get("missing_checklist_item_ids", [])})
        scored_agents.append(
            {
                "agent_id": agent_id,
                "persona": persona,
                "scorecard": score,
                "checklist_ratings": score.get("checklist_ratings") or [],
                "top_findings": [],
            }
        )
    if validation_errors:
        return {
            "schema_version": AGENT_SCHEMA_VERSION,
            "status": "needs_agent_scorecards",
            "user_facing_mode_name": "Researcher persona scorecard aggregation",
            "execution_mode": "host_ai_executes",
            "autonomous_execution": False,
            "persisted": False,
            "validation_errors": validation_errors,
            "agent_scorecard_contract": _contract(platform_key, profiles),
        }

    for agent in scored_agents:
        agent["top_findings"] = _top_findings(agent)
    averaged_scorecard = _average_scorecard(scored_agents, platform_key, profiles)
    created_at = utc_now()
    seed = {
        "created_at": created_at,
        "audit_session": (audit_session or {}).get("session_id"),
        "source_manifest": (source_manifest or {}).get("source_id"),
        "agents": [agent["agent_id"] for agent in scored_agents],
    }
    run_id = _agent_run_id(seed)
    agent_run = {
        "agent_run_id": run_id,
        "audit_session_id": (audit_session or {}).get("session_id"),
        "source_manifest_id": (source_manifest or {}).get("source_id"),
        "schema_version": AGENT_SCHEMA_VERSION,
        "mode": "researcher_persona_audit",
        "platform": platform_key,
        "personas": selected_personas,
        "per_agent_scorecards": scored_agents,
        "averaged_scorecard": averaged_scorecard,
        "disagreement_flags": _disagreement_flags(scored_agents),
        "top_findings": [finding for agent in scored_agents for finding in agent["top_findings"][:3]],
        "agent_frame_suggestion": agent_frame,
        "created_at": created_at,
        "expires_at": None,
    }
    if len(agent_run["disagreement_flags"]) >= 3:
        synthesis = flow_suggestion(
            "ux_flow_findings_synthesis",
            heuristic_id="agent_mode_1",
            trigger_reason="Agent Mode 1 produced disagreement flags across 3 or more checklist items.",
        )
        if synthesis:
            agent_run["reasoning_flow_suggestions"] = [synthesis]
    persistence = save_agent_run(agent_run)
    return {
        "schema_version": AGENT_SCHEMA_VERSION,
        "status": "ready",
        "user_facing_mode_name": "Researcher persona scorecard aggregation",
        "execution_mode": "host_ai_executes",
        "autonomous_execution": False,
        "persisted": True,
        "agent_run_id": run_id,
        "agent_run": agent_run,
        "agent_frame_suggestion": agent_frame,
        "persistence": persistence,
    }


__all__ = ["DEFAULT_RESEARCHER_PERSONAS", "get_agent_run", "run_agent_audit"]
