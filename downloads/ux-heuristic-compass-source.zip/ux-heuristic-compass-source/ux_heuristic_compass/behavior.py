from __future__ import annotations

from typing import Any

from .knowledge import activity_card as registry_activity_card
from .knowledge import bias_flag, flow_suggestion, prioritization_flow as build_prioritization_flow
from .rubric import canonical_checklist_item_id, checklist_item_by_id, heuristic_by_id
from .scoring import rating_label


BEHAVIOR_SCHEMA_VERSION = "uxhc.behavior.v1"

REPORT_REQUIRED_FIELDS = [
    "overall_grade",
    "overall_percentage",
    "overall_descriptor",
    "plain_language_read",
    "before_using_this_interface",
    "top_finding",
    "one_recommendation",
    "heuristic_scores",
    "checklist_ratings",
    "evidence_limits",
]


ACTIVITY_BY_HEURISTIC: dict[str, dict[str, str]] = {
    "h01": {
        "title": "5-Second First Impression Test",
        "why": "H1 is about whether users can quickly tell where they are, what the page is for, and what to do next.",
        "focus": "Visibility of system status and value proposition clarity.",
        "thinking": "Can a user understand the screen before they start reading carefully?",
    },
    "h03": {
        "title": "Navigation Recovery Walkthrough",
        "why": "H3 issues often show up when users take a wrong path and cannot recover without friction.",
        "focus": "User control, exits, back behavior, and undo/recovery paths.",
        "thinking": "Where can the user safely go next if their first choice is wrong?",
    },
    "h06": {
        "title": "Recognition vs. Recall Task Check",
        "why": "H6 issues require users to remember options instead of recognizing clear choices on the screen.",
        "focus": "Labels, link predictability, search suggestions, filters, and visited states.",
        "thinking": "What does the interface make users remember that it could simply show?",
    },
    "h08": {
        "title": "Visual Hierarchy Audit",
        "why": "H8 issues usually mean important decisions are competing with clutter, weak hierarchy, or excessive instructions.",
        "focus": "Primary action visibility, scanability, above-the-fold priority, and clutter.",
        "thinking": "What is visually loud, what is useful, and what should be demoted?",
    },
    "h12": {
        "title": "Empathy Map Check",
        "why": "H12 issues often reflect emotional, cultural, cognitive, or safety needs that are not visible in a basic task review.",
        "focus": "Inclusion, anxiety reduction, control, safety, and situational user needs.",
        "thinking": "What might different users feel, fear, need, or misunderstand here?",
    },
}


def build_behavior_fields(
    *,
    display_state: str,
    mode: str,
    platform: str,
    scorecard: dict[str, Any] | None,
    snapshot: dict[str, Any],
    findings: list[dict[str, Any]],
    heuristic_scores: list[dict[str, Any]],
    checklist_ratings: list[dict[str, Any]],
    evidence_limits: list[dict[str, Any]],
    audit_context: dict[str, Any] | None = None,
    preferences_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    context = _audit_context(audit_context)
    scored = display_state == "scored" and bool(scorecard)
    top_finding = _top_finding(findings)
    plain_read = _plain_language_read(scored=scored, top_finding=top_finding, snapshot=snapshot)
    before_sentence = _before_using_sentence(scored=scored, top_finding=top_finding)
    recommendation = _one_recommendation(top_finding)
    activity = _follow_up_activity(mode=mode, heuristic_scores=heuristic_scores, top_finding=top_finding)
    flows = _reasoning_flow_suggestions(
        mode=mode,
        heuristic_scores=heuristic_scores,
        checklist_ratings=checklist_ratings,
        scorecard=scorecard,
        top_finding=top_finding,
        audit_context=context,
    )
    extended_activities = _follow_up_activity_extended(
        mode=mode,
        heuristic_scores=heuristic_scores,
        checklist_ratings=checklist_ratings,
        findings=findings,
        audit_context=context,
    )
    advisories = _evaluator_bias_advisories(
        scorecard=scorecard,
        heuristic_scores=heuristic_scores,
        checklist_ratings=checklist_ratings,
        audit_context=context,
        preferences_snapshot=preferences_snapshot or {},
    )
    prioritization = _prioritization_flow(scorecard)
    implementation_contract = _implementation_inspection_contract(
        audit_context=context,
        mode=mode,
        platform=platform,
    )
    implementation_summary = _implementation_evidence_summary(audit_context=context) if implementation_contract else None

    overall_grade = (scorecard or {}).get("overall_grade")
    overall_percentage = (scorecard or {}).get("overall_quality_percentage")
    overall_descriptor = (scorecard or {}).get("overall_descriptor")
    return {
        "overall_grade": overall_grade,
        "overall_percentage": overall_percentage,
        "overall_descriptor": overall_descriptor,
        "plain_language_read": plain_read,
        "before_using_this_interface": before_sentence,
        "top_finding": top_finding,
        "one_recommendation": recommendation,
        "follow_up_activity": activity,
        "follow_up_activity_extended": extended_activities,
        "reasoning_flow_suggestions": flows,
        "evaluator_bias_advisories": advisories,
        **({"prioritization_flow": prioritization} if prioritization else {}),
        **({"implementation_inspection_contract": implementation_contract} if implementation_contract else {}),
        **({"implementation_evidence_summary": implementation_summary} if implementation_summary else {}),
        "report_readiness_contract": {
            "schema_version": "uxhc.report_readiness.v1",
            "status": "ready" if scored else "needs_checklist_ratings",
            "platform": platform,
            "required_fields": REPORT_REQUIRED_FIELDS,
            "purpose": "Use this contract to confirm the scored audit is ready for validate_ux_report_payload and generate_ux_audit_report.",
            "field_constraints": {
                "plain_language_read": "Required for scored audits; 1-2 nontechnical sentences.",
                "before_using_this_interface": "Required for scored audits; must start with 'Before using this interface,'.",
                "top_finding": "Required for scored audits; use status=no_scored_findings for a perfect score.",
                "one_recommendation": "Required for scored audits; one concrete next fix or validation action.",
            },
            "report_payload_contract": {
                "accepted_inputs": [
                    "Pass the full scored audit response as payload.",
                    "Pass report_ready_payload from a full response as payload.",
                    "Pass report_payload_ref.path as payload_path when the audit response used compact output.",
                ],
                "do_not_use": "Do not pass this contract object itself as the report payload.",
                "compact_output_policy": "Compact audit responses omit the large inline report payload and provide a payload_path instead.",
            },
            "report_payload_fields": [
                "source",
                "platform",
                "ux_health_snapshot",
                "scorecard",
                "heuristic_scores",
                "checklist_ratings",
                "evidence_limits",
                *REPORT_REQUIRED_FIELDS,
                "report_readiness_contract",
            ],
            "pre_call_checklist": [
                "Confirm source.status is ready.",
                "Confirm every active checklist item has a 0-4 rating or explicit evidence limit.",
                "Confirm overall grade fields, plain-language read, before-using sentence, and one recommendation are present.",
            ],
            "post_call_rules": [
                "Render overall grade and plain-language read near the top of the report.",
                "Keep optional profiles separate from core heuristic health.",
                "Show evidence limits instead of overstating certainty.",
            ],
        },
    }


def build_human_loop_host_action(
    *,
    enabled: bool,
    mode: str,
    display_state: str,
    platform: str,
    profiles: list[str],
    hil_gates: list[dict[str, Any]],
    onboarding: dict[str, Any],
    host_question_ui_status: str | None = None,
) -> dict[str, Any]:
    if mode == "quick":
        if not enabled:
            return _no_pause_action(mode=mode, reason="Quick audit has enough context to continue without a host pause.")
        return _pause_action(
            mode=mode,
            stage="pre_audit",
            current_gate={
                "gate_id": "quick_context_check",
                "trigger": "quick_context",
                "heuristics_in_scope": ["all_active"],
                "prompt": "Collect lightweight context before the host AI performs a quick checklist-guided pass.",
                "override_allowed": False,
            },
            hil_gates=hil_gates,
            questions=_quick_context_questions(platform=platform, profiles=profiles),
            resume_tool="quick_scan_ux",
            host_question_ui_status=host_question_ui_status,
        )

    if not enabled:
        return _no_pause_action(mode=mode, reason="Human-in-the-loop review is disabled.")
    if not hil_gates:
        return _no_pause_action(mode=mode, reason="All human-loop gates supplied to this call are resolved.")

    below_threshold_gates = [gate for gate in hil_gates if gate.get("trigger") == "below_threshold"]
    final_review_gate = next((gate for gate in hil_gates if gate.get("trigger") == "final_review"), None)
    current_gate = hil_gates[0] if hil_gates else None
    if display_state == "needs_checklist_ratings":
        stage = "pre_audit"
        questions = _pre_audit_questions(platform=platform, profiles=profiles, onboarding=onboarding)
    elif below_threshold_gates:
        stage = "mid_audit"
        current_gate = _batched_mid_audit_gate(below_threshold_gates)
        questions = _mid_audit_questions(current_gate)
    elif final_review_gate:
        stage = "final_review"
        current_gate = final_review_gate
        questions = _final_review_questions()
    else:
        return _no_pause_action(mode=mode, reason="No active HIL gate is required.")

    return _pause_action(
        mode=mode,
        stage=stage,
        current_gate=current_gate,
        hil_gates=hil_gates,
        questions=questions,
        resume_tool="audit_ux_surface",
        host_question_ui_status=host_question_ui_status,
    )


def _pause_action(
    *,
    mode: str,
    stage: str,
    current_gate: dict[str, Any] | None,
    hil_gates: list[dict[str, Any]],
    questions: list[dict[str, Any]],
    resume_tool: str,
    host_question_ui_status: str | None,
) -> dict[str, Any]:
    status = str(host_question_ui_status or "unknown").strip().lower() or "unknown"
    if status not in {"native_rendered", "fallback_text_used", "unavailable", "skipped", "unknown"}:
        status = "unknown"
    blocked_until_native = status != "native_rendered"
    return {
        "schema_version": "uxhc.human_loop.v1",
        "PAUSE_REQUIRED": True,
        "must_pause": True,
        "mode": mode,
        "stage": stage,
        "required_surface": "native_question_ui",
        "host_instruction": "PAUSE_REQUIRED is true. Call the host's native AskUserQuestion/question UI with ask_user_question_call before continuing; do not render these questions as ordinary markdown.",
        "host_question_ui_status": status,
        "HIL_BLOCKED_UNTIL_NATIVE_UI": blocked_until_native,
        "native_question_ui_compliance": {
            "required": True,
            "status": status,
            "native_rendered": status == "native_rendered",
            "text_fallback_used": status == "fallback_text_used",
            "blocked_until_native_ui_confirmed": blocked_until_native,
        },
        "current_gate": current_gate,
        "all_gates": hil_gates,
        "cadence_contract": {
            "schema_version": "uxhc.hil_cadence.v1",
            "policy": "core_audit_first",
            "quick_audit": {
                "stage": "pre_audit",
                "question_count": 3,
                "purpose": "Collect lightweight task, platform, and source context before quick checklist-guided scoring.",
            },
            "advanced_audit": [
                {"stage": "pre_audit", "question_count": 3, "purpose": "Context before checklist ratings are produced."},
                {"stage": "mid_audit", "question_count": 3, "purpose": "Human opinion and calibration around low-scoring heuristics."},
                {"stage": "final_review", "question_count": 3, "purpose": "Reflection, report readiness, and next validation."},
            ],
        },
        "questions_for_user": questions,
        "ask_user_question_call": _ask_user_question_call(stage=stage, questions=questions),
        "resume_contract": {
            "tool": resume_tool,
            "resume_with": ["prepared_source", "checklist_ratings", "profiles", "platform", "goal", "hil_enabled", "hil_answers", "host_question_ui_status", "rating_overrides", "resolved_gate_ids"],
            "skip_allowed": True,
            "override_allowed": bool(current_gate and current_gate.get("override_allowed")),
        },
        "what_this_can_change": [
            "active platform",
            "optional profiles",
            "audit goal/context",
            "checklist rating overrides",
            "report recommendation priority",
        ],
        "what_this_cannot_change": [
            "baseline rubric definitions",
            "source evidence that was not supplied",
            "donor/conversion exclusion policy",
        ],
        "tool_compliance_signal": "pause_and_render_questions",
        "repair_instruction": "If the host cannot render native questions, summarize only these questions and wait for answers before proceeding.",
    }


def stress_test_heuristic_finding(
    *,
    checklist_item_id: str,
    rating: int | float,
    rationale: str,
    platform: str | None = None,
    evidence_refs: list[str] | str | None = None,
) -> dict[str, Any]:
    supplied_id = str(checklist_item_id or "").strip().lower()
    item_id = canonical_checklist_item_id(supplied_id, "")
    item = checklist_item_by_id(item_id)
    if item is None:
        return {
            "schema_version": "uxhc.stress_test.v1",
            "tool": "stress_test_heuristic_finding",
            "status": "error",
            "error": "unknown_checklist_item_id",
            "checklist_item_id": supplied_id,
        }
    value = max(0.0, min(4.0, float(rating)))
    heuristic = heuristic_by_id(item["heuristic_id"]) or {"id": item["heuristic_id"], "name": item["heuristic_id"]}
    evidence = _as_list(evidence_refs)
    confidence = "medium" if rationale and evidence else "low" if not evidence else "medium"
    result = {
        "schema_version": "uxhc.stress_test.v1",
        "tool": "stress_test_heuristic_finding",
        "status": "ready",
        "checklist_item_id": item["id"],
        "platform": platform or item["platform"],
        "related_heuristic": {
            "heuristic_id": heuristic["id"],
            "heuristic_name": heuristic["name"],
            "checklist_text": item["text"],
        },
        "rating": value,
        "rating_label": rating_label(value),
        "alternative_explanation": _alternative_explanation(item["text"], value),
        "false_positive_check": _false_positive_check(item["text"], value),
        "why_it_likely_matters": _why_it_matters(heuristic["name"], item["text"], value),
        "probing_question": f"What user task or evidence would prove that '{item['text']}' is creating real friction rather than just evaluator preference?",
        "confidence": confidence,
        "one_concrete_fix": _stress_fix(heuristic["name"], item["text"]),
        "evidence_limit": {
            "evidence_refs": evidence,
            "limitation": "No evidence references were supplied; treat this as a reasoning check, not a validated finding." if not evidence else "",
        },
        "host_note": "Use this to check whether one heuristic finding is real usability friction, a source limitation, or evaluator preference before treating it as report-worthy.",
    }
    if value >= 3:
        flags = [
            bias_flag(
                "confirmation_bias",
                relevance_note="This rating is severity 3+. Check that it is anchored to current source evidence, not prior impressions.",
            ),
            bias_flag(
                "framing_effect",
                relevance_note="This rating is severity 3+. Restate the checklist item neutrally before accepting the score.",
            ),
        ]
        if not evidence:
            flags.append(
                bias_flag(
                    "availability_heuristic",
                    relevance_note="No evidence_refs were supplied, so this rating may be leaning on remembered interface patterns instead of current source evidence.",
                )
            )
        inference_flow = flow_suggestion(
            "ux_flow_inference_ladder_check",
            heuristic_id=str(heuristic["id"]),
            trigger_reason=f"{item['id']} was rated {value:g}, so the evaluator should trace observation to conclusion before escalating.",
        )
        result["bias_flags"] = flags
        result["reasoning_flow_suggestions"] = [inference_flow] if inference_flow else []
    return result


def _top_finding(findings: list[dict[str, Any]]) -> dict[str, Any]:
    if not findings:
        return {
            "finding_id": "no_scored_findings",
            "status": "no_scored_findings",
            "heuristic_id": "",
            "heuristic_name": "",
            "checklist_item_id": "",
            "severity": 0,
            "title": "No checklist issues scored above 0.",
            "observed_issue": "The supplied checklist ratings did not identify visible heuristic issues.",
            "recommendation": "Keep the current evidence bundle and rerun after future interface changes.",
        }
    finding = findings[0]
    return {
        "finding_id": finding.get("finding_id", ""),
        "status": "active",
        "heuristic_id": finding.get("heuristic_id", ""),
        "heuristic_name": finding.get("heuristic_name", ""),
        "checklist_item_id": finding.get("checklist_item_id", ""),
        "severity": finding.get("severity", 0),
        "severity_label": finding.get("severity_label", ""),
        "title": finding.get("title", ""),
        "observed_issue": finding.get("observed_issue", ""),
        "recommendation": finding.get("recommendation", ""),
        "confidence": finding.get("confidence", ""),
    }


def _plain_language_read(*, scored: bool, top_finding: dict[str, Any], snapshot: dict[str, Any]) -> str:
    if not scored:
        return "This audit is not scored yet. Checklist ratings are needed before the interface can receive a fair UX health read."
    if top_finding.get("status") == "no_scored_findings":
        return "The supplied evidence shows no scored heuristic issues. Treat this as a bounded screen-level read, not proof the full product is problem-free."
    heuristic_name = top_finding.get("heuristic_name") or "the lowest-scoring heuristic"
    title = _sentence_fragment(str(top_finding.get("title") or "visible usability friction"))
    severity = int(float(top_finding.get("severity") or 0))
    if severity >= 3:
        return f"The biggest visible usability risk is {title}. It affects {heuristic_name} and should be fixed before broader polish."
    return f"The main visible usability risk is {title}. It affects {heuristic_name} and is the clearest next improvement to validate."


def _before_using_sentence(*, scored: bool, top_finding: dict[str, Any]) -> str:
    if not scored:
        return "Before using this interface, collect checklist-level ratings so the audit can separate evidence from impression."
    if top_finding.get("status") == "no_scored_findings":
        return "Before using this interface, validate the highest-value task with at least one representative user because the audit evidence is still bounded."
    heuristic_name = top_finding.get("heuristic_name") or "the highest-severity heuristic issue"
    recommendation = str(top_finding.get("recommendation") or "fix the highest-severity checklist issue").rstrip(".")
    return f"Before using this interface, address {heuristic_name} first: {recommendation}."


def _one_recommendation(top_finding: dict[str, Any]) -> str:
    return str(top_finding.get("recommendation") or "Run a focused validation pass on the highest-risk user task.")


def _follow_up_activity(*, mode: str, heuristic_scores: list[dict[str, Any]], top_finding: dict[str, Any]) -> dict[str, Any]:
    selected_id = _select_activity_heuristic(heuristic_scores, top_finding)
    if _lowest_quality(heuristic_scores) < 55:
        base = {
            "title": "Think-Aloud Session On Lowest-Scoring Heuristic",
            "why": "At least one heuristic is below C, so direct task narration is more useful than another abstract review.",
            "focus": "Lowest-scoring heuristic and the task most affected by it.",
            "thinking": "What do users notice, try, misunderstand, and abandon?",
        }
    else:
        base = ACTIVITY_BY_HEURISTIC.get(selected_id, ACTIVITY_BY_HEURISTIC["h08"])

    try_this_next = _activity_card(base, variant="quick")
    activity = {
        "schema_version": "uxhc.follow_up_activity.v1",
        "try_this_next": try_this_next,
        "fit_check": "After the activity, ask whether the result confirmed the audit finding, weakened it, or revealed a different priority.",
    }
    if mode == "advanced":
        activity["solo_activity"] = _activity_card(base, variant="solo")
        activity["group_activity"] = _activity_card(base, variant="group")
    return activity


def _reasoning_flow_suggestions(
    *,
    mode: str,
    heuristic_scores: list[dict[str, Any]],
    checklist_ratings: list[dict[str, Any]],
    scorecard: dict[str, Any] | None,
    top_finding: dict[str, Any],
    audit_context: dict[str, Any],
) -> list[dict[str, Any]]:
    if mode != "advanced":
        return []
    scores = {str(score.get("heuristic_id")): score for score in heuristic_scores if score.get("heuristic_id")}
    candidates: list[tuple[int, str, str, str]] = []
    below_b = [hid for hid, score in scores.items() if float(score.get("quality_percentage", 100)) < 70]

    def add(priority: int, flow_id: str, heuristic_id: str, trigger_reason: str) -> None:
        candidates.append((priority, flow_id, heuristic_id, trigger_reason))

    catastrophic = _highest_rated_item(checklist_ratings, minimum=4)
    if catastrophic:
        add(
            0,
            "ux_flow_inference_ladder_check",
            str(catastrophic.get("heuristic_id") or top_finding.get("heuristic_id") or "all"),
            f"{catastrophic.get('checklist_item_id')} was rated 4, so the rating needs an evidence-to-conclusion check.",
        )

    navigation_issue = _navigation_recovery_item(checklist_ratings)
    if _quality(scores, "h03") < 70 or _quality(scores, "h07") < 70:
        trigger_id = "h03" if _quality(scores, "h03") <= _quality(scores, "h07") else "h07"
        add(10, "ux_flow_user_flow_audit", trigger_id, _score_reason(scores[trigger_id], "below B"))
    elif navigation_issue:
        add(
            11,
            "ux_flow_navigation_recovery_walkthrough",
            "h03",
            f"{navigation_issue.get('checklist_item_id')} is a severity {navigation_issue.get('rating'):g} recovery/navigation issue.",
        )

    if _quality(scores, "h11") < 70:
        add(12, "ux_flow_accessibility_deeper_dive", "h11", _score_reason(scores["h11"], "below B"))
    if _quality(scores, "h12") < 70:
        add(13, "ux_flow_empathy_mapping", "h12", _score_reason(scores["h12"], "below B"))
        add(16, "ux_flow_persona_perspective_rotation", "h12", _score_reason(scores["h12"], "below B"))
        add(17, "ux_flow_trigger_storming", "h12", _score_reason(scores["h12"], "below B"))
        if audit_context.get("emotional_design_concern"):
            add(14, "ux_flow_kansei_emotion_mapping", "h12", "H12 is below B and emotional design concern was flagged.")
    elif _quality(scores, "h07") < 70 and "h12" in scores:
        add(16, "ux_flow_persona_perspective_rotation", "h07", "H7 scored below B while the inclusion profile is active.")

    if _quality(scores, "h13") < 70:
        add(13, "ux_flow_service_blueprint", "h13", _score_reason(scores["h13"], "below B"))
        add(18, "ux_flow_interview_planning", "h13", _score_reason(scores["h13"], "below B"))
    if _quality(scores, "h14") < 70:
        add(13, "ux_flow_inclusive_language_audit", "h14", _score_reason(scores["h14"], "below B"))
    if (_quality(scores, "h12") < 70 or _quality(scores, "h14") < 70) and _sensitivity_content_present(checklist_ratings):
        trigger_id = "h12" if _quality(scores, "h12") < 70 else "h14"
        add(15, "ux_flow_sensitivity_review", trigger_id, f"{trigger_id} scored below B and sensitivity-related content is in scope.")

    if audit_context.get("international_or_multilingual") or "h12" in scores:
        add(20, "ux_flow_cross_cultural_audit", "h12", "International, multilingual, or inclusion-profile context is active.")
    if audit_context.get("agent_mode_1_active"):
        add(20, "ux_flow_six_hats_review", "agent_mode_1", "Agent Mode 1 is active, so researcher personas need distinct review hats.")
    if audit_context.get("agent_mode_2_logs_available"):
        add(0, "ux_flow_transcript_analysis", "agent_mode_2", "Agent Mode 2 think-aloud logs are available for synthesis.")
    if audit_context.get("source_quality") == "partial" and audit_context.get("evaluator_confidence") == "low":
        add(5, "ux_flow_secondary_research_sprint", "source", "Source quality is partial and evaluator confidence is low.")

    if _quality(scores, "h08") < 80:
        add(30, "ux_flow_visual_hierarchy", "h08", _score_reason(scores["h08"], "below A-"))
    if _quality(scores, "h14") < 80:
        add(31, "ux_flow_inclusive_language_audit", "h14", _score_reason(scores["h14"], "below A-"))

    if len(below_b) >= 3:
        add(40, "ux_flow_findings_synthesis", "multiple", f"{len(below_b)} heuristics scored below B.")
    if len(below_b) >= 5:
        add(41, "ux_flow_soft_systems_rich_picture", "systemic", f"{len(below_b)} heuristics scored below B, suggesting systemic UX friction.")

    overall = float((scorecard or {}).get("overall_quality_percentage") or 100)
    if overall <= 74:
        add(20, "ux_flow_usability_test_brief", "overall", f"Overall quality is {overall:g}%, which is B or below.")
        if audit_context.get("stakeholder_report_requested"):
            add(21, "ux_flow_satisfaction_survey", "overall", "Stakeholder report context needs quantitative validation planning.")
            add(22, "ux_flow_opportunity_scoring", "overall", "Stakeholder report context needs roadmap prioritization beyond RICE.")
        if audit_context.get("team_prioritization") or audit_context.get("hil_enabled"):
            add(53, "ux_flow_dot_voting", "overall", "Team facilitation context is active for post-audit prioritization.")
    if overall <= 64:
        add(19, "ux_flow_scamper_redesign", "overall", f"Overall quality is {overall:g}%, which is C+ or below.")
        add(20, "ux_flow_double_diamond_next_phase", "overall", f"Overall quality is {overall:g}%, which is C+ or below.")
    if _has_b_to_c_cluster(scores):
        add(52, "ux_flow_opportunity_scoring", "overall", "Multiple heuristics are in the B-C range and need prioritization.")
    if audit_context.get("team_needs_must_fix_sort"):
        add(54, "ux_flow_kano_prioritization", "overall", "Team needs to separate must-fix findings from nice-to-fix improvements.")
    if any(float(score.get("quality_percentage", 100)) <= 64 for score in scores.values()):
        add(60, "ux_flow_how_might_we", "overall", "At least one heuristic scored C+ or below and needs reframing as a design opportunity.")
    if any(float(score.get("quality_percentage", 100)) < 55 for score in scores.values()) and audit_context.get("ux_level") == "expert":
        add(45, "ux_flow_triz_reverse", "overall", "An expert evaluator saw a below-C heuristic, so under-rating severity should be checked.")

    suggestions: list[dict[str, Any]] = []
    seen_flow_ids: set[str] = set()
    for _priority, flow_id, heuristic_id, trigger_reason in sorted(candidates, key=lambda row: (row[0], row[1])):
        if len(suggestions) >= 3 or flow_id in seen_flow_ids:
            continue
        suggestion = flow_suggestion(flow_id, heuristic_id=heuristic_id, trigger_reason=trigger_reason)
        if suggestion:
            seen_flow_ids.add(flow_id)
            suggestions.append(suggestion)
    return suggestions


def _prioritization_flow(scorecard: dict[str, Any] | None) -> dict[str, Any] | None:
    if not scorecard or scorecard.get("score_status") != "scored":
        return None
    if float(scorecard.get("overall_quality_percentage") or 100) <= 74:
        return build_prioritization_flow()
    return None


def _audit_context(audit_context: dict[str, Any] | None) -> dict[str, Any]:
    context = dict(audit_context or {})
    if context.get("product_familiarity") is None:
        context["product_familiarity"] = bool(
            context.get("evaluator_product_familiarity")
            or context.get("product_familiarity_declared")
            or context.get("familiar_with_product")
        )
    if context.get("ux_level") is not None:
        context["ux_level"] = str(context["ux_level"]).lower()
    if context.get("implementation_inspection_requested") is None:
        context["implementation_inspection_requested"] = bool(
            context.get("implementation_lane_requested")
            or context.get("frontend_implementation_lane")
            or context.get("codebase_available")
            or context.get("external_audit_results")
            or context.get("implementation_evidence")
        )
    return context


def _implementation_inspection_contract(*, audit_context: dict[str, Any], mode: str, platform: str) -> dict[str, Any] | None:
    if not audit_context.get("implementation_inspection_requested"):
        return None
    harness = str(audit_context.get("ai_coding_harness") or "host_ai_or_coding_harness")
    flow = flow_suggestion(
        "ux_flow_frontend_implementation_inspection",
        heuristic_id="implementation_support",
        trigger_reason="Implementation-aware inspection was requested as an optional evidence lane.",
    )
    return {
        "schema_version": "uxhc.implementation_inspection.v1",
        "status": "requested",
        "route_id": "implementation_aware_inspection",
        "mode": mode,
        "platform": platform,
        "ai_coding_harness": harness,
        "lane_position": "support_after_core_audit",
        "purpose": "Gather code, browser, or external detector evidence that can support UXHC checklist ratings without replacing them.",
        "host_role": "The host AI or coding harness inspects available project files, rendered pages, screenshots, or external audit results and submits evidence-bound observations.",
        "uxhc_role": "UXHC maps implementation signals to likely heuristics, evidence limits, and report-safe summaries; it does not execute third-party tools or change scores without checklist_ratings.",
        "inspection_dimensions": [
            {
                "dimension_id": "accessibility_implementation",
                "inspect_for": "semantic HTML, focus order, keyboard access, ARIA use, text alternatives, contrast notes, and touch target evidence",
                "likely_heuristics": ["h11", "h05", "h09"],
                "evidence_examples": ["DOM element or component path", "screenshot evidence ref", "keyboard/focus observation", "external a11y finding"],
            },
            {
                "dimension_id": "performance_and_feedback",
                "inspect_for": "render delays, expensive animation, loading states, layout shifts, and perceived responsiveness",
                "likely_heuristics": ["h01", "h07"],
                "evidence_examples": ["browser observation", "performance trace note", "component state with missing loading feedback"],
            },
            {
                "dimension_id": "responsive_layout",
                "inspect_for": "fixed widths, horizontal overflow, breakpoints, viewport clipping, and mobile interaction constraints",
                "likely_heuristics": ["h04", "h08", "h11"],
                "evidence_examples": ["desktop/mobile screenshot pair", "CSS rule or component path", "viewport-specific observation"],
            },
            {
                "dimension_id": "design_system_consistency",
                "inspect_for": "hard-coded colors, token bypasses, inconsistent components, dark-mode drift, and repeated pattern mismatch",
                "likely_heuristics": ["h04", "h08"],
                "evidence_examples": ["component path", "token name", "CSS variable or hard-coded value", "design-system note"],
            },
            {
                "dimension_id": "visual_pattern_risk",
                "inspect_for": "decorative effects, excessive gradients, nested cards, weak hierarchy, generic typography, and visually loud elements that compete with the task",
                "likely_heuristics": ["h08", "h04"],
                "evidence_examples": ["screenshot evidence ref", "component/CSS path", "external detector issue"],
            },
            {
                "dimension_id": "ui_copy_implementation",
                "inspect_for": "truncated labels, unclear CTAs, error message placement, empty states, and copy that changes meaning across breakpoints",
                "likely_heuristics": ["h14", "h09", "h06"],
                "evidence_examples": ["visible text excerpt", "component path", "narrow viewport screenshot", "error state observation"],
            },
        ],
        "external_result_policy": {
            "supported_sources": ["impeccable_or_similar_audit_text", "external_audit_json", "manual_harness_observations"],
            "provenance_required": True,
            "trusted_for_scoring": False,
            "score_policy": "External implementation evidence can suggest checklist items to review, but scores change only when checklist_ratings are supplied.",
        },
        "must_not": [
            "Do not install, run, or vendor third-party audit tools from inside UXHC.",
            "Do not treat code-level findings as direct user evidence without a visible interface or interaction observation.",
            "Do not replace the 14-heuristic checklist scorecard with a frontend health score.",
            "Do not perform full-site crawling, auth automation, or unbounded navigation.",
        ],
        "resume_contract": {
            "tool": "audit_ux_surface" if mode == "advanced" else "quick_scan_ux",
            "resume_with": ["audit_context.implementation_evidence", "audit_context.external_audit_results", "checklist_ratings"],
            "score_update_requires": "complete checklist_ratings for affected active checklist items",
        },
        "support_flow": flow,
    }


def _implementation_evidence_summary(*, audit_context: dict[str, Any]) -> dict[str, Any] | None:
    raw_sources = []
    if audit_context.get("implementation_evidence") not in (None, "", []):
        raw_sources.append(("implementation_evidence", audit_context.get("implementation_evidence")))
    if audit_context.get("external_audit_results") not in (None, "", []):
        raw_sources.append(("external_audit_results", audit_context.get("external_audit_results")))
    if not raw_sources:
        return None

    dimension_map = {
        "accessibility_implementation": {
            "keywords": ["accessibility", "wcag", "aria", "keyboard", "focus", "contrast", "alt ", "screen reader", "touch target"],
            "likely_heuristics": ["h11", "h05", "h09"],
        },
        "performance_and_feedback": {
            "keywords": ["performance", "layout shift", "slow", "animation", "lazy", "render", "loading", "latency"],
            "likely_heuristics": ["h01", "h07"],
        },
        "responsive_layout": {
            "keywords": ["responsive", "breakpoint", "mobile", "fixed width", "overflow", "viewport", "clipped", "touch"],
            "likely_heuristics": ["h04", "h08", "h11"],
        },
        "design_system_consistency": {
            "keywords": ["theme", "token", "dark mode", "hard-coded", "hardcoded", "component", "inconsistent", "design system"],
            "likely_heuristics": ["h04", "h08"],
        },
        "visual_pattern_risk": {
            "keywords": ["gradient", "glass", "nested card", "clutter", "generic font", "visual hierarchy", "decorative", "attention"],
            "likely_heuristics": ["h08", "h04"],
        },
        "ui_copy_implementation": {
            "keywords": ["copy", "label", "cta", "error message", "empty state", "truncated", "microcopy", "button text"],
            "likely_heuristics": ["h14", "h09", "h06"],
        },
    }
    source_summaries: list[dict[str, Any]] = []
    triggered: dict[str, set[str]] = {}
    for source_name, value in raw_sources:
        text = _stringify_evidence(value)
        matched_dimensions = []
        lower = text.lower()
        for dimension_id, config in dimension_map.items():
            if any(keyword in lower for keyword in config["keywords"]):
                matched_dimensions.append(dimension_id)
                triggered.setdefault(dimension_id, set()).update(config["likely_heuristics"])
        source_summaries.append(
            {
                "source": source_name,
                "source_type": type(value).__name__,
                "matched_dimensions": matched_dimensions,
                "summary": _compact_summary(text),
            }
        )
    likely_heuristics = sorted({heuristic for values in triggered.values() for heuristic in values})
    return {
        "schema_version": "uxhc.implementation_evidence_summary.v1",
        "status": "evidence_received",
        "score_policy": "This evidence is advisory and does not change checklist ratings unless the host submits updated checklist_ratings.",
        "likely_affected_heuristics": likely_heuristics,
        "dimension_matches": [
            {
                "dimension_id": dimension_id,
                "likely_heuristics": sorted(heuristics),
            }
            for dimension_id, heuristics in sorted(triggered.items())
        ],
        "sources": source_summaries,
        "evidence_limit": "Implementation evidence can reveal code or rendered-state risks, but UXHC still needs visible interface evidence and checklist-level ratings for scored conclusions.",
    }


def _stringify_evidence(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return " ".join(_stringify_evidence(item) for item in value)
    if isinstance(value, dict):
        return " ".join(f"{key}: {_stringify_evidence(item)}" for key, item in value.items())
    return str(value)


def _compact_summary(text: str, limit: int = 220) -> str:
    compact = " ".join(text.split())
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3].rstrip() + "..."


def _follow_up_activity_extended(
    *,
    mode: str,
    heuristic_scores: list[dict[str, Any]],
    checklist_ratings: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    audit_context: dict[str, Any],
) -> list[dict[str, Any]]:
    scores = {str(score.get("heuristic_id")): score for score in heuristic_scores if score.get("heuristic_id")}
    activity_ids: list[str] = []

    def add(activity_id: str) -> None:
        if activity_id not in activity_ids:
            activity_ids.append(activity_id)

    if _quality(scores, "h01") < 70:
        add("uxhc_activity_five_second_test")
    if _quality(scores, "h03") < 70:
        add("uxhc_activity_cognitive_walkthrough")
        add("uxhc_activity_first_click")
    if _quality(scores, "h08") < 70 and audit_context.get("visual_evidence_available", True):
        add("uxhc_activity_five_second_test")
    if _quality(scores, "h12") < 70:
        add("ux_activity_empathy_map")
    if _quality(scores, "h05") < 70:
        add("ux_activity_assumption_flip")
    if _quality(scores, "h13") < 70:
        add("ux_activity_open_closed_question_flip")
    if len([finding for finding in findings if int(float(finding.get("severity") or 0)) > 0]) >= 5:
        add("uxhc_activity_affinity_mapping")
    if audit_context.get("post_agent_session"):
        add("uxhc_activity_observer_debrief")
    if audit_context.get("pre_stakeholder_report") or audit_context.get("stakeholder_report_requested"):
        add("uxhc_activity_evidence_confidence")
        add("ux_activity_insight_statement_builder")
    if any(float(score.get("quality_percentage", 100)) < 55 for score in heuristic_scores):
        add("uxhc_activity_think_aloud")
        add("ux_activity_analogous_inspiration_sweep")
    if audit_context.get("agent_mode_2_logs_available"):
        add("ux_activity_role_play_research_interview")
        add("ux_activity_rainbow_spreadsheet")
    if mode == "advanced" and audit_context.get("team_prioritization"):
        add("ux_activity_troika_consulting")
        add("ux_activity_chalk_talk_silent_board")
    if not activity_ids and any(float(score.get("quality_percentage", 100)) < 70 for score in heuristic_scores):
        add("uxhc_activity_think_aloud")

    cards = [registry_activity_card(activity_id) for activity_id in activity_ids]
    return [card for card in cards if card]


def _evaluator_bias_advisories(
    *,
    scorecard: dict[str, Any] | None,
    heuristic_scores: list[dict[str, Any]],
    checklist_ratings: list[dict[str, Any]],
    audit_context: dict[str, Any],
    preferences_snapshot: dict[str, Any],
) -> list[dict[str, Any]]:
    if not scorecard or scorecard.get("score_status") != "scored":
        return []
    scores = {str(score.get("heuristic_id")): score for score in heuristic_scores if score.get("heuristic_id")}
    advisories: list[dict[str, Any]] = []

    def add(bias_id: str, note: str) -> None:
        if all(existing["bias_id"] != bias_flag(bias_id, relevance_note=note)["bias_id"] for existing in advisories):
            advisories.append(bias_flag(bias_id, relevance_note=note))

    if _h4_rating_gradient(checklist_ratings):
        add("anchoring_bias", "H4 ratings show an early-vs-late gradient. Review whether item order anchored later scores.")
    if audit_context.get("product_familiarity"):
        add("mere_exposure_effect", "Evaluator product familiarity was declared. Check that familiarity is not being mistaken for usability.")
    if _quality(scores, "h08") >= 90 and any(_heuristic_has_issue(checklist_ratings, hid) for hid in {"h03", "h05", "h09"}):
        add("halo_effect", "H8 is very high while functional heuristics have issues. Separate visual polish from task success.")

    ux_level = str(audit_context.get("ux_level") or preferences_snapshot.get("ux_level") or "").lower()
    if ux_level == "beginner" and any(float(row.get("rating", 0)) >= 4 for row in checklist_ratings):
        add("dunning_kruger_effect", "Beginner ux_level with severity-4 ratings should be calibrated before stakeholder reporting.")
    if ux_level == "expert" and str(scorecard.get("overall_grade")) in {"A++", "A+"}:
        add("dunning_kruger_effect", "Expert ux_level with an extremely clean score should get a naive-user review before final signoff.")
    return advisories


def _quality(scores: dict[str, dict[str, Any]], heuristic_id: str) -> float:
    if heuristic_id not in scores:
        return 100.0
    return float(scores[heuristic_id].get("quality_percentage", 100))


def _score_reason(score: dict[str, Any], threshold_label: str) -> str:
    return f"{score.get('heuristic_id')} scored {score.get('letter_grade')} ({score.get('quality_percentage')}%) - {threshold_label} threshold."


def _highest_rated_item(checklist_ratings: list[dict[str, Any]], *, minimum: float) -> dict[str, Any] | None:
    rows = [row for row in checklist_ratings if float(row.get("rating", 0)) >= minimum]
    if not rows:
        return None
    return sorted(rows, key=lambda row: (-float(row.get("rating", 0)), str(row.get("checklist_item_id", ""))))[0]


def _navigation_recovery_item(checklist_ratings: list[dict[str, Any]]) -> dict[str, Any] | None:
    keywords = ["exits", "back", "previous page", "undo", "redo", "recovery", "wrong path"]
    candidates = []
    for row in checklist_ratings:
        if str(row.get("heuristic_id")) != "h03" or float(row.get("rating", 0)) < 3:
            continue
        text = f"{row.get('checklist_item_id', '')} {row.get('checklist_text', '')}".lower()
        if any(keyword in text for keyword in keywords):
            candidates.append(row)
    if not candidates:
        return None
    return sorted(candidates, key=lambda row: (-float(row.get("rating", 0)), str(row.get("checklist_item_id", ""))))[0]


def _sensitivity_content_present(checklist_ratings: list[dict[str, Any]]) -> bool:
    keywords = ["anxiety", "safe", "secure", "cultural", "inclusive", "jargon", "label", "cta", "language", "gender", "ability"]
    for row in checklist_ratings:
        if str(row.get("heuristic_id")) not in {"h12", "h14"} or float(row.get("rating", 0)) <= 0:
            continue
        text = f"{row.get('checklist_text', '')} {row.get('rationale', '')}".lower()
        if any(keyword in text for keyword in keywords):
            return True
    return False


def _has_b_to_c_cluster(scores: dict[str, dict[str, Any]]) -> bool:
    return sum(1 for score in scores.values() if 55 <= float(score.get("quality_percentage", 100)) < 80) >= 2


def _heuristic_has_issue(checklist_ratings: list[dict[str, Any]], heuristic_id: str) -> bool:
    return any(str(row.get("heuristic_id")) == heuristic_id and float(row.get("rating", 0)) > 0 for row in checklist_ratings)


def _h4_rating_gradient(checklist_ratings: list[dict[str, Any]]) -> bool:
    h4_rows = [row for row in checklist_ratings if str(row.get("heuristic_id")) == "h04"]
    if len(h4_rows) < 6:
        return False
    def index(row: dict[str, Any]) -> int:
        try:
            return int(str(row.get("checklist_item_id", "0")).split("_")[-1])
        except ValueError:
            return 0

    ordered = sorted(h4_rows, key=index)
    midpoint = len(ordered) // 2
    first = ordered[:midpoint]
    second = ordered[midpoint:]
    first_avg = sum(float(row.get("rating", 0)) for row in first) / len(first)
    second_avg = sum(float(row.get("rating", 0)) for row in second) / len(second)
    return abs(first_avg - second_avg) >= 1.0 and any(float(row.get("rating", 0)) > 0 for row in h4_rows)


def _sentence_fragment(text: str) -> str:
    cleaned = " ".join(text.strip().rstrip(".").split())
    if not cleaned:
        return "visible usability friction"
    return cleaned[:1].lower() + cleaned[1:]


def _select_activity_heuristic(heuristic_scores: list[dict[str, Any]], top_finding: dict[str, Any]) -> str:
    for score in sorted(heuristic_scores, key=lambda row: float(row.get("quality_percentage", 100))):
        heuristic_id = str(score.get("heuristic_id") or "")
        if heuristic_id in ACTIVITY_BY_HEURISTIC:
            return heuristic_id
    return str(top_finding.get("heuristic_id") or "h08")


def _lowest_quality(heuristic_scores: list[dict[str, Any]]) -> float:
    if not heuristic_scores:
        return 100.0
    return min(float(score.get("quality_percentage", 100)) for score in heuristic_scores)


def _activity_card(base: dict[str, str], *, variant: str) -> dict[str, Any]:
    steps_by_variant = {
        "quick": ["Pick the affected screen.", "Ask one person what they notice first.", "Compare their answer to the intended task."],
        "solo": ["Write the target task.", "Walk the screen slowly from the user's point of view.", "Mark each moment of hesitation, uncertainty, or extra memory load."],
        "group": ["Give each reviewer the same task.", "Have reviewers mark friction independently.", "Discuss only the mismatches and choose one fix to test."],
    }
    return {
        "title": base["title"],
        "why_this_fits": base["why"],
        "steps": steps_by_variant[variant],
        "content_focus": base["focus"],
        "thinking_focus": base["thinking"],
        "source_note": "Curated from UX Heuristic Compass.",
    }


def _pre_audit_questions(*, platform: str, profiles: list[str], onboarding: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        _question(
            "uxhc_pre_platform",
            "pre_audit",
            "Which experience are you auditing right now?",
            "single-select",
            ["desktop", "mobile", f"keep detected: {platform}"],
            "The platform controls which checklist IDs the host must rate.",
            "This cannot change the submitted source evidence.",
        ),
        _question(
            "uxhc_pre_goal",
            "pre_audit",
            "What user task or interface goal should the audit prioritize?",
            "free-text",
            [],
            "This can influence finding priority and final recommendation wording.",
            "This cannot create evidence for screens that were not supplied.",
        ),
        _question(
            "uxhc_pre_scope_context",
            "pre_audit",
            "What extra audit context should be active?",
            "multi-select",
            ["accessibility", "inclusion", "journey", "ux_writing", "familiar_with_product", "international_or_multilingual", "none", f"keep current: {', '.join(profiles) or 'none'}"],
            "This can add optional profiles, context flags, and evaluator-bias advisories.",
            "This cannot modify core H1-H10 scoring or create unsupported evidence.",
        ),
    ]


def _quick_context_questions(*, platform: str, profiles: list[str]) -> list[dict[str, Any]]:
    return [
        _question(
            "uxhc_quick_primary_task",
            "pre_audit",
            "What is the primary task or screen purpose the quick audit should judge?",
            "free-text",
            [],
            "This helps the host AI prioritize visible friction in the compact output.",
            "This cannot replace checklist ratings when scoring is requested.",
        ),
        _question(
            "uxhc_quick_platform",
            "pre_audit",
            "Which platform should the quick audit use?",
            "single-select",
            ["desktop", "mobile", f"keep detected: {platform}"],
            "This controls whether desktop or mobile checklist IDs are in scope.",
            "This cannot merge desktop and mobile into one score.",
        ),
        _question(
            "uxhc_quick_scope",
            "pre_audit",
            "Should the quick audit stay core-only or include optional profiles?",
            "single-select",
            ["core only", "include saved/default optionals", "include accessibility/inclusion/journey/ux writing", f"keep current: {', '.join(profiles) or 'none'}"],
            "This can change which checklist items the host AI rates.",
            "This cannot change the score direction or rubric definitions.",
        ),
    ]


def _batched_mid_audit_gate(gates: list[dict[str, Any]]) -> dict[str, Any]:
    heuristic_ids: list[str] = []
    prompts: list[str] = []
    for gate in gates:
        for heuristic_id in gate.get("heuristics_in_scope") or []:
            if heuristic_id not in heuristic_ids:
                heuristic_ids.append(str(heuristic_id))
        if gate.get("prompt"):
            prompts.append(str(gate["prompt"]))
    return {
        "gate_id": "hil_gate_batched_below_threshold",
        "trigger": "below_threshold",
        "threshold": "below_b_minus",
        "threshold_quality_percentage": 65,
        "heuristics_in_scope": heuristic_ids or ["low_scoring_heuristics"],
        "prompt": "Review all low-scoring heuristics before reporting.",
        "batched_gate_ids": [str(gate.get("gate_id", "")) for gate in gates if gate.get("gate_id")],
        "batched_prompts": prompts,
        "override_allowed": True,
    }


def _mid_audit_questions(gate: dict[str, Any]) -> list[dict[str, Any]]:
    heuristic_ids = [str(item) for item in (gate.get("heuristics_in_scope") or ["this heuristic"])]
    heuristic_label = ", ".join(heuristic_ids)
    return [
        _question(
            "uxhc_mid_low_heuristics_lived_read",
            "mid_audit",
            f"{heuristic_label} scored below B-. Does that match your own read of this interface?",
            "single-select",
            ["yes", "no - too severe", "no - not severe enough", "not sure"],
            "This can flag ratings for override, confidence adjustment, or human review.",
            "This cannot hide the scored checklist result from the structured scorecard.",
        ),
        _question(
            "uxhc_mid_low_heuristics_user_impact",
            "mid_audit",
            "Which user or task would feel this friction most strongly?",
            "free-text",
            [],
            "This can sharpen the report narrative and next validation activity.",
            "This cannot erase the underlying checklist ratings.",
        ),
        _question(
            "uxhc_mid_low_heuristics_rating_action",
            "mid_audit",
            "What should happen before this low-scoring heuristic appears in the report?",
            "single-select",
            ["accept as scored", "add evidence limit", "review item ratings", "deprioritize in narrative only"],
            "This can change rating confidence, evidence limits, or report priority.",
            "This cannot change rubric criteria or make unsupported source claims.",
        ),
    ]


def _ask_user_question_call(*, stage: str, questions: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "tool_name": "AskUserQuestion",
        "stage": stage,
        "rendering_policy": "native_question_ui_required",
        "fallback_policy": "If AskUserQuestion is unavailable, stop and ask these same questions interactively before continuing.",
        "questions": [
            {
                "id": question.get("question_id"),
                "header": str(question.get("question_id", "question")).replace("uxhc_", "").replace("_", " ")[:12],
                "question": question.get("question"),
                "widget_type": question.get("widget_question_type"),
                "options": question.get("choices") or [],
                "required": question.get("required", True),
                "what_this_can_change": question.get("what_this_can_change"),
                "what_this_cannot_change": question.get("what_this_cannot_change"),
            }
            for question in questions
        ],
    }


def _final_review_questions() -> list[dict[str, Any]]:
    return [
        _question(
            "uxhc_final_review_decision",
            "final_review",
            "Is the scorecard ready to generate a report?",
            "single-select",
            ["ready", "revise ratings", "add context", "do not generate report yet"],
            "This can decide whether the host proceeds to validate_ux_report_payload and generate_ux_audit_report.",
            "This cannot bypass validation requirements.",
        ),
        _question(
            "uxhc_final_priority",
            "final_review",
            "Which finding should lead the next design or product decision?",
            "free-text",
            [],
            "This can sharpen the executive summary and one recommendation.",
            "This cannot add unsupported claims beyond the submitted evidence.",
        ),
        _question(
            "uxhc_final_reflection",
            "reflection",
            "What did this audit teach you, and what should be validated next?",
            "free-text",
            [],
            "This can add a reflection or next-validation note for the host's final explanation.",
            "This cannot change the checklist score without updated ratings.",
        ),
    ]


def _question(
    question_id: str,
    stage: str,
    question: str,
    widget_type: str,
    choices: list[str],
    what_this_can_change: str,
    what_this_cannot_change: str,
) -> dict[str, Any]:
    return {
        "question_id": question_id,
        "stage": stage,
        "question": question,
        "widget_question_type": widget_type,
        "choices": choices,
        "allow_freeform_response": widget_type == "free-text",
        "what_this_can_change": what_this_can_change,
        "what_this_cannot_change": what_this_cannot_change,
        "required": True,
    }


def _no_pause_action(*, mode: str, reason: str) -> dict[str, Any]:
    return {
        "schema_version": "uxhc.human_loop.v1",
        "PAUSE_REQUIRED": False,
        "must_pause": False,
        "mode": mode,
        "stage": "none",
        "required_surface": "none",
        "current_gate": None,
        "all_gates": [],
        "questions_for_user": [],
        "resume_contract": {},
        "tool_compliance_signal": "no_pause",
        "reason": reason,
    }


def _as_list(value: list[str] | str | None) -> list[str]:
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return [str(item) for item in value if str(item)]
    return [str(value)]


def _alternative_explanation(checklist_text: str, rating: float) -> str:
    if rating <= 1:
        return "This may be a low-risk issue if the affected task is rare, users already understand the convention, or the evidence comes from a narrow screen state."
    return f"This may be acceptable if '{checklist_text}' is not important for the user's primary task or if another visible cue solves the same problem."


def _false_positive_check(checklist_text: str, rating: float) -> str:
    if rating >= 3:
        return "Verify this with task evidence before escalating: a severe rating should be tied to a likely block, error, abandonment risk, or trust break."
    return "Check whether this is observable user friction or mainly a reviewer preference about layout, wording, or polish."


def _why_it_matters(heuristic_name: str, checklist_text: str, rating: float) -> str:
    if rating >= 3:
        return f"Because this is rated {rating:g}, the issue likely affects task success, trust, or recovery under {heuristic_name}."
    if rating >= 2:
        return f"Because this is rated {rating:g}, it likely adds avoidable effort even if it does not block the task outright."
    return f"Because this is rated {rating:g}, it is probably a polish issue unless repeated evidence shows it slows users down."


def _stress_fix(heuristic_name: str, checklist_text: str) -> str:
    lower = checklist_text.lower()
    if "error" in lower:
        return "Rewrite the message in plain language and place the next recovery action next to the affected control."
    if "navigation" in lower or "link" in lower:
        return "Rename or restyle the navigation element so the destination and current state are predictable before click or tap."
    if "home page" in lower or "primary" in lower:
        return "Make the primary user action and page purpose visible without relying on surrounding explanation."
    if "label" in lower or "content" in lower:
        return "Replace internal or vague wording with the user's task language and test it at the smallest supported viewport."
    return f"Revise the interface so the evaluated element more clearly satisfies {heuristic_name}."
