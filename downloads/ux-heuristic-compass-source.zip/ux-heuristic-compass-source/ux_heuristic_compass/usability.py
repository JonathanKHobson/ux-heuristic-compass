from __future__ import annotations

import shutil
from typing import Any

from .knowledge import flow_suggestion
from .rubric import normalize_platform
from .source import prepare_ux_source
from .state import utc_now


USABILITY_SCHEMA_VERSION = "uxhc.usability_test.v1"


def _as_list(value: Any) -> list[str]:
    if value is None or value == "":
        return []
    if isinstance(value, str):
        return [value]
    return [str(item) for item in value]


def _blocked_reason(task_scope: Any, safety_policy: dict[str, Any] | None) -> str | None:
    text = " ".join(_as_list(task_scope)).lower()
    policy = safety_policy or {}
    if any(term in text for term in ["full crawl", "crawl all", "all pages", "entire site"]):
        return "full_site_crawling_not_supported"
    if any(term in text for term in ["login", "sign in", "authenticated", "account password"]):
        if not policy.get("allow_authenticated_flow", False):
            return "authenticated_flow_not_supported"
    if policy.get("allow_unbounded_navigation"):
        return "unbounded_navigation_not_supported"
    return None


def _persona_variants(target_audience: str, supplied: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    if supplied:
        return supplied[:3]
    audience = target_audience or "target user"
    return [
        {
            "agent_id": "audience_a",
            "name": "Confident audience member",
            "persona": f"A tech-comfortable member of the audience: {audience}.",
        },
        {
            "agent_id": "audience_b",
            "name": "Low-confidence audience member",
            "persona": f"A lower digital-confidence member of the audience: {audience}.",
        },
        {
            "agent_id": "audience_c",
            "name": "Interrupted mobile/context-shifted audience member",
            "persona": f"A distracted or context-constrained member of the audience: {audience}.",
        },
    ]


def _interview_validity_check(persona_runs: list[dict[str, Any]]) -> dict[str, Any]:
    flags: list[dict[str, Any]] = []
    for run in persona_runs:
        interview = run.get("interview") or {}
        satisfaction = interview.get("overall_satisfaction_1_to_5")
        try:
            satisfaction_value = int(satisfaction) if satisfaction is not None else None
        except (TypeError, ValueError):
            satisfaction_value = None
        failure_count = 0
        frustration_hits = 0
        for attempt in run.get("task_attempts") or []:
            text = " ".join(str(attempt.get(key, "")) for key in ["outcome", "notes"]).lower()
            if any(token in text for token in ["fail", "failed", "abandon", "blocked", "could not", "cannot"]):
                failure_count += 1
            if any(token in text for token in ["frustrat", "confus", "anxious", "stuck"]):
                frustration_hits += 1
        for step in run.get("think_aloud") or []:
            text = " ".join(str(step.get(key, "")) for key in ["observation", "attempted_action", "outcome"]).lower()
            if any(token in text for token in ["fail", "failed", "abandon", "blocked", "could not", "cannot"]):
                failure_count += 1
            if any(token in text for token in ["frustrat", "confus", "anxious", "stuck"]):
                frustration_hits += 1
        if satisfaction_value is not None and satisfaction_value >= 4 and (failure_count >= 2 or frustration_hits > 0):
            flags.append(
                {
                    "agent_id": run.get("agent_id", ""),
                    "flag_label": "self_report_discrepancy",
                    "overall_satisfaction_1_to_5": satisfaction_value,
                    "task_failure_or_block_count": failure_count,
                    "frustration_signal_count": frustration_hits,
                    "interpretation": "The interview response is more positive than the observed task narrative. Weight think-aloud and task evidence over satisfaction rating.",
                }
            )
    return {
        "check": "Do any interview responses contradict the think-aloud narrative for the same agent?",
        "flag_if": "Agent reported overall_satisfaction 4-5 but think-aloud logged 2+ task failures or explicit frustration statements.",
        "flag_label": "self_report_discrepancy",
        "bias_note": "Self-report and demand effects: participants or simulated personas may over-report satisfaction relative to observed behavior. Where discrepancy exists, weight think-aloud evidence over interview response.",
        "source": "Authored UXHC validity guard adapted for usability-session self-report discrepancy checks; no live Atlas dependency.",
        "flags": flags,
    }


def run_usability_test(
    *,
    target_audience: str,
    task_scope: list[str] | str,
    source_or_url: list[str] | str | None = None,
    prepared_source: dict[str, Any] | None = None,
    platform: str = "desktop",
    safety_policy: dict[str, Any] | None = None,
    personas: list[dict[str, Any]] | None = None,
    output_dir: str | None = None,
) -> dict[str, Any]:
    platform_key = normalize_platform(platform)
    blocked = _blocked_reason(task_scope, safety_policy)
    if blocked:
        return {
            "schema_version": USABILITY_SCHEMA_VERSION,
            "status": "blocked",
            "user_facing_mode_name": "Bounded usability-test prep/synthetic walkthrough support",
            "evidence_level": "bounded_prep_not_real_participant_evidence",
            "error": blocked,
            "policy": {
                "full_site_crawling": False,
                "authenticated_flows": False,
                "unbounded_navigation": False,
            },
            "next_action": "Provide a bounded public URL or prepared_source and a task scope that does not require login or full-site navigation.",
        }

    source = prepared_source
    if source is None:
        source = prepare_ux_source(
            source_or_url,
            viewport=platform_key,
            capture_urls=True,
            output_dir=output_dir,
            task_flow="; ".join(_as_list(task_scope)),
        )

    playwright_available = bool(shutil.which("npx"))
    browser_handoff = source.get("browser_handoff") or {}
    source_ready = source.get("status") in {"ready", "partial"}
    vehicle = "playwright_system_chrome" if playwright_available and browser_handoff.get("performed") else "system_chrome_capture" if browser_handoff.get("performed") else "multimodal_screenshot_fallback"
    source_summary = " ".join(str(item.get("visible_text_summary") or item.get("page_title") or item.get("state_label") or "") for item in source.get("items") or []).strip()
    persona_records = []
    for persona in _persona_variants(target_audience, personas):
        persona_records.append(
            {
                "agent_id": persona["agent_id"],
                "persona": persona,
                "think_aloud": [
                    {
                        "step": 1,
                        "observation": source_summary[:300] or "Source prepared, but no visible text summary was available.",
                        "attempted_action": "Review the bounded source for the provided task scope.",
                        "outcome": "observed_only_not_interacted" if vehicle != "playwright_system_chrome" else "bounded_capture_reviewed",
                    }
                ],
                "task_attempts": [
                    {
                        "task": "; ".join(_as_list(task_scope)),
                        "outcome": "needs_host_interpretation" if not source_ready else "source_reviewed",
                        "notes": "UXHC prepared bounded evidence; host AI must provide visual interpretation for claims beyond captured text and screenshots.",
                    }
                ],
                "interview": {
                    "overall_satisfaction_1_to_5": None,
                    "worked_well": [],
                    "confusing_or_frustrating": [],
                    "would_use_again": "unknown",
                    "wish_it_did_differently": "",
                },
            }
        )

    synthesis_flows = []
    if any(run.get("think_aloud") for run in persona_records):
        transcript_flow = flow_suggestion(
            "ux_flow_transcript_analysis",
            heuristic_id="agent_mode_2",
            trigger_reason="Agent Mode 2 generated think-aloud logs that need synthesis before findings are treated as report-ready.",
        )
        if transcript_flow:
            synthesis_flows.append(transcript_flow)
    interview_flow = flow_suggestion(
        "ux_flow_interview_planning",
        heuristic_id="agent_mode_2",
        trigger_reason="Agent Mode 2 includes post-session interview fields that should remain neutral and evidence-seeking.",
    )
    if interview_flow:
        synthesis_flows.append(interview_flow)

    return {
        "schema_version": USABILITY_SCHEMA_VERSION,
        "status": "ready" if source_ready else "partial",
        "user_facing_mode_name": "Bounded usability-test prep/synthetic walkthrough support",
        "evidence_level": "synthetic_walkthrough_or_evidence_prep_unless_real_participant_logs_supplied",
        "created_at": utc_now(),
        "platform": platform_key,
        "target_audience": target_audience,
        "task_scope": _as_list(task_scope),
        "navigation_vehicle": vehicle,
        "playwright_status": "available" if playwright_available else "not_configured",
        "source": source,
        "browser_handoff": browser_handoff,
        "persona_runs": persona_records,
        "reasoning_flow_suggestions": synthesis_flows,
        "synthesized_thematic_findings": [],
        "heuristic_mapped_findings": [],
        "overall_experience_grade": None,
        "interview_validity_check": _interview_validity_check(persona_records),
        "evidence_limits": [
            {
                "reason": "Audience-persona usability test output is a bounded evidence-prep contract unless the host supplies visual/task interpretation.",
                "confidence_impact": "Findings require host interpretation before scoring.",
                "evaluatable": source_ready,
            }
        ],
    }
