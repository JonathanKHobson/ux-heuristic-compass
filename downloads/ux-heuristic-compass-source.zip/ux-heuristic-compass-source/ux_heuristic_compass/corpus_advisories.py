from __future__ import annotations

from copy import deepcopy
from typing import Any


CULTURAL_MODULE_ID = "cultural_context_integrity"
CULTURAL_LENS_PREFIX = "cross_cultural_"
ACCESSIBILITY_MODULE_ID = "accessibility_readiness"
WCAG_LENS_PREFIX = "wcag_"
STANDARD_WCAG_LENS_ID = "standard_wcag_pour"


_CULTURAL_EVIDENCE_TERMS = (
    "culture",
    "cultural",
    "community authority",
    "community review",
    "indigenous",
    "decolonial",
    "pluriversal",
    "localization",
    "localisation",
    "language",
    "script",
    "right-to-left",
    "rtl",
    "faith",
    "observance",
    "low-bandwidth",
    "low bandwidth",
    "shared device",
    "mediated access",
)


_ACCESSIBILITY_EVIDENCE_TERMS = (
    "accessibility",
    "a11y",
    "wcag",
    "keyboard",
    "focus",
    "screen reader",
    "assistive technology",
    "contrast",
    "caption",
    "transcript",
    "alt text",
    "aria",
    "name role value",
    "target size",
    "touch target",
    "reflow",
    "zoom",
    "status message",
    "live region",
)


_WCAG_LENS_LEVELS: dict[str, tuple[str, ...]] = {
    STANDARD_WCAG_LENS_ID: ("A", "AA"),
    "wcag_text_alternatives_media": ("A", "AA"),
    "wcag_info_relationships_semantics": ("A",),
    "wcag_contrast_visual_presentation": ("A", "AA"),
    "wcag_reflow_resize_text_spacing": ("AA",),
    "wcag_keyboard_no_trap": ("A",),
    "wcag_focus_order_visible_not_obscured": ("A", "AA"),
    "wcag_bypass_navigation_headings_labels": ("A", "AA"),
    "wcag_target_size_pointer_gestures": ("A", "AA"),
    "wcag_timing_pause_motion_safety": ("A",),
    "wcag_error_identification_suggestion_prevention": ("A", "AA"),
    "wcag_labels_instructions_input_purpose": ("A", "AA"),
    "wcag_name_role_value_custom_widgets": ("A",),
    "wcag_status_messages": ("AA",),
    "wcag_language_readability": ("A", "AA", "AAA"),
    "wcag_accessible_authentication": ("AA", "AAA"),
    "wcag_forms_component_pattern": ("A", "AA"),
    "wcag_modals_popovers_focus_management": ("A",),
    "wcag_tables_dashboards_structure": ("A",),
    "wcag_mobile_touch_orientation": ("AA",),
    "wcag_manual_evidence_matrix": ("A", "AA"),
}


def _severity_penalty(severity: int) -> int:
    if severity >= 4:
        return 30
    if severity == 3:
        return 22
    if severity == 2:
        return 14
    if severity == 1:
        return 7
    return 0


def _index_label(score: int | None) -> str:
    if score is None:
        return "Evidence-Limited Context Review Needed"
    if score >= 85:
        return "Strong Context Fit"
    if score >= 70:
        return "Mostly Context-Aware"
    if score >= 50:
        return "Needs Context Review"
    if score >= 25:
        return "High Context Risk"
    return "Insufficient Context Safety"


def _highest_wcag_level(levels: set[str]) -> str:
    if "AAA" in levels:
        return "AAA"
    if "AA" in levels:
        return "AA"
    if "A" in levels:
        return "A"
    return "Evidence Limited"


def _cultural_lenses(finding: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        dict(lens)
        for lens in finding.get("support_lenses") or []
        if str(lens.get("lens_id") or "").startswith(CULTURAL_LENS_PREFIX)
    ]


def _accessibility_lenses(finding: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        dict(lens)
        for lens in finding.get("support_lenses") or []
        if str(lens.get("lens_id") or "").startswith(WCAG_LENS_PREFIX)
        or str(lens.get("lens_id") or "") == STANDARD_WCAG_LENS_ID
    ]


def _evidence_limit_is_cultural(limit: Any) -> bool:
    text = ""
    if isinstance(limit, dict):
        text = " ".join(str(value or "") for value in limit.values())
    else:
        text = str(limit or "")
    lower = text.lower()
    return any(term in lower for term in _CULTURAL_EVIDENCE_TERMS)


def _evidence_limit_is_accessibility(limit: Any) -> bool:
    text = ""
    if isinstance(limit, dict):
        text = " ".join(str(value or "") for value in limit.values())
    else:
        text = str(limit or "")
    lower = text.lower()
    return any(term in lower for term in _ACCESSIBILITY_EVIDENCE_TERMS)


def build_cultural_context_advisory(
    findings: list[dict[str, Any]],
    evidence_limits: list[Any] | None = None,
    *,
    max_rows: int = 6,
) -> dict[str, Any] | None:
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for finding in findings:
        severity = max(0, min(4, int(finding.get("severity") or finding.get("rating") or 0)))
        for lens in _cultural_lenses(finding):
            key = (str(finding.get("finding_signature") or finding.get("finding_id") or ""), str(lens.get("lens_id") or ""))
            if key in seen:
                continue
            seen.add(key)
            rows.append(
                {
                    "row_type": "finding_lens",
                    "finding_id": finding.get("finding_id", ""),
                    "finding_signature": finding.get("finding_signature", ""),
                    "title": finding.get("title", ""),
                    "severity": severity,
                    "heuristic_id": finding.get("heuristic_id", ""),
                    "checklist_item_id": finding.get("checklist_item_id", ""),
                    "evidence_ref": finding.get("evidence_ref", ""),
                    "lens_id": lens.get("lens_id", ""),
                    "lens_name": lens.get("name", ""),
                    "source_family": lens.get("source_family", ""),
                    "why_it_matters": lens.get("report_phrase") or lens.get("audit_use", ""),
                    "caveat": lens.get("caveat", ""),
                    "misuse_warning": lens.get("misuse_warning", ""),
                    "score_policy": "support_only",
                }
            )

    relevant_limits = [limit for limit in evidence_limits or [] if _evidence_limit_is_cultural(limit)]
    for idx, limit in enumerate(relevant_limits[:3], start=1):
        reason = str(limit.get("reason") if isinstance(limit, dict) else limit)
        rows.append(
            {
                "row_type": "evidence_limit",
                "finding_id": "",
                "finding_signature": "",
                "title": f"Cultural context evidence limit {idx}",
                "severity": 0,
                "heuristic_id": str(limit.get("checklist_item_id", "") if isinstance(limit, dict) else ""),
                "checklist_item_id": str(limit.get("checklist_item_id", "") if isinstance(limit, dict) else ""),
                "evidence_ref": "",
                "lens_id": "",
                "lens_name": "Cultural context evidence limit",
                "source_family": "UXHC evidence limit",
                "why_it_matters": reason,
                "caveat": "This evidence limit names a context to verify; it does not prove a cultural-context failure.",
                "misuse_warning": "Do not infer community needs or cultural meaning from missing evidence alone.",
                "score_policy": "support_only",
            }
        )

    if not rows:
        return None

    rows.sort(key=lambda row: (-int(row.get("severity") or 0), str(row.get("lens_id") or ""), str(row.get("title") or "")))
    finding_rows = [row for row in rows if row.get("row_type") == "finding_lens"]
    unique_findings = {str(row.get("finding_signature") or row.get("finding_id") or row.get("title")): int(row.get("severity") or 0) for row in finding_rows}
    penalty = min(100, sum(_severity_penalty(severity) for severity in unique_findings.values()) + min(24, len(relevant_limits) * 8))
    index_score = max(0, 100 - penalty) if finding_rows else None
    index_label = _index_label(index_score)
    top_row = rows[0]
    if finding_rows:
        top_signal = (
            "Cultural Context Signal: "
            f"{top_row.get('lens_name') or 'a cultural context lens'} flags {top_row.get('title') or 'the top finding'} "
            "as needing evidence-bound local or community-context validation."
        )
    else:
        top_signal = "Cultural Context Signal: available evidence is too limited to assess culturally situated fit without local-context review."
    return {
        "schema_version": "uxhc.corpus_advisory.v1",
        "module_id": CULTURAL_MODULE_ID,
        "module_type": "support_advisory",
        "display_default": True,
        "signal_label": "Cultural Context Signal",
        "section_title": "Cultural Context Integrity Advisory",
        "index_name": "Context Integrity Index",
        "context_integrity_index": index_score,
        "index_score": index_score,
        "index_label": index_label,
        "top_signal": top_signal,
        "evidence_basis": {
            "derived_from": "existing UXHC findings, attached cross-cultural support lenses, and cultural-context evidence limits",
            "finding_count": len(unique_findings),
            "lens_count": len({str(row.get("lens_id")) for row in finding_rows if row.get("lens_id")}),
            "evidence_limit_count": len(relevant_limits),
            "score_policy": "support_only",
        },
        "caveat": "Evidence-limited support guidance only; not a cultural certification, moral judgment, universal cultural claim, or substitute for affected-community review.",
        "rows": deepcopy(rows[: max(1, max_rows)]),
        "score_policy": "support_only",
    }


def build_accessibility_readiness_advisory(
    findings: list[dict[str, Any]],
    evidence_limits: list[Any] | None = None,
    *,
    max_rows: int = 6,
) -> dict[str, Any] | None:
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    referenced_levels: set[str] = set()
    for finding in findings:
        severity = max(0, min(4, int(finding.get("severity") or finding.get("rating") or 0)))
        for lens in _accessibility_lenses(finding):
            lens_id = str(lens.get("lens_id") or "")
            key = (str(finding.get("finding_signature") or finding.get("finding_id") or ""), lens_id)
            if key in seen:
                continue
            seen.add(key)
            levels = _WCAG_LENS_LEVELS.get(lens_id, ("A", "AA"))
            referenced_levels.update(levels)
            rows.append(
                {
                    "row_type": "finding_lens",
                    "finding_id": finding.get("finding_id", ""),
                    "finding_signature": finding.get("finding_signature", ""),
                    "title": finding.get("title", ""),
                    "severity": severity,
                    "heuristic_id": finding.get("heuristic_id", ""),
                    "checklist_item_id": finding.get("checklist_item_id", ""),
                    "evidence_ref": finding.get("evidence_ref", ""),
                    "lens_id": lens_id,
                    "lens_name": lens.get("name", ""),
                    "source_family": lens.get("source_family", ""),
                    "wcag_level": "/".join(levels),
                    "why_it_matters": lens.get("report_phrase") or lens.get("audit_use", ""),
                    "caveat": lens.get("caveat", ""),
                    "misuse_warning": lens.get("misuse_warning", ""),
                    "score_policy": "support_only",
                }
            )

    relevant_limits = [limit for limit in evidence_limits or [] if _evidence_limit_is_accessibility(limit)]
    for idx, limit in enumerate(relevant_limits[:3], start=1):
        reason = str(limit.get("reason") if isinstance(limit, dict) else limit)
        rows.append(
            {
                "row_type": "evidence_limit",
                "finding_id": "",
                "finding_signature": "",
                "title": f"Accessibility evidence limit {idx}",
                "severity": 0,
                "heuristic_id": str(limit.get("checklist_item_id", "") if isinstance(limit, dict) else ""),
                "checklist_item_id": str(limit.get("checklist_item_id", "") if isinstance(limit, dict) else ""),
                "evidence_ref": "",
                "lens_id": "",
                "lens_name": "Accessibility evidence limit",
                "source_family": "UXHC evidence limit",
                "wcag_level": "Evidence Limited",
                "why_it_matters": reason,
                "caveat": "This evidence limit names accessibility evidence to collect; it does not prove WCAG conformance or failure.",
                "misuse_warning": "Do not treat missing keyboard, focus, screen-reader, contrast, or state evidence as a final accessibility verdict.",
                "score_policy": "support_only",
            }
        )

    if not rows:
        return None

    rows.sort(key=lambda row: (-int(row.get("severity") or 0), str(row.get("lens_id") or ""), str(row.get("title") or "")))
    finding_rows = [row for row in rows if row.get("row_type") == "finding_lens"]
    level_signal = _highest_wcag_level(referenced_levels) if finding_rows else "Evidence Limited"
    top_row = rows[0]
    if finding_rows:
        top_signal = (
            "Accessibility Readiness Signal: "
            f"WCAG {level_signal}-level criteria are implicated by {top_row.get('title') or 'the top accessibility finding'}; "
            "this remains evidence-limited until manual accessibility testing."
        )
    else:
        top_signal = "Accessibility Readiness Signal: available evidence is too limited to assign a WCAG level signal without manual accessibility review."
    return {
        "schema_version": "uxhc.corpus_advisory.v1",
        "module_id": ACCESSIBILITY_MODULE_ID,
        "module_type": "support_advisory",
        "display_default": True,
        "signal_label": "Accessibility Readiness Signal",
        "section_title": "WCAG-Informed Accessibility Readiness",
        "level_name": "WCAG Level Signal",
        "wcag_level_signal": level_signal,
        "index_label": level_signal,
        "top_signal": top_signal,
        "evidence_basis": {
            "derived_from": "existing UXHC findings, attached WCAG support lenses, and accessibility evidence limits",
            "finding_count": len({str(row.get("finding_signature") or row.get("finding_id") or row.get("title")) for row in finding_rows}),
            "lens_count": len({str(row.get("lens_id")) for row in finding_rows if row.get("lens_id")}),
            "evidence_limit_count": len(relevant_limits),
            "score_policy": "support_only",
            "level_policy": "WCAG level signal names the highest referenced level in evidence-backed support cues; it is not a conformance result.",
        },
        "caveat": "Evidence-limited accessibility support guidance only; not WCAG, ADA, legal, procurement, or conformance certification.",
        "rows": deepcopy(rows[: max(1, max_rows)]),
        "score_policy": "support_only",
    }


__all__ = [
    "ACCESSIBILITY_MODULE_ID",
    "CULTURAL_MODULE_ID",
    "build_accessibility_readiness_advisory",
    "build_cultural_context_advisory",
]
