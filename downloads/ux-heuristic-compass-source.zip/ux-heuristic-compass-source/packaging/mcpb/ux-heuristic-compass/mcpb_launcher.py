#!/usr/bin/env python3
"""Launcher used by the UX Heuristics Compass MCPB package.

The installed bundle is read-only. Writable preferences, agent runs, and
report-payload snapshots are redirected to per-user app data.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _user_data_dir() -> Path:
    override = os.getenv("UXHC_USER_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = Path(os.getenv("APPDATA", str(Path.home() / "AppData" / "Roaming")))
        return base / "UXHeuristicsCompass"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "UX Heuristics Compass"
    return Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "ux-heuristic-compass"


def main() -> None:
    bundle_root = Path(__file__).resolve().parent
    user_data = _user_data_dir()
    state_dir = user_data / "state"
    reports_dir = user_data / "reports"

    for path in (user_data, state_dir, reports_dir):
        path.mkdir(parents=True, exist_ok=True)

    os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
    os.environ.setdefault("UXHC_STATE_DIR", str(state_dir))
    os.environ.setdefault("UXHC_REPORTS_DIR", str(reports_dir))

    if str(bundle_root) not in sys.path:
        sys.path.insert(0, str(bundle_root))

    sys.argv = [str(bundle_root / "server.py"), *sys.argv[1:]]

    from server import main as server_main  # pylint: disable=import-outside-toplevel

    server_main()


if __name__ == "__main__":
    main()
