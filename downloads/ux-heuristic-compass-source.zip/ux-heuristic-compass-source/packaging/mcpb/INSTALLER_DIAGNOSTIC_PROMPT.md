# UX Heuristics Compass MCPB Installer / Diagnostic Prompt

Paste this into Claude, Claude Code, Codex, or another capable coding assistant when you want help installing or diagnosing UX Heuristics Compass.

```text
You are helping me install or diagnose the UX Heuristics Compass MCPB/Desktop Extension in Claude Desktop.

Goal:
- Get UX Heuristics Compass installed and visible as an MCP server/tool set.
- Do not delete or overwrite any existing client MCP configuration.
- Preserve unrelated MCP servers and settings.
- Prefer MCPB/Desktop Extension installation over manual JSON editing when Claude Desktop supports it.

Context:
- The package file should be named ux-heuristic-compass-0.1.0.mcpb.
- UX Heuristics Compass is a local MCP server for interface heuristic audits.
- It should expose tools such as get_started, prepare_ux_source, quick_scan_ux, audit_ux_surface, validate_ux_report_payload, generate_ux_audit_report, run_agent_audit, run_usability_test, and stress_test_heuristic_finding.
- Writable preferences and report-payload snapshots should stay in user app data.

Steps:
1. Confirm the current client supports MCPB/Desktop Extension installation.
2. Help me install the .mcpb through the current supported UI.
3. Restart the client if needed.
4. Check whether UX Heuristics Compass appears in the available MCP tools.
5. Run a small smoke prompt: "Call get_started for UX Heuristics Compass and tell me the first five-minute path."
6. If it fails, diagnose in this order:
   - Is the .mcpb file present and not still zipped inside another archive?
   - Is the client updated enough to show Extensions or MCPB support?
   - Did UV dependency setup fail on first launch?
   - Are there MCP logs showing a process launch error?
   - Are writable files being redirected to user app data rather than the extension folder?
   - Is any failure specific to preferences/report storage rather than the core UXHC tools?

Safety rules:
- Do not add provider keys.
- Do not overwrite existing MCP servers or unrelated config.
- Do not install third-party audit tools while diagnosing this install.
- If manual config inspection is needed, read the current config first and preserve all existing entries.

Expected result:
- UX Heuristics Compass is installed.
- get_started works.
- If a feature is unavailable, explain whether it is an install issue, dependency issue, client restart issue, or unsupported-client behavior.
```
