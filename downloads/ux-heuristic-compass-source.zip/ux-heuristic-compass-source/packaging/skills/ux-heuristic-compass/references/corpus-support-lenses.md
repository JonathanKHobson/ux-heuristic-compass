# UXHC Corpus Support Lenses

Use this reference when UXHC support lenses appear in findings, guidance-only output, or generated reports. This file tracks the skill-side view of shipped corpus slices so host AIs do not treat runtime support layers as new scorecards.

## Core Rule

Corpus lenses are explanatory support only.

- H01-H14 remain the canonical rubric.
- Checklist ratings remain 0-4 severity ratings.
- Corpus lenses never change grades, percentages, severity counts, finding order, report readiness, or validation status.
- Corpus lenses should attach only to evidence-backed findings, meaningful host observations, or explicit evidence limits.
- Do not claim certification, conformance, community approval, real user behavior, or business outcomes unless the user supplies that evidence.

## Shipped Slice: UXHC-CORPUS-001

`UXHC-CORPUS-001` adds curated non-Western, cross-cultural, Indigenous, decolonial, multilingual, faith-aware, low-resource, and mediated-access support lenses.

Runtime lens prefix:

```text
cross_cultural_*
```

Primary mappings:

| Lens family | Typical heuristic connections | Use when evidence suggests |
| --- | --- | --- |
| Cultural safety and community authority | H02, H12, H13, H14 | The interface uses culturally situated language, imagery, identity claims, or community-facing commitments without enough context or authority cues. |
| Indigenous data governance and Local Contexts/TK labels | H02, H04, H10, H12, H13 | The product collects, labels, displays, or operationalizes Indigenous/community knowledge, data, names, imagery, or AI outputs. |
| Relational research methods and deep listening | H10, H12, H13, H14 | The experience asks for sensitive disclosure, feedback, consultation, or community input but does not show a respectful participation path. |
| Pluriversal, postcolonial, and place-based design | H02, H04, H12, H13 | The design assumes one dominant model of identity, progress, service, family, time, place, or authority. |
| Low-resource, shared-device, and mediated access | H01, H03, H07, H10, H12, H13 | The task may be completed through low bandwidth, shared devices, assisted access, intermittent connectivity, or constrained time. |
| Script direction, localization, literacy, and orality | H02, H04, H06, H10, H11, H14 | The UI includes multilingual content, RTL or non-Latin scripts, translation quality, audio/oral pathways, literacy assumptions, or locale-specific formatting. |
| Faith-aware and observance-sensitive UX | H03, H05, H10, H12, H13, H14 | Timing, privacy, notifications, food, finance, health, education, or identity flows may conflict with religious or spiritual observance. |

Required framing:

```text
This is culturally situated support guidance, not cultural certification, community approval, or a universal claim about any culture. Validate with affected communities, local expertise, or culturally grounded reviewers when the stakes are meaningful.
```

## Report Output For UXHC-CORPUS-001

When relevant lenses attach to evidence-backed findings, advanced reports may include:

- `Cultural Context Signal`: one sentence near the UX Health Snapshot.
- `Cultural Context Integrity Advisory`: a deeper support-only report module.
- `Context Integrity Index`: a support-only advisory index derived from existing findings, evidence strength, and selected lenses.

Labels:

| Range | Label |
| ---: | --- |
| 85-100 | Strong Context Fit |
| 70-84 | Mostly Context-Aware |
| 50-69 | Needs Context Review |
| 25-49 | High Context Risk |
| 0-24 | Insufficient Context Safety |
| insufficient evidence | Evidence-Limited Context Review Needed |

The index is not an overall UX grade. Do not compare it to the main UX Health grade as if they are equivalent scoring systems.

## Host Behavior

When the cultural context advisory appears:

- Summarize it as a support-only signal, not as the audit's main verdict.
- Tie every concern back to a finding, evidence ref, or evidence limit.
- Prefer "may need validation with..." and "evidence suggests..." language.
- Avoid universalizing phrases such as "all non-Western users," "culturally safe certified," "decolonized certified," or "community-approved" unless the user supplied direct proof.
- Do not inflate severity solely because a cultural lens attached. Severity stays governed by the submitted checklist rating.

When no culturally situated evidence exists:

- Do not force a cultural advisory section.
- If the audience may be culturally specific but evidence is missing, name that as an evidence limit or a validation nudge rather than inventing a finding.

## Shipped Slice: UXHC-CORPUS-002

`UXHC-CORPUS-002` adds curated WCAG/accessibility support lenses. These lenses are derived from the supplied WCAG accessibility packet and summarize practical WCAG 2.2 support areas; they do not import one runtime lens per success criterion.

Runtime lens prefixes:

```text
standard_wcag_pour
wcag_*
```

Primary mappings:

| Lens family | Typical heuristic connections | Use when evidence suggests |
| --- | --- | --- |
| Perceivable content and visual presentation | H04, H08, H10, H11, H14 | Text alternatives, media equivalents, contrast, visual state, reflow, zoom, or text spacing may affect access. |
| Keyboard, focus, and operability | H01, H03, H04, H07, H11 | Keyboard access, focus order, visible focus, bypass links, target size, pointer gestures, timing, motion, or no-trap behavior needs review. |
| Understandable forms and recovery | H02, H05, H06, H09, H11, H14 | Labels, instructions, error identification, error suggestion, redundant entry, or accessible authentication may create access barriers. |
| Robust components and announcements | H01, H04, H06, H09, H11 | Custom widgets, modals, ARIA, name/role/value, live regions, status messages, tables, dashboards, or mobile/touch patterns need technical validation. |
| Manual evidence matrix | H01, H03, H05, H09, H11 | The finding needs keyboard traversal, focus, screen-reader, contrast, caption/media, or state evidence before stronger claims are safe. |

Required framing:

```text
This is WCAG-informed support guidance, not WCAG, ADA, legal, procurement, or conformance certification. Use it to identify evidence-backed accessibility risk and decide what manual or technical review is needed next.
```

## Report Output For UXHC-CORPUS-002

When relevant lenses attach to evidence-backed findings, advanced reports may include:

- `Accessibility Readiness Signal`: one sentence near the UX Health Snapshot.
- `WCAG-Informed Accessibility Readiness`: a deeper support-only report module.
- `WCAG Level Signal`: the highest WCAG level implicated by selected support cues: `A`, `AA`, or `AAA`; or `Evidence Limited` when evidence is insufficient.

The WCAG level signal is not a score and not a conformance result. Do not say the interface is A, AA, or AAA compliant. Say that A, AA, or AAA-level criteria are implicated by the evidence and that manual accessibility testing is needed before any conformance claim.

When the accessibility readiness advisory appears:

- Summarize it after the main UX grade and top finding.
- Tie every concern back to a finding, evidence ref, support lens, or evidence limit.
- Use "WCAG A-level criteria are implicated..." or "WCAG AA-level criteria are implicated..." phrasing.
- Avoid "WCAG compliant," "ADA compliant," "legally compliant," "certified," or "conforms to AA/AAA" language.
- Do not inflate severity solely because a WCAG lens attached. Severity stays governed by the submitted checklist rating.

When no accessibility evidence exists:

- Do not force an accessibility readiness section.
- If accessibility evidence is missing, name the missing keyboard/focus/screen-reader/contrast/state evidence as an evidence limit or validation nudge.

## Shipped Slice: UXHC-CORPUS-003

`UXHC-CORPUS-003` adds curated ISO UX/UI/HCI support lenses. These lenses are derived from the supplied ISO UX/UI/HCI corpus and summarize practical ISO support areas; they do not make UXHC an ISO audit, compliance process, certification process, procurement proof, or legal assurance.

Runtime lens prefixes:

```text
standard_iso_9241_110
iso_*
```

Primary mappings:

| Lens family | Typical heuristic connections | Use when evidence suggests |
| --- | --- | --- |
| Usability in context and quality in use | H01, H02, H07, H12, H13 | The finding depends on target users, goals, tasks, context of use, effectiveness, efficiency, satisfaction, freedom from risk, or context coverage. |
| Human-centred design and organizational process | H05, H10, H12, H13 | The risk points to missing user requirements, weak evaluation loops, lifecycle ownership, supplier evidence, or product-quality governance. |
| Information presentation and UI patterns | H01, H04, H08, H09, H11, H14 | The interface has detectability, discriminability, conciseness, visual presentation, component-state, form, auditory, or navigation-design risks. |
| Accessibility ergonomics and individualization | H03, H07, H10, H11, H13 | The finding needs software accessibility, assistive-technology, preference, personalization, haptic/tactile access, or individualized adaptability language. |
| Localization and UI standards | H02, H04, H06, H11, H14 | Icons, language selectors, locale formatting, cultural/linguistic adaptability, or UI symbol conventions affect comprehension. |
| CIF/SQuaRE evidence and reporting | H01, H02, H09, H10, H13 | The audit needs context-of-use, user-needs, user-requirements, evaluation-report, product-quality, or quality-in-use traceability. |
| AI, privacy, security, workload, and operations ergonomics | H01, H03, H05, H09, H10, H12, H13 | AI quality/risk/transparency, privacy by design, security UX, mental workload, control-centre dashboards, gesture/haptic/immersive UX, or consumer-product operation affects user risk. |

Required framing:

```text
This is ISO-informed support guidance only; not formal ISO standards compliance, conformance, certification, procurement proof, or legal assurance. Use it to improve explanation, evidence quality, and validation planning.
```

## Report Output For UXHC-CORPUS-003

There is no ISO score, ISO readiness index, or special ISO advisory module in this slice.

ISO lenses may appear in:

- finding-level `support_lenses[]`
- audit-level `support_lens_suggestions[]`
- guidance-only support-lens cues
- the report section `Supporting UX Laws And Principles`

When ISO lenses appear:

- Tie every ISO reference back to an evidence-backed finding, host observation, or evidence limit.
- Use phrasing like "ISO-informed support reference" or "connects to ISO-style guidance."
- Do not say "ISO compliant," "ISO certified," "conforms to ISO," "procurement ready," or anything that sounds like legal assurance.
- Do not inflate severity solely because an ISO lens attached. Severity stays governed by the submitted checklist rating.

## Shipped Slice: UXHC-CORPUS-004

`UXHC-CORPUS-004` adds curated CX/service-journey support lenses. These lenses are derived from the supplied CX deep-dive packet and summarize practical customer-experience operating concepts for promise delivery, effort, recovery, complaints, channel continuity, customer education, respectful retention, and CX governance. They do not make UXHC a CX measurement platform or business-outcome proof engine.

Runtime lens prefix:

```text
cx_*
```

Primary mappings:

| Lens family | Typical heuristic connections | Use when evidence suggests |
| --- | --- | --- |
| Promise delivery and expectation gaps | H02, H05, H10, H13, H14 | Marketing, policy, onboarding, or service copy creates an expectation without a visible delivery path, owner, or recovery path. |
| Customer effort and ownership gaps | H01, H03, H07, H09, H10, H13 | Customers must repeat themselves, restart, switch channels, coordinate internal teams, or find support without clear ownership. |
| Recovery, complaints, and perceived justice | H05, H09, H10, H12, H13, H14 | Complaint, refund, dispute, error, escalation, or service recovery flows lack acknowledgement, status, fairness, explanation, or closure. |
| Omnichannel continuity and status transparency | H01, H03, H04, H05, H07, H09, H13 | Customers move across web, app, chat, phone, email, branch, or partner channels and need context carryover, case status, or next-update clarity. |
| Evidence, privacy, and service records | H03, H04, H09, H11, H13 | Customers upload documents, receipts, IDs, photos, or proof and need acknowledgement, traceability, privacy, and no repeated submission. |
| Customer success and education | H06, H10, H13, H14 | Complex services need sequenced onboarding, knowledge, adoption, value-realization, or training support after signup or purchase. |
| Retention, endings, and ethical exit | H03, H05, H09, H12, H13 | Cancellation, renewal, save offers, win-back, offboarding, export, closure, or final billing could become confusing or coercive. |

Required framing:

```text
This is CX support guidance only; no ROI, NPS, retention, loyalty, satisfaction, revenue, churn, or real-customer outcome claim unless supplied evidence supports it. Use CX lenses to improve journey, recovery, ownership, and validation language.
```

## Report Output For UXHC-CORPUS-004

There is no CX score, CX readiness index, or special CX advisory module in this slice.

CX lenses may appear in:

- finding-level `support_lenses[]`
- audit-level `support_lens_suggestions[]`
- guidance-only support-lens cues
- the report section `Supporting UX Laws And Principles`

When CX lenses appear:

- Tie every CX reference back to an evidence-backed finding, host observation, or evidence limit.
- Use phrasing like "CX support reference," "service-journey support lens," or "connects to customer-experience guidance."
- Do not say the finding proves ROI, NPS movement, loyalty, retention, satisfaction, churn reduction, revenue impact, or real customer behavior.
- Do not recommend dark-pattern retention tactics; respectful retention means clear cancellation, fair recovery, and non-coercive exit paths.
- Do not inflate severity solely because a CX lens attached. Severity stays governed by the submitted checklist rating.

## Shipped Slice: UXHC-CORPUS-005 And UXHC-CORPUS-006

`UXHC-CORPUS-005` and `UXHC-CORPUS-006` harden the shipped support-lens corpus rather than adding a new corpus family.

Runtime lens output now normalizes family phrasing through compact policy keys:

| Policy key | Report family label | Use |
| --- | --- | --- |
| `core` | UX/UI Support Lens | General UX laws, HCI principles, UI conventions, and non-Nielsen heuristic systems. |
| `cross_cultural` | Cultural Context Support | Cultural, multilingual, Indigenous, decolonial, local-context, mediated-access, and community-authority cues. |
| `wcag` | WCAG Accessibility Support | WCAG/accessibility cues, including POUR, keyboard, focus, contrast, labels, media, widgets, and manual-test needs. |
| `iso` | ISO UX/UI/HCI Support | ISO-informed usability, HCD, interaction quality, accessibility ergonomics, AI, privacy/security, and operational-risk cues. |
| `cx` | CX Service-Journey Support | Service journey, promise delivery, recovery, complaints, handoff, effort, and customer-relationship cues. |

Every family policy supplies source-quality, applicability, evidence-needed, and reporting-guardrail wording. These fields help hosts keep support references concise and safe; they do not add a new required schema, score, grade, checklist field, report module, or public tool.

Final overclaim rules:

- No WCAG/ADA/legal/procurement/compliance/conformance/certification proof.
- No ISO compliance, conformance, certification, procurement proof, or legal assurance.
- No cultural certification, universal claims about any culture, or community approval.
- No ROI, NPS, retention, loyalty, satisfaction, revenue, churn, or real-customer outcome proof.
- No real participant research, user testing, or synthetic-user evidence unless participant evidence is supplied.
- No claim that support lenses changed UXHC grades, ratings, severity, priority, or canonical checklist scoring.

In reports, preserve the normalized **Supporting UX Laws And Principles** language. It can say a finding also connects to a support family and what evidence is needed next, but it must stay secondary to H01-H14 and the evidence-backed findings.

## Future Corpus Slice Sync

Every shipped corpus slice must update this skill package, not just the runtime registry.

Minimum source-skill updates per slice:

1. Update `SKILL.md` only if the slice changes first-use routing or major report behavior.
2. Update this reference file with the shipped lens family, mappings, caveats, report behavior, and host wording rules.
3. Update `references/heuristics-checklist.md` when the slice affects how hosts explain H01-H14 support coverage.
4. Update `references/mcp-bridge.md` when the slice affects MCP routing, payload fields, or report rendering.
5. Update `references/report-payload-field-guide.md` if new optional report fields may appear.
6. Add or update tests that assert the skill source mentions the shipped slice and preserves support-only boundaries.

Planned slices:

| Slice | Skill package update expectation |
| --- | --- |
| `UXHC-CORPUS-002` WCAG/accessibility | Shipped: WCAG-informed support wording, Accessibility Readiness Signal guidance, WCAG Level Signal guidance, and conformance-safe language. |
| `UXHC-CORPUS-003` ISO UX/UI/HCI | Shipped: ISO-informed support wording, ordinary support-lens report behavior, and formal-compliance guardrails. |
| `UXHC-CORPUS-004` CX | Shipped: H13-centered CX support wording, ordinary support-lens report behavior, and no-business-outcome-overclaim guardrails. |
| `UXHC-CORPUS-005` corpus quality | Shipped: normalized family policies for source quality, applicability, evidence needed, display family, and report guardrails. |
| `UXHC-CORPUS-006` overclaim suite | Shipped: regression expectations and forbidden claim language for WCAG, ISO, cultural context, CX, synthetic-user, and score-authority drift. |
