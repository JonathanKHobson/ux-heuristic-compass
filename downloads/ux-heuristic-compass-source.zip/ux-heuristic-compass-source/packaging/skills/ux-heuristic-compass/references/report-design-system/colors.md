# Color Rules

The standard report uses the fixed UXHC green/neutral palette until audited
brand color contrast validation exists.

## Grade Colors

- A range: green `#22863a`.
- B+ range: olive green `#5a7f3e`.
- B range: muted olive `#7a8c3e`.
- C range: orange `#c96a00`.
- D/F range: red `#cb2431`.

## Use Rules

- Header uses `#0d6e6e` with white text.
- Mission context uses warm yellow background with a left accent.
- Critical/top finding uses red border and soft red background.
- Evidence and validation cards use neutral gray surfaces.
- Do not auto-theme from the evaluated brand until contrast checking exists.
