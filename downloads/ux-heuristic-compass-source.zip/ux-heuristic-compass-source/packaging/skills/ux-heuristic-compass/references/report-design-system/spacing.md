# Spacing Rules

## Page

- Header padding: 40px 48px desktop, 32px 24px mobile.
- Container max width: 1100px.
- Container padding: 32px 24px desktop, 24px 16px mobile.

## Components

- Cards: 28px padding, 24px bottom margin, 12px radius.
- Overall summary gap: 24px.
- Scorecard grid gap: 16px.
- Finding internal sections: 10px top margin.
- Tables: 10-12px cell padding.

Do not nest cards inside cards. Repeated items such as findings, score items,
validation options, and checklist details may be card-like.
