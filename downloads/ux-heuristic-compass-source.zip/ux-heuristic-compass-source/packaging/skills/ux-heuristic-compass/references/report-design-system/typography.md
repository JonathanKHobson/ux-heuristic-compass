# Typography Rules

Reports use system UI fonts only:

```css
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
```

## Scale

- Header title: 28px, 700 weight.
- Overall grade: 64px, 900 weight.
- Section title: 18px, 700 weight.
- Finding title: 15px, 700 weight.
- Body: 14-15px.
- Metadata, labels, table headers: 11-13px.

Keep labels uppercase with modest letter spacing. Do not scale type with viewport
width.
