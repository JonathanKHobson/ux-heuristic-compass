# Layout Rules

- Use a single column page with section cards.
- Use a two-column top summary only for the compact grade card plus the flexible
  Plain Language Read card.
- Use responsive CSS grid for heuristic cards and validation cards.
- Tables may horizontally scroll on narrow screens.
- Keep Evidence Limits and Recommended Next Validation Steps above the roadmap.
- Keep micro-solutions near the bottom as tactical quick wins, not as the main
  recommendation.
