# UXHC Heuristics Checklist Reference

This reference is the compact standalone rubric for UX Heuristics Compass. Use it when the MCP is unavailable, when explaining the rubric, or when drafting host prompts.

## What The Audit Scores

UXHC scores visible or documented usability issues in an interface. It does not score the people who built the interface, the product's total value, or whether the design is legally compliant.

The score asks: given the evidence available, how severe are the visible usability issues?

## Rating Scale

Every active checklist item receives one severity rating.

| Score | Meaning | Use when |
| ---: | --- | --- |
| 0 | No issue | The evidence shows the item is handled well or no visible problem appears. |
| 1 | Cosmetic | The issue is small, low-friction, or mainly polish. Fix if time permits. |
| 2 | Minor | The issue may slow or confuse users but probably does not block the task. |
| 3 | Major | The issue creates meaningful friction, uncertainty, exclusion, or recovery trouble. |
| 4 | Catastrophic | The issue can block the task, cause serious error, or make the experience near-unusable. |

Higher quality percentages mean better UX quality. Severe issues lower the score.

## Core Heuristics

| ID | Heuristic | What To Look For |
| --- | --- | --- |
| H1 | Visibility of System Status | The interface keeps users informed about where they are, what changed, what is loading, and what happened after an action. |
| H2 | Match Between System and the Real World | Labels, concepts, ordering, and language match the user's mental model instead of internal system terms. |
| H3 | User Control and Freedom | Users can undo, cancel, go back, exit, recover, or change direction without feeling trapped. |
| H4 | Consistency and Standards | Similar things look and behave similarly, and the interface follows familiar platform and web conventions. |
| H5 | Error Prevention | The design helps users avoid mistakes before they happen, especially destructive or hard-to-recover errors. |
| H6 | Recognition Rather Than Recall | The interface shows useful choices, labels, context, and instructions instead of forcing users to remember hidden information. |
| H7 | Flexibility and Efficiency of Use | The design supports both new and experienced users through shortcuts, efficient paths, defaults, and adaptable workflows. Calibrate severity against the user's ability cost: low bandwidth, mobile-only access, low literacy, cognitive load, or time pressure can turn a small friction into a major issue. |
| H8 | Aesthetic and Minimalist Design | The screen reduces clutter, prioritizes what matters, and avoids making low-value content compete with core actions. |
| H9 | Help Users Recognize, Diagnose, and Recover From Errors | Error states are visible, understandable, specific, and paired with a clear recovery path. |
| H10 | Help and Documentation | Help, instructions, and support content are easy to find, task-relevant, and not a substitute for a broken core flow. |

## Optional General Profiles

These are first-class optional heuristics. Include them when the user asks for expanded coverage, when the interface materially raises those issues, or when the MCP/user selects the corresponding profile.

| ID | Profile ID | Accepted Aliases | Heuristic | Use when |
| --- | --- | --- | --- | --- |
| H11 | `accessibility` | `a11y` | Accessibility and Ease of Access | The audit should consider keyboard, readable text, contrast, form affordances, focus, captions, sensory assumptions, or ease of access. If H11 has severity 3-4 findings, hand off to `patterns:accessibility-reality-check` or a real WCAG/accessibility review; UXHC is not a compliance audit. |
| H12 | `inclusion` | `empathy` | Empathetic Engagement and Inclusion | The experience may affect users with different emotional states, identities, contexts, abilities, language backgrounds, or safety needs. Use the Persona Spectrum from `patterns:inclusive-design-framework`: permanent, temporary, and situational constraints can produce the same usability barrier. |
| H13 | `journey` | `cx` | Customer Journey and Satisfaction | The audit needs to consider whether the screen fits the broader task journey, expectation, handoff, or service moment. Use audience ability and task stakes to calibrate journey severity, especially when a small friction compounds across steps. |
| H14 | `ux_writing` | `content_strategy` | UX Writing / Content and Tone | Labels, microcopy, instructions, error messages, empty states, or tone may affect comprehension and trust. |

When `quick_scan_ux` or `audit_ux_surface` is called without optional profiles, the MCP returns `audit_scope_lock` listing the omitted profiles and instructions for re-running with expanded coverage. Surface this to the user before summarizing audit results.

## Support Lenses And Corpus Advisories

UXHC can attach support-only laws, principles, standards, conventions, non-Nielsen heuristic systems, and curated corpus lenses to findings. These lenses explain why a risk matters; they do not create ratings or alter the H01-H14 scorecard.

`UXHC-CORPUS-001` adds cultural-context support lenses for non-Western, cross-cultural, Indigenous, decolonial, multilingual, faith-aware, low-resource, and mediated-access evidence. These lenses usually support H02, H04, H10, H12, H13, and H14, with selected H01/H03/H05/H11 links when evidence supports them.

If a report includes `Cultural Context Signal` or `Cultural Context Integrity Advisory`, present it as support-only context guidance. It is not cultural certification, community approval, or a second UX grade. Read `references/corpus-support-lenses.md` before summarizing that module.

`UXHC-CORPUS-002` adds WCAG/accessibility support lenses. These primarily support H11 and selected H01/H03/H04/H05/H06/H09/H10/H14 findings. If a report includes `Accessibility Readiness Signal` or `WCAG-Informed Accessibility Readiness`, present it as evidence-limited WCAG support guidance. It is not WCAG, ADA, legal, procurement, or conformance certification, and it does not change 0-4 checklist ratings.

`UXHC-CORPUS-003` adds ISO UX/UI/HCI support lenses. These can support any H01-H14 finding when ISO usability, HCD process, information presentation, UI pattern, accessibility ergonomics, quality-in-use, AI, privacy/security, workload, or operations evidence is relevant. Present them as ISO-informed support references only; they are not ISO compliance, conformance, certification, procurement proof, or legal assurance.

`UXHC-CORPUS-004` adds CX/service-journey support lenses. These primarily support H13 and selected H01/H03/H04/H05/H09/H10/H12/H14 findings when promise debt, effort, recovery, complaints, omnichannel continuity, support handoff, status transparency, customer education, respectful retention, or CX governance evidence is relevant. Present them as CX support references only; they do not prove ROI, NPS, retention, loyalty, satisfaction, revenue, churn, or real-customer outcomes.

## Checklist Counts

Use these counts when explaining scope. Do not invent additional baseline checklist items.

| ID | Heuristic | Desktop items | Mobile items |
| --- | --- | ---: | ---: |
| H1 | Visibility of System Status | 9 | 9 |
| H2 | Match Between System and the Real World | 3 | 3 |
| H3 | User Control and Freedom | 5 | 5 |
| H4 | Consistency and Standards | 21 | 21 |
| H5 | Error Prevention | 5 | 5 |
| H6 | Recognition Rather Than Recall | 4 | 4 |
| H7 | Flexibility and Efficiency of Use | 9 | 9 |
| H8 | Aesthetic and Minimalist Design | 16 | 16 |
| H9 | Help Users Recognize, Diagnose, and Recover From Errors | 2 | 2 |
| H10 | Help and Documentation | 5 | 5 |
| H11 | Accessibility and Ease of Access | 4 | 4 |
| H12 | Empathetic Engagement and Inclusion | 6 | 6 |
| H13 | Customer Journey and Satisfaction | 6 | 6 |
| H14 | UX Writing / Content and Tone | 7 | 7 |

Core scope is H1-H10. Expanded scope can include H11-H14. Full dual-platform all-optionals coverage is 204 checklist items.

## Checklist ID Pattern

Checklist IDs follow this shape:

```text
h{heuristic_number_zero_padded}_{platform_initial}_{item_index_zero_padded}
```

Examples:

- `h01_d_01` means H1 desktop item 1.
- `h07_m_09` means H7 mobile item 9.
- `h11_d_01` means H11 desktop item 1.

Use the MCP for exact checklist IDs and item text. In standalone mode, name the heuristic and evidence clearly even when you do not know the exact checklist ID.

## Evidence Limits

Always name evidence limits. Common limits:

- screenshot does not show hover, focus, loading, visited, disabled, or error states
- mobile and desktop states are not both available
- page capture is cropped, low-resolution, stale, or partially hidden
- task flow is inferred from one screen
- user goal, audience, or success criteria are missing
- code suggests an issue but rendered behavior was not observed

Do not score hidden states with high confidence. If a state is not visible, either ask for more evidence or mark the rating as low confidence.
