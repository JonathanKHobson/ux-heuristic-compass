# UX Heuristic Compass

UX Heuristic Compass is a local-first MCP/product for structured checklist-level heuristic UX audits of websites, application screens, screenshots, and bounded page captures.

The product goal is simple: help a reviewer identify visible usability issues, rank them by severity, and turn them into a stakeholder-ready audit report before a design or interface ships.

This repository now contains the planning package plus the full local MCP launch scope: 14 heuristic records, 204 dual-platform checklist items, checklist-level scoring, source preparation, bounded URL capture, an internal evidence graph, durable run summaries, audit payload generation, behavioral audit contracts, preferences persistence, Agent Mode 1 aggregation, bounded Agent Mode 2 evidence prep, report validation, Markdown/HTML/PDF report generation, calibration/comparison scaffolds, project-specific add-on scaffolding, tests, and a local stdio MCP server.

## MVP Boundary

UX Heuristic Compass is not a broad UX research platform in the first version. The MVP should audit:

- screenshot or image bundles
- desktop and mobile viewport captures
- bounded URL captures for up to 10 explicit pages or a named task flow

The MVP should not include:

- full-site crawling
- authenticated flows
- autonomous browser-agent navigation
- analytics ingestion
- competitive scraping as a default path
- donor, ecommerce, nonprofit, SaaS, education, or other domain-specific checklists in the baseline rubric

Project-specific heuristic checklists are a later development lane. The north-star version can generate curated add-on checklists from the product type, audience, task, competitive references, and domain constraints, but that should be opt-in and case-by-case.

## Core Audit First Contract

UXHC's center is the heuristic audit, not the support library around it. Every completed audit should lead with the source scope, UX Health Snapshot, checklist-level scorecard, top finding, plain-language read, and one concrete recommendation before it surfaces Atlas cards, teaching activities, bias advisories, or agent frames.

Any new flow, activity, bias advisory, or agent frame must directly support at least one of these purposes:

- better checklist interpretation
- better evidence quality
- better severity or confidence calibration
- better prioritization
- better next-step validation
- better human-in-the-loop teaching

If an addition does not strengthen the bounded interface audit, it belongs in backlog, documentation, or a separate UX research product.

## Core Rubric

The baseline rubric is Nielsen Norman Group's 10 usability heuristics:

1. Visibility of system status
2. Match between system and the real world
3. User control and freedom
4. Consistency and standards
5. Error prevention
6. Recognition rather than recall
7. Flexibility and efficiency of use
8. Aesthetic and minimalist design
9. Help users recognize, diagnose, and recover from errors
10. Help and documentation

Optional general add-on profiles from the supplied HE scorecard:

- `accessibility` -> H11, accessibility and ease of access
- `inclusion` -> H12, empathetic engagement and inclusion
- `journey` -> H13, customer journey and satisfaction
- `ux_writing` -> H14, UX writing and content design

Advanced audits can now state scope explicitly with `optional_profile_mode`: `core_only`, `scoped`, `all_optionals`, or `ask`. The compatibility flag `full_advanced=true` means H1-H14 unless the host/user chooses core-only or a scoped optional subset; if optionals are omitted, the audit returns an `audit_scope_lock` and reports list the omitted profiles.

Explicitly excluded from the baseline:

- donor/conversion checklist
- project-specific nonprofit donation flow checks
- any checklist that only makes sense for one domain or business model

## Local MCP Tool Surface

The MCP server exposes 18 tools:

- `get_started`
- `ux_heuristic_overview`
- `list_heuristics`
- `prepare_ux_source`
- `quick_scan_ux`
- `audit_ux_surface`
- `validate_ux_report_payload`
- `generate_ux_audit_report`
- `calibrate_ux_sensitivity`
- `calibrate_ux_severity`
- `compare_ux_audits`
- `draft_project_addon_profile`
- `save_preferences`
- `stress_test_heuristic_finding`
- `update_preferences`
- `run_agent_audit`
- `get_agent_run`
- `run_usability_test`

Host-side tool search may initially surface only a subset, often the first five matching tools. Treat `get_started` and `ux_heuristic_overview` as the authoritative discovery surfaces: both return `tool_discovery_contract.public_tool_count=18`, and `get_started(topic="tools")` returns the full tool contracts when a cold host needs deeper routing help.

The host AI owns conversation, visual interpretation, and user-facing explanation. UX Heuristic Compass owns rubric structure, bounded source manifests, scoring contracts, report readiness, browser-capture hygiene, preferences, local persistence, agent-run aggregation, and artifact generation.

Evidence handling is graph-centered but still local and bounded. `prepare_ux_source`, `quick_scan_ux`, and `audit_ux_surface` can carry an `evidence_graph` that normalizes screenshots, screenshot regions, visible-text summaries, accessibility snapshots, DOM/devtools snippets, code-component notes, Figma nodes, host observations, and human notes into typed evidence nodes. Checklist `evidence_refs` are validated against that graph; unknown refs warn by default and become blockers only when strict evidence validation is requested.

Every public MCP call can persist a compact `UXHCRunSummary` JSONL trace under the local UXHC state directory. Traces record run id, tool name, evidence counts, checklist-rating counts, blockers, warnings, payload/report paths, HIL state, and adapter sources so failed reports, source-boundary issues, HIL drift, and adapter misuse can be debugged after the fact.

`calibrate_ux_sensitivity` is canonical. `calibrate_ux_severity` remains as a compatibility alias.

`run_agent_audit` is user-facing “Researcher persona scorecard aggregation”: the host embodies the researcher personas and submits scorecards, while UXHC aggregates, flags disagreements, and persists the run. `run_usability_test` is user-facing “Bounded usability-test prep/synthetic walkthrough support” unless real participant logs are supplied; it is not unbounded autonomous navigation and should not be represented as real user evidence by default.

`list_heuristics` now defaults to compact summary output so cold agents can discover the rubric without receiving the full checklist arrays. It also surfaces `support_lens_summary` so hosts can see the support-only UX/UI laws, WCAG/accessibility, ISO, cultural-context, and CX/service-journey corpus without running an audit. Use `list_heuristics(detail_level="full")` when the host needs every checklist item inline, or `list_heuristics(topic="support_lenses")` / `list_heuristics(detail_level="support_lenses")` when the host needs the full support-lens catalog.

Every public tool has a host-facing usage contract: purpose, use when, do not use when, returned shape, next host action, and repair path. `get_started` exposes these contracts so cold hosts can choose the right route without treating UXHC as a crawler, compliance scanner, synthetic-user proof, or handmade report generator.

`quick_scan_ux` can return a `quick_ux_risk_card` for first-pass triage. When checklist ratings are missing, the card is explicitly `unscored_risk_snapshot`: useful as a market-facing risk read, but not a full grade, not a complete scorecard, not user-tested evidence, and not compliance certification.

`quick_scan_ux` also has an ultra-quick `output_detail="guidance_only"` lane for tiny component refinement, fix prompts, micro-plans, or naming what feels wrong. Guidance-only output is intentionally not an audit: no grade, no scorecard, no report payload, no checkpoint, no artifact, no compliance claim, and no user-testing claim. If `quick_scan_ux` is called without an `output_detail`, UXHC returns a one-question mode gate so the host can choose `guidance_only`, `status_only`, `compact`, or `full` instead of hiding the options.

Scored audits return behavioral contracts after the core scorecard:

- `report_readiness_contract`
- `plain_language_read`
- `before_using_this_interface`
- `follow_up_activity`
- `follow_up_activity_extended` with optional validation/teaching activities
- `human_loop_host_action` for Quick Audit context checks and Advanced Audit HIL pauses
- `implementation_inspection_contract` when an AI coding harness/code-aware inspection lane is requested
- `report_harness` metadata inside the report readiness contract, naming the static one-page HTML design-system rules
- `reasoning_flow_suggestions` with targeted Atlas-adapted imported-static flow cards plus authored UXHC cards
- `support_lens_suggestions` with support-only UX/UI laws, principles, standards, conventions, non-Nielsen heuristic lenses, curated cultural-context lenses, WCAG/accessibility lenses, ISO UX/UI/HCI standards lenses, and CX/service-journey lenses mapped to findings
- `corpus_advisory_modules` when relevant evidence-backed findings trigger a support-only module such as Accessibility Readiness Signal / WCAG-Informed Accessibility Readiness or Cultural Context Signal / Cultural Context Integrity Advisory
- `evaluator_bias_advisories` for anchoring, familiarity, halo, and evaluator-experience calibration risks
- `prioritization_flow` when an overall scored audit is B or below

The support lens layer is explanatory, not a second rubric. Lenses can help a host explain why a finding matters, name a relevant law, convention, WCAG/accessibility consideration, ISO-informed standards reference, cultural-context consideration, or CX/service-journey consideration, and choose a validation step, but they never create findings, change 0-4 checklist ratings, alter grades, certify compliance, certify cultural safety, prove ISO conformance, prove business outcomes, or replace local/community/expert review. Corpus families use normalized report phrasing and source-quality guardrails so output stays evidence-bound, support-only, and clear about what extra evidence would be needed for stronger claims.

Optional implementation-aware inspection is available through `audit_context`, not through a new tool. When `implementation_inspection_requested`, `codebase_available`, `implementation_evidence`, or `external_audit_results` is supplied, `quick_scan_ux` and `audit_ux_surface` can return an `implementation_inspection_contract`. This is a route for an AI coding harness such as Codex, Claude Code, Cursor, or a similar local agent to inspect source code, rendered previews, Playwright observations, or external frontend audit results and feed evidence back into the audit. UXHC maps those signals to likely affected heuristics and evidence limits; it does not run third-party audit tools, vendor external skills, or change checklist scores without submitted `checklist_ratings`.

Rendered review guidance is deliberately light in the default scaffolding. If the user supplies HTML, browser-compatible UI code, or a local preview, cold hosts should prefer rendered browser evidence before final UX claims. Call `get_started(topic="rendered_review")` for Playwright/local-server guidance: serve local HTML through HTTP/local server, avoid `file://` for browser review unless the artifact is explicitly static-file safe, and treat Playwright output as evidence-only.

Host-supplied external adapter results are accepted as evidence-only inputs through source prep or audit context. Supported adapter labels include Playwright MCP, Chrome DevTools MCP, axe-core/Playwright axe, Lighthouse, Figma MCP, and generic host-supplied evidence. Playwright and Chrome DevTools support means "accept their evidence outputs," not "run those tools from inside UXHC." Figma support is also host-supplied: files, frames, nodes, components, variants, screenshots, prototype states, and design-token notes normalize into the `AuditEvidenceGraph` with `score_authority: "evidence_only"`. Adapter output can support checklist interpretation and report traceability, but it cannot directly set UXHC scores.

Public distribution metadata and compatibility docs live in `dist/mcp-directory-metadata.json` and `docs/public/`. These files describe the 18-tool surface, host compatibility, security boundaries, evidence-only adapter policy, JSONL trace policy, and public-safe redacted example reports.

Screenshot-region refs such as `img-1:r1` are first-class evidence nodes. They can include a parent screenshot ref, label, optional bounds, and notes; reports render them as plain-text evidence appendix rows. Missing parent refs warn by default and block only when strict evidence mode is requested.

Human-loop responses with `PAUSE_REQUIRED=true` include `host_instruction`, an `ask_user_question_call` payload, and an MCP elicitation-compatible `elicitation_request`. Hosts should render those through their native AskUserQuestion/question UI and wait for answers before continuing; they should not flatten required HIL questions into ordinary markdown.

HIL can resume without a separate public tool. `quick_scan_ux` and `audit_ux_surface` accept `resume_run_id`, `hil_answers`, `host_question_ui_status`, `rating_overrides`, and `resolved_gate_ids`; paused responses include `resume_run_id` plus `audit_checkpoint_ref.path` so a host can restore the saved local audit state without resubmitting all checklist ratings. Responses include `resolved_gates`, `unresolved_gates`, `hil_compliance`, `hil_report_summary`, and `HIL_BLOCKED_UNTIL_NATIVE_UI` so hosts can tell whether native question UI was used, skipped, unavailable/resolved, or replaced by text fallback.

The Atlas/activity layer is audit-support intelligence, not the product center: UXHC stores UX-adapted flow cards and source IDs locally, but it does not require a live Knowledge Atlas connection at audit time. File-o-Fun-derived activities are kept separate from reasoning flows; draft-source activities include facilitation notes so hosts do not treat them as fully validated workshop scripts.

`stress_test_heuristic_finding` reviews one heuristic finding for UX fit: alternative explanations, false-positive risk, why the issue likely matters, evidence limits, evaluator bias flags for high-severity ratings, and one concrete fix.

## Planning Package

Start here:

1. `docs/planning/mission-audience-purpose-charter.md`
2. `docs/planning/master-prd.md`
3. `docs/planning/master-roadmap.md`
4. `docs/planning/backlog.md`
5. `docs/planning/source-ingestion-spec.md`
6. `docs/planning/scoring-and-report-contract.md`
7. `docs/planning/evaluation-strategy.md`

Supporting controls:

- `docs/planning/effort-impact-matrix.md`
- `docs/planning/adopt-adapt-reject-matrix.md`
- `docs/planning/file-ownership-and-parallel-work-rules.md`

## Implementation Principle

Clone the proven Critical Compass architecture pattern, not the Critical Compass purpose.

Reuse the infrastructure shape:

- local knowledge base
- deterministic payload builders
- host-facing workflow scaffolds
- report-readiness validation
- Markdown/PDF/local viewer artifacts
- conservative confidence and evidence boundaries

## Bounded URL Capture

`prepare_ux_source(..., capture_urls=True)` can capture up to 10 explicit public URL pages into a local source manifest. It records:

- URL, viewport, page title, and visible text summary
- a screenshot path when a local Chrome capture succeeds
- capture metadata JSON
- a browser handoff status proving no temporary UXHC Chrome profile remains

Browser handoff is scoped to UXHC-owned Chrome processes only: UXHC may inspect or warn about Chrome/Playwright sessions launched by another host, but it must not ask the host to kill Claude-, Codex-, Playwright-MCP-, or other external automation sessions.

V1 URL capture remains deliberately limited: no crawling, no authenticated flows, and no autonomous browser-agent navigation.

If a caller requests more than 10 pages, the response reports both `requested_max_pages` and `effective_max_pages` plus a `max_pages_capped` warning. URL captures also accept `render_wait_ms` for bounded client-render timing and warn when the captured page appears to be a loading/client-rendered SPA state. Hosts may pass `interactive_state_hints` for known tabs, accordions, toggles, modals, empty/error/loading states, or desktop/mobile states; UXHC records which hints are matched to supplied `state_labels` or evidence refs and turns unmatched hints into evidence-limit warnings rather than clicking through the UI itself.

## Report Artifacts

`audit_ux_surface` defaults to `output_detail="status_only"` so full H1-H14 audits can be driven without returning huge checklist/report payloads. The status response includes grade, active-scope badge, HIL state/counts, source status, report readiness, `report_payload_ref.path`, `resume_run_id` when HIL pauses, and the next host action. `quick_scan_ux` should be called with an explicit mode: `guidance_only` for tiny non-scored refinement help, `status_only` for small scored-audit orchestration, and `compact` or `full` only when the host needs diagnostic detail.

Paused HIL audits write local beta checkpoints under the UXHC state directory. To resume, call the same audit tool with `resume_run_id`, `hil_answers` or `resolved_gate_ids`, `host_question_ui_status`, and optional `rating_overrides`; UXHC restores source, profiles, platform, checklist ratings, scorecard, HIL gates, and report payload context from the checkpoint, then recomputes any explicit rating overrides.

`validate_ux_report_payload` accepts either an inline scored payload or `payload_path=report_payload_ref.path`. `generate_ux_audit_report` writes Markdown and, by default, an adjacent static one-page HTML report under the local UXHC state reports directory when `output_path` is omitted. It can also write an adjacent PDF when `include_pdf=True`. Use `response_mode="compact"` to return only status, paths, validation/render metadata, redaction metadata, PDF metadata, run summary, and repair tasks instead of full Markdown content. Reports use the UXHC report design-system harness: scorecard and findings lead, evidence limits and validation steps appear before the roadmap, checklist rows are available without JavaScript, and evidence refs/paths render as plain text with no links or external assets. Long evidence-limit diagnostic runs are grouped and collapsed in static `<details>` sections so repeated missing evidence-ref warnings do not swamp the report. Reports also include a compact static Evidence Gallery when evidence exists; it groups evidence cards by finding and preserves source paths, region refs, state labels, bounds, and capture metadata in local/private artifacts while public-safe rendering redacts private details. Optional `redaction_mode="public_safe"` redacts local paths, private URL details, emails, token-like values, and supplied `sensitive_labels` in rendered artifacts only; the raw audit payload is not mutated. If validation blocks, UXHC returns slot-specific `repair_tasks`; the host must repair the payload and retry the UXHC renderer instead of handmaking HTML. Optional `run_visual_qa=True` now preflights Playwright availability before browser launch; when Playwright is unavailable, report generation returns a warning and no browser is opened, and when it runs, UXHC reports owned temp-profile browser handoff metadata. If the minimal fallback PDF renderer is used, the report returns `qa_status: ready_with_warnings`.

Feedback reports can be converted into structured JSON/Markdown issue bundles without adding a public MCP tool:

```bash
python3 scripts/export_feedback_issues.py /path/to/feedback.md --format both
```

Generated issue bundles are local artifacts under the UXHC state directory unless `--output-dir` is supplied.

## Calibration And Comparison

`calibrate_ux_sensitivity` runs deterministic severity fixtures against the current checklist scoring contract and returns a human review rubric for finding quality.

`compare_ux_audits` compares two audit payloads and classifies findings as fixed, new, unresolved, or severity-changed. In `desktop_mobile` mode, baseline-only findings are treated as desktop-only and candidate-only findings are treated as mobile-only. It also returns a `comparison_report_payload` with compact platform report context, active-scope summaries, HIL status, evidence counts, checklist visibility, and static no-link rendering support through `generate_ux_audit_report`.

## Project-Specific Add-Ons

`draft_project_addon_profile` creates an opt-in scaffold from user-supplied project context, tasks, audience, constraints, and references. It does not scrape competitors, does not modify the baseline score, and keeps all criteria in the `project_specific_addon` lane.

Replace the audit domain:

- text reasoning audit becomes interface heuristic audit
- Critical Integrity Snapshot becomes UX Health Snapshot
- bias/fallacy findings become UX heuristic findings
- check-worthy claims become evidence-needed or validation-needed UX observations

## Local Runtime

Use a stable Python environment and run the server from the project root:

```bash
python3 server.py --self-test
```

Project-scoped MCP config:

```text
.mcp.json
```

It points to your local Python runtime and this project's `server.py`:

```text
python3 /path/to/ux-heuristic-compass/server.py
```

## Validation Commands

Validation should verify runtime, report, and scope language:

```bash
cd /path/to/ux-heuristic-compass
python3 -m pytest -q
python3 server.py --self-test
python3 scripts/generate_health_dashboard.py --self-test
python3 scripts/check_directory_readiness.py
find docs/planning -type f -name '*.md' | sort
rg -n "donor|conversion" README.md AGENTS.md docs/planning ux_heuristic_compass tests
rg -n "full-site crawling|autonomous browser-agent|authenticated flows" docs/planning README.md AGENTS.md
```

The donor/conversion scan should only find exclusion, rejection, or regression-test references. It must not appear as a core or optional rubric definition.

The MCP smoke should list these tools:

```text
audit_ux_surface
calibrate_ux_sensitivity
calibrate_ux_severity
compare_ux_audits
draft_project_addon_profile
generate_ux_audit_report
get_agent_run
get_started
list_heuristics
prepare_ux_source
quick_scan_ux
run_agent_audit
run_usability_test
save_preferences
stress_test_heuristic_finding
update_preferences
ux_heuristic_overview
validate_ux_report_payload
```
