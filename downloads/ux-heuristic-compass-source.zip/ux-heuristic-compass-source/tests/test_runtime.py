from __future__ import annotations

import http.server
import os
import threading
from pathlib import Path

from server import _self_test, get_started
from ux_heuristic_compass.addons import draft_project_addon_profile
from ux_heuristic_compass.agents import get_agent_run, run_agent_audit
from ux_heuristic_compass.audit import audit_ux_surface, quick_scan_ux
from ux_heuristic_compass.behavior import stress_test_heuristic_finding
from ux_heuristic_compass.calibration import calibrate_ux_sensitivity, calibrate_ux_severity
from ux_heuristic_compass.comparison import compare_ux_audits
from ux_heuristic_compass.knowledge import load_activity_registry, load_bias_registry, load_flow_library
from ux_heuristic_compass.report import generate_ux_audit_report, validate_ux_report_payload
from ux_heuristic_compass.rubric import get_active_checklist_items, list_heuristics, normalize_profiles
from ux_heuristic_compass.scoring import grade_for_percentage, score_checklist_ratings
from ux_heuristic_compass.source import prepare_ux_source
from ux_heuristic_compass.state import load_preferences, save_preferences, update_preferences
from ux_heuristic_compass.usability import _interview_validity_check, run_usability_test


def complete_ratings(platform: str = "desktop", profiles: list[str] | None = None, issue_ids: dict[str, int] | None = None) -> list[dict[str, object]]:
    issue_ids = issue_ids or {}
    ratings = []
    for item in get_active_checklist_items(platform, profiles=profiles):
        score = issue_ids.get(item["id"], 0)
        ratings.append(
            {
                "checklist_item_id": item["id"],
                "rating": score,
                "evidence_refs": ["img-1"],
                "rationale": "Fixture issue." if score else "No visible issue in fixture.",
                "confidence": "high" if score >= 3 else "medium",
            }
        )
    return ratings


def screenshot_source(tmp_path: Path, viewport: str = "desktop") -> dict[str, object]:
    screenshot = tmp_path / f"{viewport}-home.png"
    screenshot.write_bytes(b"fake png fixture")
    return prepare_ux_source(str(screenshot), viewport=viewport, state_labels=["home"])


def test_rubric_has_14_heuristics_204_items_correct_h7_h9_and_no_source_specific_h14() -> None:
    rubric = list_heuristics()
    assert rubric["counts"]["heuristics"] == 14
    assert rubric["counts"]["core_items_desktop"] == 79
    assert rubric["counts"]["core_items_mobile"] == 79
    assert rubric["counts"]["optional_items_desktop"] == 23
    assert rubric["counts"]["optional_items_mobile"] == 23
    assert rubric["counts"]["dual_platform_all_items"] == 204
    assert rubric["detail_level"] == "summary"
    assert rubric["optional_profiles"]["ux_writing"]["heuristic_id"] == "h14"
    assert "checklist_items_desktop" not in rubric["heuristics"][0]
    full_rubric = list_heuristics(detail_level="full")
    h7 = next(item for item in full_rubric["heuristics"] if item["id"] == "h07")
    assert len(h7["checklist_items_desktop"]) == 9
    assert len(h7["checklist_items_mobile"]) == 9
    assert [item["text"] for item in h7["checklist_items_desktop"]] == [item["text"] for item in h7["checklist_items_mobile"]]
    h9 = next(item for item in full_rubric["heuristics"] if item["id"] == "h09")
    assert [item["id"] for item in h9["checklist_items_desktop"]] == ["h09_d_01", "h09_d_02"]
    assert [item["id"] for item in h9["checklist_items_mobile"]] == ["h09_m_01", "h09_m_02"]
    assert "Error messages should be expressed in plain language" not in str(h9["checklist_items_desktop"])
    h14 = next(item for item in full_rubric["heuristics"] if item["id"] == "h14")
    assert "current product" in str(h14)
    assert "current product" in h14["description"]
    assert all(item["source"] == "authored_mobile_v1" for item in h14["checklist_items_mobile"])


def test_h9_legacy_aliases_and_deprecated_description_do_not_affect_scores() -> None:
    ratings = complete_ratings("desktop")
    ratings = [row for row in ratings if row["checklist_item_id"] not in {"h09_d_01", "h09_d_02"}]
    ratings.extend(
        [
            {
                "checklist_item_id": "h09_d_01",
                "checklist_text": "Error messages should be expressed in plain language",
                "rating": 4,
                "evidence_refs": ["legacy"],
            },
            {
                "checklist_item_id": "h09_d_02",
                "checklist_text": "The site uses a customised 404 page, which includes tips on how to find the missing page and links to Home and Search",
                "rating": 3,
                "evidence_refs": ["legacy"],
            },
            {
                "checklist_item_id": "h09_d_03",
                "checklist_text": "Error messages contain clear instructions on what to do next, including form error states",
                "rating": 2,
                "evidence_refs": ["legacy"],
            },
        ]
    )
    score = score_checklist_ratings(ratings, platform="desktop")
    h9_rows = [row for row in score["checklist_ratings"] if row["heuristic_id"] == "h09"]
    assert score["score_status"] == "scored"
    assert [row["checklist_item_id"] for row in h9_rows] == ["h09_d_01", "h09_d_02"]
    assert [row["rating"] for row in h9_rows] == [3, 2]
    assert score["deprecated_checklist_item_ids"][0]["checklist_item_id"] == "h09_d_01"


def test_profile_normalization_rejects_donor_conversion() -> None:
    accepted, rejected = normalize_profiles(["accessibility", "donor", "conversion", "content_strategy", "h13", "cx", "empathy", "ux_content"])
    assert accepted == ["accessibility", "ux_writing", "journey", "inclusion"]
    assert rejected == ["donor", "conversion"]


def test_scoring_grade_inversion_and_optional_expanded_grade() -> None:
    assert grade_for_percentage(100)["letter_grade"] == "A++"
    assert grade_for_percentage(0)["letter_grade"] == "F"
    ratings = complete_ratings("desktop", profiles=["accessibility"], issue_ids={"h01_d_01": 4, "h11_d_01": 2})
    score = score_checklist_ratings(ratings, platform="desktop", profiles=["accessibility"])
    assert score["score_status"] == "scored"
    assert score["core_quality_percentage"] < 100
    assert score["expanded_quality_percentage"] is not None
    assert any(row["heuristic_id"] == "h11" for row in score["optional_profile_scores"])


def test_prepare_screenshot_source(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setattr("ux_heuristic_compass.source._external_automation_processes", lambda profile_dir=None: ["123 /usr/bin/node claude-playwright --remote-debugging-port=9222"])
    result = screenshot_source(tmp_path, viewport="mobile")
    assert result["status"] == "ready"
    assert result["items"][0]["source_type"] == "screenshot"
    assert result["items"][0]["viewport"]["device_class"] == "mobile"
    assert result["evidence_refs"][0]["evidence_ref"] == "img-1"
    assert result["browser_handoff"]["ownership_scope"] == "uxhc_temp_profile_only"
    assert result["browser_handoff"]["external_automation_detected"]
    assert result["browser_handoff"]["external_automation_blocking"] is False


def test_prepare_url_source_is_bounded_and_partial() -> None:
    result = prepare_ux_source(
        [
            "https://example.com/a",
            "https://example.com/b",
            "https://example.com/c",
            "https://example.com/d",
        ],
        max_pages=8,
        render_wait_ms="3000",
    )
    assert result["status"] == "partial"
    assert len(result["items"]) == 3
    assert result["capture_policy"]["browser_capture_performed"] is False
    assert result["capture_policy"]["requested_max_pages"] == 8
    assert result["capture_policy"]["effective_max_pages"] == 3
    assert result["capture_policy"]["render_wait_ms"] == 3000
    assert any(warning["code"] == "max_pages_capped" for warning in result["warnings"])
    assert any(warning["code"] == "url_limit_applied" for warning in result["warnings"])


def test_bounded_url_capture_prepares_screenshot_and_handoff(tmp_path: Path) -> None:
    site_root = tmp_path / "site"
    site_root.mkdir()
    (site_root / "index.html").write_text(
        """
        <!doctype html>
        <html>
          <head><title>Fixture Page</title></head>
          <body>
            <h1>Fixture UX Surface</h1>
            <button>Start assessment</button>
          </body>
        </html>
        """,
        encoding="utf-8",
    )

    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            return

    previous_cwd = os.getcwd()
    os.chdir(site_root)
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), QuietHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        url = f"http://127.0.0.1:{server.server_port}/index.html"
        result = prepare_ux_source(
            [url],
            capture_urls=True,
            output_dir=str(tmp_path / "captures"),
            task_flow="Open fixture home page",
        )
    finally:
        server.shutdown()
        thread.join(timeout=5)
        os.chdir(previous_cwd)

    item = result["items"][0]
    assert result["status"] == "ready"
    assert result["capture_policy"]["full_site_crawling"] is False
    assert result["capture_policy"]["authenticated_flows"] is False
    assert result["capture_policy"]["autonomous_browser_agent"] is False
    assert result["browser_handoff"]["status"] == "verified"
    assert result["browser_handoff"]["automation_processes_remaining"] == []
    assert result["browser_handoff"]["ownership_scope"] == "uxhc_temp_profile_only"
    assert "must not be killed" in result["browser_handoff"]["external_automation_policy"]
    assert item["page_title"] == "Fixture Page"
    assert "Fixture UX Surface" in item["visible_text_summary"]
    assert item["screenshot_path"] and Path(item["screenshot_path"]).exists()


def test_bounded_url_capture_warns_on_loading_state(tmp_path: Path) -> None:
    site_root = tmp_path / "spa"
    site_root.mkdir()
    (site_root / "index.html").write_text(
        "<!doctype html><html><head><title>Loading | Fixture</title></head><body><app-root>Loading...</app-root></body></html>",
        encoding="utf-8",
    )

    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            return

    previous_cwd = os.getcwd()
    os.chdir(site_root)
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), QuietHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        result = prepare_ux_source(
            [f"http://127.0.0.1:{server.server_port}/index.html"],
            capture_urls=True,
            output_dir=str(tmp_path / "spa-captures"),
        )
    finally:
        server.shutdown()
        thread.join(timeout=5)
        os.chdir(previous_cwd)

    warnings = result["items"][0]["warnings"]
    assert any(warning["code"] == "client_rendered_or_loading_state" for warning in warnings)


def test_audit_without_checklist_ratings_returns_contract_not_score(tmp_path: Path) -> None:
    audit = audit_ux_surface(
        screenshot_source(tmp_path),
        observations=["The primary call to action is hard to find."],
        platform="desktop",
    )
    assert audit["ux_health_snapshot"]["display_state"] == "needs_checklist_ratings"
    assert audit["checklist_rating_contract"]["active_checklist_item_count"] == 79
    assert audit["legacy_observation_findings"]
    assert audit["checklist_ratings"] == []


def test_audit_with_complete_checklist_ratings_scores_and_quick_scan_compacts(tmp_path: Path) -> None:
    ratings = complete_ratings("desktop", issue_ids={"h08_d_02": 3, "h04_d_03": 2})
    audit = audit_ux_surface(screenshot_source(tmp_path), checklist_ratings=ratings, platform="desktop")
    assert audit["ux_health_snapshot"]["display_state"] == "scored"
    assert audit["scorecard"]["score_status"] == "scored"
    assert audit["scorecard"]["core_quality_percentage"] < 100
    assert len(audit["checklist_ratings"]) == 79
    assert audit["findings"][0]["checklist_item_id"] == "h08_d_02"
    assert audit["report_readiness_contract"]["status"] == "ready"
    assert "canonical_payload_template" not in audit["report_readiness_contract"]
    assert audit["report_readiness_contract"]["report_payload_contract"]["accepted_inputs"]
    assert validate_ux_report_payload(audit["report_ready_payload"])["qa_status"] == "ready"
    assert audit["report_payload_ref"]["path"]
    assert audit["plain_language_read"]
    assert audit["before_using_this_interface"].startswith("Before using this interface,")
    assert audit["top_finding"]["checklist_item_id"] == "h08_d_02"
    assert audit["one_recommendation"]
    assert not audit["one_recommendation"].startswith("Address the checklist item:")
    assert audit["follow_up_activity"]["try_this_next"]["source_note"] == "Curated from UX Heuristic Compass."
    assert "prioritization_flow" not in audit
    compact = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=ratings,
        platform="desktop",
        output_detail="compact",
    )
    assert compact["output_detail"] == "compact"
    assert compact["report_payload_ref"]["path"]
    assert compact["large_output_guidance"]["jq_required"] is False
    assert compact["checklist_ratings_omitted"]["count"] == 79
    assert "checklist_ratings" not in compact

    quick = quick_scan_ux(
        screenshot_source(tmp_path),
        checklist_ratings=ratings,
        platform="desktop",
        goal="Check the primary home page task.",
    )
    assert quick["tool"] == "quick_scan_ux"
    assert quick["mode"] == "quick"
    assert quick["hil_gates"] == []
    assert quick["human_loop_host_action"]["PAUSE_REQUIRED"] is False
    assert quick["report_readiness_contract"]["status"] == "ready"
    assert validate_ux_report_payload(quick["report_ready_payload"])["qa_status"] == "ready"
    assert len(quick["top_findings"]) == 2
    assert quick["scorecard"]["score_status"] == "scored"

    alias_audit = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", profiles=["ux_writing"]),
        platform="desktop",
        profiles=["content_strategy"],
    )
    assert alias_audit["profiles"]["accepted"] == ["ux_writing"]
    assert alias_audit["profiles"]["normalized_profiles"][0]["normalized_to"] == "ux_writing"
    assert alias_audit["profiles"]["inactive_optional_profiles"][0]["heuristic_id"] == "h11"


def test_advanced_scope_lock_and_optional_profile_modes(tmp_path: Path) -> None:
    partial = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", profiles=["accessibility"]),
        platform="desktop",
        profiles=["accessibility"],
        full_advanced=True,
    )
    lock = partial["audit_scope_lock"]
    assert lock["status"] == "confirmation_required"
    assert lock["optional_profile_mode"] == "ask"
    omitted_ids = [profile["heuristic_id"] for profile in lock["omitted_optional_profiles"]]
    assert omitted_ids == ["h12", "h13", "h14"]
    assert "all_optionals" in lock["rerun_guidance"]

    all_optionals = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", profiles=["accessibility", "inclusion", "journey", "ux_writing"]),
        platform="desktop",
        profiles=["accessibility"],
        optional_profile_mode="all_optionals",
    )
    assert all_optionals["profiles"]["accepted"] == ["accessibility", "inclusion", "journey", "ux_writing"]
    assert all_optionals["scorecard"]["active_checklist_item_count"] == 102
    assert all_optionals["audit_scope_lock"]["status"] == "all_optionals_active"

    core_only = quick_scan_ux(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop"),
        platform="desktop",
        profiles=["accessibility"],
        optional_profile_mode="core_only",
        goal="Core-only quick check.",
    )
    assert core_only["profiles"]["accepted"] == []
    assert core_only["audit_scope_lock"]["status"] == "core_only"


def test_behavioral_copy_is_generated_not_truncated_checklist_echo(tmp_path: Path) -> None:
    ratings = complete_ratings("desktop", issue_ids={"h08_d_03": 3})
    audit = audit_ux_surface(screenshot_source(tmp_path), checklist_ratings=ratings, platform="desktop")
    assert audit["top_finding"]["title"] == "Page clutter competing with primary actions"
    assert "attention-att" not in audit["top_finding"]["title"]
    assert "attention-att" not in audit["plain_language_read"]
    assert "attention-attracting features" not in audit["plain_language_read"]
    assert audit["plain_language_read"].startswith("The biggest visible usability risk is page clutter")
    assert audit["before_using_this_interface"].startswith("Before using this interface,")
    assert audit["one_recommendation"].startswith("Audit the screen")
    assert "Address the checklist item:" not in audit["one_recommendation"]
    assert audit["reasoning_flow_suggestions"] == []


def test_atlas_reasoning_flow_selection_uses_priority_thresholds(tmp_path: Path) -> None:
    flows = load_flow_library()
    assert flows["ux_flow_task_scenario_design"]["source_entry_id"] == "task-templates:task-scenarios-write"
    assert flows["ux_flow_user_flow_audit"]["source_entry_id"] == "task-templates:user-flow-audit"
    assert flows["ux_flow_transcript_analysis"]["source_entry_id"] == "task-templates:transcripts-analyze"
    assert flows["ux_flow_six_hats_review"]["source_type"] == "authored_uxhc_v1"
    assert load_activity_registry()["ux_activity_empathy_map"]["facilitation_note"] == "Activity source under review - verify before facilitating."

    h11_low = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", profiles=["accessibility"], issue_ids={"h11_d_01": 3, "h11_d_02": 3}),
        profiles=["accessibility"],
        platform="desktop",
    )
    assert h11_low["reasoning_flow_suggestions"][0]["flow_id"] == "ux_flow_accessibility_deeper_dive"

    h3_low = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={"h03_d_02": 4, "h03_d_03": 4}),
        platform="desktop",
    )
    h3_flow_ids = [flow["flow_id"] for flow in h3_low["reasoning_flow_suggestions"]]
    assert h3_flow_ids[:2] == ["ux_flow_inference_ladder_check", "ux_flow_user_flow_audit"]
    assert "ux_flow_how_might_we" in h3_flow_ids
    assert len(h3_flow_ids) <= 3

    h8_low = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={f"h08_d_{idx:02d}": 2 for idx in range(1, 8)}),
        platform="desktop",
    )
    assert [flow["flow_id"] for flow in h8_low["reasoning_flow_suggestions"]] == ["ux_flow_visual_hierarchy"]

    h3_recovery = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={"h03_d_02": 3, "h03_d_03": 2}),
        platform="desktop",
    )
    assert [flow["flow_id"] for flow in h3_recovery["reasoning_flow_suggestions"]] == ["ux_flow_navigation_recovery_walkthrough"]

    overall_c = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={item["id"]: 2 for item in get_active_checklist_items("desktop")}),
        platform="desktop",
    )
    flow_ids = [flow["flow_id"] for flow in overall_c["reasoning_flow_suggestions"]]
    assert "ux_flow_scamper_redesign" in flow_ids
    assert "ux_flow_double_diamond_next_phase" in flow_ids
    assert overall_c["prioritization_flow"]["flow_id"] == "ux_flow_rice_prioritization"
    assert all(flow["knowledge_atlas_enrichment"]["status"] == "imported_static" for flow in overall_c["reasoning_flow_suggestions"])
    assert len(flow_ids) <= 3
    assert len(flow_ids) == len(set(flow_ids))

    b_ratings = [
        {
            "checklist_item_id": item["id"],
            "rating": 1.1,
            "evidence_refs": ["img-1"],
            "rationale": "Moderate fixture issue.",
            "confidence": "medium",
        }
        for item in get_active_checklist_items("desktop")
    ]
    overall_b = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=b_ratings,
        platform="desktop",
        audit_context={"stakeholder_report_requested": True},
    )
    flow_ids = [flow["flow_id"] for flow in overall_b["reasoning_flow_suggestions"]]
    assert "ux_flow_usability_test_brief" in flow_ids
    assert "ux_flow_opportunity_scoring" in flow_ids
    assert len(flow_ids) <= 3

    quick = quick_scan_ux(screenshot_source(tmp_path), checklist_ratings=complete_ratings("desktop", issue_ids={"h03_d_02": 4, "h03_d_03": 4}), platform="desktop")
    assert quick["reasoning_flow_suggestions"] == []


def test_wave_two_three_activity_and_bias_advisories(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("UXHC_STATE_DIR", str(tmp_path / "state"))
    save_preferences(
        user_id="beginner_user",
        ux_level="beginner",
        hil_default="ai_decides",
        agent_default="ask_each_time",
        platform_default="desktop",
        optional_profiles=["inclusion", "journey", "ux_writing"],
    )
    h12 = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings(
                "desktop",
                profiles=["inclusion"],
                issue_ids={"h12_d_01": 4, "h12_d_02": 4},
        ),
        profiles=["inclusion"],
        platform="desktop",
        user_id="beginner_user",
        audit_context={"emotional_design_concern": True, "product_familiarity": True},
    )
    flow_ids = [flow["flow_id"] for flow in h12["reasoning_flow_suggestions"]]
    activity_ids = [activity["activity_id"] for activity in h12["follow_up_activity_extended"]]
    advisory_ids = [advisory["bias_id"] for advisory in h12["evaluator_bias_advisories"]]
    assert "ux_flow_empathy_mapping" in flow_ids
    assert "ux_flow_kansei_emotion_mapping" in flow_ids
    assert "ux_activity_empathy_map" in activity_ids
    assert "uxhc_bias_08" in advisory_ids
    assert "uxhc_bias_10" in advisory_ids

    h4_gradient = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={f"h04_d_{idx:02d}": 3 for idx in range(1, 8)}),
        platform="desktop",
    )
    assert "uxhc_bias_07" in [advisory["bias_id"] for advisory in h4_gradient["evaluator_bias_advisories"]]

    halo = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={"h03_d_02": 1}),
        platform="desktop",
    )
    assert "uxhc_bias_09" in [advisory["bias_id"] for advisory in halo["evaluator_bias_advisories"]]


def test_hil_gates_and_onboarding_contracts(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("UXHC_STATE_DIR", str(tmp_path / "state"))
    first_start = get_started(user_id="new_user")
    assert first_start["onboarding_required"] is True
    assert first_start["onboarding"]["next_tool"] == "save_preferences"

    missing = audit_ux_surface(screenshot_source(tmp_path), platform="desktop", hil_enabled=True, user_id="new_user")
    assert missing["onboarding"]["onboarding_status"] == "required"
    assert [gate["gate_id"] for gate in missing["hil_gates"]] == ["hil_gate_collect_ratings"]
    assert missing["human_loop_host_action"]["PAUSE_REQUIRED"] is True
    assert missing["human_loop_host_action"]["stage"] == "pre_audit"
    assert len(missing["human_loop_host_action"]["questions_for_user"]) == 3
    assert "AskUserQuestion" in missing["human_loop_host_action"]["host_instruction"]
    assert missing["human_loop_host_action"]["ask_user_question_call"]["tool_name"] == "AskUserQuestion"
    assert missing["human_loop_host_action"]["HIL_BLOCKED_UNTIL_NATIVE_UI"] is True
    assert missing["hil_compliance"]["host_question_ui_status"] == "unknown"
    assert missing["HIL_BLOCKED_UNTIL_NATIVE_UI"] is True
    assert missing["human_loop_host_action"]["cadence_contract"]["advanced_audit"][0]["question_count"] == 3

    native_missing = audit_ux_surface(
        screenshot_source(tmp_path),
        platform="desktop",
        hil_enabled=True,
        user_id="new_user",
        host_question_ui_status="native_rendered",
    )
    assert native_missing["human_loop_host_action"]["HIL_BLOCKED_UNTIL_NATIVE_UI"] is False
    assert native_missing["hil_compliance"]["native_ui_confirmed"] is True

    resolved_missing = audit_ux_surface(
        screenshot_source(tmp_path),
        platform="desktop",
        hil_enabled=True,
        user_id="new_user",
        resolved_gate_ids=["hil_gate_collect_ratings"],
        host_question_ui_status="native_rendered",
    )
    assert resolved_missing["human_loop_host_action"]["PAUSE_REQUIRED"] is False
    assert resolved_missing["resolved_gates"][0]["gate_id"] == "hil_gate_collect_ratings"
    assert resolved_missing["unresolved_gates"] == []
    assert resolved_missing["HIL_BLOCKED_UNTIL_NATIVE_UI"] is False

    save_preferences(
        user_id="new_user",
        ux_level="practitioner",
        hil_default="enabled",
        agent_default="ask_each_time",
        platform_default="desktop",
        optional_profiles=[],
    )
    saved_start = get_started(user_id="new_user")
    assert saved_start["onboarding_required"] is False
    assert saved_start["onboarding"]["preferences_summary"]["ux_level"] == "practitioner"

    scored = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={f"h04_d_{idx:02d}": 4 for idx in range(1, 10)}),
        platform="desktop",
        hil_enabled=True,
        user_id="new_user",
    )
    gate_ids = [gate["gate_id"] for gate in scored["hil_gates"]]
    assert "hil_gate_final_review" in gate_ids
    assert any(gate["trigger"] == "below_threshold" and gate["heuristics_in_scope"] == ["h04"] for gate in scored["hil_gates"])
    assert scored["human_loop_host_action"]["PAUSE_REQUIRED"] is True
    assert scored["human_loop_host_action"]["stage"] == "mid_audit"
    assert len(scored["human_loop_host_action"]["questions_for_user"]) == 3
    assert scored["human_loop_host_action"]["current_gate"]["gate_id"] == "hil_gate_batched_below_threshold"
    assert scored["reasoning_flow_suggestions"][0]["source"] in {"knowledge_atlas_adapted", "authored_uxhc_v1"}
    assert scored["reasoning_flow_suggestions"][0]["knowledge_atlas_enrichment"]["status"] == "imported_static"

    resolved_mid = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={f"h04_d_{idx:02d}": 4 for idx in range(1, 10)}),
        platform="desktop",
        hil_enabled=True,
        user_id="new_user",
        resolved_gate_ids=["hil_gate_batched_below_threshold", "hil_gate_final_review"],
        host_question_ui_status="native_rendered",
    )
    assert resolved_mid["human_loop_host_action"]["PAUSE_REQUIRED"] is False
    assert resolved_mid["unresolved_gates"] == []

    final_only = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={"h08_d_02": 1}),
        platform="desktop",
        hil_enabled=True,
        user_id="new_user",
    )
    assert final_only["human_loop_host_action"]["stage"] == "final_review"
    assert len(final_only["human_loop_host_action"]["questions_for_user"]) == 3

    quick_missing = quick_scan_ux(screenshot_source(tmp_path), platform="desktop")
    assert quick_missing["human_loop_host_action"]["PAUSE_REQUIRED"] is True
    assert quick_missing["human_loop_host_action"]["stage"] == "pre_audit"
    assert len(quick_missing["human_loop_host_action"]["questions_for_user"]) == 3
    assert quick_missing["human_loop_host_action"]["ask_user_question_call"]["tool_name"] == "AskUserQuestion"
    quick_resolved = quick_scan_ux(
        screenshot_source(tmp_path),
        platform="desktop",
        resolved_gate_ids=["quick_context_check"],
        host_question_ui_status="native_rendered",
    )
    assert quick_resolved["human_loop_host_action"]["PAUSE_REQUIRED"] is False
    assert quick_resolved["resolved_gates"][0]["gate_id"] == "quick_context_check"

    quick_context_ready = quick_scan_ux(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop"),
        platform="desktop",
        goal="Check whether the home page makes the primary action clear.",
    )
    assert quick_context_ready["human_loop_host_action"]["PAUSE_REQUIRED"] is False


def test_report_validation_blocks_unscored_and_generates_checklist_report(tmp_path: Path) -> None:
    blocked = audit_ux_surface(screenshot_source(tmp_path), platform="desktop")
    blocked_validation = validate_ux_report_payload(blocked)
    assert blocked_validation["qa_status"] == "blocked"
    assert "checklist_ratings" in blocked_validation["missing_report_fields"]

    ratings = complete_ratings("desktop", issue_ids={"h08_d_02": 3})
    audit = audit_ux_surface(screenshot_source(tmp_path), checklist_ratings=ratings, platform="desktop")
    missing_behavior = dict(audit)
    missing_behavior.pop("plain_language_read")
    assert validate_ux_report_payload(missing_behavior)["qa_status"] == "blocked"
    invalid_prefix = {**audit, "before_using_this_interface": "Use this interface after fixing H8."}
    invalid_validation = validate_ux_report_payload(invalid_prefix)
    assert invalid_validation["qa_status"] == "blocked"
    assert "before_using_this_interface.prefix" in invalid_validation["missing_report_fields"]
    output = tmp_path / "report.md"
    result = generate_ux_audit_report(audit, output_path=str(output), include_pdf=True, report_title="Fixture UX Audit")
    assert result["qa_status"] in {"ready", "ready_with_warnings"}
    assert result["pdf_rendering"]["requested"] is True
    assert result["pdf_rendering"]["renderer"]
    path_result = generate_ux_audit_report(payload_path=audit["report_payload_ref"]["path"], output_path=str(tmp_path / "report-from-path.md"))
    assert path_result["qa_status"] == "ready"
    assert output.exists()
    assert result["viewer_path"] and Path(result["viewer_path"]).exists()
    assert result["pdf_path"] and Path(result["pdf_path"]).exists()
    text = output.read_text(encoding="utf-8")
    assert "Core grade:" in text
    assert "Plain-language read:" in text
    assert "Before using this interface:" in text
    assert "Follow-Up Activity" in text
    assert "Checklist Issue Ledger" in text
    assert "Complete Checklist Scores" in text
    assert "Audit Scope and Omitted Profiles" in text
    assert "Evidence Appendix" in text
    assert "<details>" in text
    assert "h08_d_02" in text
    viewer = Path(result["viewer_path"]).read_text(encoding="utf-8")
    assert 'data-filter="all"' in viewer
    assert "filterChecklist('major')" in viewer
    assert "Evidence Appendix" in viewer

    overridden_ratings = complete_ratings("desktop", issue_ids={"h08_d_02": 3})
    for row in overridden_ratings:
        if row["checklist_item_id"] == "h08_d_02":
            row["finding_title"] = "Host supplied primary-action title"
            row["recommendation"] = "Move the primary action above competing navigation and keep the label task-focused."
    overridden = audit_ux_surface(screenshot_source(tmp_path), checklist_ratings=overridden_ratings, platform="desktop")
    assert overridden["top_finding"]["title"] == "Host supplied primary-action title"
    assert overridden["one_recommendation"].startswith("Move the primary action")


def test_pdf_fallback_reports_warning(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("UXHC_FORCE_MINIMAL_PDF", "1")
    audit = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={"h08_d_02": 3}),
        platform="desktop",
    )
    result = generate_ux_audit_report(audit, output_path=str(tmp_path / "fallback.md"), include_pdf=True)
    assert result["qa_status"] == "ready_with_warnings"
    assert result["pdf_rendering"]["renderer"] == "minimal_pdf_fallback"
    assert result["pdf_rendering"]["fallback_used"] is True
    assert Path(result["pdf_path"]).exists()


def test_core_audit_first_output_order_and_drift_guardrails(tmp_path: Path) -> None:
    audit = audit_ux_surface(
        screenshot_source(tmp_path),
        checklist_ratings=complete_ratings("desktop", issue_ids={"h08_d_02": 3}),
        platform="desktop",
    )
    keys = list(audit.keys())
    assert keys.index("scorecard") < keys.index("reasoning_flow_suggestions")
    assert keys.index("top_finding") < keys.index("follow_up_activity")
    assert keys.index("plain_language_read") < keys.index("follow_up_activity_extended")
    assert keys.index("one_recommendation") < keys.index("reasoning_flow_suggestions")

    readme = Path("README.md").read_text(encoding="utf-8")
    charter = Path("docs/planning/mission-audience-purpose-charter.md").read_text(encoding="utf-8")
    prd = Path("docs/planning/master-prd.md").read_text(encoding="utf-8")
    docs = "\n".join([readme, charter, prd])
    assert "Core Audit First" in docs
    assert "audit-support intelligence" in docs
    assert "complete heuristic scorecard" in docs
    assert "full-site crawling" in docs
    assert "autonomous browser-agent navigation" in docs

    runtime_text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in [
            Path("ux_heuristic_compass/audit.py"),
            Path("ux_heuristic_compass/behavior.py"),
            Path("ux_heuristic_compass/agents.py"),
            Path("ux_heuristic_compass/usability.py"),
        ]
    )
    assert "steelman" not in runtime_text.lower()
    assert "Critical Compass" not in runtime_text
    assert "Oppia" not in runtime_text


def test_implementation_inspection_lane_is_optional_and_advisory(tmp_path: Path) -> None:
    source = screenshot_source(tmp_path)
    ratings = complete_ratings("desktop", issue_ids={"h08_d_02": 3})
    baseline = audit_ux_surface(source, checklist_ratings=ratings, platform="desktop")
    audit = audit_ux_surface(
        source,
        checklist_ratings=ratings,
        platform="desktop",
        audit_context={
            "implementation_inspection_requested": True,
            "ai_coding_harness": "Codex CLI",
            "implementation_evidence": [
                {
                    "source": "manual harness review",
                    "issue": "Fixed width mobile layout overflows, keyboard focus is unclear, hard-coded theme values are used, and decorative gradients compete with the primary action.",
                }
            ],
            "external_audit_results": {
                "tool": "optional frontend audit",
                "findings": ["ARIA/focus concern", "dark mode token drift", "button label truncation"],
            },
        },
    )
    contract = audit["implementation_inspection_contract"]
    summary = audit["implementation_evidence_summary"]
    assert contract["route_id"] == "implementation_aware_inspection"
    assert contract["ai_coding_harness"] == "Codex CLI"
    assert contract["support_flow"]["flow_id"] == "ux_flow_frontend_implementation_inspection"
    assert contract["external_result_policy"]["trusted_for_scoring"] is False
    assert "Do not install, run, or vendor third-party audit tools from inside UXHC." in contract["must_not"]
    assert summary["status"] == "evidence_received"
    assert {"h04", "h08", "h11"}.issubset(set(summary["likely_affected_heuristics"]))
    assert audit["scorecard"]["overall_quality_percentage"] == baseline["scorecard"]["overall_quality_percentage"]

    quick = quick_scan_ux(
        source,
        checklist_ratings=ratings,
        platform="desktop",
        audit_context={"codebase_available": True, "ai_coding_harness": "Cursor"},
    )
    assert quick["implementation_inspection_contract"]["route_id"] == "implementation_aware_inspection"
    assert quick["implementation_inspection_contract"]["ai_coding_harness"] == "Cursor"
    assert quick["reasoning_flow_suggestions"] == []

    output = tmp_path / "implementation-lane-report.md"
    report = generate_ux_audit_report(audit, output_path=str(output), include_pdf=False)
    assert report["qa_status"] == "ready"
    text = output.read_text(encoding="utf-8")
    assert "Implementation-Aware Inspection" in text
    assert "Likely affected heuristics:" in text
    assert "does not change checklist ratings" in text

    flows = load_flow_library()
    assert flows["ux_flow_frontend_implementation_inspection"]["source_type"] == "authored_uxhc_v1"

    started = get_started()
    assert "implementation_inspection" in started["behavioral_contracts"]


def test_preferences_complete_partial_and_update(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("UXHC_STATE_DIR", str(tmp_path / "state"))
    partial = save_preferences(ux_level="beginner")
    assert partial["status"] == "incomplete"
    assert load_preferences() is None

    saved = save_preferences(
        ux_level="practitioner",
        hil_default="ai_decides",
        agent_default="ask_each_time",
        platform_default="desktop",
        optional_profiles=["accessibility", "ux_writing"],
    )
    assert saved["status"] == "saved"
    assert load_preferences()["ux_level"] == "practitioner"
    updated = update_preferences(ux_level="expert")
    assert updated["updated"] is True
    assert load_preferences()["ux_level"] == "expert"
    assert load_preferences()["optional_profiles"] == ["accessibility", "ux_writing"]


def test_agent_mode_1_persists_retrieves_and_flags_disagreement(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("UXHC_STATE_DIR", str(tmp_path / "state"))
    ratings_a = complete_ratings("desktop", profiles=["accessibility"])
    ratings_b = complete_ratings("desktop", profiles=["accessibility"], issue_ids={"h11_d_02": 4})
    ratings_c = complete_ratings("desktop", profiles=["accessibility"], issue_ids={"h11_d_02": 2})
    missing = run_agent_audit(platform="desktop", profiles=["accessibility"])
    assert missing["status"] == "agent_run_contract_ready"
    assert missing["user_facing_mode_name"] == "Researcher persona scorecard aggregation"
    assert missing["execution_mode"] == "host_ai_executes"
    assert missing["autonomous_execution"] is False
    assert missing["agent_frame_suggestion"]["flow_id"] == "ux_flow_six_hats_review"
    assert missing["agent_scorecard_contract"]["personas_input_contract"]["example_personas"][0]["agent_id"] == "agent_a"
    invalid = run_agent_audit(platform="desktop", personas=["researcher one"])
    assert invalid["status"] == "invalid_personas"
    assert invalid["error"] == "personas_must_be_dictionaries"
    result = run_agent_audit(
        platform="desktop",
        profiles=["accessibility"],
        per_agent_scorecards=[
            {"agent_id": "agent_a", "checklist_ratings": ratings_a},
            {"agent_id": "agent_b", "checklist_ratings": ratings_b},
            {"agent_id": "agent_c", "checklist_ratings": ratings_c},
        ],
    )
    assert result["status"] == "ready"
    assert result["user_facing_mode_name"] == "Researcher persona scorecard aggregation"
    assert result["persisted"] is True
    assert result["agent_run"]["averaged_scorecard"]["score_status"] == "scored"
    assert result["agent_run"]["disagreement_flags"][0]["checklist_item_id"] == "h11_d_02"
    assert result["agent_run"]["disagreement_flags"][0]["delta"] == 4
    assert [flag["bias_id"] for flag in result["agent_run"]["disagreement_flags"][0]["bias_context"]] == ["uxhc_bias_02", "uxhc_bias_01"]
    assert result["agent_frame_suggestion"]["flow_id"] == "ux_flow_six_hats_review"
    retrieved = get_agent_run(result["agent_run_id"])
    assert retrieved["status"] == "ready"
    assert get_agent_run("missing")["error"] == "run_not_found"
    assert get_agent_run("../bad")["error"] == "invalid_agent_run_id"


def test_usability_mode_blocks_unsafe_scope_and_returns_bounded_contract(tmp_path: Path) -> None:
    blocked = run_usability_test(
        target_audience="parents",
        task_scope="login and crawl all pages",
        source_or_url="https://example.com",
        safety_policy={},
    )
    assert blocked["status"] == "blocked"
    source = screenshot_source(tmp_path)
    result = run_usability_test(
        target_audience="parents of middle-school students",
        task_scope="Review the home page",
        prepared_source=source,
        platform="desktop",
    )
    assert result["status"] == "ready"
    assert result["user_facing_mode_name"] == "Bounded usability-test prep/synthetic walkthrough support"
    assert result["evidence_level"] == "synthetic_walkthrough_or_evidence_prep_unless_real_participant_logs_supplied"
    assert len(result["persona_runs"]) == 3
    assert result["navigation_vehicle"] in {"multimodal_screenshot_fallback", "system_chrome_capture", "playwright_system_chrome"}
    assert result["interview_validity_check"]["flag_label"] == "self_report_discrepancy"
    assert result["reasoning_flow_suggestions"][0]["flow_id"] == "ux_flow_transcript_analysis"
    assert result["reasoning_flow_suggestions"][0]["knowledge_atlas_enrichment"]["source_entry_id"] == "task-templates:transcripts-analyze"
    discrepant = _interview_validity_check(
        [
            {
                "agent_id": "audience_a",
                "think_aloud": [{"observation": "I am stuck and frustrated.", "outcome": "failed"}],
                "task_attempts": [{"outcome": "failed"}, {"outcome": "abandoned"}],
                "interview": {"overall_satisfaction_1_to_5": 5},
            }
        ]
    )
    assert discrepant["flags"][0]["flag_label"] == "self_report_discrepancy"


def test_compare_ux_audits_prefers_checklist_item_ids(tmp_path: Path) -> None:
    source = screenshot_source(tmp_path)
    baseline = audit_ux_surface(source, checklist_ratings=complete_ratings("desktop", issue_ids={"h08_d_02": 3, "h04_d_03": 2}), platform="desktop")
    candidate = audit_ux_surface(source, checklist_ratings=complete_ratings("desktop", issue_ids={"h04_d_03": 2, "h09_d_02": 3}), platform="desktop")
    comparison = compare_ux_audits(baseline, candidate)
    assert comparison["matching_strategy"] == "checklist_item_id"
    assert comparison["summary"]["fixed_count"] == 1
    assert comparison["summary"]["new_count"] == 1
    assert comparison["summary"]["unresolved_count"] == 1


def test_calibration_canonical_and_alias() -> None:
    canonical = calibrate_ux_sensitivity()
    alias = calibrate_ux_severity()
    assert canonical["tool"] == "calibrate_ux_sensitivity"
    assert alias["tool"] == "calibrate_ux_severity"
    assert alias["canonical_tool"] == "calibrate_ux_sensitivity"
    assert canonical["calibration_status"] == "passed"


def test_project_addon_scaffold_is_opt_in_and_blocks_donor_conversion_terms() -> None:
    addon = draft_project_addon_profile(
        project_name="Example Product",
        product_type="local UX audit tool",
        audience="startup product managers",
        tasks=["prepare a screenshot audit", "share the report with a stakeholder"],
        constraints=["local-first evidence handling"],
        competitive_references=["reference pattern supplied by the reviewer"],
    )
    assert addon["status"] == "ready"
    assert addon["baseline_health_impact"] == "none"
    assert addon["scoring_policy"]["separate_from_core_he_health"] is True

    blocked = draft_project_addon_profile(
        project_name="Donation Flow",
        audience="donor prospects",
        tasks=["increase conversion"],
    )
    assert blocked["status"] == "blocked"
    assert "donor" in blocked["blocked_terms"]


def test_stress_test_heuristic_finding_is_ux_native() -> None:
    result = stress_test_heuristic_finding(
        checklist_item_id="h08_d_02",
        rating=3,
        rationale="Primary action is hard to find in the fixture.",
        platform="desktop",
        evidence_refs=["img-1"],
    )
    assert result["status"] == "ready"
    assert result["related_heuristic"]["heuristic_id"] == "h08"
    assert "alternative_explanation" in result
    assert "false_positive_check" in result
    assert "why_it_likely_matters" in result
    assert "one_concrete_fix" in result
    assert [flag["bias_id"] for flag in result["bias_flags"]] == ["uxhc_bias_01", "uxhc_bias_02"]
    assert result["reasoning_flow_suggestions"][0]["flow_id"] == "ux_flow_inference_ladder_check"

    no_evidence = stress_test_heuristic_finding(
        checklist_item_id="h08_d_02",
        rating=4,
        rationale="Primary action appears unavailable.",
        platform="desktop",
    )
    assert [flag["bias_id"] for flag in no_evidence["bias_flags"]] == ["uxhc_bias_01", "uxhc_bias_02", "uxhc_bias_03"]

    low_severity = stress_test_heuristic_finding(
        checklist_item_id="h08_d_02",
        rating=2,
        rationale="Primary action could be clearer.",
        platform="desktop",
        evidence_refs=["img-1"],
    )
    assert "bias_flags" not in low_severity


def test_self_test_reports_full_local_mcp_launch_status() -> None:
    result = _self_test()
    assert result["tool_count"] == 18
    assert result["rubric_heuristic_count"] == 14
    assert result["dual_platform_all_items"] == 204
    assert result["audit_display_state"] == "scored"
    assert result["validation_status"] == "ready"
    assert result["preferences_status"] == "saved"
    assert result["agent_status"] == "ready"
    assert result["agent_retrieval_status"] == "ready"
    assert result["stress_test_status"] == "ready"
